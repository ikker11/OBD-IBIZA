package com.ikker.obdibiza

import android.app.Application
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Conn { DESCONECTADO, CONECTANDO, CONECTADO }

/**
 * Un reloj colocado en una página: dato, posición del centro (fracción del ancho y del alto
 * de la zona de relojes) y diámetro (fracción del alto).
 */
data class GaugeItem(val id: String, val x: Float, val y: Float, val size: Float)

/** Disposición inicial: dos relojes laterales y uno grande en el centro. */
fun defaultLayout(ids: List<String>): List<GaugeItem> = listOf(
    GaugeItem(ids[0], 0.17f, 0.5f, 0.70f),
    GaugeItem(ids[1], 0.5f, 0.5f, 0.84f),
    GaugeItem(ids[2], 0.83f, 0.5f, 0.70f),
)

/** Ordenador de viaje: se calcula integrando la velocidad (y el consumo, si el coche lo da). */
data class Trip(
    val startMs: Long = System.currentTimeMillis(),
    val distanceKm: Double = 0.0,
    val movingSeconds: Double = 0.0,
    val maxSpeed: Double = 0.0,
    val fuelLitres: Double? = null,
) {
    val avgSpeed: Double? get() = if (movingSeconds > 10) distanceKm / (movingSeconds / 3600) else null
    val avgConsumption: Double? get() = fuelLitres?.let { f -> if (distanceKm > 0.5) f / distanceKm * 100 else null }
}

enum class AccelMode(val title: String, val from: Double, val to: Double) {
    ZERO_100("0 – 100 km/h", 0.0, 100.0),
    ZERO_60("0 – 60 km/h", 0.0, 60.0),
    MID_80_120("80 – 120 km/h", 80.0, 120.0),
}

enum class AccelState { PARADO, PREPARADO, MIDIENDO, HECHO }

/** Cronómetro de aceleración. Los tiempos de cruce se interpolan entre lecturas para afinar. */
data class Accel(
    val mode: AccelMode = AccelMode.ZERO_100,
    val state: AccelState = AccelState.PARADO,
    val startMs: Long = 0,
    val resultS: Double? = null,
    val best: Map<AccelMode, Double> = emptyMap(),
)

/** Posible identificador de temperatura de aceite encontrado al rastrear la centralita. */
data class OilCandidate(val did: Int, val formula: Int, val value: Double)

data class UiState(
    val conn: Conn = Conn.DESCONECTADO,
    val status: String = "Enchufa el cable OBD y pulsa Conectar",
    val adapter: String = "",
    val protocol: String = "",
    val vin: String = "",
    val supportedPids: Set<Int> = emptySet(),
    val values: Map<String, Double> = emptyMap(),
    val peaks: Map<String, Double> = emptyMap(),
    val mil: Boolean? = null,
    val dtcCount: Int? = null,
    val dtcs: List<String>? = null,
    val pendingDtcs: List<String>? = null,
    val permanentDtcs: List<String>? = null,
    val dtcBusy: Boolean = false,
    val dtcMessage: String = "",
    val log: List<String> = emptyList(),
    val dashboard: List<String> = Params.defaultDashboard,
    val columns: Int = 3,
    val refreshHz: Double = 0.0,
    val traffic: Boolean = false,
    val demo: Boolean = false,
    /** Reloj grande principal, valor del centro y segundo reloj. */
    /** Páginas del panel: cada una con 3 relojes (izquierda, centro, derecha). */
    val pages: List<List<GaugeItem>> = Params.defaultPages.map { defaultLayout(it) },
    val pageNames: List<String> = Params.defaultPageNames,
    /** Imagen elegida por el usuario para el reloj principal (null = ninguna). */
    val logo: androidx.compose.ui.graphics.ImageBitmap? = null,
    val page: Int = 0,
    val ringMain: String = "rpm",
    val ringCenter: String = "speed",
    val ringSecond: String = Params.BOOST,
    val ringThird: String = "oil",
    /** De dónde sale la temperatura del aceite ("" = no encontrada). */
    val oilSource: String = "",
    val oilCustomDid: String = "",
    val oilCustomFormula: Int = 0,
    val oilTestMessage: String = "",
    /** Rastreo de identificadores: progreso 0..1 (null = parado) y candidatos encontrados. */
    val oilScanProgress: Float? = null,
    val oilCandidates: List<OilCandidate> = emptyList(),
    /** Datos que pide la pantalla abierta (gráficas, barras…), además de la página de relojes. */
    val focus: List<String> = emptyList(),
    val trip: Trip = Trip(),
    val accel: Accel = Accel(),
    /** Revoluciones a las que se encienden del todo las luces de cambio. */
    val shiftRpm: Int = 4000,
    /** Últimos valores de cada dato para las mini-gráficas. */
    val history: Map<String, List<Float>> = emptyMap(),
) {
    /** Todo lo que se ve en el panel y por tanto se lee en cada vuelta. */
    val live: List<String> get() = ((pages.getOrNull(page)?.map { it.id } ?: emptyList()) + focus + "speed").distinct()
}

class ObdViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    private val usb = app.getSystemService(Context.USB_SERVICE) as UsbManager
    private val prefs = app.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
    private var elm: Elm327? = null
    private var pollJob: Job? = null
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                ACTION_PERMISSION -> {
                    if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) tryConnect(quiet = false)
                    else setStatus("Permiso USB denegado. Vuelve a pulsar Conectar y acepta.")
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    if (elm != null) disconnect("Cable OBD desenchufado")
                }
            }
        }
    }

    init {
        val f = IntentFilter().apply {
            addAction(ACTION_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(app, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        val saved = prefs.getString("widgets", null)
            ?.split(",")?.filter { it in Params.byId }
            ?.takeIf { it.isNotEmpty() }
        _state.update {
            it.copy(
                dashboard = saved ?: Params.defaultDashboard,
                columns = prefs.getInt("columnas", 3),
                pages = loadPages(),
                pageNames = prefs.getString("pageNames", null)?.split("|") ?: Params.defaultPageNames,
                logo = loadLogo(),
                ringMain = prefs.getString("ringMain", null)?.takeIf { id -> id in Params.byId } ?: "rpm",
                ringCenter = prefs.getString("ringCenter", null)?.takeIf { id -> id in Params.byId } ?: "speed",
                ringSecond = prefs.getString("ringSecond", null)?.takeIf { id -> id in Params.byId } ?: Params.BOOST,
                ringThird = prefs.getString("ringThird", null)?.takeIf { id -> id in Params.byId } ?: "oil",
                oilCustomDid = prefs.getString("oilDid", "") ?: "",
                oilCustomFormula = prefs.getInt("oilFormula", 0),
                shiftRpm = prefs.getInt("shiftRpm", 4000),
            )
        }
    }

    // ------------------------------------------------------------ Panel personalizable

    fun setDashboard(ids: List<String>) {
        prefs.edit().putString("widgets", ids.joinToString(",")).apply()
        _state.update { it.copy(dashboard = ids) }
    }

    // Formato guardado: "id@x@y@tamaño,id@x@y@tamaño;…" (una página por ";")
    private fun loadPages(): List<List<GaugeItem>> =
        prefs.getString("layout", null)
            ?.split(";")
            ?.map { pg ->
                pg.split(",").mapNotNull { g ->
                    val f = g.split("@")
                    if (f.size == 4 && f[0] in Params.byId) {
                        GaugeItem(f[0], f[1].toFloatOrNull() ?: 0.5f, f[2].toFloatOrNull() ?: 0.5f, f[3].toFloatOrNull() ?: 0.6f)
                    } else null
                }
            }
            ?.filter { it.isNotEmpty() }
            ?.takeIf { it.isNotEmpty() }
            ?: Params.defaultPages.map { defaultLayout(it) }

    fun setPages(pages: List<List<GaugeItem>>) {
        val clean = pages.filter { it.isNotEmpty() }.ifEmpty { Params.defaultPages.map { defaultLayout(it) } }
        prefs.edit().putString(
            "layout",
            clean.joinToString(";") { pg -> pg.joinToString(",") { "${it.id}@${it.x}@${it.y}@${it.size}" } },
        ).apply()
        _state.update { it.copy(pages = clean, page = it.page.coerceIn(0, clean.size - 1)) }
    }

    fun pageName(st: UiState, i: Int) = st.pageNames.getOrNull(i)?.takeIf { it.isNotBlank() } ?: "Página ${i + 1}"

    private fun saveNames(names: List<String>) {
        prefs.edit().putString("pageNames", names.joinToString("|") { it.replace("|", "/") }).apply()
        _state.update { it.copy(pageNames = names) }
    }

    fun renamePage(i: Int, name: String) {
        val st = _state.value
        val names = List(st.pages.size) { j -> if (j == i) name.take(24) else st.pageNames.getOrElse(j) { "" } }
        saveNames(names)
    }

    fun addPage() {
        val st = _state.value
        setPages(st.pages + listOf(defaultLayout(listOf("coolant", "rpm", "oil"))))
        saveNames(List(st.pages.size) { j -> st.pageNames.getOrElse(j) { "" } } + "Página ${st.pages.size + 1}")
    }

    fun removePage(i: Int) {
        val st = _state.value
        if (st.pages.size <= 1) return
        setPages(st.pages.filterIndexed { j, _ -> j != i })
        saveNames(List(st.pages.size) { j -> st.pageNames.getOrElse(j) { "" } }.filterIndexed { j, _ -> j != i })
    }

    fun resetPages() {
        setPages(Params.defaultPages.map { defaultLayout(it) })
        saveNames(Params.defaultPageNames)
    }

    /** Guarda la página actual tal como ha quedado al moverla en el editor. */
    fun setCurrentPage(items: List<GaugeItem>) {
        val st = _state.value
        setPages(st.pages.mapIndexed { i, pg -> if (i == st.page) items else pg })
    }

    fun resetCurrentPage() {
        val st = _state.value
        val def = Params.defaultPages[st.page % Params.defaultPages.size]
        setCurrentPage(defaultLayout(def))
    }

    // ------------------------------------------------------------ Logo propio en el reloj principal

    private val logoFile get() = java.io.File(getApplication<Application>().filesDir, "logo.png")

    private fun loadLogo(): androidx.compose.ui.graphics.ImageBitmap? = try {
        if (logoFile.exists()) android.graphics.BitmapFactory.decodeFile(logoFile.path)?.asImageBitmap() else null
    } catch (_: Exception) { null }

    /** Copia la imagen elegida, la reduce y la guarda dentro de la app. */
    fun setLogo(uri: android.net.Uri) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val app = getApplication<Application>()
                val src = app.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it) } ?: return@launch
                val scale = minOf(1f, 400f / maxOf(src.width, src.height))
                val bmp = android.graphics.Bitmap.createScaledBitmap(src, (src.width * scale).toInt().coerceAtLeast(1), (src.height * scale).toInt().coerceAtLeast(1), true)
                logoFile.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
                _state.update { it.copy(logo = bmp.asImageBitmap()) }
            } catch (ex: Exception) {
                log("No se pudo cargar la imagen: ${ex.message}")
            }
        }
    }

    fun clearLogo() {
        logoFile.delete()
        _state.update { it.copy(logo = null) }
    }

    /** ANTERIOR / SIGUIENTE: cambia de página de relojes (da la vuelta). */
    fun movePage(delta: Int) = _state.update {
        val n = it.pages.size
        it.copy(page = ((it.page + delta) % n + n) % n)
    }

    /** Flechas de cada reloj: cambia el dato de ese reloj al anterior o siguiente de la lista. */
    fun cycleGauge(slot: Int, dir: Int) {
        val st = _state.value
        val cur = st.pages.getOrNull(st.page) ?: return
        val item = cur.getOrNull(slot) ?: return
        val ids = Params.all.map { it.id }
        val idx = ids.indexOf(item.id).coerceAtLeast(0)
        val next = ids[((idx + dir) % ids.size + ids.size) % ids.size]
        setCurrentPage(cur.mapIndexed { j, g -> if (j == slot) g.copy(id = next) else g })
    }

    fun setRings(main: String, center: String, second: String, third: String) {
        prefs.edit().putString("ringMain", main).putString("ringCenter", center)
            .putString("ringSecond", second).putString("ringThird", third).apply()
        _state.update { it.copy(ringMain = main, ringCenter = center, ringSecond = second, ringThird = third) }
    }

    // ------------------------------------------------------------ Temperatura del aceite
    //
    // El PID estándar 015C casi nunca lo da un TDI de VAG de 2011. Se prueba en este orden:
    //  1) 015C estándar   2) 22F45C (el mismo dato pedido por UDS a la centralita de motor)
    //  3) un identificador propio que se puede escribir en Ajustes (22XXXX)

    private var oilDid: Int? = null
    private var oilFormula = 0

    fun setOilCustom(did: String, formula: Int) {
        val clean = did.uppercase().filter { it in "0123456789ABCDEF" }.take(4)
        prefs.edit().putString("oilDid", clean).putInt("oilFormula", formula).apply()
        _state.update { it.copy(oilCustomDid = clean, oilCustomFormula = formula) }
    }

    fun retestOil() {
        val e = elm ?: return _state.update { it.copy(oilTestMessage = "Conecta primero con el coche") }
        viewModelScope.launch {
            _state.update { it.copy(oilTestMessage = "Probando…") }
            try { detectOil(e) } catch (ex: Exception) { disconnect("Error: ${ex.message}") }
        }
    }

    private suspend fun detectOil(e: Elm327) {
        val st = _state.value
        if (0x5C in st.supportedPids) {
            oilDid = null
            _state.update { it.copy(oilSource = "OBD estándar (015C)", oilTestMessage = "") }
            return
        }
        val candidates = buildList {
            st.oilCustomDid.toIntOrNull(16)?.let { add(it to st.oilCustomFormula) }
            add(0xF45C to 0)
        }
        for ((did, f) in candidates) {
            val data = Elm327.mode22(e.send("22%04X".format(did), 2000), did) ?: continue
            val t = oilCalc(data, f) ?: continue
            if (t in -40.0..170.0) {
                oilDid = did; oilFormula = f
                log("Temperatura de aceite encontrada en 22%04X: %.1f °C".format(did, t))
                _state.update { it.copy(oilSource = "UDS 22%04X".format(did), oilTestMessage = "Leyendo: %.0f °C".format(t)) }
                return
            }
        }
        oilDid = null
        _state.update {
            it.copy(oilSource = "", oilTestMessage = "Tu centralita no da la temperatura del aceite con estos identificadores")
        }
    }

    // ---- Rastreo de la temperatura del aceite
    //
    // Corre en segundo plano (puedes salir de la app), no para el panel, se pausa si el coche se mueve y,
    // si se interrumpe, BUSCAR continúa por donde iba. Solo lee datos (servicio 22): no cambia nada del coche.

    private var scanJob: Job? = null
    private var scanPos = 0
    private var scanAnswered = 0
    private val scanFound = mutableListOf<OilCandidate>()

    /** Orden del rastreo: primero lo más probable en VAG, después rangos más amplios. */
    private val scanOrder: List<Int> by lazy {
        (0x2000..0x20FF) + (0x1000..0x1FFF) + (0xF400..0xF4FF) + (0x2100..0x2FFF) + (0x0100..0x0FFF) + (0xF100..0xF3FF)
    }

    /**
     * Pregunta cuatro identificadores UDS que casi toda centralita VAG contesta (bastidor, referencias…).
     * Devuelve cuántos contestaron, aunque sea con un "no soportado": si ninguno, rastrear no sirve de nada.
     */
    private suspend fun probeUds(e: Elm327): Int {
        var answered = 0
        for (did in listOf(0xF190, 0xF187, 0xF18C, 0xF40D)) {
            val r = e.send("22%04X".format(did), 1500)
            val ms = Elm327.messages(r)
            val ok = ms.any { it.size >= 3 && it[0] == 0x62 } ||
                ms.any { it.size >= 3 && it[0] == 0x7F && it[1] == 0x22 }
            if (ok) answered++
            log("Sonda 22%04X: %s".format(did, r.replace("\n", " ").ifEmpty { "sin respuesta" }))
        }
        return answered
    }

    /** Qué fórmulas probar según los bytes que devuelve el identificador. */
    private fun oilFormulasFor(size: Int): List<Int> = when {
        size == 1 -> listOf(0, 4, 3)
        size == 2 -> listOf(1, 5)
        size in 3..8 -> listOf(1, 5, 0)
        else -> emptyList()
    }

    fun scanOil() {
        val e = elm ?: return _state.update { it.copy(oilTestMessage = "Conecta primero con el coche") }
        if (_state.value.oilScanProgress != null) return
        val total = scanOrder.size
        scanJob = viewModelScope.launch {
            if (scanPos <= 0 || scanPos >= total) { scanPos = 0; scanFound.clear(); scanAnswered = 0 }
            _state.update {
                it.copy(
                    oilScanProgress = scanPos / total.toFloat(), oilCandidates = scanFound.take(40).toList(),
                    oilTestMessage = if (scanPos > 0) "Continuando el rastreo…" else "Probando la centralita…",
                )
            }
            try {
                if (scanPos == 0 && probeUds(e) == 0) {
                    _state.update {
                        it.copy(
                            oilScanProgress = null,
                            oilTestMessage = "La centralita de motor no contesta a lecturas UDS (22). Rastrear aquí no sirve: " +
                                "el dato debe de estar en otro módulo. Mira el registro en Ajustes.",
                        )
                    }
                    return@launch
                }
                val coolant = Elm327.mode01(e.send("0105"), 0x05)?.let { it[0] - 40.0 } ?: _state.value.values["coolant"]
                e.send("ATST 20")   // espera menos a los identificadores que no existen
                while (elm === e && scanPos < total && _state.value.oilScanProgress != null) {
                    // En pausa mientras el coche se mueve
                    while (elm === e && _state.value.oilScanProgress != null && (_state.value.values["speed"] ?: 0.0) > 3.0) {
                        _state.update { it.copy(oilTestMessage = "En pausa: el coche se mueve. Sigue al parar.") }
                        delay(1500)
                    }
                    if (elm !== e || _state.value.oilScanProgress == null) break
                    val did = scanOrder[scanPos]
                    val data = Elm327.mode22(e.send("22%04X".format(did), 500), did)
                    if (data != null) {
                        scanAnswered++
                        for (f in oilFormulasFor(data.size)) {
                            val t = oilCalc(data, f) ?: continue
                            val near = coolant == null || kotlin.math.abs(t - coolant) <= 25
                            if (t in 15.0..150.0 && near && did != 0xF405) {
                                scanFound += OilCandidate(did, f, t)
                                log("Candidato 22%04X = %.1f °C (fórmula %d)".format(did, t, f))
                                break
                            }
                        }
                    }
                    scanPos++
                    if (scanPos % 16 == 0 || data != null) {
                        _state.update {
                            it.copy(
                                oilScanProgress = scanPos / total.toFloat(), oilCandidates = scanFound.take(40).toList(),
                                oilTestMessage = "Rastreando… respondieron $scanAnswered identificadores",
                            )
                        }
                    }
                }
                if (elm === e) { try { e.send("ATST 32") } catch (_: Exception) { } }
                val finished = scanPos >= total
                val percent = (scanPos * 100L / total).toInt()
                if (finished) scanPos = 0
                _state.update {
                    it.copy(
                        oilScanProgress = null, oilCandidates = scanFound.take(40).toList(),
                        oilTestMessage = when {
                            scanFound.isNotEmpty() -> "Elige el que coincida con Carly"
                            finished -> "Rastreo completo: no se encontró ninguno ($scanAnswered respondieron)."
                            else -> "Rastreo parado al $percent %. BUSCAR continúa desde ahí."
                        },
                    )
                }
            } catch (ex: Exception) {
                _state.update { it.copy(oilScanProgress = null) }
                if (elm === e) disconnect("Error rastreando: ${ex.message}")
            }
        }
    }

    fun stopOilScan() = _state.update { it.copy(oilScanProgress = null) }

    fun useOilCandidate(c: OilCandidate) {
        setOilCustom("%04X".format(c.did), c.formula)
        oilDid = c.did; oilFormula = c.formula
        _state.update { it.copy(oilSource = "UDS 22%04X".format(c.did), oilTestMessage = "Guardado: 22%04X".format(c.did)) }
    }

    /**
     * Fórmulas: 0 = A−40 · 1 = (A·256+B−2731)/10 (décimas de kelvin) · 2 = (A·256+B)/10−273,1 ·
     * 3 = A directo en °C · 4 = A·0,75−48 (habitual en VAG) · 5 = (A·256+B)/10 con signo (décimas de °C)
     */
    private fun oilCalc(d: IntArray, f: Int): Double? = when (f) {
        0 -> if (d.isNotEmpty()) d[0] - 40.0 else null
        1 -> if (d.size >= 2) (d[0] * 256 + d[1] - 2731) / 10.0 else null
        2 -> if (d.size >= 2) (d[0] * 256 + d[1]) / 10.0 - 273.1 else null
        3 -> if (d.isNotEmpty()) d[0].toDouble() else null
        4 -> if (d.isNotEmpty()) d[0] * 0.75 - 48.0 else null
        5 -> if (d.size >= 2) (d[0] * 256 + d[1]).toShort().toInt() / 10.0 else null
        else -> null
    }

    fun setShiftRpm(rpm: Int) {
        val v = rpm.coerceIn(2000, 5000)
        prefs.edit().putInt("shiftRpm", v).apply()
        _state.update { it.copy(shiftRpm = v) }
    }

    /** Guarda valores nuevos, máximos e historial (60 muestras) de cada dato. */
    fun setFocus(ids: List<String>) = _state.update { it.copy(focus = ids) }

    fun resetTrip() = _state.update { it.copy(trip = Trip()) }

    fun setAccelMode(m: AccelMode) = _state.update { it.copy(accel = it.accel.copy(mode = m, state = AccelState.PARADO, resultS = null)) }

    /** Deja el cronómetro esperando la salida. */
    fun armAccel() = _state.update { it.copy(accel = it.accel.copy(state = AccelState.PREPARADO, resultS = null)) }

    fun cancelAccel() = _state.update { it.copy(accel = it.accel.copy(state = AccelState.PARADO)) }

    private var lastSpeed: Double? = null
    private var lastSpeedMs = 0L

    /** Viaje y cronómetro: se actualizan con cada lectura nueva de velocidad. */
    private fun onSpeed(s: UiState, v: Double, fuelRate: Double?): UiState {
        val now = System.currentTimeMillis()
        val pv = lastSpeed
        val pt = lastSpeedMs
        lastSpeed = v; lastSpeedMs = now
        if (pv == null || now - pt > 3000) return s
        val dt = (now - pt) / 1000.0
        // Viaje
        val t = s.trip
        val mid = (pv + v) / 2
        val trip = t.copy(
            distanceKm = t.distanceKm + mid * dt / 3600,
            movingSeconds = t.movingSeconds + if (mid > 1) dt else 0.0,
            maxSpeed = maxOf(t.maxSpeed, v),
            fuelLitres = fuelRate?.let { (t.fuelLitres ?: 0.0) + it * dt / 3600 } ?: t.fuelLitres,
        )
        // Cronómetro
        fun cross(target: Double) = pt + ((target - pv) / (v - pv) * (now - pt)).toLong()
        var a = s.accel
        when (a.state) {
            AccelState.PREPARADO -> {
                val m = a.mode
                if (m.from == 0.0 && pv < 0.5 && v >= 0.5) a = a.copy(state = AccelState.MIDIENDO, startMs = pt)
                else if (m.from > 0 && pv < m.from && v >= m.from) a = a.copy(state = AccelState.MIDIENDO, startMs = cross(m.from))
            }
            AccelState.MIDIENDO -> {
                val m = a.mode
                if (v >= m.to && pv < m.to) {
                    val r = (cross(m.to) - a.startMs) / 1000.0
                    val best = a.best[m]
                    a = a.copy(state = AccelState.HECHO, resultS = r, best = if (best == null || r < best) a.best + (m to r) else a.best)
                } else if (v < 0.5 || (m.from > 0 && v < m.from - 5)) {
                    a = a.copy(state = AccelState.PREPARADO)
                }
            }
            else -> {}
        }
        return s.copy(trip = trip, accel = a)
    }

    private fun applyValues(newValues: Map<String, Double>, replace: Boolean = false, hz: Double? = null) {
        if (newValues.isNotEmpty()) lastDataMs = System.currentTimeMillis()
        _state.update { s0 ->
            val s = newValues["speed"]?.let { onSpeed(s0, it, newValues["fuelrate"] ?: s0.values["fuelrate"]) } ?: s0
            val peaks = s.peaks.toMutableMap()
            val hist = s.history.toMutableMap()
            newValues.forEach { (k, v) ->
                if (v > (peaks[k] ?: Double.NEGATIVE_INFINITY)) peaks[k] = v
                hist[k] = ((hist[k] ?: emptyList()) + v.toFloat()).takeLast(HISTORY)
            }
            s.copy(
                values = if (replace) newValues else s.values + newValues,
                peaks = peaks, history = hist, refreshHz = hz ?: s.refreshHz,
            )
        }
    }

    fun setColumns(n: Int) {
        prefs.edit().putInt("columnas", n).apply()
        _state.update { it.copy(columns = n) }
    }

    fun setTraffic(on: Boolean) {
        elm?.logTraffic = on
        _state.update { it.copy(traffic = on) }
    }

    fun resetPeaks() = _state.update { it.copy(peaks = emptyMap()) }

    // ------------------------------------------------------------ Conexión

    /** Si está activa, la app conecta sola y vuelve a conectar cuando se pierde. Solo la apaga el botón DESCONECTAR. */
    private var autoReconnect = prefs.getBoolean("autoReconnect", true)
    private var lastDataMs = 0L
    private var permissionAskedMs = 0L
    private var supervisorJob: Job? = null

    private fun setAutoReconnect(on: Boolean) {
        autoReconnect = on
        prefs.edit().putBoolean("autoReconnect", on).apply()
    }

    /** Botón CONECTAR, apertura de la app o cable enchufado: conecta y mantiene la conexión viva. */
    fun connect() {
        setAutoReconnect(true)
        startKeepAlive()
        tryConnect(quiet = false)
    }

    /** Botón DESCONECTAR: se desconecta y no vuelve a conectar sola hasta que pulses CONECTAR. */
    fun userDisconnect() {
        if (!_state.value.demo) {
            setAutoReconnect(false)
            stopKeepAlive()
        }
        disconnect("Desconectado")
    }

    /** Servicio en primer plano: evita que Android cierre la app al irte a la radio, YouTube o el GPS. */
    private fun startKeepAlive() {
        try {
            val app = getApplication<Application>()
            ContextCompat.startForegroundService(app, Intent(app, ObdService::class.java))
        } catch (ex: Exception) {
            log("No se pudo iniciar el servicio en segundo plano: ${ex.message}")
        }
    }

    private fun stopKeepAlive() {
        try {
            val app = getApplication<Application>()
            app.stopService(Intent(app, ObdService::class.java))
        } catch (_: Exception) { }
    }

    /**
     * Vigila la conexión: si no la hay, la intenta de nuevo sola (cada vez más despacio si el coche está
     * apagado); si el coche deja de contestar, la reinicia.
     */
    fun startSupervisor() {
        if (supervisorJob?.isActive == true) return
        supervisorJob = viewModelScope.launch {
            var failures = 0
            while (isActive) {
                val st = _state.value
                var wait = 2000L
                if (!st.demo) {
                    when (st.conn) {
                        Conn.DESCONECTADO -> {
                            if (autoReconnect) {
                                tryConnect(quiet = failures > 0)
                                failures++
                                wait = if (failures < 6) 3000L else if (failures < 20) 6000L else 15000L
                            }
                        }
                        Conn.CONECTADO -> {
                            failures = 0
                            if (!st.dtcBusy && System.currentTimeMillis() - lastDataMs > NO_DATA_MS) {
                                disconnect("Sin datos del coche · reconectando…")
                            }
                        }
                        Conn.CONECTANDO -> { }
                    }
                }
                delay(wait)
            }
        }
    }

    private fun tryConnect(quiet: Boolean) {
        if (_state.value.conn != Conn.DESCONECTADO) return
        val driver = UsbSerialProber.getDefaultProber().findAllDrivers(usb).firstOrNull()
        if (driver == null) {
            val msg = "No encuentro el cable OBD USB. ¿Está enchufado a la pantalla?"
            if (!quiet || _state.value.status != msg) setStatus(msg)
            if (!quiet) {
                val others = usb.deviceList.values.joinToString { "%04X:%04X".format(it.vendorId, it.productId) }
                if (others.isNotEmpty()) log("Dispositivos USB vistos (no reconocidos como serie): $others")
            }
            return
        }
        val device: UsbDevice = driver.device
        if (!usb.hasPermission(device)) {
            val now = System.currentTimeMillis()
            // Al reintentar sola no se vuelve a abrir el aviso de permiso a cada rato
            if (quiet && now - permissionAskedMs < 20_000) return
            permissionAskedMs = now
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(
                getApplication(), 0,
                Intent(ACTION_PERMISSION).setPackage(getApplication<Application>().packageName), flags,
            )
            setStatus("Acepta el permiso USB en la pantalla…")
            usb.requestPermission(device, pi)
            return
        }
        val connection = usb.openDevice(device)
        if (connection == null) {
            val msg = "No se pudo abrir el cable USB"
            if (!quiet || _state.value.status != msg) setStatus(msg)
            return
        }
        _state.update { it.copy(conn = Conn.CONECTANDO, status = "Buscando adaptador…") }
        log("Cable USB: ${driver.javaClass.simpleName.removeSuffix("SerialDriver")} %04X:%04X".format(device.vendorId, device.productId))

        viewModelScope.launch {
            try {
                withTimeout(CONNECT_TIMEOUT_MS) { doConnect(driver, connection) }
            } catch (ex: TimeoutCancellationException) {
                disconnect("Tiempo agotado conectando · reintentando…")
            } catch (ex: Exception) {
                disconnect("Error de comunicación: ${ex.message ?: ex.javaClass.simpleName}")
            }
        }
    }

    private suspend fun doConnect(driver: UsbSerialDriver, connection: UsbDeviceConnection) {
        val port = driver.ports[0]
        port.open(connection)
        try { port.setDTR(true); port.setRTS(true) } catch (_: Exception) { }
        val e = Elm327(port, connection) { log(it) }
        e.logTraffic = _state.value.traffic
        elm = e

        val version = e.detect(prefs.getInt("baud", 0))
        if (version == null) {
            disconnect("El cable no responde como ELM327. Si es un cable VAG-COM/KKL no es compatible.")
            return
        }
        // Se recuerda la velocidad que funcionó, para conectar más rápido la próxima vez
        if (e.baud > 0) prefs.edit().putInt("baud", e.baud).apply()
        _state.update { it.copy(adapter = version, status = "Conectando con el coche…") }

        for (c in listOf("ATE0", "ATL0", "ATS0", "ATH0", "ATAT1", "ATSP0")) e.send(c)
        var r = e.send("0100", 12000)
        if (Elm327.mode01Supported(r) == null) {
            log("Búsqueda automática sin respuesta, probando CAN 11 bit 500 kbps…")
            e.send("ATSP6")
            r = e.send("0100", 8000)
        }
        val first = Elm327.mode01Supported(r)
        if (first == null) {
            disconnect("El coche no responde. Pon el contacto (o arranca) y se reintentará solo.")
            return
        }
        val protocol = e.send("ATDP").removePrefix("AUTO,").trim()

        // PIDs soportados
        val supported = first.toMutableSet()
        for (base in listOf(0x20, 0x40, 0x60, 0x80, 0xA0)) {
            if (base !in supported) break
            val s = Elm327.supported(e.send("01%02X".format(base)), base)
            if (s.isEmpty()) break
            supported += s
        }
        log("PIDs soportados: " + supported.sorted().joinToString(" ") { "%02X".format(it) })

        // En CAN, hablar solo con la centralita de motor (7E0): respuestas limpias y permite UDS
        if (protocol.contains("15765")) e.send("ATSH7E0")
        val vin = Elm327.vin(e.send("0902", 5000)) ?: ""
        lastDataMs = System.currentTimeMillis()
        _state.update {
            it.copy(
                conn = Conn.CONECTADO, protocol = protocol, vin = vin, supportedPids = supported,
                status = "Conectado · $protocol",
            )
        }
        readStatus()
        detectOil(e)
        startPolling()
    }

    fun disconnect(reason: String = "Desconectado") {
        pollJob?.cancel(); pollJob = null
        elm?.close(); elm = null
        _state.update {
            it.copy(conn = Conn.DESCONECTADO, status = reason, refreshHz = 0.0, demo = false, oilScanProgress = null)
        }
        log(reason)
    }

    // ------------------------------------------------------------ Modo demo (sin cable)

    /** Simula un coche en marcha para probar la app sin cable ni coche. */
    fun startDemo() {
        if (_state.value.conn != Conn.DESCONECTADO) return
        _state.update {
            it.copy(
                conn = Conn.CONECTADO, demo = true, status = "MODO DEMO · datos simulados",
                adapter = "Simulador", protocol = "Demo", vin = "VSSZZZ6JZBR000000", oilSource = "Demo",
                supportedPids = Params.byPid.keys, mil = true, dtcCount = 2,
            )
        }
        log("Modo demo iniciado")
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            var t = 0.0
            while (isActive) {
                t += 0.1
                // Aceleraciones y retenciones cíclicas
                val ph = ((kotlin.math.sin(t * 0.45) + 1) / 2).let { it * it }
                val noise = { a: Double -> (Math.random() - 0.5) * a }
                val map = 101 + ph * 135 + noise(3.0)
                val v = mapOf(
                    "rpm" to 850 + ph * 3300 + noise(40.0),
                    "speed" to maxOf(0.0, -12 + ph * 135),
                    "load" to ph * 95 + noise(2.0),
                    "absload" to ph * 90,
                    "pedal" to ph * 100,
                    "pedal2" to ph * 50,
                    "throttle" to 20 + ph * 80,
                    "throttlecmd" to 20 + ph * 80,
                    "relthrottle" to ph * 80,
                    "torquedem" to ph * 100,
                    "torque" to ph * 96,
                    "torqueref" to 320.0,
                    "map" to map,
                    "baro" to 101.0,
                    Params.BOOST to (map - 101) / 100,
                    "maf" to 9 + ph * 150 + noise(2.0),
                    "egrcmd" to (1 - ph) * 55,
                    "egrerr" to noise(6.0),
                    "rail" to 280 + ph * 1450 + noise(20.0),
                    "fuelrate" to 0.9 + ph * 16,
                    "fuellevel" to 63.0,
                    "injtiming" to 2 + ph * 9,
                    "coolant" to 89 + kotlin.math.sin(t * 0.05) * 3,
                    "iat" to 28 + ph * 14,
                    "ambient" to 19.0,
                    "oil" to minOf(52 + t * 0.6, 97.0) + ph * 4,
                    Params.BATTERY to 14.1 + noise(0.15),
                    "modvolt" to 14.0 + noise(0.1),
                    "runtime" to t / 6,
                    "distmil" to 37.0,
                    "timemil" to 52.0,
                    "distclr" to 1240.0,
                    "timeclr" to 1530.0,
                    "warmups" to 41.0,
                )
                applyValues(v, replace = true, hz = 30.0)
                delay(100)
            }
        }
    }

    // ------------------------------------------------------------ Lectura en tiempo real

    private fun startPolling() {
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            var cycle = 0
            var rotate = 0
            var t0 = System.currentTimeMillis()
            var reads = 0
            try {
                while (isActive) {
                    val e = elm ?: break
                    val st = _state.value
                    val supported = st.supportedPids

                    // 1) Lo que hay en el panel, en cada vuelta
                    val pids = linkedSetOf<Int>()
                    for (id in st.live) {
                        when (id) {
                            Params.BOOST -> { pids += 0x0B; if (cycle % 20 == 0 && 0x33 in supported) pids += 0x33 }
                            else -> Params.byId[id]?.pid?.let { if (it in supported) pids += it }
                        }
                    }
                    // 2) Uno del resto en cada vuelta, para rellenar los submenús
                    val rest = Params.all.mapNotNull { it.pid }.filter { it in supported && it !in pids }
                    if (rest.isNotEmpty()) pids += rest[rotate++ % rest.size]

                    val newValues = mutableMapOf<String, Double>()
                    for (pid in pids) {
                        val data = Elm327.mode01(e.send("01%02X".format(pid), 1500), pid) ?: continue
                        val p = Params.byPid[pid] ?: continue
                        newValues[p.id] = p.calc(data)
                        reads++
                    }
                    // Aceite por UDS (si el PID estándar no existe)
                    val did = oilDid
                    if (did != null && ("oil" in st.live || cycle % 10 == 5)) {
                        Elm327.mode22(e.send("22%04X".format(did), 1500), did)?.let { d ->
                            oilCalc(d, oilFormula)?.let { newValues["oil"] = it; reads++ }
                        }
                    }
                    // Turbo relativo = MAP - presión atmosférica
                    val map = newValues["map"] ?: st.values["map"]
                    val baro = newValues["baro"] ?: st.values["baro"] ?: 101.3
                    if (map != null && "map" in newValues) newValues[Params.BOOST] = (map - baro) / 100.0

                    // Batería (la mide el propio adaptador)
                    if (cycle % 10 == 0 || (Params.BATTERY in st.live && cycle % 3 == 0)) {
                        e.send("ATRV", 800).replace("V", "").trim().toDoubleOrNull()?.let { newValues[Params.BATTERY] = it }
                    }

                    if (newValues.isNotEmpty()) applyValues(newValues)
                    val now = System.currentTimeMillis()
                    if (now - t0 >= 2000) {
                        val hz = reads * 1000.0 / (now - t0)
                        _state.update { it.copy(refreshHz = hz) }
                        t0 = now; reads = 0
                    }
                    cycle++
                    if (pids.isEmpty()) delay(300)
                }
            } catch (ex: Exception) {
                if (isActive) disconnect("Conexión perdida: ${ex.message ?: ex.javaClass.simpleName}")
            }
        }
    }

    // ------------------------------------------------------------ Averías

    private suspend fun readStatus() {
        val e = elm ?: return
        val m = Elm327.messages(e.send("0101")).firstOrNull { it.size >= 3 && it[0] == 0x41 && it[1] == 0x01 }
        if (m != null) _state.update { it.copy(mil = (m[2] and 0x80) != 0, dtcCount = m[2] and 0x7F) }
    }

    fun readDtcs() {
        if (_state.value.demo) {
            _state.update {
                it.copy(
                    dtcs = listOf("P0401", "P2002"), pendingDtcs = listOf("P0299"), permanentDtcs = emptyList(),
                    mil = true, dtcCount = 2, dtcMessage = "Averías de ejemplo (modo demo)",
                )
            }
            return
        }
        val e = elm ?: return setDtcMessage("Conecta primero con el coche")
        viewModelScope.launch {
            _state.update { it.copy(dtcBusy = true, dtcMessage = "Leyendo averías…") }
            try {
                readStatus()
                val stored = Elm327.dtcs(e.send("03", 6000), 0x43)
                val pending = Elm327.dtcs(e.send("07", 6000), 0x47)
                val permanent = Elm327.dtcs(e.send("0A", 6000), 0x4A)
                val total = stored.size + pending.size + permanent.size
                _state.update {
                    it.copy(
                        dtcs = stored, pendingDtcs = pending, permanentDtcs = permanent, dtcBusy = false,
                        dtcMessage = if (total == 0) "Sin averías en la centralita de motor ✔" else "Lectura completada · ${timeFmt.format(Date())}",
                    )
                }
            } catch (ex: Exception) {
                _state.update { it.copy(dtcBusy = false) }
                disconnect("Error leyendo averías: ${ex.message}")
            }
        }
    }

    fun clearDtcs() {
        if (_state.value.demo) {
            _state.update {
                it.copy(
                    dtcs = emptyList(), pendingDtcs = emptyList(), permanentDtcs = emptyList(),
                    mil = false, dtcCount = 0, dtcMessage = "Averías borradas (modo demo)",
                )
            }
            return
        }
        val e = elm ?: return setDtcMessage("Conecta primero con el coche")
        viewModelScope.launch {
            _state.update { it.copy(dtcBusy = true, dtcMessage = "Borrando averías…") }
            try {
                val r = e.send("04", 6000)
                val ok = Elm327.messages(r).any { it.isNotEmpty() && it[0] == 0x44 }
                _state.update {
                    it.copy(
                        dtcBusy = false,
                        dtcMessage = if (ok) "Averías borradas. Si el fallo sigue presente volverá a aparecer."
                        else "El coche no confirmó el borrado ($r). Prueba con contacto puesto y motor parado.",
                    )
                }
                if (ok) readDtcs()
            } catch (ex: Exception) {
                _state.update { it.copy(dtcBusy = false) }
                disconnect("Error borrando averías: ${ex.message}")
            }
        }
    }

    private fun setDtcMessage(m: String) = _state.update { it.copy(dtcMessage = m) }

    // ------------------------------------------------------------ Consola

    fun sendRaw(cmd: String) {
        val e = elm ?: return log("No conectado")
        viewModelScope.launch {
            try { log("> $cmd\n" + e.send(cmd.trim().uppercase(), 5000).ifEmpty { "(sin respuesta)" }) }
            catch (ex: Exception) { disconnect("Error: ${ex.message}") }
        }
    }

    // ------------------------------------------------------------ Utilidades

    private fun setStatus(s: String) { _state.update { it.copy(status = s) }; log(s) }

    private fun log(s: String) {
        val line = "${timeFmt.format(Date())}  $s"
        _state.update { it.copy(log = (it.log + line).takeLast(400)) }
    }

    override fun onCleared() {
        disconnect()
        try { getApplication<Application>().unregisterReceiver(receiver) } catch (_: Exception) { }
    }

    companion object {
        const val HISTORY = 600
        const val ACTION_PERMISSION = "com.ikker.obdibiza.USB_PERMISSION"
        /** Si el coche no da ningún dato en este tiempo se reinicia la conexión. */
        const val NO_DATA_MS = 15_000L
        /** Tiempo máximo para completar una conexión antes de abandonarla y reintentar. */
        const val CONNECT_TIMEOUT_MS = 60_000L
    }
}
