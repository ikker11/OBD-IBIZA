package com.ikker.obdibiza

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val vm: ObdViewModel by viewModels()

    // Android 13+: permiso para mostrar el aviso fijo de "leyendo el coche"
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private var notifAsked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Pantalla siempre encendida mientras la app está delante
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemBars()
        setContent { ObdApp(vm) }
        // Conexión automática al abrir (si el cable ya está enchufado)
        vm.connect()

        // Segundo plano: mientras estés conectado al coche (no en demo), un servicio en primer
        // plano mantiene viva la lectura aunque uses el navegador u otra app.
        lifecycleScope.launch {
            vm.state.map { it.conn == Conn.CONECTADO && !it.demo }.distinctUntilChanged().collect { live ->
                if (live) startKeepAlive() else stopKeepAlive()
            }
        }
    }

    private fun startKeepAlive() {
        if (Build.VERSION.SDK_INT >= 33 && !notifAsked &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifAsked = true
            try { notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS) } catch (_: Exception) { }
        }
        try { ContextCompat.startForegroundService(this, Intent(this, ObdService::class.java)) } catch (_: Exception) { }
    }

    private fun stopKeepAlive() {
        try { stopService(Intent(this, ObdService::class.java)) } catch (_: Exception) { }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    /** Oculta las barras de Android para aprovechar toda la pantalla del coche. */
    private fun hideSystemBars() {
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) vm.connect()
    }
}

/**
 * Servicio en primer plano: no lee nada por sí mismo, solo avisa a Android de que la app está
 * en uso (aviso fijo "Leyendo el coche") para que no la cierre mientras estás en otra app.
 */
class ObdService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("obd", "Lectura del coche", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val n: Notification = NotificationCompat.Builder(this, "obd")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("OBD Ibiza")
            .setContentText("Leyendo el coche · toca para abrir")
            .setOngoing(true)
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else {
            startForeground(1, n)
        }
        return START_NOT_STICKY
    }
}
