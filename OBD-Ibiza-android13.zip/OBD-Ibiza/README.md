# OBD Ibiza

App para tablet / pantalla Android de coche que lee la OBD del **SEAT Ibiza 6J 2.0 TDI (CFHD) de 2011** con un cable **ELM327 USB** (u OBDLink SX).

## Funciones
- **Panel deportivo personalizable**: tú eliges qué relojes salen, en qué orden y en cuántas columnas (2–5). Marca el valor máximo de cada reloj.
- **Datos**: submenús (Motor, Turbo y admisión, Combustible, Temperaturas, Eléctrico, Estadísticas) con todos los parámetros.
- **Averías**: lectura de códigos guardados, pendientes y permanentes con descripción en español, y **borrado** de códigos.
- **Coche**: bastidor (VIN), protocolo, adaptador, batería.
- **Consola**: para mandar órdenes ELM327 a mano y ver el tráfico.
- Se abre sola y se conecta al enchufar el cable USB. Pantalla siempre encendida.

## Conseguir el APK
Cada vez que se sube un cambio a GitHub, la pestaña **Actions** compila la app y la publica en **Releases** como `OBD-Ibiza.apk`.
Descárgalo desde la tablet e instálalo (permite “instalar apps de origen desconocido”).
Las versiones nuevas se instalan encima sin desinstalar la anterior.

## Cable compatible
- Recomendado: **OBDLink SX / EX USB** (el EX es FTDI y se detecta solo, probado a 115200 baudios primero).
- Económico: **ELM327 USB con chips FTDI FT232RL + PIC18F25K80**.
- **No** sirven los cables VAG-COM / KKL 409.1.

## Pantalla Android 13 (modelo A007, 4 GB, 8 núcleos)
La app está compilada para Android 13/14 (targetSdk 34): permiso USB con PendingIntent explícito, receptores no exportados, pantalla completa y pantalla siempre encendida. Si el cable no se detecta, abre la pestaña Consola: aparece la lista de dispositivos USB vistos.

## Segundo plano
Al conectar con el coche aparece un aviso fijo "Leyendo el coche" (servicio en primer plano). Así Android no cierra la app mientras usas el navegador u otra app, y el viaje (distancia, medias, consumo) sigue contando. Acepta el permiso de notificaciones la primera vez.
