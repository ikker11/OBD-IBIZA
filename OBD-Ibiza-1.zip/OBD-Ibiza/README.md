# OBD Ibiza

App para tablet / pantalla Android de coche que lee la OBD del **SEAT Ibiza 6J 2.0 TDI (CFHD) de 2011** con un cable **ELM327 USB** (u OBDLink SX).

## Funciones
- **Panel deportivo personalizable**: tú eliges qué relojes salen, en qué orden y en cuántas columnas (2–5). Marca el valor máximo de cada reloj.
- **Datos**: submenús (Motor, Turbo y admisión, Combustible, Temperaturas, Eléctrico, Estadísticas) con todos los parámetros.
- **Averías**: lectura de códigos guardados, pendientes y permanentes con descripción en español, y **borrado** de códigos.
- **Coche**: bastidor (VIN), protocolo, adaptador, batería.
- **Consola**: para mandar órdenes ELM327 a mano y ver el tráfico.
- Se abre sola y se conecta al enchufar el cable USB. Pantalla siempre encendida.

## Conseguir el APK
Cada vez que se sube un cambio a GitHub, la pestaña **Actions** compila la app y la publica en **Releases** como `OBD-Ibiza.apk`.
Descárgalo desde la tablet e instálalo (permite “instalar apps de origen desconocido”).
Las versiones nuevas se instalan encima sin desinstalar la anterior.

## Cable compatible
- Recomendado: **OBDLink SX USB**.
- Económico: **ELM327 USB con chips FTDI FT232RL + PIC18F25K80**.
- **No** sirven los cables VAG-COM / KKL 409.1.
