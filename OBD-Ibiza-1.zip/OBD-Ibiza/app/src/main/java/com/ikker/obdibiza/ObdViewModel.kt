package com.ikker.obdibiza

import android.app.Application
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Conn { DESCONECTADO, CONECTANDO, CONECTADO }

data class UiState(
    val conn: Conn = Conn.DESCONECTADO,
    val status: String = "Enchufa el cable OBD y pulsa CONECTAR",
    val adapter: String = "",
    val protocol: String = "",
    val vin: String = "",
    val supportedPids: Set<Int> = emptySet(),
    val values: Map<String, Double> = emptyMap(),
    val peaks: Map<String, Double> = emptyMap(),
    val mil: Boolean? = null,
    val dtcCount: Int? = null,
    val dtcs: List<String>? = null,
    val pendingDtcs: List<String>? = null,
    val permanentDtcs: List<String>? = null,
    val dtcBusy: Boolean = false,
    val dtcMessage: String = "",
    val log: List<String> = emptyList(),
    val dashboard: List<String> = Params.defaultDashboard,
    val columns: Int = 3,
    val refreshHz: Double = 0.0,
    val traffic: Boolean = false,
    val demo: Boolean = false,
)

class ObdViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    private val usb = app.getSystemService(Context.USB_SERVICE) as UsbManager
    private val prefs = app.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
    private var elm: Elm327? = null
    private var pollJob: Job? = null
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                ACTION_PERMISSION -> {
                    if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) connect()
                    else setStatus("Permiso USB denegado. Vuelve a pulsar CONECTAR y acepta.")
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    if (elm != null) disconnect("Cable OBD desenchufado")
                }
            }
        }
    }

    init {
        val f = IntentFilter().apply {
            addAction(ACTION_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(app, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        val saved = prefs.getString("panel", null)
            ?.split(",")?.filter { it in Params.byId }
            ?.takeIf { it.isNotEmpty() }
        _state.update {
            it.copy(dashboard = saved ?: Params.defaultDashboard, columns = prefs.getInt("columnas", 3))
        }
    }

    // ------------------------------------------------------------ Panel personalizable

    fun setDashboard(ids: List<String>) {
        prefs.edit().putString("panel", ids.joinToString(",")).apply()
        _state.update { it.copy(dashboard = ids) }
    }

    fun setColumns(n: Int) {
        prefs.edit().putInt("columnas", n).apply()
        _state.update { it.copy(columns = n) }
    }

    fun setTraffic(on: Boolean) {
        elm?.logTraffic = on
        _state.update { it.copy(traffic = on) }
    }

    fun resetPeaks() = _state.update { it.copy(peaks = emptyMap()) }

    // ------------------------------------------------------------ Conexión

    fun connect() {
        if (_state.value.conn != Conn.DESCONECTADO) return
        val driver = UsbSerialProber.getDefaultProber().findAllDrivers(usb).firstOrNull()
        if (driver == null) {
            setStatus("No encuentro el cable OBD USB. ¿Está enchufado a la pantalla?")
            val others = usb.deviceList.values.joinToString { "%04X:%04X".format(it.vendorId, it.productId) }
            if (others.isNotEmpty()) log("Dispositivos USB vistos (no reconocidos como serie): $others")
            return
        }
        val device: UsbDevice = driver.device
        if (!usb.hasPermission(device)) {
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(
                getApplication(), 0,
                Intent(ACTION_PERMISSION).setPackage(getApplication<Application>().packageName), flags,
            )
            setStatus("Acepta el permiso USB en la pantalla…")
            usb.requestPermission(device, pi)
            return
        }
        val connection = usb.openDevice(device)
        if (connection == null) {
            setStatus("No se pudo abrir el cable USB")
            return
        }
        _state.update { it.copy(conn = Conn.CONECTANDO, status = "Buscando adaptador…") }
        log("Cable USB: ${driver.javaClass.simpleName.removeSuffix("SerialDriver")} %04X:%04X".format(device.vendorId, device.productId))

        viewModelScope.launch {
            try {
                val port = driver.ports[0]
                port.open(connection)
                try { port.setDTR(true); port.setRTS(true) } catch (_: Exception) { }
                val e = Elm327(port, connection) { log(it) }
                e.logTraffic = _state.value.traffic
                elm = e

                val version = e.detect()
                if (version == null) {
                    disconnect("El cable no responde como ELM327. Si es un cable VAG-COM/KKL no es compatible.")
                    return@launch
                }
                _state.update { it.copy(adapter = version, status = "Conectando con el coche…") }

                for (c in listOf("ATE0", "ATL0", "ATS0", "ATH0", "ATAT1", "ATSP0")) e.send(c)
                var r = e.send("0100", 12000)
                if (Elm327.mode01Supported(r) == null) {
                    log("Búsqueda automática sin respuesta, probando CAN 11 bit 500 kbps…")
                    e.send("ATSP6")
                    r = e.send("0100", 8000)
                }
                val first = Elm327.mode01Supported(r)
                if (first == null) {
                    disconnect("El coche no responde. Pon el contacto (o arranca) y vuelve a conectar.")
                    return@launch
                }
                val protocol = e.send("ATDP").removePrefix("AUTO,").trim()

                // PIDs soportados
                val supported = first.toMutableSet()
                for (base in listOf(0x20, 0x40, 0x60, 0x80, 0xA0)) {
                    if (base !in supported) break
                    val s = Elm327.supported(e.send("01%02X".format(base)), base)
                    if (s.isEmpty()) break
                    supported += s
                }
                log("PIDs soportados: " + supported.sorted().joinToString(" ") { "%02X".format(it) })

                val vin = Elm327.vin(e.send("0902", 5000)) ?: ""
                _state.update {
                    it.copy(
                        conn = Conn.CONECTADO, protocol = protocol, vin = vin, supportedPids = supported,
                        status = "Conectado · $protocol",
                    )
                }
                readStatus()
                startPolling()
            } catch (ex: Exception) {
                disconnect("Error de comunicación: ${ex.message ?: ex.javaClass.simpleName}")
            }
        }
    }

    fun disconnect(reason: String = "Desconectado") {
        pollJob?.cancel(); pollJob = null
        elm?.close(); elm = null
        _state.update { it.copy(conn = Conn.DESCONECTADO, status = reason, refreshHz = 0.0, demo = false) }
        log(reason)
    }

    // ------------------------------------------------------------ Modo demo (sin cable)

    /** Simula un coche en marcha para probar la app sin cable ni coche. */
    fun startDemo() {
        if (_state.value.conn != Conn.DESCONECTADO) return
        _state.update {
            it.copy(
                conn = Conn.CONECTADO, demo = true, status = "MODO DEMO · datos simulados",
                adapter = "Simulador", protocol = "Demo", vin = "VSSZZZ6JZBR000000",
                supportedPids = Params.byPid.keys, mil = true, dtcCount = 2,
            )
        }
        log("Modo demo iniciado")
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            var t = 0.0
            while (isActive) {
                t += 0.1
                // Aceleraciones y retenciones cíclicas
                val ph = ((kotlin.math.sin(t * 0.45) + 1) / 2).let { it * it }
                val noise = { a: Double -> (Math.random() - 0.5) * a }
                val map = 101 + ph * 135 + noise(3.0)
                val v = mapOf(
                    "rpm" to 850 + ph * 3300 + noise(40.0),
                    "speed" to 30 + ph * 90,
                    "load" to ph * 95 + noise(2.0),
                    "absload" to ph * 90,
                    "pedal" to ph * 100,
                    "pedal2" to ph * 50,
                    "throttle" to 20 + ph * 80,
                    "throttlecmd" to 20 + ph * 80,
                    "relthrottle" to ph * 80,
                    "torquedem" to ph * 100,
                    "torque" to ph * 96,
                    "torqueref" to 320.0,
                    "map" to map,
                    "baro" to 101.0,
                    Params.BOOST to (map - 101) / 100,
                    "maf" to 9 + ph * 150 + noise(2.0),
                    "egrcmd" to (1 - ph) * 55,
                    "egrerr" to noise(6.0),
                    "rail" to 280 + ph * 1450 + noise(20.0),
                    "fuelrate" to 0.9 + ph * 16,
                    "fuellevel" to 63.0,
                    "injtiming" to 2 + ph * 9,
                    "coolant" to 89 + kotlin.math.sin(t * 0.05) * 3,
                    "iat" to 28 + ph * 14,
                    "ambient" to 19.0,
                    "oil" to 96 + ph * 8,
                    Params.BATTERY to 14.1 + noise(0.15),
                    "modvolt" to 14.0 + noise(0.1),
                    "runtime" to t / 6,
                    "distmil" to 37.0,
                    "timemil" to 52.0,
                    "distclr" to 1240.0,
                    "timeclr" to 1530.0,
                    "warmups" to 41.0,
                )
                _state.update { s ->
                    val peaks = s.peaks.toMutableMap()
                    v.forEach { (k, x) -> if (x > (peaks[k] ?: Double.NEGATIVE_INFINITY)) peaks[k] = x }
                    s.copy(values = v, peaks = peaks, refreshHz = 30.0)
                }
                delay(100)
            }
        }
    }

    // ------------------------------------------------------------ Lectura en tiempo real

    private fun startPolling() {
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            var cycle = 0
            var rotate = 0
            var t0 = System.currentTimeMillis()
            var reads = 0
            try {
                while (isActive) {
                    val e = elm ?: break
                    val st = _state.value
                    val supported = st.supportedPids

                    // 1) Lo que hay en el panel, en cada vuelta
                    val pids = linkedSetOf<Int>()
                    for (id in st.dashboard) {
                        when (id) {
                            Params.BOOST -> { pids += 0x0B; if (cycle % 20 == 0 && 0x33 in supported) pids += 0x33 }
                            else -> Params.byId[id]?.pid?.let { if (it in supported) pids += it }
                        }
                    }
                    // 2) Uno del resto en cada vuelta, para rellenar los submenús
                    val rest = Params.all.mapNotNull { it.pid }.filter { it in supported && it !in pids }
                    if (rest.isNotEmpty()) pids += rest[rotate++ % rest.size]

                    val newValues = mutableMapOf<String, Double>()
                    for (pid in pids) {
                        val data = Elm327.mode01(e.send("01%02X".format(pid), 1500), pid) ?: continue
                        val p = Params.byPid[pid] ?: continue
                        newValues[p.id] = p.calc(data)
                        reads++
                    }
                    // Turbo relativo = MAP - presión atmosférica
                    val map = newValues["map"] ?: st.values["map"]
                    val baro = newValues["baro"] ?: st.values["baro"] ?: 101.3
                    if (map != null && "map" in newValues) newValues[Params.BOOST] = (map - baro) / 100.0

                    // Batería (la mide el propio adaptador)
                    if (cycle % 10 == 0 || (Params.BATTERY in st.dashboard && cycle % 3 == 0)) {
                        e.send("ATRV", 800).replace("V", "").trim().toDoubleOrNull()?.let { newValues[Params.BATTERY] = it }
                    }

                    if (newValues.isNotEmpty()) {
                        _state.update { s ->
                            val peaks = s.peaks.toMutableMap()
                            newValues.forEach { (k, v) -> if (v > (peaks[k] ?: Double.NEGATIVE_INFINITY)) peaks[k] = v }
                            s.copy(values = s.values + newValues, peaks = peaks)
                        }
                    }
                    val now = System.currentTimeMillis()
                    if (now - t0 >= 2000) {
                        val hz = reads * 1000.0 / (now - t0)
                        _state.update { it.copy(refreshHz = hz) }
                        t0 = now; reads = 0
                    }
                    cycle++
                    if (pids.isEmpty()) delay(300)
                }
            } catch (ex: Exception) {
                if (isActive) disconnect("Conexión perdida: ${ex.message ?: ex.javaClass.simpleName}")
            }
        }
    }

    // ------------------------------------------------------------ Averías

    private suspend fun readStatus() {
        val e = elm ?: return
        val m = Elm327.messages(e.send("0101")).firstOrNull { it.size >= 3 && it[0] == 0x41 && it[1] == 0x01 }
        if (m != null) _state.update { it.copy(mil = (m[2] and 0x80) != 0, dtcCount = m[2] and 0x7F) }
    }

    fun readDtcs() {
        if (_state.value.demo) {
            _state.update {
                it.copy(
                    dtcs = listOf("P0401", "P2002"), pendingDtcs = listOf("P0299"), permanentDtcs = emptyList(),
                    mil = true, dtcCount = 2, dtcMessage = "Averías de ejemplo (modo demo)",
                )
            }
            return
        }
        val e = elm ?: return setDtcMessage("Conecta primero con el coche")
        viewModelScope.launch {
            _state.update { it.copy(dtcBusy = true, dtcMessage = "Leyendo averías…") }
            try {
                readStatus()
                val stored = Elm327.dtcs(e.send("03", 6000), 0x43)
                val pending = Elm327.dtcs(e.send("07", 6000), 0x47)
                val permanent = Elm327.dtcs(e.send("0A", 6000), 0x4A)
                val total = stored.size + pending.size + permanent.size
                _state.update {
                    it.copy(
                        dtcs = stored, pendingDtcs = pending, permanentDtcs = permanent, dtcBusy = false,
                        dtcMessage = if (total == 0) "Sin averías en la centralita de motor ✔" else "Lectura completada · ${timeFmt.format(Date())}",
                    )
                }
            } catch (ex: Exception) {
                _state.update { it.copy(dtcBusy = false) }
                disconnect("Error leyendo averías: ${ex.message}")
            }
        }
    }

    fun clearDtcs() {
        if (_state.value.demo) {
            _state.update {
                it.copy(
                    dtcs = emptyList(), pendingDtcs = emptyList(), permanentDtcs = emptyList(),
                    mil = false, dtcCount = 0, dtcMessage = "Averías borradas (modo demo)",
                )
            }
            return
        }
        val e = elm ?: return setDtcMessage("Conecta primero con el coche")
        viewModelScope.launch {
            _state.update { it.copy(dtcBusy = true, dtcMessage = "Borrando averías…") }
            try {
                val r = e.send("04", 6000)
                val ok = Elm327.messages(r).any { it.isNotEmpty() && it[0] == 0x44 }
                _state.update {
                    it.copy(
                        dtcBusy = false,
                        dtcMessage = if (ok) "Averías borradas. Si el fallo sigue presente volverá a aparecer."
                        else "El coche no confirmó el borrado ($r). Prueba con contacto puesto y motor parado.",
                    )
                }
                if (ok) readDtcs()
            } catch (ex: Exception) {
                _state.update { it.copy(dtcBusy = false) }
                disconnect("Error borrando averías: ${ex.message}")
            }
        }
    }

    private fun setDtcMessage(m: String) = _state.update { it.copy(dtcMessage = m) }

    // ------------------------------------------------------------ Consola

    fun sendRaw(cmd: String) {
        val e = elm ?: return log("No conectado")
        viewModelScope.launch {
            try { log("> $cmd\n" + e.send(cmd.trim().uppercase(), 5000).ifEmpty { "(sin respuesta)" }) }
            catch (ex: Exception) { disconnect("Error: ${ex.message}") }
        }
    }

    // ------------------------------------------------------------ Utilidades

    private fun setStatus(s: String) { _state.update { it.copy(status = s) }; log(s) }

    private fun log(s: String) {
        val line = "${timeFmt.format(Date())}  $s"
        _state.update { it.copy(log = (it.log + line).takeLast(400)) }
    }

    override fun onCleared() {
        disconnect()
        try { getApplication<Application>().unregisterReceiver(receiver) } catch (_: Exception) { }
    }

    companion object {
        const val ACTION_PERMISSION = "com.ikker.obdibiza.USB_PERMISSION"
    }
}
