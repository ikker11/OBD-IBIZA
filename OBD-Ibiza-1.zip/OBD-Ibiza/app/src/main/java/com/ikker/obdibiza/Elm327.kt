package com.ikker.obdibiza

import android.hardware.usb.UsbDeviceConnection
import com.hoho.android.usbserial.driver.UsbSerialPort
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.IOException

/**
 * Comunicación con un adaptador ELM327 (u OBDLink/STN compatible) por USB-serie.
 * Todas las órdenes pasan por un Mutex, así el sondeo en tiempo real y las órdenes
 * manuales (leer averías, consola…) nunca se pisan.
 */
class Elm327(
    private val port: UsbSerialPort,
    private val connection: UsbDeviceConnection,
    private val onLog: (String) -> Unit,
) {
    private val lock = Mutex()
    private val buf = ByteArray(1024)
    var logTraffic = false

    suspend fun send(cmd: String, timeoutMs: Long = 2500): String = lock.withLock {
        withContext(Dispatchers.IO) { raw(cmd, timeoutMs) }
    }

    @Throws(IOException::class)
    private fun raw(cmd: String, timeoutMs: Long): String {
        // Vaciar restos de respuestas anteriores
        try {
            var guard = 0
            while (port.read(buf, 20) > 0 && guard++ < 20) { /* descartar */ }
        } catch (_: Exception) { }

        port.write((cmd + "\r").toByteArray(Charsets.US_ASCII), 1000)
        val sb = StringBuilder()
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            val n = port.read(buf, 100)
            if (n > 0) {
                sb.append(String(buf, 0, n, Charsets.ISO_8859_1))
                if (sb.indexOf(">") >= 0) break
            }
        }
        val cleaned = sb.toString()
            .replace(">", "")
            .replace("\u0000", "")
            .split('\r', '\n')
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.equals(cmd, ignoreCase = true) }
            .filterNot { it.startsWith("SEARCHING", true) || it.startsWith("BUS INIT", true) }
            .joinToString("\n")
        if (logTraffic) onLog("> $cmd\n${cleaned.ifEmpty { "(sin respuesta)" }}")
        return cleaned
    }

    /** Busca la velocidad del adaptador probando las más habituales. Devuelve la versión o null. */
    suspend fun detect(): String? {
        for (baud in listOf(38400, 115200, 9600, 230400, 57600, 500000)) {
            try {
                port.setParameters(baud, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            } catch (_: Exception) { continue }
            onLog("Probando $baud baudios…")
            send("", 300)
            val r = send("ATZ", 2500)
            if (r.contains("ELM", true) || r.contains("STN", true) || r.contains("OBDLINK", true)) {
                onLog("Adaptador encontrado a $baud baudios: $r")
                return r.lines().lastOrNull { it.contains("ELM", true) || it.contains("STN", true) || it.contains("OBD", true) } ?: r
            }
        }
        return null
    }

    fun close() {
        try { port.close() } catch (_: Exception) { }
        try { connection.close() } catch (_: Exception) { }
    }

    companion object {
        private val ERRORS = listOf("NO DATA", "UNABLE TO CONNECT", "CAN ERROR", "BUS ERROR", "STOPPED", "ERROR", "?")

        fun isError(r: String) = r.isBlank() || ERRORS.any { r.trim().uppercase().startsWith(it) }

        private val frameIndex = Regex("^[0-9A-F]:")

        /** Convierte la respuesta en mensajes (lista de bytes). Junta tramas CAN multi-frame. */
        fun messages(resp: String): List<IntArray> {
            val lines = resp.uppercase().lines().map { it.replace(" ", "") }.filter { it.isNotEmpty() }
            val multi = lines.any { frameIndex.containsMatchIn(it) }
            val hexLines = if (multi) {
                listOf(lines.filter { frameIndex.containsMatchIn(it) }.joinToString("") { it.substring(2) })
            } else lines
            return hexLines.mapNotNull { l ->
                if (l.isEmpty() || l.length % 2 != 0 || !l.all { it in "0123456789ABCDEF" }) null
                else IntArray(l.length / 2) { i -> l.substring(i * 2, i * 2 + 2).toInt(16) }
            }
        }

        /** Datos de un PID del modo 01 ("41 PID A B …"). */
        fun mode01(resp: String, pid: Int): IntArray? {
            val need = Params.bytesFor(pid)
            for (m in messages(resp)) {
                if (m.size >= 2 + need && m[0] == 0x41 && m[1] == pid) return m.copyOfRange(2, 2 + need)
            }
            return null
        }

        /** Mapa de PIDs soportados (0100, 0120, …). */
        fun supported(resp: String, base: Int): Set<Int> {
            val out = mutableSetOf<Int>()
            for (m in messages(resp)) {
                if (m.size >= 6 && m[0] == 0x41 && m[1] == base) {
                    for (i in 0 until 32) {
                        val byte = m[2 + i / 8]
                        if (byte and (0x80 shr (i % 8)) != 0) out += base + i + 1
                    }
                }
            }
            return out
        }

        /** Respuesta a "0100": PIDs 01-20 soportados, o null si el coche no ha contestado. */
        fun mode01Supported(resp: String): Set<Int>? =
            if (messages(resp).any { it.size >= 6 && it[0] == 0x41 && it[1] == 0x00 }) supported(resp, 0x00) else null

        /** Códigos de avería de los modos 03 (43), 07 (47) o 0A (4A). */
        fun dtcs(resp: String, header: Int): List<String> {
            val out = linkedSetOf<String>()
            for (m in messages(resp)) {
                if (m.isEmpty() || m[0] != header) continue
                var data = m.copyOfRange(1, m.size)
                // En CAN el primer byte es el número de códigos (quedaría impar)
                if (data.size % 2 == 1) data = data.copyOfRange(1, data.size)
                var i = 0
                while (i + 1 < data.size) {
                    val a = data[i]; val b = data[i + 1]
                    if (a != 0 || b != 0) out += decodeDtc(a, b)
                    i += 2
                }
            }
            return out.toList()
        }

        fun decodeDtc(a: Int, b: Int): String {
            val letter = "PCBU"[a shr 6]
            return "%c%d%X%02X".format(letter, (a shr 4) and 0x3, a and 0xF, b)
        }

        /** Número de bastidor (modo 09 PID 02). */
        fun vin(resp: String): String? {
            val bytes = messages(resp).flatMap { it.toList() }
            val idx = bytes.windowed(2).indexOfFirst { it[0] == 0x49 && it[1] == 0x02 }
            if (idx < 0) return null
            val chars = bytes.drop(idx + 2)
                .filter { it in 0x30..0x5A }
                .map { it.toChar() }
                .joinToString("")
            return if (chars.length >= 17) chars.takeLast(17) else chars.ifEmpty { null }
        }
    }
}
