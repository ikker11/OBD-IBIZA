package com.ikker.obdibiza

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

// ------------------------------------------------------------------ Colores "racing"

object C {
    val bg = Color(0xFF0B0B0D)
    val panel = Color(0xFF151518)
    val panel2 = Color(0xFF1D1D22)
    val line = Color(0xFF2A2A31)
    val red = Color(0xFFE10600)
    val redDark = Color(0xFF7A0400)
    val amber = Color(0xFFFFB300)
    val green = Color(0xFF00D26A)
    val text = Color(0xFFF2F2F2)
    val dim = Color(0xFF8C8C96)
}

private val Mono = FontFamily.Monospace

enum class Screen(val label: String) { PANEL("PANEL"), DATOS("DATOS"), AVERIAS("AVERÍAS"), VEHICULO("COCHE"), CONSOLA("CONSOLA") }

@Composable
fun ObdApp(vm: ObdViewModel) {
    val st by vm.state.collectAsStateWithLifecycle()
    var screen by rememberSaveable { mutableStateOf(Screen.PANEL) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.red, onPrimary = Color.White, background = C.bg, surface = C.panel,
            onSurface = C.text, onBackground = C.text, surfaceVariant = C.panel2,
        )
    ) {
        Surface(color = C.bg, modifier = Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                TopBar(st, onConnect = vm::connect, onDemo = vm::startDemo, onDisconnect = { vm.disconnect() })
                Row(Modifier.fillMaxSize()) {
                    NavRail(screen, st) { screen = it }
                    Box(Modifier.weight(1f).fillMaxHeight().padding(10.dp)) {
                        when (screen) {
                            Screen.PANEL -> DashboardScreen(st, vm)
                            Screen.DATOS -> DataScreen(st, vm)
                            Screen.AVERIAS -> DtcScreen(st, vm)
                            Screen.VEHICULO -> VehicleScreen(st)
                            Screen.CONSOLA -> ConsoleScreen(st, vm)
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Barra superior

@Composable
private fun TopBar(st: UiState, onConnect: () -> Unit, onDemo: () -> Unit, onDisconnect: () -> Unit) {
    val dot = when (st.conn) {
        Conn.CONECTADO -> C.green
        Conn.CONECTANDO -> C.amber
        Conn.DESCONECTADO -> C.red
    }
    Row(
        Modifier
            .fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(C.redDark, C.bg, C.bg)))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "OBD", color = C.red, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, fontSize = 22.sp,
        )
        Text(
            " IBIZA", color = C.text, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, fontSize = 22.sp,
        )
        Text("  2.0 TDI", color = C.dim, fontStyle = FontStyle.Italic, fontSize = 13.sp)
        Spacer(Modifier.width(16.dp))
        Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(dot))
        Spacer(Modifier.width(8.dp))
        Text(
            st.status, color = C.text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        if (st.conn == Conn.CONECTADO) {
            Text("%.1f lect/s".format(st.refreshHz), color = C.dim, fontFamily = Mono, fontSize = 12.sp)
            Spacer(Modifier.width(12.dp))
        }
        if (st.conn == Conn.DESCONECTADO) {
            RaceButton("DEMO", outlined = true, color = C.dim, onClick = onDemo)
            Spacer(Modifier.width(8.dp))
            RaceButton("CONECTAR", onClick = onConnect)
        } else {
            RaceButton("DESCONECTAR", outlined = true, onClick = onDisconnect)
        }
    }
}

@Composable
private fun NavRail(current: Screen, st: UiState, onSelect: (Screen) -> Unit) {
    Column(
        Modifier.fillMaxHeight().width(92.dp).background(C.panel).padding(vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Screen.values().forEach { s ->
            val sel = s == current
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .clickable { onSelect(s) }
                    .background(if (sel) C.panel2 else Color.Transparent),
                contentAlignment = Alignment.Center,
            ) {
                if (sel) Box(Modifier.align(Alignment.CenterStart).width(4.dp).fillMaxHeight().background(C.red))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        s.label, color = if (sel) C.text else C.dim, fontWeight = FontWeight.Bold,
                        fontStyle = FontStyle.Italic, fontSize = 12.sp,
                    )
                    if (s == Screen.AVERIAS && st.mil == true) {
                        Text("● MIL", color = C.amber, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun RaceButton(text: String, outlined: Boolean = false, enabled: Boolean = true, color: Color = C.red, onClick: () -> Unit) {
    val shape = RoundedCornerShape(6.dp)
    Box(
        Modifier
            .clip(shape)
            .then(if (outlined) Modifier.border(1.5.dp, color, shape) else Modifier.background(if (enabled) color else C.line))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text, color = if (outlined) color else Color.White, fontWeight = FontWeight.Black,
            fontStyle = FontStyle.Italic, fontSize = 13.sp,
        )
    }
}

// ------------------------------------------------------------------ Relojes

@Composable
fun Gauge(param: Param, value: Double?, peak: Double?, modifier: Modifier = Modifier) {
    val frac = if (value == null) 0f else ((value - param.min) / (param.max - param.min)).toFloat().coerceIn(0f, 1f)
    val anim by animateFloatAsState(frac, tween(180), label = "g")
    val warn = param.isWarning(value)
    val arcColor by animateColorAsState(if (warn) C.amber else C.red, label = "c")
    val redFrom = param.warnHigh?.let { ((it - param.min) / (param.max - param.min)).toFloat().coerceIn(0f, 1f) }

    Box(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.verticalGradient(listOf(C.panel2, C.panel)))
            .border(1.dp, if (warn) C.amber else C.line, RoundedCornerShape(12.dp))
            .padding(8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = size.minDimension * 0.07f
            val d = min(size.width, size.height) - stroke * 2
            val topLeft = Offset((size.width - d) / 2, (size.height - d) / 2 + stroke * 0.6f)
            val arcSize = Size(d, d)
            val start = 150f
            val sweep = 240f
            drawArc(C.line, start, sweep, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            if (redFrom != null) {
                drawArc(
                    C.redDark, start + sweep * redFrom, sweep * (1 - redFrom), false, topLeft, arcSize,
                    style = Stroke(stroke, cap = StrokeCap.Butt),
                )
            }
            // Marcas
            val c = Offset(topLeft.x + d / 2, topLeft.y + d / 2)
            val rOut = d / 2 - stroke * 1.2f
            for (i in 0..10) {
                val a = Math.toRadians((start + sweep * i / 10.0))
                val rIn = rOut - if (i % 5 == 0) stroke * 0.9f else stroke * 0.5f
                drawLine(
                    C.dim,
                    Offset(c.x + (rIn * cos(a)).toFloat(), c.y + (rIn * sin(a)).toFloat()),
                    Offset(c.x + (rOut * cos(a)).toFloat(), c.y + (rOut * sin(a)).toFloat()),
                    strokeWidth = 2f,
                )
            }
            if (value != null) {
                drawArc(
                    Brush.sweepGradient(listOf(arcColor.copy(alpha = 0.6f), arcColor), c),
                    start, sweep * anim, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round),
                )
                // Aguja-punto
                val a = Math.toRadians((start + sweep * anim).toDouble())
                val r = d / 2
                drawCircle(Color.White, stroke * 0.45f, Offset(c.x + (r * cos(a)).toFloat(), c.y + (r * sin(a)).toFloat()))
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(param.short, color = C.dim, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic)
            Text(
                param.format(value), color = if (warn) C.amber else C.text, fontFamily = Mono,
                fontWeight = FontWeight.Bold, fontSize = 34.sp, maxLines = 1,
            )
            Text(param.unit, color = C.dim, fontSize = 12.sp)
        }
        if (peak != null) {
            Text(
                "MÁX ${param.format(peak)}", color = C.dim, fontFamily = Mono, fontSize = 10.sp,
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }
    }
}

// ------------------------------------------------------------------ PANEL

@Composable
private fun DashboardScreen(st: UiState, vm: ObdViewModel) {
    var editing by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("COLUMNAS", color = C.dim, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            for (n in 2..5) {
                RaceButton("$n", outlined = st.columns != n, color = if (st.columns == n) C.red else C.dim) { vm.setColumns(n) }
            }
            Spacer(Modifier.weight(1f))
            RaceButton("MÁX ↺", outlined = true, color = C.dim) { vm.resetPeaks() }
            RaceButton("PERSONALIZAR") { editing = true }
        }
        Spacer(Modifier.height(10.dp))
        if (st.dashboard.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Pulsa PERSONALIZAR y elige los datos que quieres ver", color = C.dim)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(st.columns),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(st.dashboard, key = { it }) { id ->
                    val p = Params.byId[id] ?: return@items
                    Gauge(p, st.values[id], st.peaks[id], Modifier.aspectRatio(1f))
                }
            }
        }
    }
    if (editing) CustomizeDialog(st, onSave = { vm.setDashboard(it); editing = false }, onDismiss = { editing = false })
}

@Composable
private fun CustomizeDialog(st: UiState, onSave: (List<String>) -> Unit, onDismiss: () -> Unit) {
    val selected = remember { mutableStateListOf<String>().apply { addAll(st.dashboard) } }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth(0.94f).fillMaxHeight(0.92f).clip(RoundedCornerShape(14.dp)).background(C.panel).padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "PERSONALIZAR PANEL", color = C.text, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic,
                    fontSize = 18.sp, modifier = Modifier.weight(1f),
                )
                RaceButton("CANCELAR", outlined = true, color = C.dim, onClick = onDismiss)
                Spacer(Modifier.width(8.dp))
                RaceButton("GUARDAR") { onSave(selected.toList()) }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                // En el panel (orden)
                Column(Modifier.weight(1f).fillMaxHeight()) {
                    Text("EN EL PANEL (${selected.size})", color = C.red, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                        itemsIndexed(selected.toList(), key = { _, id -> id }) { i, id ->
                            val p = Params.byId[id] ?: return@itemsIndexed
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(C.panel2).padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text("${i + 1}.", color = C.dim, fontFamily = Mono, modifier = Modifier.width(32.dp))
                                Text(p.name, color = C.text, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                SmallBtn("▲", i > 0) { selected.removeAt(i); selected.add(i - 1, id) }
                                SmallBtn("▼", i < selected.size - 1) { selected.removeAt(i); selected.add(i + 1, id) }
                                SmallBtn("✕", true, C.red) { selected.remove(id) }
                            }
                        }
                    }
                }
                // Disponibles
                Column(Modifier.weight(1f).fillMaxHeight()) {
                    Text("AÑADIR", color = C.red, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                        Category.values().forEach { cat ->
                            val avail = Params.all.filter { it.category == cat && it.id !in selected }
                            if (avail.isNotEmpty()) {
                                item(key = "h_${cat.name}") {
                                    Text(cat.title.uppercase(), color = C.dim, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                                }
                                items(avail, key = { it.id }) { p ->
                                    val unsupported = isUnsupported(p, st)
                                    Row(
                                        Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(C.panel2)
                                            .clickable { selected.add(p.id) }.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Column(Modifier.weight(1f)) {
                                            Text(p.name, color = if (unsupported) C.dim else C.text)
                                            if (unsupported) Text("Tu coche no lo da por OBD", color = C.dim, fontSize = 11.sp)
                                        }
                                        Text("＋", color = C.red, fontWeight = FontWeight.Black, fontSize = 18.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun isUnsupported(p: Param, st: UiState): Boolean {
    if (st.supportedPids.isEmpty()) return false
    val pid = when (p.id) { Params.BOOST -> 0x0B; Params.BATTERY -> return false; else -> p.pid ?: return false }
    return pid !in st.supportedPids
}

@Composable
private fun SmallBtn(t: String, enabled: Boolean, color: Color = C.text, onClick: () -> Unit) {
    Box(
        Modifier.size(38.dp).clip(RoundedCornerShape(6.dp)).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(t, color = if (enabled) color else C.line, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
}

// ------------------------------------------------------------------ DATOS (submenús)

@Composable
private fun DataScreen(st: UiState, vm: ObdViewModel) {
    var cat by rememberSaveable { mutableStateOf<Category?>(null) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RaceButton("TODOS", outlined = cat != null, color = if (cat == null) C.red else C.dim) { cat = null }
            Category.values().forEach { c ->
                RaceButton(c.title.uppercase(), outlined = cat != c, color = if (cat == c) C.red else C.dim) { cat = c }
            }
        }
        Spacer(Modifier.height(10.dp))
        val list = Params.all.filter { (cat == null || it.category == cat) }
            .sortedBy { isUnsupported(it, st) }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(list, key = { it.id }) { p ->
                val v = st.values[p.id]
                val unsupported = isUnsupported(p, st)
                val inPanel = p.id in st.dashboard
                val frac = if (v == null) 0f else ((v - p.min) / (p.max - p.min)).toFloat().coerceIn(0f, 1f)
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(C.panel).padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, color = if (unsupported) C.dim else C.text, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (unsupported) "No disponible en tu coche por OBD-II"
                            else p.category.title + (st.peaks[p.id]?.let { "  ·  máx ${p.format(it)} ${p.unit}" } ?: ""),
                            color = C.dim, fontSize = 11.sp,
                        )
                        if (!unsupported) {
                            Box(Modifier.padding(top = 6.dp).fillMaxWidth(0.9f).height(4.dp).clip(RoundedCornerShape(2.dp)).background(C.line)) {
                                Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(if (p.isWarning(v)) C.amber else C.red))
                            }
                        }
                    }
                    Text(
                        p.format(v), color = if (p.isWarning(v)) C.amber else C.text, fontFamily = Mono,
                        fontWeight = FontWeight.Bold, fontSize = 26.sp, textAlign = TextAlign.End, modifier = Modifier.width(140.dp),
                    )
                    Text(" " + p.unit, color = C.dim, fontSize = 13.sp, modifier = Modifier.width(52.dp))
                    RaceButton(
                        if (inPanel) "EN PANEL" else "+ PANEL", outlined = !inPanel,
                        color = if (inPanel) C.red else C.dim,
                    ) {
                        vm.setDashboard(if (inPanel) st.dashboard - p.id else st.dashboard + p.id)
                    }
                }
            }
            item {
                Text(
                    "Los datos que no están en el panel se van actualizando por turnos (uno en cada vuelta) para no frenar el panel.",
                    color = C.dim, fontSize = 11.sp, modifier = Modifier.padding(8.dp),
                )
            }
        }
    }
}

// ------------------------------------------------------------------ AVERÍAS

@Composable
private fun DtcScreen(st: UiState, vm: ObdViewModel) {
    var confirm by remember { mutableStateOf(false) }
    val connected = st.conn == Conn.CONECTADO
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            val milColor = when (st.mil) { true -> C.amber; false -> C.green; null -> C.dim }
            Box(
                Modifier.clip(RoundedCornerShape(8.dp)).border(1.5.dp, milColor, RoundedCornerShape(8.dp)).padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(
                    when (st.mil) {
                        true -> "TESTIGO MOTOR ENCENDIDO · ${st.dtcCount ?: 0} códigos"
                        false -> "TESTIGO MOTOR APAGADO · ${st.dtcCount ?: 0} códigos"
                        null -> "ESTADO DESCONOCIDO"
                    },
                    color = milColor, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                )
            }
            Spacer(Modifier.weight(1f))
            RaceButton("LEER AVERÍAS", enabled = connected && !st.dtcBusy) { vm.readDtcs() }
            RaceButton("BORRAR AVERÍAS", outlined = true, enabled = connected && !st.dtcBusy) { if (connected) confirm = true }
        }
        if (st.dtcMessage.isNotEmpty()) {
            Text(st.dtcMessage, color = C.text, modifier = Modifier.padding(vertical = 10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
            dtcSection("GUARDADAS (confirmadas)", st.dtcs, C.red)
            dtcSection("PENDIENTES (detectadas, aún sin confirmar)", st.pendingDtcs, C.amber)
            dtcSection("PERMANENTES (se borran solas al repararse)", st.permanentDtcs, C.dim)
            item {
                Text(
                    "Se lee la centralita de motor por OBD-II estándar. ABS, airbag, confort, etc. usan diagnosis propia de VAG y no aparecen aquí.",
                    color = C.dim, fontSize = 11.sp, modifier = Modifier.padding(top = 12.dp),
                )
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            containerColor = C.panel,
            title = { Text("¿Borrar códigos de avería?", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Hazlo con el contacto puesto y el motor PARADO.\n\n" +
                        "Se apagará el testigo y se reiniciarán los monitores de preparación (necesarios para pasar la ITV) " +
                        "hasta que conduzcas un tiempo. Si la avería sigue, el código volverá a salir."
                )
            },
            confirmButton = { RaceButton("BORRAR") { confirm = false; vm.clearDtcs() } },
            dismissButton = { RaceButton("CANCELAR", outlined = true, color = C.dim) { confirm = false } },
        )
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.dtcSection(title: String, codes: List<String>?, color: Color) {
    item(key = "t_$title") {
        Text(title, color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
    }
    when {
        codes == null -> item(key = "n_$title") { Text("Sin leer todavía", color = C.dim, fontSize = 13.sp) }
        codes.isEmpty() -> item(key = "e_$title") { Text("Ninguna ✔", color = C.green, fontSize = 13.sp) }
        else -> items(codes, key = { "$title$it" }) { code ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(C.panel).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(code, color = color, fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.width(110.dp))
                Text(DtcInfo.describe(code), color = C.text)
            }
        }
    }
}

// ------------------------------------------------------------------ COCHE

@Composable
private fun VehicleScreen(st: UiState) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { InfoRow("Vehículo", "SEAT Ibiza (6J) · 2.0 TDI CR · motor CFHD · 2011") }
        item { InfoRow("Bastidor (VIN)", st.vin.ifEmpty { "—" }) }
        item { InfoRow("Protocolo", st.protocol.ifEmpty { "—" }) }
        item { InfoRow("Adaptador", st.adapter.ifEmpty { "—" }) }
        item { InfoRow("Datos disponibles por OBD", if (st.supportedPids.isEmpty()) "—" else "${st.supportedPids.size} PIDs") }
        item { InfoRow("Batería", st.values[Params.BATTERY]?.let { "%.1f V".format(it) } ?: "—") }
        item {
            Text(
                "Consejo: con el motor parado la batería debería marcar unos 12,4–12,7 V; arrancado, 13,8–14,6 V.",
                color = C.dim, fontSize = 12.sp, modifier = Modifier.padding(8.dp),
            )
        }
    }
}

@Composable
private fun InfoRow(k: String, v: String) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(C.panel).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(k.uppercase(), color = C.dim, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(220.dp))
        Text(v, color = C.text, fontFamily = Mono, fontSize = 16.sp)
    }
}

// ------------------------------------------------------------------ CONSOLA

@Composable
private fun ConsoleScreen(st: UiState, vm: ObdViewModel) {
    var cmd by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(st.log.size) { if (st.log.isNotEmpty()) listState.scrollToItem(st.log.size - 1) }
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Ver todo el tráfico OBD", color = C.text, modifier = Modifier.weight(1f))
            Switch(
                checked = st.traffic, onCheckedChange = vm::setTraffic,
                colors = SwitchDefaults.colors(checkedTrackColor = C.red),
            )
        }
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color.Black).padding(8.dp),
        ) {
            items(st.log) { Text(it, color = C.green, fontFamily = Mono, fontSize = 12.sp) }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = cmd, onValueChange = { cmd = it }, singleLine = true,
                placeholder = { Text("Orden ELM327 (ej. ATRV, 010C, 03)") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { if (cmd.isNotBlank()) { vm.sendRaw(cmd); cmd = "" } }),
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(8.dp))
            RaceButton("ENVIAR") { if (cmd.isNotBlank()) { vm.sendRaw(cmd); cmd = "" } }
        }
    }
}
