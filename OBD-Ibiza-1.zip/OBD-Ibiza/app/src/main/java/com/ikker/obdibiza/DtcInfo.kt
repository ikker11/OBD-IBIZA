package com.ikker.obdibiza

/** Descripciones en español de códigos genéricos habituales en un 2.0 TDI common rail. */
object DtcInfo {
    private val known = mapOf(
        "P0016" to "Correlación cigüeñal / árbol de levas",
        "P0087" to "Presión del rail demasiado baja",
        "P0088" to "Presión del rail demasiado alta",
        "P0089" to "Regulador de presión de combustible: funcionamiento",
        "P0093" to "Fuga de combustible detectada",
        "P0100" to "Caudalímetro (MAF): circuito",
        "P0101" to "Caudalímetro (MAF): rango / funcionamiento",
        "P0102" to "Caudalímetro (MAF): señal baja",
        "P0103" to "Caudalímetro (MAF): señal alta",
        "P0106" to "Sensor de presión de colector (MAP): rango",
        "P0110" to "Sensor temperatura aire admisión: circuito",
        "P0115" to "Sensor temperatura refrigerante: circuito",
        "P0116" to "Sensor temperatura refrigerante: rango",
        "P0117" to "Sensor temperatura refrigerante: señal baja",
        "P0118" to "Sensor temperatura refrigerante: señal alta",
        "P0128" to "Termostato: temperatura por debajo de la de regulación",
        "P0190" to "Sensor de presión del rail: circuito",
        "P0201" to "Inyector cilindro 1: circuito",
        "P0202" to "Inyector cilindro 2: circuito",
        "P0203" to "Inyector cilindro 3: circuito",
        "P0204" to "Inyector cilindro 4: circuito",
        "P0234" to "Sobrepresión del turbo",
        "P0299" to "Presión del turbo insuficiente",
        "P0335" to "Sensor de cigüeñal: circuito",
        "P0340" to "Sensor de árbol de levas: circuito",
        "P0380" to "Calentadores (bujías incandescentes): circuito",
        "P0381" to "Testigo de calentadores: circuito",
        "P0400" to "EGR: caudal",
        "P0401" to "EGR: caudal insuficiente",
        "P0402" to "EGR: caudal excesivo",
        "P0403" to "Válvula EGR: circuito",
        "P0404" to "Válvula EGR: rango / funcionamiento",
        "P0409" to "Sensor de la EGR: circuito",
        "P0470" to "Sensor de presión de escape: circuito",
        "P0471" to "Sensor de presión de escape: rango",
        "P0500" to "Sensor de velocidad del vehículo",
        "P0545" to "Sensor temperatura de escape: señal baja",
        "P0546" to "Sensor temperatura de escape: señal alta",
        "P0560" to "Tensión del sistema",
        "P0562" to "Tensión del sistema baja",
        "P0563" to "Tensión del sistema alta",
        "P0571" to "Interruptor de freno: circuito",
        "P0606" to "Centralita de motor: procesador",
        "P0670" to "Módulo de calentadores: circuito",
        "P0671" to "Calentador cilindro 1: circuito",
        "P0672" to "Calentador cilindro 2: circuito",
        "P0673" to "Calentador cilindro 3: circuito",
        "P0674" to "Calentador cilindro 4: circuito",
        "P0700" to "Cambio: avería registrada en la centralita del cambio",
        "P1403" to "EGR (fabricante): desviación de control",
        "P2002" to "Filtro de partículas (FAP): eficiencia por debajo del umbral",
        "P2015" to "Mariposas del colector: sensor de posición",
        "P2263" to "Sistema de turbo: funcionamiento",
        "P2425" to "Refrigeración EGR: válvula de control",
        "P242F" to "Filtro de partículas: restricción por acumulación de ceniza",
        "P2452" to "Sensor de presión diferencial del FAP: circuito",
        "P2453" to "Sensor de presión diferencial del FAP: rango",
        "P2463" to "Filtro de partículas: acumulación de hollín",
        "P2563" to "Sensor de posición del turbo (geometría variable): rango",
        "U0001" to "Bus CAN de alta velocidad",
        "U0100" to "Sin comunicación con la centralita de motor",
        "U0101" to "Sin comunicación con la centralita del cambio",
        "U0121" to "Sin comunicación con el ABS",
        "U0155" to "Sin comunicación con el cuadro de instrumentos",
    )

    fun describe(code: String): String {
        known[code]?.let { return it }
        val system = when (code.first()) {
            'P' -> "Motor / transmisión"
            'C' -> "Chasis"
            'B' -> "Carrocería"
            else -> "Red de comunicación"
        }
        val manufacturer = code.getOrNull(1) == '1' || code.getOrNull(1) == '3'
        return "$system — ${if (manufacturer) "código específico de VW/Seat" else "código genérico"} (búscalo con el código exacto)"
    }
}
