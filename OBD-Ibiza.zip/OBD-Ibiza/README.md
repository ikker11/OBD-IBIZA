# OBD Ibiza

App para tablet / pantalla Android de coche que lee la OBD del **SEAT Ibiza 6J 2.0 TDI (CFHD) de 2011** con un cable **ELM327 USB** (u OBDLink SX).

## Funciones
- **Panel deportivo personalizable**: tú eliges qué relojes salen, en qué orden y en cuántas columnas (2–5). Marca el valor máximo de cada reloj.
- **Datos**: submenús (Motor, Turbo y admisión, Combustible, Temperaturas, Eléctrico, Estadísticas) con todos los parámetros.
- **Averías**: lectura de códigos guardados, pendientes y permanentes (OBD) y de la **memoria propia de la centralita de VAG** (la que leen Autel o VCDS), con descripción en español y si cada fallo sigue activo o ya está resuelto. **BORRAR** limpia las dos memorias de la centralita (OBD modo 04 y UDS 14 FF FF FF) y después comprueba qué ha quedado.
- **Ficha técnica de cada avería** (toca la avería): título normalizado SAE, componente con su referencia VAG (G70, N75, G450…), tipo de fallo que da la centralita (circuito abierto, cortocircuito a masa…), estado (activa, confirmada, pendiente, testigo), gravedad, efecto en el coche, causas de más a menos probables y comprobaciones. 95 averías de 2.0 TDI common rail con ficha completa.
- **Coche**: bastidor (VIN), protocolo, adaptador, batería.
- **Consola**: para mandar órdenes ELM327 a mano y ver el tráfico.
- Se abre sola y se conecta al enchufar el cable USB. Pantalla siempre encendida.
- **Segundo plano**: la conexión vive en un servicio, así que puedes salir a la radio, YouTube o el GPS sin que se desconecte. Solo el botón DESCONECTAR la apaga.
- **Reconexión automática**: si se pierde (o el coche está apagado), reintenta sola cada pocos segundos, sin quitar ni poner el cable. Recuerda la velocidad del adaptador para conectar antes.
- **Límite de velocidad (GPS + OpenStreetMap)**: con el GPS de la pantalla busca la vía por la que vas y enseña su límite como una señal dentro del reloj de velocidad, con una marca roja en la escala. Si te pasas (más el margen que elijas), el reloj parpadea en rojo y, si quieres, pita. Si el mapa no tiene el límite, lo deduce por el tipo de vía ("aprox.", aro discontinuo). Necesita internet en la pantalla (datos compartidos del móvil). Se configura en Ajustes → Límite de velocidad.
- **Presión del turbo precisa**: el dato OBD estándar (010B) no pasa de 255 kPa, unos 1,54 bar de turbo. En Ajustes → Presión del turbo → BUSCAR, la app encuentra en la centralita la presión real y la ambiental en hPa (las mismas que leen Autel o VCDS), las confirma sola mientras conduces y desde entonces las usa sin tope y con precisión de 1 hPa. Si el coche da los PID ampliados 0170/0187 se usan directamente. Mientras se use el dato estándar, el reloj avisa cuando llega a su tope.
- **Temperatura del aceite**: fija, siempre de la centralita de motor con el identificador **22 11 BE** y la fórmula (A·256 + B − 2731) / 10 °C, con décimas. Comprobada con Autel. No se busca ni se puede cambiar, y no se usa el PID estándar 015C.

## Conseguir el APK
Cada vez que se sube un cambio a GitHub, la pestaña **Actions** compila la app y la publica en **Releases** como `OBD-Ibiza.apk`.
Descárgalo desde la tablet e instálalo (permite “instalar apps de origen desconocido”).
Las versiones nuevas se instalan encima sin desinstalar la anterior.

## Cable compatible
- Recomendado: **OBDLink SX USB**.
- Económico: **ELM327 USB con chips FTDI FT232RL + PIC18F25K80**.
- **No** sirven los cables VAG-COM / KKL 409.1.
