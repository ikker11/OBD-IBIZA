# OBD Ibiza

App para tablet / pantalla Android de coche que lee la OBD del **SEAT Ibiza 6J 2.0 TDI (CFHD) de 2011** con un cable **ELM327 USB** (u OBDLink SX).

## Funciones
- **Panel deportivo personalizable**: tú eliges qué relojes salen, en qué orden y en cuántas columnas (2–5). Marca el valor máximo de cada reloj.
- **Datos**: submenús (Motor, Turbo y admisión, Combustible, Temperaturas, Eléctrico, Estadísticas) con todos los parámetros.
- **Averías como en un equipo de taller**: centralita de motor con su estado (correcto / N averías); al abrirla, sus apartados (admisión y turbo, inyección, EGR, filtro de partículas…) y en cada uno los componentes con «Correcto» o su avería. Lee la memoria OBD y la propia de VAG (solo averías reales: activas, pendientes o confirmadas). Se leen solas al conectar y la última lectura se guarda: lo borrado sigue borrado al volver a arrancar. **BORRAR** limpia las dos memorias de la centralita y comprueba qué ha quedado.
- **Ficha técnica de cada avería** (toca la avería): título normalizado SAE, componente con su referencia VAG (G70, N75, G450…), tipo de fallo que da la centralita (circuito abierto, cortocircuito a masa…), estado (activa, confirmada, pendiente, testigo), gravedad, efecto en el coche, causas de más a menos probables y comprobaciones. 95 averías de 2.0 TDI common rail con ficha completa.
- **Coche**: bastidor (VIN), protocolo, adaptador, batería.
- **Consola**: para mandar órdenes ELM327 a mano y ver el tráfico.
- Se abre sola y se conecta al enchufar el cable USB. Pantalla siempre encendida.
- **Segundo plano**: la conexión vive en un servicio, así que puedes salir a la radio, YouTube o el GPS sin que se desconecte. Solo el botón DESCONECTAR la apaga.
- **Reconexión automática**: si se pierde (o el coche está apagado), reintenta sola cada pocos segundos, sin quitar ni poner el cable. Recuerda la velocidad del adaptador para conectar antes.
- **Límite de velocidad (GPS + OpenStreetMap)**: con el GPS de la pantalla busca la vía por la que vas y enseña su límite como una señal dentro del reloj de velocidad, con una marca roja en la escala. Si te pasas (más el margen que elijas), el reloj parpadea en rojo y, si quieres, pita. Si el mapa no tiene el límite, lo deduce por el tipo de vía ("aprox.", aro discontinuo). **Funciona sin internet**: la app trae integrado el mapa de toda la **Comunitat Valenciana** (OpenStreetMap, Geofabrik, datos del 2-nov-2026: 222.371 vías). Para otras zonas, importando un mapa preparado (Ajustes → Límite de velocidad → IMPORTAR) o descargando los alrededores una vez con wifi (DESCARGAR, 25/50/100 km). Las zonas nuevas por las que pases con internet se guardan solas.
- **Corregir el límite**: si una señal no coincide, toca el reloj de velocidad (o Ajustes → Límite → CORREGIR), elige el límite real y queda guardado para ese tramo o para toda la calle. **Actualizar con wifi** (Ajustes → Mapa): baja solas las mejoras del mapa de los alrededores, o al momento con ACTUALIZAR.
- **Radares**: los 180 radares fijos de la Comunitat Valenciana vienen en la app (OpenStreetMap). Aviso del que tienes delante, a la distancia que elijas (300 m – 2 km, por defecto 1 km): la señal de velocidad parpadea y suena un aviso. Ajustes → Radares: distancia, tipo de sonido, repetición, volumen, parpadeo y apagar los avisos.
- **Diagnóstico USB** (Ajustes): datos de la pantalla y su chip, comprobación de root, botón REINICIAR USB (solo el USB, sin reiniciar la pantalla; necesita root) y opción de reiniciarlo solo cuando se cuelga. **Registro de desconexiones**: hora de cada fallo, tensión de la batería, si la pantalla venía de apagarse y, con root, los mensajes del sistema sobre el USB; se puede copiar.
- **Presión del turbo precisa**: el dato OBD estándar (010B) no pasa de 255 kPa, unos 1,54 bar de turbo. En Ajustes → Presión del turbo → BUSCAR, la app encuentra en la centralita la presión real y la ambiental en hPa (las mismas que leen Autel o VCDS), las confirma sola mientras conduces y desde entonces las usa sin tope y con precisión de 1 hPa. Si el coche da los PID ampliados 0170/0187 se usan directamente. Mientras se use el dato estándar, el reloj avisa cuando llega a su tope.
- **Temperatura del aceite**: fija, siempre de la centralita de motor con el identificador **22 11 BE** y la fórmula (A·256 + B − 2731) / 10 °C, con décimas. Comprobada con Autel. No se busca ni se puede cambiar, y no se usa el PID estándar 015C.

## Conseguir el APK
Cada vez que se sube un cambio a GitHub, la pestaña **Actions** compila la app y la publica en **Releases** como `OBD-Ibiza.apk`.
Descárgalo desde la tablet e instálalo (permite “instalar apps de origen desconocido”).
Las versiones nuevas se instalan encima sin desinstalar la anterior.

## Cable compatible
- Recomendado: **OBDLink SX USB**.
- Económico: **ELM327 USB con chips FTDI FT232RL + PIC18F25K80**.
- **No** sirven los cables VAG-COM / KKL 409.1.
