package com.ikker.obdibiza

/** Categorías = submenús de la pantalla "Datos". */
enum class Category(val title: String) {
    MOTOR("Motor"),
    TURBO("Turbo y admisión"),
    COMBUSTIBLE("Combustible"),
    TEMPERATURAS("Temperaturas"),
    ELECTRICO("Eléctrico"),
    ESTADISTICAS("Estadísticas"),
}

/**
 * Un parámetro que se puede mostrar en el panel o en los submenús.
 * - pid != null  -> se lee con modo 01 (OBD-II estándar)
 * - pid == null  -> parámetro calculado (turbo) o del adaptador (batería)
 */
class Param(
    val id: String,
    val name: String,
    val short: String,
    val unit: String,
    val category: Category,
    val min: Double,
    val max: Double,
    val decimals: Int = 0,
    val warnLow: Double? = null,
    val warnHigh: Double? = null,
    val pid: Int? = null,
    val calc: (IntArray) -> Double = { 0.0 },
) {
    fun format(v: Double?): String = when {
        v == null -> "—"
        decimals == 0 -> Math.round(v).toString()
        else -> String.format(java.util.Locale("es", "ES"), "%.${decimals}f", v)
    }

    fun isWarning(v: Double?): Boolean =
        v != null && ((warnHigh != null && v >= warnHigh) || (warnLow != null && v <= warnLow))
}

private fun ab(d: IntArray) = d[0] * 256 + d[1]

object Params {
    const val BOOST = "boost"
    const val BATTERY = "battery"

    val all: List<Param> = listOf(
        // ---------- Motor ----------
        Param("rpm", "Revoluciones", "Revoluciones", "rpm", Category.MOTOR, 0.0, 5000.0, warnHigh = 4500.0, pid = 0x0C) { ab(it) / 4.0 },
        Param("speed", "Velocidad", "Velocidad", "km/h", Category.MOTOR, 0.0, 220.0, pid = 0x0D) { it[0].toDouble() },
        Param("load", "Carga del motor", "Carga", "%", Category.MOTOR, 0.0, 100.0, pid = 0x04) { it[0] * 100.0 / 255 },
        Param("absload", "Carga absoluta", "Carga absoluta", "%", Category.MOTOR, 0.0, 100.0, pid = 0x43) { ab(it) * 100.0 / 255 },
        Param("pedal", "Pedal acelerador", "Pedal", "%", Category.MOTOR, 0.0, 100.0, pid = 0x49) { it[0] * 100.0 / 255 },
        Param("pedal2", "Pedal acelerador (sensor 2)", "Pedal (2)", "%", Category.MOTOR, 0.0, 100.0, pid = 0x4A) { it[0] * 100.0 / 255 },
        Param("throttle", "Mariposa", "Mariposa", "%", Category.MOTOR, 0.0, 100.0, pid = 0x11) { it[0] * 100.0 / 255 },
        Param("throttlecmd", "Mariposa (ordenada)", "Mariposa pedida", "%", Category.MOTOR, 0.0, 100.0, pid = 0x4C) { it[0] * 100.0 / 255 },
        Param("relthrottle", "Mariposa relativa", "Mariposa relativa", "%", Category.MOTOR, 0.0, 100.0, pid = 0x45) { it[0] * 100.0 / 255 },
        Param("torquedem", "Par solicitado", "Par pedido", "%", Category.MOTOR, 0.0, 100.0, pid = 0x61) { it[0] - 125.0 },
        Param("torque", "Par real", "Par", "%", Category.MOTOR, 0.0, 100.0, pid = 0x62) { it[0] - 125.0 },
        Param("torqueref", "Par de referencia", "Par de referencia", "Nm", Category.MOTOR, 0.0, 500.0, pid = 0x63) { ab(it).toDouble() },

        // ---------- Turbo y admisión ----------
        Param(BOOST, "Presión turbo (relativa)", "Turbo", "bar", Category.TURBO, -0.2, 2.5, decimals = 2, warnHigh = 2.0),
        Param("map", "Presión colector (absoluta)", "Colector", "kPa", Category.TURBO, 0.0, 350.0, pid = 0x0B) { it[0].toDouble() },
        Param("baro", "Presión atmosférica", "Atmosférica", "kPa", Category.TURBO, 60.0, 110.0, pid = 0x33) { it[0].toDouble() },
        Param("maf", "Caudal de aire (MAF)", "Caudal de aire", "g/s", Category.TURBO, 0.0, 200.0, decimals = 1, pid = 0x10) { ab(it) / 100.0 },
        Param("egrcmd", "EGR ordenada", "EGR", "%", Category.TURBO, 0.0, 100.0, pid = 0x2C) { it[0] * 100.0 / 255 },
        Param("egrerr", "Error EGR", "Error EGR", "%", Category.TURBO, -100.0, 100.0, pid = 0x2D) { it[0] * 100.0 / 128 - 100 },

        // ---------- Combustible ----------
        Param("rail", "Presión rail (inyección)", "Rail", "bar", Category.COMBUSTIBLE, 0.0, 2000.0, pid = 0x23) { ab(it) / 10.0 },
        Param("fuelrate", "Consumo instantáneo", "Consumo", "L/h", Category.COMBUSTIBLE, 0.0, 30.0, decimals = 1, pid = 0x5E) { ab(it) / 20.0 },
        Param("fuellevel", "Nivel de combustible", "Depósito", "%", Category.COMBUSTIBLE, 0.0, 100.0, warnLow = 10.0, pid = 0x2F) { it[0] * 100.0 / 255 },
        Param("injtiming", "Avance de inyección", "Avance", "°", Category.COMBUSTIBLE, -30.0, 30.0, decimals = 1, pid = 0x5D) { ab(it) / 128.0 - 210 },

        // ---------- Temperaturas ----------
        Param("coolant", "Temperatura refrigerante", "Refrigerante", "°C", Category.TEMPERATURAS, 0.0, 130.0, warnHigh = 105.0, pid = 0x05) { it[0] - 40.0 },
        Param("iat", "Temperatura aire admisión", "Aire admisión", "°C", Category.TEMPERATURAS, -20.0, 80.0, warnHigh = 60.0, pid = 0x0F) { it[0] - 40.0 },
        Param("ambient", "Temperatura exterior", "Exterior", "°C", Category.TEMPERATURAS, -20.0, 50.0, pid = 0x46) { it[0] - 40.0 },
        // Aceite: fijo de la centralita (22 11 BE), nunca del PID estándar 015C. Lo lee ObdViewModel.
        Param("oil", "Temperatura del aceite", "Aceite", "°C", Category.TEMPERATURAS, 0.0, 150.0, decimals = 1, warnLow = 60.0, warnHigh = 125.0),

        // ---------- Eléctrico ----------
        Param(BATTERY, "Tensión batería (OBD)", "Batería", "V", Category.ELECTRICO, 10.0, 16.0, decimals = 1, warnLow = 11.8, warnHigh = 15.0),
        Param("modvolt", "Tensión centralita motor", "Tensión ECU", "V", Category.ELECTRICO, 10.0, 16.0, decimals = 2, warnLow = 11.8, warnHigh = 15.0, pid = 0x42) { ab(it) / 1000.0 },

        // ---------- Estadísticas ----------
        Param("runtime", "Tiempo desde arranque", "En marcha", "min", Category.ESTADISTICAS, 0.0, 600.0, decimals = 1, pid = 0x1F) { ab(it) / 60.0 },
        Param("distmil", "Km con testigo de avería", "Km con testigo", "km", Category.ESTADISTICAS, 0.0, 65535.0, pid = 0x21) { ab(it).toDouble() },
        Param("timemil", "Minutos con testigo de avería", "Min con testigo", "min", Category.ESTADISTICAS, 0.0, 65535.0, pid = 0x4D) { ab(it).toDouble() },
        Param("distclr", "Km desde borrado de averías", "Km desde borrado", "km", Category.ESTADISTICAS, 0.0, 65535.0, pid = 0x31) { ab(it).toDouble() },
        Param("timeclr", "Minutos desde borrado de averías", "Min desde borrado", "min", Category.ESTADISTICAS, 0.0, 65535.0, pid = 0x4E) { ab(it).toDouble() },
        Param("warmups", "Calentamientos desde borrado", "Calentamientos", "", Category.ESTADISTICAS, 0.0, 255.0, pid = 0x30) { it[0].toDouble() },
    )

    val byId: Map<String, Param> = all.associateBy { it.id }
    val byPid: Map<Int, Param> = all.filter { it.pid != null }.associateBy { it.pid!! }

    /** Bytes de datos que devuelve cada PID (para validar la respuesta). */
    fun bytesFor(pid: Int): Int = when (pid) {
        0x0C, 0x10, 0x1F, 0x21, 0x23, 0x31, 0x42, 0x43, 0x4D, 0x4E, 0x5D, 0x5E, 0x63 -> 2
        else -> 1
    }

    val defaultPageNames = listOf("Performance", "Crucero", "Motor", "Diésel")

    /** Páginas iniciales del panel (izquierda, centro, derecha). */
    val defaultPages = listOf(
        listOf("oil", "rpm", BOOST),
        listOf("coolant", "speed", "iat"),
        listOf("load", "maf", BATTERY),
        listOf("rail", "torque", "egrcmd"),
    )

    val defaultDashboard = listOf(BOOST, "oil", "coolant", "iat", "load", BATTERY)
}

// ═══════════════════════════════════════════════════════════════════ Límite de velocidad
// Lógica pura (sin Android): interpretar los límites de OpenStreetMap, deducirlos por el tipo de vía
// cuando no están apuntados y averiguar por qué vía va el coche con la posición y el rumbo del GPS.

/** Una vía de OpenStreetMap: etiquetas y trazado (latitudes y longitudes de sus puntos). */
class OsmWay(val id: Long, val tags: Map<String, String>, val lat: DoubleArray, val lon: DoubleArray) {
    // Recuadro de la vía: permite descartar rápido las que están lejos
    val minLat = lat.minOrNull() ?: 0.0
    val maxLat = lat.maxOrNull() ?: 0.0
    val minLon = lon.minOrNull() ?: 0.0
    val maxLon = lon.maxOrNull() ?: 0.0
}

/** Vía reconocida: a qué distancia está y si se va en el sentido en que está dibujada. */
class WayMatch(val way: OsmWay, val distM: Double, val forward: Boolean)

/** Límite en km/h (null = desconocido), si es deducido por el tipo de vía y nombre de la vía. */
data class LimitInfo(val kmh: Int?, val estimated: Boolean, val road: String, val wayId: Long)

object SpeedLimits {
    private const val EARTH = 6_371_000.0
    private const val DEG = Math.PI / 180
    /** Más lejos de esto la vía no se da por buena (error normal del GPS + ancho de la calzada). */
    const val MAX_DIST_M = 35.0

    /** Tipos de vía por los que circula un coche (los que se descargan). */
    const val HIGHWAYS = "motorway|trunk|primary|secondary|tertiary|unclassified|residential|living_street|" +
        "motorway_link|trunk_link|primary_link|secondary_link|tertiary_link"

    fun distanceM(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val x = (lon2 - lon1) * DEG * Math.cos((lat1 + lat2) / 2 * DEG)
        val y = (lat2 - lat1) * DEG
        return Math.sqrt(x * x + y * y) * EARTH
    }

    /** 1 = sentido único en el sentido del dibujo, -1 = sentido único al revés, 0 = doble sentido. */
    fun oneway(t: Map<String, String>): Int = when (t["oneway"]?.lowercase()) {
        "yes", "1", "true" -> 1
        "-1", "reverse" -> -1
        "no", "false", "0" -> 0
        else -> if (t["junction"] in setOf("roundabout", "circular") || t["highway"] == "motorway") 1 else 0
    }

    /** Carriles por sentido (null = no está apuntado). */
    fun lanesPerDirection(t: Map<String, String>): Int? {
        val ow = oneway(t) != 0
        if (!ow) t["lanes:forward"]?.trim()?.toIntOrNull()?.let { return it }
        val l = t["lanes"]?.trim()?.toIntOrNull() ?: return null
        return if (ow) l else maxOf(1, l / 2)
    }

    private val numRe = Regex("^(\\d+(?:[.,]\\d+)?)\\s*(mph|km/h|kmh|kph)?$")
    private val zoneRe = Regex("zone:?(\\d+)")

    /** Convierte un valor de maxspeed de OpenStreetMap ("50", "ES:urban", "ES:zone30"…) a km/h. */
    fun parseMaxspeed(raw: String?, lanesPerDir: Int? = null): Int? {
        val s = raw?.trim()?.lowercase()?.split(';', '|')?.firstOrNull()?.trim()
        if (s.isNullOrEmpty()) return null
        when (s) {
            // Ciudad: 30 en calles de un carril por sentido, 50 con dos o más (DGT, 2021)
            "es:urban", "urban" -> return if ((lanesPerDir ?: 2) >= 2) 50 else 30
            "es:rural", "rural" -> return 90
            "es:motorway", "motorway" -> return 120
            "es:living_street", "living_street" -> return 20
            "walk" -> return 10
        }
        zoneRe.find(s)?.let { return it.groupValues[1].toIntOrNull()?.takeIf { v -> v in 5..150 } }
        val m = numRe.find(s) ?: return null
        var v = m.groupValues[1].replace(',', '.').toDoubleOrNull() ?: return null
        if (m.groupValues[2] == "mph") v *= 1.609
        return Math.round(v).toInt().takeIf { it in 5..150 }
    }

    /** Nombres de calle (castellano y valenciano) que indican que la vía va por dentro de un pueblo o ciudad. */
    private val urbanName = Regex(
        "^(c/|av\\.|avda\\.|(calle|carrer|avenida|avinguda|avda|plaza|plaça|pza|paseo|passeig|travessera|travesía|travesia|ronda|rambla|glorieta|bulevar|boulevard)(?=[\\s,.]|$))",
        RegexOption.IGNORE_CASE,
    )

    private fun urban(lanesPerDir: Int?, default: Int) = when {
        lanesPerDir == null -> default
        lanesPerDir >= 2 -> 50
        else -> 30
    }

    /**
     * Límite genérico por el tipo de vía cuando el mapa no lo tiene. Una vía con nombre y sin matrícula
     * (sin "CV-10", "N-340"…) se toma como calle de ciudad.
     */
    fun infer(t: Map<String, String>): Int? {
        val lpd = lanesPerDirection(t)
        val name = t["name"].orEmpty()
        // En ciudad: con nombre y sin matrícula, o con nombre de calle aunque lleve matrícula (travesías)
        val inTown = name.isNotBlank() && (t["ref"].isNullOrBlank() || urbanName.containsMatchIn(name))
        return when (t["highway"]) {
            "motorway" -> 120
            "trunk" -> when {
                t["motorroad"] == "yes" -> 100
                oneway(t) != 0 && (lpd ?: 1) >= 2 -> 120
                inTown -> urban(lpd, 50)
                else -> 90
            }
            "primary", "secondary" -> if (inTown) urban(lpd, 50) else 90
            "tertiary" -> if (inTown) urban(lpd, 50) else 90
            "unclassified" -> if (inTown) urban(lpd, 30) else 90
            "residential" -> urban(lpd, 30)
            "living_street" -> 20
            else -> null   // ramales de entrada y salida: sin límite general
        }
    }

    /** Límite de la vía reconocida, en el sentido en que se circula. */
    fun limitFor(m: WayMatch): LimitInfo {
        val t = m.way.tags
        val lpd = lanesPerDirection(t)
        val dir = if (m.forward) t["maxspeed:forward"] else t["maxspeed:backward"]
        val tagged = parseMaxspeed(dir, lpd)
            ?: parseMaxspeed(t["maxspeed"], lpd)
            ?: parseMaxspeed(t["zone:maxspeed"], lpd)
            ?: parseMaxspeed(t["maxspeed:type"], lpd)
            ?: parseMaxspeed(t["source:maxspeed"], lpd)
        val road = listOfNotNull(t["ref"]?.takeIf { it.isNotBlank() }, t["name"]?.takeIf { it.isNotBlank() })
            .joinToString(" · ")
        return if (tagged != null) LimitInfo(tagged, false, road, m.way.id)
        else LimitInfo(infer(t), true, road, m.way.id)
    }

    /** Diferencia entre dos rumbos, de 0 a 180 grados. */
    fun angleDiff(a: Double, b: Double): Double {
        val d = Math.abs(((a - b) % 360 + 360) % 360)
        return if (d > 180) 360 - d else d
    }

    /**
     * Vía más probable para una posición: la más cercana, castigando las que no van en la dirección
     * del rumbo y descartando las de sentido único en contra. Para no dar saltos en los cruces se
     * sigue con la vía anterior mientras siga siendo casi igual de buena.
     */
    fun match(ways: List<OsmWay>, lat: Double, lon: Double, bearing: Double?, prevId: Long?): WayMatch? {
        val k = DEG * EARTH
        val kx = k * Math.cos(lat * DEG)
        var best: WayMatch? = null
        var bestScore = Double.MAX_VALUE
        var prev: WayMatch? = null
        var prevScore = Double.MAX_VALUE
        val mLat = 70.0 / k
        val mLon = 70.0 / kx
        for (w in ways) {
            if (w.lat.size < 2) continue
            if (lat < w.minLat - mLat || lat > w.maxLat + mLat || lon < w.minLon - mLon || lon > w.maxLon + mLon) continue
            val ow = oneway(w.tags)
            var wScore = Double.MAX_VALUE
            var wDist = 0.0
            var wFwd = true
            for (i in 0 until w.lat.size - 1) {
                val ax = (w.lon[i] - lon) * kx
                val ay = (w.lat[i] - lat) * k
                val dx = (w.lon[i + 1] - lon) * kx - ax
                val dy = (w.lat[i + 1] - lat) * k - ay
                val len2 = dx * dx + dy * dy
                val t = if (len2 < 1e-6) 0.0 else ((-ax * dx - ay * dy) / len2).coerceIn(0.0, 1.0)
                val d = Math.hypot(ax + t * dx, ay + t * dy)
                if (d > 60) continue
                var score = d
                var fwd = true
                if (bearing != null && len2 > 1e-6) {
                    val seg = (Math.toDegrees(Math.atan2(dx, dy)) + 360) % 360
                    val diff = angleDiff(bearing, seg)
                    fwd = diff <= 90
                    score += when {
                        ow == 1 && diff > 110 -> 1000.0
                        ow == -1 && diff < 70 -> 1000.0
                        else -> minOf(diff, 180 - diff) / 90 * 20
                    }
                }
                if (score < wScore) { wScore = score; wDist = d; wFwd = fwd }
            }
            if (wScore == Double.MAX_VALUE) continue
            if (wScore < bestScore) { bestScore = wScore; best = WayMatch(w, wDist, wFwd) }
            if (w.id == prevId) { prevScore = wScore; prev = WayMatch(w, wDist, wFwd) }
        }
        if (prev != null && prevScore < 500 && prevScore <= bestScore + 8 && prev.distM <= MAX_DIST_M) return prev
        return best?.takeIf { bestScore < 500 && it.distM <= MAX_DIST_M }
    }
}

// ═══════════════════════════════════════════════════════════════════ Presión del turbo precisa
// El dato OBD estándar de presión del colector (010B) es de un byte: no pasa de 255 kPa absolutos, unos
// 1,54 bar de turbo. La centralita guarda la presión real en su propia memoria con 2 bytes (en hPa), que es
// la que leen Autel o VCDS. Aquí se elige cuál es comparando cada candidato con el 010B mientras el turbo
// sopla pero sin llegar a su tope.

/** Fórmulas para un dato de presión de 2 bytes. 0 = hPa · 1 = décimas de hPa · 2 = centésimas de bar. */
object PressureFormula {
    const val COUNT = 3
    fun hpa(d: IntArray, f: Int): Double? {
        if (d.size < 2) return null
        val raw = d[0] * 256 + d[1]
        return when (f) {
            0 -> raw.toDouble()
            1 -> raw / 10.0
            2 -> raw * 10.0
            else -> null
        }
    }
}

/** Identificador de la centralita que podría ser una presión; se va puntuando al conducir. */
class BoostCandidate(val did: Int, val formula: Int) {
    var n = 0
    var sumErr = 0.0
    var ambN = 0
    var ambSum = 0.0
    var ambOk = true
    val meanErr: Double get() = if (n == 0) Double.MAX_VALUE else sumErr / n
    /** Se queda quieto en la presión atmosférica mientras el turbo sopla: es la presión ambiental. */
    val isAmbient: Boolean get() = ambOk && ambN >= 3
    /** Ya está claro que no sigue al turbo. */
    val discarded: Boolean get() = n >= 2 && meanErr > 300
}

enum class Calib { ESPERANDO, HECHO, FALLIDO }

class BoostCalibrator(list: List<BoostCandidate>) {
    val cands: List<BoostCandidate> = list.toList()
    var boost: BoostCandidate? = null
        private set
    var ambient: BoostCandidate? = null
        private set

    companion object {
        /** Solo se compara cuando el turbo sopla y el dato estándar aún no está en su tope (255 kPa). */
        fun usable(mapKpa: Double) = mapKpa in 125.0..245.0
        const val SAMPLES = 5
        const val MAX_ERR_HPA = 60.0
    }

    fun sample(c: BoostCandidate, hpa: Double, mapKpa: Double, baroKpa: Double) {
        c.n++
        c.sumErr += Math.abs(hpa - mapKpa * 10)
        val dev = Math.abs(hpa - baroKpa * 10)
        if (dev > 25) c.ambOk = false else { c.ambN++; c.ambSum += dev }
    }

    /** Los que todavía hay que leer. */
    fun pending(): List<BoostCandidate> = cands.filter { c ->
        when {
            // Descartado como presión del turbo: se sigue leyendo solo si puede ser la ambiental
            c.discarded -> c.ambOk && c.ambN < 3
            else -> c.n < SAMPLES + 3
        }
    }

    /** Cuántos están ya decididos (para el progreso). */
    fun done(): Int = cands.count { it.discarded || it.n >= SAMPLES }

    fun decide(): Calib {
        if (cands.any { !it.discarded && it.n < SAMPLES }) return Calib.ESPERANDO
        val best = cands.filter { it.n >= SAMPLES && it.meanErr <= MAX_ERR_HPA }.minByOrNull { it.meanErr }
            ?: return Calib.FALLIDO
        boost = best
        ambient = cands.filter { it !== best && it.isAmbient }.minByOrNull { it.ambSum / it.ambN }
        return Calib.HECHO
    }
}

// ═══════════════════════════════════════════════════════════════════ Mapa de límites guardado
// El mapa se guarda en la pantalla por teselas de 0,05° (unos 5,5 × 4,3 km). Cada tesela es un fichero
// comprimido con las vías y solo las etiquetas que hacen falta, así funciona sin internet solo con el GPS.

object LimitTiles {
    const val SIZE = 0.05
    private const val VERSION = 1
    /** Etiquetas que se guardan (el resto no hace falta para el límite). */
    val KEEP = setOf(
        "highway", "maxspeed", "maxspeed:forward", "maxspeed:backward", "maxspeed:type", "zone:maxspeed",
        "source:maxspeed", "oneway", "junction", "lanes", "lanes:forward", "ref", "name", "motorroad",
    )

    fun key(lat: Double, lon: Double): Long {
        val ix = Math.floor(lon / SIZE).toInt()
        val iy = Math.floor(lat / SIZE).toInt()
        return (ix.toLong() shl 32) or (iy.toLong() and 0xFFFFFFFFL)
    }

    fun ix(key: Long): Int = (key shr 32).toInt()
    fun iy(key: Long): Int = key.toInt()

    /** Sur, oeste, norte, este. */
    fun bbox(key: Long): DoubleArray {
        val s = iy(key) * SIZE
        val w = ix(key) * SIZE
        return doubleArrayOf(s, w, s + SIZE, w + SIZE)
    }

    fun fileName(key: Long) = "t_%d_%d.bin".format(ix(key), iy(key))

    /** La tesela de la posición y las vecinas si está a menos de [marginM] metros del borde. */
    fun around(lat: Double, lon: Double, marginM: Double): List<Long> {
        val dLat = marginM / 111_320.0
        val dLon = marginM / (111_320.0 * Math.cos(Math.toRadians(lat)))
        return listOf(
            key(lat, lon), key(lat - dLat, lon - dLon), key(lat - dLat, lon + dLon),
            key(lat + dLat, lon - dLon), key(lat + dLat, lon + dLon),
        ).distinct()
    }

    /** Teselas a menos de [km] del punto, de la más cercana a la más lejana. */
    fun inRadius(lat: Double, lon: Double, km: Double): List<Long> {
        val dLat = km * 1000 / 111_320.0
        val dLon = km * 1000 / (111_320.0 * Math.cos(Math.toRadians(lat)))
        val out = ArrayList<Pair<Long, Double>>()
        var y = Math.floor((lat - dLat) / SIZE).toInt()
        val y1 = Math.floor((lat + dLat) / SIZE).toInt()
        while (y <= y1) {
            var x = Math.floor((lon - dLon) / SIZE).toInt()
            val x1 = Math.floor((lon + dLon) / SIZE).toInt()
            while (x <= x1) {
                // Punto de la tesela más cercano al centro
                val cy = (lat).coerceIn(y * SIZE, (y + 1) * SIZE)
                val cx = (lon).coerceIn(x * SIZE, (x + 1) * SIZE)
                val d = SpeedLimits.distanceM(lat, lon, cy, cx)
                if (d <= km * 1000) out += ((x.toLong() shl 32) or (y.toLong() and 0xFFFFFFFFL)) to d
                x++
            }
            y++
        }
        return out.sortedBy { it.second }.map { it.first }
    }

    fun write(out: java.io.OutputStream, ways: List<OsmWay>) {
        java.io.DataOutputStream(java.io.BufferedOutputStream(java.util.zip.GZIPOutputStream(out))).use { d ->
            d.writeInt(VERSION)
            d.writeLong(System.currentTimeMillis())
            d.writeInt(ways.size)
            for (w in ways) {
                d.writeLong(w.id)
                val tags = w.tags.filterKeys { it in KEEP }
                d.writeByte(tags.size)
                for ((k, v) in tags) { d.writeUTF(k); d.writeUTF(v.take(200)) }
                d.writeInt(w.lat.size)
                for (i in w.lat.indices) {
                    d.writeInt(Math.round(w.lat[i] * 1e6).toInt())
                    d.writeInt(Math.round(w.lon[i] * 1e6).toInt())
                }
            }
        }
    }

    /** Lee una tesela guardada. Devuelve las vías y la fecha en que se descargó, o null si el fichero no vale. */
    fun read(inp: java.io.InputStream): Pair<List<OsmWay>, Long>? = try {
        java.io.DataInputStream(java.io.BufferedInputStream(java.util.zip.GZIPInputStream(inp))).use { d ->
            if (d.readInt() != VERSION) return null
            val time = d.readLong()
            val n = d.readInt()
            val ways = ArrayList<OsmWay>(n)
            repeat(n) {
                val id = d.readLong()
                val nt = d.readUnsignedByte()
                val tags = HashMap<String, String>(nt * 2)
                repeat(nt) { val k = d.readUTF(); tags[k] = d.readUTF() }
                val np = d.readInt()
                val la = DoubleArray(np)
                val lo = DoubleArray(np)
                for (i in 0 until np) { la[i] = d.readInt() / 1e6; lo[i] = d.readInt() / 1e6 }
                ways += OsmWay(id, tags, la, lo)
            }
            ways to time
        }
    } catch (_: Exception) { null }
}

// ═══════════════════════════════════════════════════════════════════ Radares
// Radares fijos del mapa (OpenStreetMap). Se avisa del que está por delante, en la dirección de la marcha,
// a menos de la distancia elegida. El rumbo con que mira cada radar no siempre está en el mapa, así que no
// se usa: basta con que esté delante y casi en línea con el coche.

class Radar(val lat: Double, val lon: Double, val kmh: Int?, val dir: Double?)

/** Radar por delante y a qué distancia está, en metros. */
class RadarAhead(val radar: Radar, val distM: Double)

object Radars {
    /** Lee el fichero "lat;lon;límite;rumbo" (las líneas que empiezan por # son comentarios). */
    fun parse(text: String): List<Radar> = text.lineSequence().mapNotNull { l ->
        if (l.isBlank() || l.startsWith("#")) return@mapNotNull null
        val f = l.split(';')
        val lat = f.getOrNull(0)?.toDoubleOrNull() ?: return@mapNotNull null
        val lon = f.getOrNull(1)?.toDoubleOrNull() ?: return@mapNotNull null
        Radar(lat, lon, f.getOrNull(2)?.toIntOrNull(), f.getOrNull(3)?.toDoubleOrNull())
    }.toList()

    /** Rumbo de A a B (0 = norte, en grados). */
    fun bearing(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val x = (lon2 - lon1) * Math.cos(Math.toRadians((lat1 + lat2) / 2))
        val y = lat2 - lat1
        return (Math.toDegrees(Math.atan2(x, y)) + 360) % 360
    }

    /**
     * El radar más cercano que está delante: a menos de [maxM] metros, casi en la dirección de la marcha
     * (±25°, o más cuando ya está muy cerca) y a no más de 60 m a un lado de la trayectoria.
     */
    fun ahead(list: List<Radar>, lat: Double, lon: Double, heading: Double?, maxM: Double): RadarAhead? {
        if (heading == null) return null
        val dLat = maxM / 111_320.0
        val dLon = maxM / (111_320.0 * Math.cos(Math.toRadians(lat)))
        var best: RadarAhead? = null
        for (r in list) {
            if (Math.abs(r.lat - lat) > dLat || Math.abs(r.lon - lon) > dLon) continue
            val d = SpeedLimits.distanceM(lat, lon, r.lat, r.lon)
            if (d > maxM) continue
            val diff = SpeedLimits.angleDiff(heading, bearing(lat, lon, r.lat, r.lon))
            val maxDiff = if (d < 80) 70.0 else 25.0
            if (diff > maxDiff) continue
            if (d * Math.sin(Math.toRadians(diff)) > 60) continue
            if (best == null || d < best.distM) best = RadarAhead(r, d)
        }
        return best
    }
}
