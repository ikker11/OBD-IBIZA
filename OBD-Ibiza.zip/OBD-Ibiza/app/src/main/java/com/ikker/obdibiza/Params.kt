package com.ikker.obdibiza

/** Categorías = submenús de la pantalla "Datos". */
enum class Category(val title: String) {
    MOTOR("Motor"),
    TURBO("Turbo y admisión"),
    COMBUSTIBLE("Combustible"),
    TEMPERATURAS("Temperaturas"),
    ELECTRICO("Eléctrico"),
    RUEDAS("Ruedas (ABS)"),
    ESTADISTICAS("Estadísticas"),
}

/**
 * Un parámetro que se puede mostrar en el panel o en los submenús.
 * - pid != null  -> se lee con modo 01 (OBD-II estándar)
 * - pid == null  -> parámetro calculado (turbo) o del adaptador (batería)
 */
class Param(
    val id: String,
    val name: String,
    val short: String,
    val unit: String,
    val category: Category,
    val min: Double,
    val max: Double,
    val decimals: Int = 0,
    val warnLow: Double? = null,
    val warnHigh: Double? = null,
    val pid: Int? = null,
    val calc: (IntArray) -> Double = { 0.0 },
) {
    fun format(v: Double?): String = when {
        v == null -> "—"
        decimals == 0 -> Math.round(v).toString()
        else -> String.format(java.util.Locale("es", "ES"), "%.${decimals}f", v)
    }

    fun isWarning(v: Double?): Boolean =
        v != null && ((warnHigh != null && v >= warnHigh) || (warnLow != null && v <= warnLow))
}

private fun ab(d: IntArray) = d[0] * 256 + d[1]

object Params {
    const val BOOST = "boost"
    const val BATTERY = "battery"

    /** Velocidad de cada rueda, del grupo 1 del ABS (se lee cada 2 s mientras el ABS contesta). */
    val WHEELS = listOf("wfl", "wfr", "wrl", "wrr")

    val all: List<Param> = listOf(
        Param("wfl", "Rueda delantera izquierda", "Del. izq.", "km/h", Category.RUEDAS, 0.0, 250.0, decimals = 1),
        Param("wfr", "Rueda delantera derecha", "Del. der.", "km/h", Category.RUEDAS, 0.0, 250.0, decimals = 1),
        Param("wrl", "Rueda trasera izquierda", "Tras. izq.", "km/h", Category.RUEDAS, 0.0, 250.0, decimals = 1),
        Param("wrr", "Rueda trasera derecha", "Tras. der.", "km/h", Category.RUEDAS, 0.0, 250.0, decimals = 1),
        // ---------- Motor ----------
        Param("rpm", "Revoluciones", "Revoluciones", "rpm", Category.MOTOR, 0.0, 5000.0, warnHigh = 4500.0, pid = 0x0C) { ab(it) / 4.0 },
        Param("speed", "Velocidad", "Velocidad", "km/h", Category.MOTOR, 0.0, 220.0, pid = 0x0D) { it[0].toDouble() },
        Param("load", "Carga del motor", "Carga", "%", Category.MOTOR, 0.0, 100.0, pid = 0x04) { it[0] * 100.0 / 255 },
        Param("absload", "Carga absoluta", "Carga absoluta", "%", Category.MOTOR, 0.0, 100.0, pid = 0x43) { ab(it) * 100.0 / 255 },
        Param("pedal", "Pedal acelerador", "Pedal", "%", Category.MOTOR, 0.0, 100.0, pid = 0x49) { it[0] * 100.0 / 255 },
        Param("pedal2", "Pedal acelerador (sensor 2)", "Pedal (2)", "%", Category.MOTOR, 0.0, 100.0, pid = 0x4A) { it[0] * 100.0 / 255 },
        Param("throttle", "Mariposa", "Mariposa", "%", Category.MOTOR, 0.0, 100.0, pid = 0x11) { it[0] * 100.0 / 255 },
        Param("throttlecmd", "Mariposa (ordenada)", "Mariposa pedida", "%", Category.MOTOR, 0.0, 100.0, pid = 0x4C) { it[0] * 100.0 / 255 },
        Param("relthrottle", "Mariposa relativa", "Mariposa relativa", "%", Category.MOTOR, 0.0, 100.0, pid = 0x45) { it[0] * 100.0 / 255 },
        Param("torquedem", "Par solicitado", "Par pedido", "%", Category.MOTOR, 0.0, 100.0, pid = 0x61) { it[0] - 125.0 },
        Param("torque", "Par real", "Par", "%", Category.MOTOR, 0.0, 100.0, pid = 0x62) { it[0] - 125.0 },
        Param("torqueref", "Par de referencia", "Par de referencia", "Nm", Category.MOTOR, 0.0, 500.0, pid = 0x63) { ab(it).toDouble() },

        // ---------- Turbo y admisión ----------
        Param(BOOST, "Presión turbo (relativa)", "Turbo", "bar", Category.TURBO, -0.2, 2.5, decimals = 2, warnHigh = 2.0),
        Param("map", "Presión colector (absoluta)", "Colector", "kPa", Category.TURBO, 0.0, 350.0, pid = 0x0B) { it[0].toDouble() },
        Param("baro", "Presión atmosférica", "Atmosférica", "kPa", Category.TURBO, 60.0, 110.0, pid = 0x33) { it[0].toDouble() },
        Param("maf", "Caudal de aire (MAF)", "Caudal de aire", "g/s", Category.TURBO, 0.0, 200.0, decimals = 1, pid = 0x10) { ab(it) / 100.0 },
        Param("egrcmd", "EGR ordenada", "EGR", "%", Category.TURBO, 0.0, 100.0, pid = 0x2C) { it[0] * 100.0 / 255 },
        Param("egrerr", "Error EGR", "Error EGR", "%", Category.TURBO, -100.0, 100.0, pid = 0x2D) { it[0] * 100.0 / 128 - 100 },

        // ---------- Combustible ----------
        Param("rail", "Presión rail (inyección)", "Rail", "bar", Category.COMBUSTIBLE, 0.0, 2000.0, pid = 0x23) { ab(it) / 10.0 },
        Param("fuelrate", "Consumo instantáneo", "Consumo", "L/h", Category.COMBUSTIBLE, 0.0, 30.0, decimals = 1, pid = 0x5E) { ab(it) / 20.0 },
        // Prueba (12-nov): consumo por la cantidad inyectada que da la centralita. Dos candidatos; ×0,02 mg por unidad
        // (cuadra con los 0,6 l/h del cuadro al ralentí). Cuando se confirme uno, pasa a ser el consumo de verdad.
        Param("injA", "Inyección A (22 11 68)", "Iny. A", "mg", Category.COMBUSTIBLE, 0.0, 80.0, decimals = 2),
        Param("lphA", "Consumo A (22 11 68)", "Cons. A", "L/h", Category.COMBUSTIBLE, 0.0, 30.0, decimals = 2),
        Param("l100A", "Consumo A a los 100 (22 11 68)", "A /100", "L/100", Category.COMBUSTIBLE, 0.0, 30.0, decimals = 1),
        Param("injB", "Inyección B (22 10 47)", "Iny. B", "mg", Category.COMBUSTIBLE, 0.0, 80.0, decimals = 2),
        Param("lphB", "Consumo B (22 10 47)", "Cons. B", "L/h", Category.COMBUSTIBLE, 0.0, 30.0, decimals = 2),
        Param("l100B", "Consumo B a los 100 (22 10 47)", "B /100", "L/100", Category.COMBUSTIBLE, 0.0, 30.0, decimals = 1),
        Param("fuellevel", "Nivel de combustible", "Depósito", "%", Category.COMBUSTIBLE, 0.0, 100.0, warnLow = 10.0, pid = 0x2F) { it[0] * 100.0 / 255 },
        Param("lambda", "Lambda pedida", "Lambda", "λ", Category.COMBUSTIBLE, 0.0, 2.0, decimals = 2, pid = 0x44) { ab(it) * 2.0 / 65536 },
        Param("lambdas", "Lambda medida (sonda)", "Lambda sonda", "λ", Category.COMBUSTIBLE, 0.0, 2.0, decimals = 2, pid = 0x34) { ab(it) * 2.0 / 65536 },
        Param("injtiming", "Avance de inyección", "Avance", "°", Category.COMBUSTIBLE, -30.0, 30.0, decimals = 1, pid = 0x5D) { ab(it) / 128.0 - 210 },

        // ---------- Temperaturas ----------
        Param("coolant", "Temperatura refrigerante", "Refrigerante", "°C", Category.TEMPERATURAS, 0.0, 130.0, warnHigh = 105.0, pid = 0x05) { it[0] - 40.0 },
        Param("iat", "Temperatura aire admisión", "Aire admisión", "°C", Category.TEMPERATURAS, -20.0, 80.0, warnHigh = 60.0, pid = 0x0F) { it[0] - 40.0 },
        Param("ambient", "Temperatura exterior", "Exterior", "°C", Category.TEMPERATURAS, -20.0, 50.0, pid = 0x46) { it[0] - 40.0 },
        // Aceite: fijo de la centralita (22 11 BE), nunca del PID estándar 015C. Lo lee ObdViewModel.
        Param("oil", "Temperatura del aceite", "Aceite", "°C", Category.TEMPERATURAS, 0.0, 150.0, decimals = 1, warnLow = 60.0, warnHigh = 125.0),

        // ---------- Eléctrico ----------
        Param(BATTERY, "Tensión batería (OBD)", "Batería", "V", Category.ELECTRICO, 10.0, 16.0, decimals = 1, warnLow = 11.8, warnHigh = 15.0),
        Param("modvolt", "Tensión centralita motor", "Tensión ECU", "V", Category.ELECTRICO, 10.0, 16.0, decimals = 2, warnLow = 11.8, warnHigh = 15.0, pid = 0x42) { ab(it) / 1000.0 },

        // ---------- Estadísticas ----------
        Param("runtime", "Tiempo desde arranque", "En marcha", "min", Category.ESTADISTICAS, 0.0, 600.0, decimals = 1, pid = 0x1F) { ab(it) / 60.0 },
        Param("distmil", "Km con testigo de avería", "Km con testigo", "km", Category.ESTADISTICAS, 0.0, 65535.0, pid = 0x21) { ab(it).toDouble() },
        Param("timemil", "Minutos con testigo de avería", "Min con testigo", "min", Category.ESTADISTICAS, 0.0, 65535.0, pid = 0x4D) { ab(it).toDouble() },
        Param("distclr", "Km desde borrado de averías", "Km desde borrado", "km", Category.ESTADISTICAS, 0.0, 65535.0, pid = 0x31) { ab(it).toDouble() },
        Param("timeclr", "Minutos desde borrado de averías", "Min desde borrado", "min", Category.ESTADISTICAS, 0.0, 65535.0, pid = 0x4E) { ab(it).toDouble() },
        Param("warmups", "Calentamientos desde borrado", "Calentamientos", "", Category.ESTADISTICAS, 0.0, 255.0, pid = 0x30) { it[0].toDouble() },
    )

    val byId: Map<String, Param> = all.associateBy { it.id }
    val byPid: Map<Int, Param> = all.filter { it.pid != null }.associateBy { it.pid!! }

    /** Bytes de datos que devuelve cada PID (para validar la respuesta). */
    fun bytesFor(pid: Int): Int = when (pid) {
        0x0C, 0x10, 0x1F, 0x21, 0x23, 0x31, 0x42, 0x43, 0x44, 0x4D, 0x4E, 0x5D, 0x5E, 0x63 -> 2
        0x34 -> 4
        else -> 1
    }

    val defaultPageNames = listOf("Performance", "Crucero", "Motor", "Diésel")

    /** Páginas iniciales del panel (izquierda, centro, derecha). */
    val defaultPages = listOf(
        listOf("oil", "rpm", BOOST),
        listOf("coolant", "speed", "iat"),
        listOf("load", "maf", BATTERY),
        listOf("rail", "torque", "egrcmd"),
    )

    val defaultDashboard = listOf(BOOST, "oil", "coolant", "iat", "load", BATTERY)
}

// ═══════════════════════════════════════════════════════════════════ Límite de velocidad
// Lógica pura (sin Android): interpretar los límites de OpenStreetMap, deducirlos por el tipo de vía
// cuando no están apuntados y averiguar por qué vía va el coche con la posición y el rumbo del GPS.

/** Una vía de OpenStreetMap: etiquetas y trazado (latitudes y longitudes de sus puntos). */
class OsmWay(val id: Long, val tags: Map<String, String>, val lat: DoubleArray, val lon: DoubleArray) {
    // Recuadro de la vía: permite descartar rápido las que están lejos
    val minLat = lat.minOrNull() ?: 0.0
    val maxLat = lat.maxOrNull() ?: 0.0
    val minLon = lon.minOrNull() ?: 0.0
    val maxLon = lon.maxOrNull() ?: 0.0
}

/** Vía reconocida: a qué distancia está y si se va en el sentido en que está dibujada. */
class WayMatch(val way: OsmWay, val distM: Double, val forward: Boolean)

/** Límite en km/h (null = desconocido), si es deducido por el tipo de vía y nombre de la vía. */
data class LimitInfo(val kmh: Int?, val estimated: Boolean, val road: String, val wayId: Long, val corrected: Boolean = false)

object SpeedLimits {
    private const val EARTH = 6_371_000.0
    private const val DEG = Math.PI / 180
    /** Más lejos de esto la vía no se da por buena (error normal del GPS + ancho de la calzada). */
    const val MAX_DIST_M = 35.0
    /** Límite que se pone en todas las rotondas. */
    const val ROUNDABOUT_KMH = 40

    /** Tipos de vía por los que circula un coche (los que se descargan). */
    const val HIGHWAYS = "motorway|trunk|primary|secondary|tertiary|unclassified|residential|living_street|" +
        "motorway_link|trunk_link|primary_link|secondary_link|tertiary_link"

    fun distanceM(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val x = (lon2 - lon1) * DEG * Math.cos((lat1 + lat2) / 2 * DEG)
        val y = (lat2 - lat1) * DEG
        return Math.sqrt(x * x + y * y) * EARTH
    }

    /** 1 = sentido único en el sentido del dibujo, -1 = sentido único al revés, 0 = doble sentido. */
    fun oneway(t: Map<String, String>): Int = when (t["oneway"]?.lowercase()) {
        "yes", "1", "true" -> 1
        "-1", "reverse" -> -1
        "no", "false", "0" -> 0
        else -> if (t["junction"] in setOf("roundabout", "circular") || t["highway"] == "motorway") 1 else 0
    }

    /** Carriles por sentido (null = no está apuntado). */
    fun lanesPerDirection(t: Map<String, String>): Int? {
        val ow = oneway(t) != 0
        if (!ow) t["lanes:forward"]?.trim()?.toIntOrNull()?.let { return it }
        val l = t["lanes"]?.trim()?.toIntOrNull() ?: return null
        return if (ow) l else maxOf(1, l / 2)
    }

    private val numRe = Regex("^(\\d+(?:[.,]\\d+)?)\\s*(mph|km/h|kmh|kph)?$")
    private val zoneRe = Regex("zone:?(\\d+)")

    /** Convierte un valor de maxspeed de OpenStreetMap ("50", "ES:urban", "ES:zone30"…) a km/h. */
    fun parseMaxspeed(raw: String?, lanesPerDir: Int? = null): Int? {
        val s = raw?.trim()?.lowercase()?.split(';', '|')?.firstOrNull()?.trim()
        if (s.isNullOrEmpty()) return null
        when (s) {
            // Ciudad: 30 en calles de un carril por sentido, 50 con dos o más (DGT, 2021)
            "es:urban", "urban" -> return if ((lanesPerDir ?: 2) >= 2) 50 else 30
            "es:rural", "rural" -> return 90
            "es:motorway", "motorway" -> return 120
            "es:living_street", "living_street" -> return 20
            "walk" -> return 10
        }
        zoneRe.find(s)?.let { return it.groupValues[1].toIntOrNull()?.takeIf { v -> v in 5..150 } }
        val m = numRe.find(s) ?: return null
        var v = m.groupValues[1].replace(',', '.').toDoubleOrNull() ?: return null
        if (m.groupValues[2] == "mph") v *= 1.609
        return Math.round(v).toInt().takeIf { it in 5..150 }
    }

    /** Nombres de calle (castellano y valenciano) que indican que la vía va por dentro de un pueblo o ciudad. */
    private val urbanName = Regex(
        "^(c/|av\\.|avda\\.|(calle|carrer|avenida|avinguda|avda|plaza|plaça|pza|paseo|passeig|travessera|travesía|travesia|ronda|rambla|glorieta|bulevar|boulevard)(?=[\\s,.]|$))",
        RegexOption.IGNORE_CASE,
    )

    private fun urban(lanesPerDir: Int?, default: Int) = when {
        lanesPerDir == null -> default
        lanesPerDir >= 2 -> 50
        else -> 30
    }

    /** Nombres de caminos y carreteras: aunque no lleven matrícula, no son calles de un pueblo. */
    private val ruralName = Regex(
        "^(camí|cami|camino|carretera|ctra\\.?|senda|vereda|pista|partida|cañada|colada|autovía|autovia|autopista|variante|vía de servicio|via de servicio)(?=[\\s,.]|$)",
        RegexOption.IGNORE_CASE,
    )

    private val unpavedSurfaces = setOf(
        "unpaved", "gravel", "fine_gravel", "dirt", "earth", "ground", "grass", "sand", "mud", "compacted", "pebblestone", "rock",
    )

    /**
     * Límite genérico cuando el mapa no lo tiene, según el Reglamento General de Circulación (turismos):
     *  · Fuera de poblado (art. 48): autopistas y autovías 120 · carreteras convencionales 90
     *    (también las vías para automóviles; 100 solo si está señalizado) · vías sin pavimentar 30.
     *  · En poblado (art. 50, desde mayo de 2021): 20 en plataforma única de calzada y acera ·
     *    30 con un carril por sentido · 50 con dos o más carriles por sentido.
     * Una vía con nombre y sin matrícula (o con nombre de calle aunque la lleve) se toma como de poblado,
     * salvo que el nombre sea de camino o carretera.
     */
    fun infer(t: Map<String, String>): Int? {
        val hw = t["highway"]
        if (t["surface"]?.lowercase() in unpavedSurfaces) return if (hw == "living_street") 20 else 30
        val lpd = lanesPerDirection(t)
        val name = t["name"].orEmpty()
        val inTown = name.isNotBlank() && !ruralName.containsMatchIn(name) &&
            (t["ref"].isNullOrBlank() || urbanName.containsMatchIn(name))
        return when (hw) {
            "motorway" -> 120
            "trunk", "primary", "secondary", "tertiary" -> if (inTown) urban(lpd, 50) else 90
            "unclassified" -> if (inTown) urban(lpd, 30) else 90
            "residential" -> urban(lpd, 30)
            "living_street" -> 20
            else -> null   // ramales de entrada y salida: sin límite general
        }
    }

    /** Límite de la vía reconocida, en el sentido en que se circula. */
    fun limitFor(m: WayMatch): LimitInfo {
        val t = m.way.tags
        val lpd = lanesPerDirection(t)
        val dir = if (m.forward) t["maxspeed:forward"] else t["maxspeed:backward"]
        val tagged = parseMaxspeed(dir, lpd)
            ?: parseMaxspeed(t["maxspeed"], lpd)
            ?: parseMaxspeed(t["zone:maxspeed"], lpd)
            ?: parseMaxspeed(t["maxspeed:type"], lpd)
            ?: parseMaxspeed(t["source:maxspeed"], lpd)
        val road = listOfNotNull(t["ref"]?.takeIf { it.isNotBlank() }, t["name"]?.takeIf { it.isNotBlank() })
            .joinToString(" · ")
        // Rotondas: siempre 40 (elegido por ella; sus correcciones a mano siguen mandando)
        if (t["junction"] in setOf("roundabout", "circular")) return LimitInfo(ROUNDABOUT_KMH, false, road.ifEmpty { "Rotonda" }, m.way.id)
        return if (tagged != null) LimitInfo(tagged, false, road, m.way.id)
        else LimitInfo(infer(t), true, road, m.way.id)
    }

    /** Diferencia entre dos rumbos, de 0 a 180 grados. */
    fun angleDiff(a: Double, b: Double): Double {
        val d = Math.abs(((a - b) % 360 + 360) % 360)
        return if (d > 180) 360 - d else d
    }

    /**
     * Vía más probable para una posición: la más cercana, castigando las que no van en la dirección
     * del rumbo y descartando las de sentido único en contra. Para no dar saltos en los cruces se
     * sigue con la vía anterior mientras siga siendo casi igual de buena.
     */
    fun match(ways: List<OsmWay>, lat: Double, lon: Double, bearing: Double?, prevId: Long?): WayMatch? {
        val k = DEG * EARTH
        val kx = k * Math.cos(lat * DEG)
        var best: WayMatch? = null
        var bestScore = Double.MAX_VALUE
        var prev: WayMatch? = null
        var prevScore = Double.MAX_VALUE
        val mLat = 70.0 / k
        val mLon = 70.0 / kx
        for (w in ways) {
            if (w.lat.size < 2) continue
            if (lat < w.minLat - mLat || lat > w.maxLat + mLat || lon < w.minLon - mLon || lon > w.maxLon + mLon) continue
            val ow = oneway(w.tags)
            var wScore = Double.MAX_VALUE
            var wDist = 0.0
            var wFwd = true
            for (i in 0 until w.lat.size - 1) {
                val ax = (w.lon[i] - lon) * kx
                val ay = (w.lat[i] - lat) * k
                val dx = (w.lon[i + 1] - lon) * kx - ax
                val dy = (w.lat[i + 1] - lat) * k - ay
                val len2 = dx * dx + dy * dy
                val t = if (len2 < 1e-6) 0.0 else ((-ax * dx - ay * dy) / len2).coerceIn(0.0, 1.0)
                val d = Math.hypot(ax + t * dx, ay + t * dy)
                if (d > 60) continue
                var score = d
                var fwd = true
                if (bearing != null && len2 > 1e-6) {
                    val seg = (Math.toDegrees(Math.atan2(dx, dy)) + 360) % 360
                    val diff = angleDiff(bearing, seg)
                    fwd = diff <= 90
                    score += when {
                        ow == 1 && diff > 110 -> 1000.0
                        ow == -1 && diff < 70 -> 1000.0
                        else -> minOf(diff, 180 - diff) / 90 * 20
                    }
                }
                if (score < wScore) { wScore = score; wDist = d; wFwd = fwd }
            }
            if (wScore == Double.MAX_VALUE) continue
            if (wScore < bestScore) { bestScore = wScore; best = WayMatch(w, wDist, wFwd) }
            if (w.id == prevId) { prevScore = wScore; prev = WayMatch(w, wDist, wFwd) }
        }
        if (prev != null && prevScore < 500 && prevScore <= bestScore + 8 && prev.distM <= MAX_DIST_M) return prev
        return best?.takeIf { bestScore < 500 && it.distM <= MAX_DIST_M }
    }
}

// ═══════════════════════════════════════════════════════════════════ Presión del turbo precisa
// El dato OBD estándar de presión del colector (010B) es de un byte: no pasa de 255 kPa absolutos, unos
// 1,54 bar de turbo. La centralita guarda la presión real en su propia memoria con 2 bytes (en hPa), que es
// la que leen Autel o VCDS. Aquí se elige cuál es comparando cada candidato con el 010B mientras el turbo
// sopla pero sin llegar a su tope.

/** Fórmulas para un dato de presión de 2 bytes. 0 = hPa · 1 = décimas de hPa · 2 = centésimas de bar. */
object PressureFormula {
    const val COUNT = 3
    fun hpa(d: IntArray, f: Int): Double? {
        if (d.size < 2) return null
        val raw = d[0] * 256 + d[1]
        return when (f) {
            0 -> raw.toDouble()
            1 -> raw / 10.0
            2 -> raw * 10.0
            else -> null
        }
    }
}

/** Identificador de la centralita que podría ser una presión; se va puntuando al conducir. */
class BoostCandidate(val did: Int, val formula: Int) {
    var n = 0
    var sumErr = 0.0
    var ambN = 0
    var ambSum = 0.0
    var ambOk = true
    val meanErr: Double get() = if (n == 0) Double.MAX_VALUE else sumErr / n
    /** Se queda quieto en la presión atmosférica mientras el turbo sopla: es la presión ambiental. */
    val isAmbient: Boolean get() = ambOk && ambN >= 3
    /** Ya está claro que no sigue al turbo. */
    val discarded: Boolean get() = n >= 2 && meanErr > 300
}

enum class Calib { ESPERANDO, HECHO, FALLIDO }

class BoostCalibrator(list: List<BoostCandidate>) {
    val cands: List<BoostCandidate> = list.toList()
    var boost: BoostCandidate? = null
        private set
    var ambient: BoostCandidate? = null
        private set

    companion object {
        /** Solo se compara cuando el turbo sopla y el dato estándar aún no está en su tope (255 kPa). */
        fun usable(mapKpa: Double) = mapKpa in 125.0..245.0
        const val SAMPLES = 5
        const val MAX_ERR_HPA = 60.0
    }

    fun sample(c: BoostCandidate, hpa: Double, mapKpa: Double, baroKpa: Double) {
        c.n++
        c.sumErr += Math.abs(hpa - mapKpa * 10)
        val dev = Math.abs(hpa - baroKpa * 10)
        if (dev > 25) c.ambOk = false else { c.ambN++; c.ambSum += dev }
    }

    /** Los que todavía hay que leer. */
    fun pending(): List<BoostCandidate> = cands.filter { c ->
        when {
            // Descartado como presión del turbo: se sigue leyendo solo si puede ser la ambiental
            c.discarded -> c.ambOk && c.ambN < 3
            else -> c.n < SAMPLES + 3
        }
    }

    /** Cuántos están ya decididos (para el progreso). */
    fun done(): Int = cands.count { it.discarded || it.n >= SAMPLES }

    fun decide(): Calib {
        if (cands.any { !it.discarded && it.n < SAMPLES }) return Calib.ESPERANDO
        val best = cands.filter { it.n >= SAMPLES && it.meanErr <= MAX_ERR_HPA }.minByOrNull { it.meanErr }
            ?: return Calib.FALLIDO
        boost = best
        ambient = cands.filter { it !== best && it.isAmbient }.minByOrNull { it.ambSum / it.ambN }
        return Calib.HECHO
    }
}

// ═══════════════════════════════════════════════════════════════════ Mapa de límites guardado
// El mapa se guarda en la pantalla por teselas de 0,05° (unos 5,5 × 4,3 km). Cada tesela es un fichero
// comprimido con las vías y solo las etiquetas que hacen falta, así funciona sin internet solo con el GPS.

object LimitTiles {
    const val SIZE = 0.05
    private const val VERSION = 1
    /** Etiquetas que se guardan (el resto no hace falta para el límite). */
    val KEEP = setOf(
        "highway", "maxspeed", "maxspeed:forward", "maxspeed:backward", "maxspeed:type", "zone:maxspeed",
        "source:maxspeed", "oneway", "junction", "lanes", "lanes:forward", "ref", "name", "motorroad",
        "surface", "tracktype",
    )

    fun key(lat: Double, lon: Double): Long {
        val ix = Math.floor(lon / SIZE).toInt()
        val iy = Math.floor(lat / SIZE).toInt()
        return (ix.toLong() shl 32) or (iy.toLong() and 0xFFFFFFFFL)
    }

    fun ix(key: Long): Int = (key shr 32).toInt()
    fun iy(key: Long): Int = key.toInt()

    /** Sur, oeste, norte, este. */
    fun bbox(key: Long): DoubleArray {
        val s = iy(key) * SIZE
        val w = ix(key) * SIZE
        return doubleArrayOf(s, w, s + SIZE, w + SIZE)
    }

    fun fileName(key: Long) = "t_%d_%d.bin".format(ix(key), iy(key))

    /** La tesela de la posición y las vecinas si está a menos de [marginM] metros del borde. */
    fun around(lat: Double, lon: Double, marginM: Double): List<Long> {
        val dLat = marginM / 111_320.0
        val dLon = marginM / (111_320.0 * Math.cos(Math.toRadians(lat)))
        return listOf(
            key(lat, lon), key(lat - dLat, lon - dLon), key(lat - dLat, lon + dLon),
            key(lat + dLat, lon - dLon), key(lat + dLat, lon + dLon),
        ).distinct()
    }

    /** Teselas a menos de [km] del punto, de la más cercana a la más lejana. */
    fun inRadius(lat: Double, lon: Double, km: Double): List<Long> {
        val dLat = km * 1000 / 111_320.0
        val dLon = km * 1000 / (111_320.0 * Math.cos(Math.toRadians(lat)))
        val out = ArrayList<Pair<Long, Double>>()
        var y = Math.floor((lat - dLat) / SIZE).toInt()
        val y1 = Math.floor((lat + dLat) / SIZE).toInt()
        while (y <= y1) {
            var x = Math.floor((lon - dLon) / SIZE).toInt()
            val x1 = Math.floor((lon + dLon) / SIZE).toInt()
            while (x <= x1) {
                // Punto de la tesela más cercano al centro
                val cy = (lat).coerceIn(y * SIZE, (y + 1) * SIZE)
                val cx = (lon).coerceIn(x * SIZE, (x + 1) * SIZE)
                val d = SpeedLimits.distanceM(lat, lon, cy, cx)
                if (d <= km * 1000) out += ((x.toLong() shl 32) or (y.toLong() and 0xFFFFFFFFL)) to d
                x++
            }
            y++
        }
        return out.sortedBy { it.second }.map { it.first }
    }

    fun write(out: java.io.OutputStream, ways: List<OsmWay>) {
        java.io.DataOutputStream(java.io.BufferedOutputStream(java.util.zip.GZIPOutputStream(out))).use { d ->
            d.writeInt(VERSION)
            d.writeLong(System.currentTimeMillis())
            d.writeInt(ways.size)
            for (w in ways) {
                d.writeLong(w.id)
                val tags = w.tags.filterKeys { it in KEEP }
                d.writeByte(tags.size)
                for ((k, v) in tags) { d.writeUTF(k); d.writeUTF(v.take(200)) }
                d.writeInt(w.lat.size)
                for (i in w.lat.indices) {
                    d.writeInt(Math.round(w.lat[i] * 1e6).toInt())
                    d.writeInt(Math.round(w.lon[i] * 1e6).toInt())
                }
            }
        }
    }

    /** Lee una tesela guardada. Devuelve las vías y la fecha en que se descargó, o null si el fichero no vale. */
    fun read(inp: java.io.InputStream): Pair<List<OsmWay>, Long>? = try {
        java.io.DataInputStream(java.io.BufferedInputStream(java.util.zip.GZIPInputStream(inp))).use { d ->
            if (d.readInt() != VERSION) return null
            val time = d.readLong()
            val n = d.readInt()
            val ways = ArrayList<OsmWay>(n)
            repeat(n) {
                val id = d.readLong()
                val nt = d.readUnsignedByte()
                val tags = HashMap<String, String>(nt * 2)
                repeat(nt) { val k = d.readUTF(); tags[k] = d.readUTF() }
                val np = d.readInt()
                val la = DoubleArray(np)
                val lo = DoubleArray(np)
                for (i in 0 until np) { la[i] = d.readInt() / 1e6; lo[i] = d.readInt() / 1e6 }
                ways += OsmWay(id, tags, la, lo)
            }
            ways to time
        }
    } catch (_: Exception) { null }
}

// ═══════════════════════════════════════════════════════════════════ Radares
// Radares fijos del mapa (OpenStreetMap). Se avisa del que está por delante, en la dirección de la marcha,
// a menos de la distancia elegida. El rumbo con que mira cada radar no siempre está en el mapa, así que no
// se usa: basta con que esté delante y casi en línea con el coche.

/**
 * Radar: [tramo] = inicio de un tramo de control de velocidad (si no, radar fijo).
 * [mine] = añadido a mano en la pantalla; [dir] = rumbo con el que se iba al añadirlo (solo avisa en ese sentido).
 */
class Radar(
    val lat: Double, val lon: Double, val kmh: Int?, val dir: Double?,
    val tramo: Boolean = false, val mine: Boolean = false,
    /** Solo los tuyos: nombre (la calle al guardarlo), fecha, si avisa en los dos sentidos y si está activo. */
    val name: String = "", val date: String = "", val both: Boolean = false, val on: Boolean = true,
) {
    fun copy(name: String = this.name, tramo: Boolean = this.tramo, both: Boolean = this.both, kmh: Int? = this.kmh, on: Boolean = this.on) =
        Radar(lat, lon, kmh, dir, tramo, mine, name, date, both, on)
}

/** Radar por delante y a qué distancia está, en metros. */
class RadarAhead(val radar: Radar, val distM: Double)

object Radars {
    /** Lee el fichero "lat;lon;límite;rumbo" (las líneas que empiezan por # son comentarios). */
    fun parse(text: String): List<Radar> = text.lineSequence().mapNotNull { l ->
        if (l.isBlank() || l.startsWith("#")) return@mapNotNull null
        val f = l.split(';')
        val lat = f.getOrNull(0)?.toDoubleOrNull() ?: return@mapNotNull null
        val lon = f.getOrNull(1)?.toDoubleOrNull() ?: return@mapNotNull null
        Radar(lat, lon, f.getOrNull(2)?.toIntOrNull(), f.getOrNull(3)?.toDoubleOrNull())
    }.toList()

    /**
     * Radares añadidos a mano: "lat;lon;límite;rumbo;tipo;sentidos;activo;fecha;nombre"
     * (tipo F = fijo, T = tramo; sentidos 1 = uno, 2 = los dos; activo 1/0). Los de la v36–v38 solo tienen los 5 primeros.
     */
    fun encodeMine(list: List<Radar>): String = list.joinToString("\n") { r ->
        listOf(
            "%.6f".format(java.util.Locale.US, r.lat), "%.6f".format(java.util.Locale.US, r.lon), r.kmh?.toString() ?: "",
            r.dir?.let { "%.0f".format(java.util.Locale.US, it) } ?: "", if (r.tramo) "T" else "F",
            if (r.both) "2" else "1", if (r.on) "1" else "0", r.date.replace(";", ","), r.name.replace(";", ",").replace("\n", " "),
        ).joinToString(";")
    }

    fun decodeMine(text: String?): List<Radar> = text.orEmpty().lines().mapNotNull { l ->
        val f = l.split(';')
        val lat = f.getOrNull(0)?.toDoubleOrNull() ?: return@mapNotNull null
        val lon = f.getOrNull(1)?.toDoubleOrNull() ?: return@mapNotNull null
        Radar(
            lat, lon, f.getOrNull(2)?.toIntOrNull(), f.getOrNull(3)?.toDoubleOrNull(), f.getOrNull(4) == "T", mine = true,
            name = f.getOrNull(8).orEmpty(), date = f.getOrNull(7).orEmpty(), both = f.getOrNull(5) == "2", on = f.getOrNull(6) != "0",
        )
    }

    /** El radar más cercano en cualquier dirección (para comprobar si el mapa lo tiene). */
    fun nearest(list: List<Radar>, lat: Double, lon: Double): RadarAhead? =
        list.minByOrNull { SpeedLimits.distanceM(lat, lon, it.lat, it.lon) }?.let { RadarAhead(it, SpeedLimits.distanceM(lat, lon, it.lat, it.lon)) }

    /** Rumbo de A a B (0 = norte, en grados). */
    fun bearing(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val x = (lon2 - lon1) * Math.cos(Math.toRadians((lat1 + lat2) / 2))
        val y = lat2 - lat1
        return (Math.toDegrees(Math.atan2(x, y)) + 360) % 360
    }

    /**
     * El radar más cercano que está delante: a menos de [maxM] metros, casi en la dirección de la marcha
     * (±25°, o más cuando ya está muy cerca) y a no más de 60 m a un lado de la trayectoria.
     */
    fun ahead(list: List<Radar>, lat: Double, lon: Double, heading: Double?, maxM: Double): RadarAhead? {
        if (heading == null) return null
        val dLat = maxM / 111_320.0
        val dLon = maxM / (111_320.0 * Math.cos(Math.toRadians(lat)))
        var best: RadarAhead? = null
        for (r in list) {
            if (Math.abs(r.lat - lat) > dLat || Math.abs(r.lon - lon) > dLon) continue
            val d = SpeedLimits.distanceM(lat, lon, r.lat, r.lon)
            if (d > maxM) continue
            val diff = SpeedLimits.angleDiff(heading, bearing(lat, lon, r.lat, r.lon))
            if (r.mine) {
                if (!r.on) continue
                // Solo en el sentido en que se guardó (salvo que sea de los dos sentidos)
                if (!r.both && r.dir != null && SpeedLimits.angleDiff(heading, r.dir) > 60) continue
                // Más margen que en los del mapa: en una calle con curvas el radar no queda en línea recta
                // hasta los últimos metros, y antes no avisaba hasta los ~200 m
                if (diff > (if (d < 150) 90.0 else 80.0)) continue
                // Con su sentido guardado ya se sabe que va por donde toca: no se mira cuánto se aparta la curva.
                // En los de los dos sentidos sí, para no avisar de un radar de una calle paralela.
                if ((r.both || r.dir == null) && d * Math.sin(Math.toRadians(diff)) > 300) continue
            } else {
                val maxDiff = if (d < 80) 70.0 else 25.0
                if (diff > maxDiff) continue
                if (d * Math.sin(Math.toRadians(diff)) > 60) continue
            }
            if (best == null || d < best.distM) best = RadarAhead(r, d)
        }
        return best
    }
}

// ═══════════════════════════════════════════════════════════════════ Correcciones del límite
// Cuando el mapa no coincide con la señal, se corrige a mano y queda guardado: para ese tramo de vía o para
// toda la calle (mismo nombre, a menos de 5 km de donde se corrigió, para no confundir calles de otros pueblos).

class LimitFix(val wayId: Long?, val name: String?, val lat: Double, val lon: Double, val kmh: Int)

object LimitFixes {
    const val STREET_RADIUS_M = 5000.0

    fun encode(list: List<LimitFix>): String = list.joinToString("\n") { f ->
        listOf(f.wayId?.toString() ?: "", (f.name ?: "").replace("\n", " ").replace("|", "/"), "%.5f".format(java.util.Locale.US, f.lat), "%.5f".format(java.util.Locale.US, f.lon), f.kmh.toString()).joinToString("|")
    }

    fun decode(text: String?): List<LimitFix> = text.orEmpty().lines().mapNotNull { l ->
        val p = l.split("|")
        if (p.size != 5) return@mapNotNull null
        val kmh = p[4].toIntOrNull() ?: return@mapNotNull null
        LimitFix(p[0].toLongOrNull(), p[1].ifBlank { null }, p[2].toDoubleOrNull() ?: return@mapNotNull null, p[3].toDoubleOrNull() ?: return@mapNotNull null, kmh)
    }

    /** Aplica la corrección que toque: primero la de ese tramo y, si no hay, la de toda la calle. */
    fun apply(info: LimitInfo, way: OsmWay, lat: Double, lon: Double, list: List<LimitFix>): LimitInfo {
        if (list.isEmpty()) return info
        val name = way.tags["name"]
        val fix = list.firstOrNull { it.wayId == way.id }
            ?: if (name.isNullOrBlank()) null else list.firstOrNull {
                it.wayId == null && it.name.equals(name, ignoreCase = true) && SpeedLimits.distanceM(lat, lon, it.lat, it.lon) <= STREET_RADIUS_M
            }
        return if (fix == null) info else info.copy(kmh = fix.kmh, estimated = false, corrected = true)
    }
}

// ═══════════════════════════════════════════════════════════════════ Nombre corto de la vía
// Para que quepa debajo del reloj: abreviaturas de las señales (castellano y valenciano) y, en autopistas,
// autovías y carreteras, la matrícula en vez del nombre largo.

object RoadNames {
    private val abbr = listOf(
        "avinguda" to "Av.", "avenida" to "Av.", "carrer" to "C/", "calle" to "C/", "plaça" to "Pl.", "plaza" to "Pl.",
        "passeig" to "Pg.", "paseo" to "P.º", "carretera" to "Ctra.", "camino" to "Cno.", "ronda" to "Rda.",
        "travessera" to "Trav.", "travesía" to "Trav.", "travesia" to "Trav.", "glorieta" to "Gta.", "bulevar" to "Bv.",
        "urbanització" to "Urb.", "urbanización" to "Urb.", "polígon" to "Pol.", "polígono" to "Pol.", "partida" to "Pda.",
    )
    private val roadWords = Regex("^(autopista|autovía|autovia|carretera|variante|vía de servicio|via de servicio)\\b", RegexOption.IGNORE_CASE)

    /** "AP-7 · Autopista del Mediterráneo" → "AP-7" · "Avinguda dels Germans Bou" → "Av. dels Germans Bou". */
    fun short(road: String): String {
        if (road.isBlank()) return road
        val parts = road.split(" · ")
        val ref = if (parts.size >= 2) parts[0] else null
        val name = parts.last()
        if (ref != null && roadWords.containsMatchIn(name)) return ref
        val lower = name.lowercase()
        for ((word, short) in abbr) {
            if (lower.startsWith("$word ")) {
                var rest = name.substring(word.length + 1)
                // "Carrer de Navarra" → "C/ Navarra" · "Carrer d'Enmig" → "C/ Enmig" (se mantienen "del", "de la"…)
                val keepDe = listOf("de la ", "de les ", "de los ", "de las ", "de l'", "de l’").any { rest.startsWith(it, ignoreCase = true) }
                if (rest.startsWith("de ", ignoreCase = true) && !keepDe) rest = rest.substring(3)
                else if (rest.startsWith("d'", ignoreCase = true) || rest.startsWith("d’", ignoreCase = true)) rest = rest.substring(2)
                return "$short $rest"
            }
        }
        return name
    }
}

// ═══════════════════════════════════════════════════════════════════ Consumo
// Muchos diésel de 2011 no dan el consumo por OBD (015E). Se calcula con lo que sí dan, por orden:
//  1) 015E, el consumo que da el coche.
//  2) Par real (0162) + revoluciones: el gasóleo es proporcional al par más los rozamientos.
//  3) Carga del motor (0104) + revoluciones: en los diésel la carga sigue a la cantidad inyectada.
//  4) Caudal de aire (0110) + lambda de la sonda (0134) o la pedida (0144): gasóleo = aire / (14,5 × λ).
// En todos, con el motor retenido (sin carga y más de 1100 rpm) hay corte de inyección: consumo 0.
// Y siempre se puede igualar con el marcador del cuadro (factor de corrección).

enum class FuelSource(val text: String, val pids: List<Int>) {
    PID("Consumo que da el coche (015E)", listOf(0x5E)),
    TORQUE("Calculado por par y revoluciones (0162 + 010C)", listOf(0x62, 0x0C)),
    LOAD("Calculado por carga del motor y revoluciones (0104 + 010C)", listOf(0x04, 0x0C)),
    MAF_O2("Calculado por caudal de aire y sonda lambda (0110 + 0134)", listOf(0x10, 0x34)),
    MAF_LAMBDA("Calculado por caudal de aire y lambda (0110 + 0144)", listOf(0x10, 0x44)),
    NONE("El coche no da datos para calcularlo", emptyList()),
}

object Fuel {
    const val DIESEL_KG_PER_L = 0.832
    private const val DIESEL_MJ_PER_KG = 42.6
    private const val INDICATED_EFFICIENCY = 0.42
    private const val CYLINDERS = 4
    /** Par de referencia del CFHD de serie, si el coche no da el 0163. */
    const val DEFAULT_REF_NM = 320.0
    /** Datos que pueden servir para el consumo (para enseñar en Ajustes cuáles da el coche). */
    val relevant = listOf(0x5E to "Consumo", 0x62 to "Par real", 0x63 to "Par de referencia", 0x04 to "Carga",
        0x0C to "Revoluciones", 0x10 to "Caudal de aire", 0x34 to "Sonda lambda", 0x44 to "Lambda pedida", 0x0D to "Velocidad")

    fun source(supported: Set<Int>): FuelSource =
        FuelSource.values().firstOrNull { it != FuelSource.NONE && it.pids.all { p -> p in supported } } ?: FuelSource.NONE

    /** L/h a partir del par real (en % del de referencia), el par de referencia (Nm) y las revoluciones. */
    fun fromTorque(torquePct: Double, refNm: Double, rpm: Double): Double {
        if (rpm < 300) return 0.0
        if (torquePct <= 0 && rpm > 1100) return 0.0   // retención: corte de inyección
        val effNm = maxOf(0.0, torquePct) / 100 * refNm
        val frictionNm = 12 + 6 * rpm / 1000 + 8       // rozamientos y accesorios (alternador, bomba…)
        // Trabajo indicado por cilindro y ciclo = π·Par (J). Gasóleo = trabajo / (poder calorífico × rendimiento)
        val mgPerStroke = Math.PI * (effNm + frictionNm) / (DIESEL_MJ_PER_KG * INDICATED_EFFICIENCY)
        val gPerS = mgPerStroke * CYLINDERS * rpm / 120 / 1000
        return gPerS * 3.6 / DIESEL_KG_PER_L
    }

    /**
     * L/h a partir de la carga calculada (%). En los diésel VAG la carga es el par pedido respecto al máximo,
     * e incluye lo que se pierde en rozamientos (al ralentí marca un 15–25 %), así que se le quita esa parte.
     */
    fun fromLoad(loadPct: Double, rpm: Double): Double {
        if (rpm < 300) return 0.0
        if (loadPct < 3 && rpm > 1100) return 0.0
        val friction = 12 + 6 * rpm / 1000 + 8
        val nm = maxOf(0.0, loadPct / 100 * (DEFAULT_REF_NM + 40) - friction)
        return fromTorque(nm / DEFAULT_REF_NM * 100, DEFAULT_REF_NM, rpm)
    }

    /** L/h a partir del caudal de aire (g/s) y la lambda. null si la lambda no vale para calcular. */
    fun fromMaf(mafGs: Double, lambda: Double): Double? {
        if (lambda < 0.7 || lambda >= 1.95) return null
        return mafGs / (14.5 * lambda) * 3.6 / DIESEL_KG_PER_L
    }

    /** Sonda fuera de escala (λ ≥ 2, diésel con poca carga): se supone λ ≈ 3. */
    fun fromMafLean(mafGs: Double): Double = mafGs / (14.5 * 3.0) * 3.6 / DIESEL_KG_PER_L

    /** l/100 km (null parado, cuando no tiene sentido). */
    fun per100(lph: Double, kmh: Double): Double? = if (kmh < 5) null else lph / kmh * 100
}
