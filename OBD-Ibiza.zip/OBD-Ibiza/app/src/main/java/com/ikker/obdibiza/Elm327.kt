package com.ikker.obdibiza

import android.hardware.usb.UsbDeviceConnection
import com.hoho.android.usbserial.driver.UsbSerialPort
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.IOException

/**
 * Comunicación con un adaptador ELM327 (u OBDLink/STN compatible) por USB-serie.
 * Todas las órdenes pasan por un Mutex, así el sondeo en tiempo real y las órdenes
 * manuales (leer averías, consola…) nunca se pisan.
 */
class Elm327(
    private val port: UsbSerialPort,
    private val connection: UsbDeviceConnection,
    private val onLog: (String) -> Unit,
) {
    private val lock = Mutex()
    var logTraffic = false
    /** Últimos bytes recibidos tal cual (para diagnosticar). */
    @Volatile private var lastRx = ""

    // ── Lectura continua ─────────────────────────────────────────────────────────────
    // Antes cada orden hacía lecturas USB con tiempo límite que, si no llegaba nada, se cancelaban.
    // Algunas pantallas chinas llevan controladores USB que se cuelgan con muchas cancelaciones, y
    // entonces solo vuelven reiniciando la pantalla. Ahora un único hilo lee sin parar (sin tiempo
    // límite, nunca se cancela nada) y deja lo que llega en un búfer; cada orden solo espera ahí.
    private val rx = StringBuilder()
    private val rxLock = Object()
    @Volatile private var running = true
    @Volatile private var readerError: IOException? = null
    private val reader = Thread({
        val b = ByteArray(4096)
        try {
            while (running) {
                val n = port.read(b, 0)
                if (n > 0) synchronized(rxLock) { rx.append(String(b, 0, n, Charsets.ISO_8859_1)); rxLock.notifyAll() }
            }
        } catch (e: Exception) {
            if (running) {
                readerError = e as? IOException ?: IOException(e.message ?: e.javaClass.simpleName)
                synchronized(rxLock) { rxLock.notifyAll() }
            }
        }
    }, "obd-lectura").apply { isDaemon = true; start() }

    suspend fun send(cmd: String, timeoutMs: Long = 2500): String = lock.withLock {
        withContext(Dispatchers.IO) { raw(cmd, timeoutMs) }
    }

    @Throws(IOException::class)
    private fun raw(cmd: String, timeoutMs: Long): String {
        readerError?.let { throw it }
        // Vaciar restos de respuestas anteriores
        synchronized(rxLock) { rx.setLength(0) }
        port.write((cmd + "\r").toByteArray(Charsets.US_ASCII), 1000)
        val end = System.currentTimeMillis() + timeoutMs
        val got: String
        synchronized(rxLock) {
            while (rx.indexOf(">") < 0) {
                readerError?.let { throw it }
                val left = end - System.currentTimeMillis()
                if (left <= 0) break
                rxLock.wait(left)
            }
            got = rx.toString()
            rx.setLength(0)
        }
        lastRx = got
        val cleaned = got
            .replace(">", "")
            .replace("\u0000", "")
            .split('\r', '\n')
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.equals(cmd, ignoreCase = true) }
            .filterNot { it.startsWith("SEARCHING", true) || it.startsWith("BUS INIT", true) }
            .joinToString("\n")
        if (logTraffic) onLog("> $cmd\n${cleaned.ifEmpty { "(sin respuesta)" }}")
        return cleaned
    }

    /**
     * Modo escucha: manda la orden de monitor (STMA o ATMA) y va pasando cada línea que llega a [onLine]
     * hasta que [stop] diga que pare. Para cortar el monitor se manda un retorno de carro y se espera el ">".
     * Devuelve null si se paró a mano, o lo que dijo el adaptador si el monitor terminó solo
     * (por ejemplo "BUFFER FULL", "?" si no admite la orden).
     */
    suspend fun monitor(cmd: String, onLine: (String) -> Unit, stop: () -> Boolean): String? = lock.withLock {
        withContext(Dispatchers.IO) {
            readerError?.let { throw it }
            synchronized(rxLock) { rx.setLength(0) }
            port.write((cmd + "\r").toByteArray(Charsets.US_ASCII), 1000)
            val pending = StringBuilder()
            var ended: String? = null
            while (!stop() && ended == null) {
                readerError?.let { throw it }
                val chunk: String
                synchronized(rxLock) {
                    if (rx.isEmpty()) rxLock.wait(200)
                    chunk = rx.toString()
                    rx.setLength(0)
                }
                if (chunk.isEmpty()) continue
                pending.append(chunk)
                while (true) {
                    val i = pending.indexOfFirst { it == '\r' || it == '\n' || it == '>' }
                    if (i < 0) break
                    val c = pending[i]
                    val line = pending.substring(0, i).replace("\u0000", "").trim()
                    pending.delete(0, i + 1)
                    if (line.isNotEmpty() && !line.equals(cmd, ignoreCase = true)) {
                        val up = line.uppercase()
                        if (up == "?" || up.startsWith("BUFFER FULL") || up.startsWith("STOPPED") || up.startsWith("CAN ERROR")) ended = line
                        else onLine(line)
                    }
                    if (c == '>') { if (ended == null) ended = "fin del monitor"; break }
                }
            }
            if (ended == null) {
                // Parar el monitor: cualquier carácter lo corta; luego llega "STOPPED" y el ">"
                port.write("\r".toByteArray(Charsets.US_ASCII), 1000)
                val end = System.currentTimeMillis() + 2000
                synchronized(rxLock) {
                    while (rx.indexOf(">") < 0) {
                        val left = end - System.currentTimeMillis()
                        if (left <= 0) break
                        rxLock.wait(left)
                    }
                    rx.setLength(0)
                }
            }
            ended
        }
    }

    /**
     * Saludo al adaptador. El OBDLink EX trabaja siempre a 115200 baudios, así que no se prueba
     * ninguna otra velocidad: se fija esa, se vacían los buffers y se reinicia con ATZ.
     * Si no contesta, un segundo intento por la misma velocidad (por si seguía ocupado con algo
     * anterior). Devuelve la versión o null.
     */
    suspend fun handshake(): String? {
        try {
            port.setParameters(BAUD, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
        } catch (ex: Exception) {
            onLog("No se pudo fijar $BAUD baudios: ${ex.message}")
            return null
        }
        try { port.purgeHwBuffers(true, true) } catch (_: Exception) { }
        delay(300)   // deja que el chip USB termine de arrancar tras abrir el puerto
        onLog("Conectando a $BAUD baudios…")
        for (attempt in 1..2) {
            send("", 300)   // corta lo que hubiera a medias
            val r = send("ATZ", 3500)
            if (isAdapter(r)) {
                onLog("Adaptador encontrado: " + (r.lines().lastOrNull { isAdapter(it) } ?: r))
                return r.lines().lastOrNull { isAdapter(it) } ?: r
            }
            // Lo que llegó del adaptador, en hexadecimal, para saber si está mudo o contesta otra cosa
            val hex = lastRx.toByteArray(Charsets.ISO_8859_1).joinToString(" ") { "%02X".format(it) }
            onLog("ATZ ($attempt) → " + hex.take(90).ifEmpty { "(silencio, 0 bytes)" })
        }
        return rescueBaud()
    }

    /**
     * Último recurso, una sola vez por sesión de la app: si el adaptador no contesta a 115200 puede que
     * se le haya quedado guardada otra velocidad. Se prueban las demás; si contesta a alguna, se le
     * borran los ajustes guardados (STRSTNVM) y se reinicia, con lo que vuelve a 115200 de fábrica.
     */
    private suspend fun rescueBaud(): String? {
        if (rescueDone) return null
        rescueDone = true
        onLog("Sin respuesta a $BAUD · probando otras velocidades (solo esta vez)")
        for (b in listOf(38400, 9600, 230400, 57600, 460800, 500000, 1000000, 2000000)) {
            try { port.setParameters(b, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE) } catch (_: Exception) { continue }
            try { port.purgeHwBuffers(true, true) } catch (_: Exception) { }
            send("", 200)
            val r = send("ATZ", 2000)
            if (!isAdapter(r)) continue
            onLog("El adaptador contesta a $b baudios · lo devuelvo a $BAUD de fábrica")
            send("STRSTNVM", 3000)   // borra los ajustes guardados, incluida la velocidad
            send("STFAC", 3000)
            send("ATZ", 800)         // reinicia: arranca ya a 115200
            try { port.setParameters(BAUD, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE) } catch (_: Exception) { }
            try { port.purgeHwBuffers(true, true) } catch (_: Exception) { }
            delay(1000)
            send("", 300)
            val r2 = send("ATZ", 3500)
            if (isAdapter(r2)) {
                onLog("Adaptador recuperado a $BAUD baudios")
                return r2.lines().lastOrNull { isAdapter(it) } ?: r2
            }
            onLog("No se recuperó tras el reinicio")
            return null
        }
        try { port.setParameters(BAUD, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE) } catch (_: Exception) { }
        onLog("No contesta a ninguna velocidad")
        return null
    }

    private fun isAdapter(r: String) = r.contains("ELM", true) || r.contains("STN", true) || r.contains("OBDLINK", true)

    fun close() {
        running = false
        try { port.close() } catch (_: Exception) { }   // desbloquea el hilo de lectura
        try { connection.close() } catch (_: Exception) { }
    }

    companion object {
        /** Única velocidad usada con el adaptador. */
        const val BAUD = 115200

        /** Si ya se ha hecho el barrido de rescate en esta sesión de la app (para no repetirlo en cada reintento). */
        @Volatile private var rescueDone = false

        private val ERRORS = listOf("NO DATA", "UNABLE TO CONNECT", "CAN ERROR", "BUS ERROR", "STOPPED", "ERROR", "?")

        fun isError(r: String) = r.isBlank() || ERRORS.any { r.trim().uppercase().startsWith(it) }

        private val frameIndex = Regex("^[0-9A-F]:")
        private val byteCount = Regex("^[0-9A-F]{3}$")

        /** Convierte la respuesta en mensajes (lista de bytes). Junta tramas CAN multi-frame. */
        fun messages(resp: String): List<IntArray> {
            val lines = resp.uppercase().lines().map { it.replace(" ", "") }.filter { it.isNotEmpty() }
            val multi = lines.any { frameIndex.containsMatchIn(it) }
            val hexLines = if (multi) {
                var joined = lines.filter { frameIndex.containsMatchIn(it) }.joinToString("") { it.substring(2) }
                // La primera línea ("00F") dice cuántos bytes trae el mensaje: lo demás es relleno de la última trama
                val len = lines.firstOrNull { byteCount.matches(it) }?.toIntOrNull(16)
                if (len != null && len * 2 <= joined.length) joined = joined.substring(0, len * 2)
                listOf(joined)
            } else lines
            return hexLines.mapNotNull { l ->
                if (l.isEmpty() || l.length % 2 != 0 || !l.all { it in "0123456789ABCDEF" }) null
                else IntArray(l.length / 2) { i -> l.substring(i * 2, i * 2 + 2).toInt(16) }
            }
        }

        /** Datos de un PID del modo 01 ("41 PID A B …"). */
        fun mode01(resp: String, pid: Int): IntArray? {
            val need = Params.bytesFor(pid)
            for (m in messages(resp)) {
                if (m.size >= 2 + need && m[0] == 0x41 && m[1] == pid) return m.copyOfRange(2, 2 + need)
            }
            return null
        }

        /** Respuesta a una petición con varios PIDs ("01 0C 0D 05"): "41 0C xx xx 0D xx 05 xx" → mapa PID → datos. */
        fun mode01Multi(resp: String, wanted: List<Int>): Map<Int, IntArray> {
            val out = mutableMapOf<Int, IntArray>()
            for (m in messages(resp)) {
                if (m.size < 3 || m[0] != 0x41) continue
                var i = 1
                while (i < m.size) {
                    val pid = m[i]
                    if (pid !in wanted) break
                    val n = Params.bytesFor(pid)
                    if (i + 1 + n > m.size) break
                    out[pid] = m.copyOfRange(i + 1, i + 1 + n)
                    i += 1 + n
                }
            }
            return out
        }

        /** Mapa de PIDs soportados (0100, 0120, …). */
        fun supported(resp: String, base: Int): Set<Int> {
            val out = mutableSetOf<Int>()
            for (m in messages(resp)) {
                if (m.size >= 6 && m[0] == 0x41 && m[1] == base) {
                    for (i in 0 until 32) {
                        val byte = m[2 + i / 8]
                        if (byte and (0x80 shr (i % 8)) != 0) out += base + i + 1
                    }
                }
            }
            return out
        }

        /**
         * Presión del colector de 2 bytes de los PID ampliados (en kPa absolutos, resolución 1/32):
         * 0187 = presión del colector · 0170 = control del turbo (se usa la presión real del sensor A).
         */
        fun extendedMap(resp: String, pid: Int): Double? {
            for (m in messages(resp)) {
                if (m.size < 3 || m[0] != 0x41 || m[1] != pid) continue
                if (pid == 0x87 && m.size >= 5 && (m[2] and 0x01) != 0) return (m[3] * 256 + m[4]) / 32.0
                if (pid == 0x70 && m.size >= 7 && (m[2] and 0x02) != 0) return (m[5] * 256 + m[6]) / 32.0
            }
            return null
        }

        /** Datos de un ReadDataByIdentifier UDS ("62 DID_H DID_L A B …"). */
        fun mode22(resp: String, did: Int): IntArray? {
            for (m in messages(resp)) {
                if (m.size >= 4 && m[0] == 0x62 && m[1] == (did shr 8) && m[2] == (did and 0xFF)) return m.copyOfRange(3, m.size)
            }
            return null
        }

        /** Respuesta a "0100": PIDs 01-20 soportados, o null si el coche no ha contestado. */
        fun mode01Supported(resp: String): Set<Int>? =
            if (messages(resp).any { it.size >= 6 && it[0] == 0x41 && it[1] == 0x00 }) supported(resp, 0x00) else null

        /** Códigos de avería de los modos 03 (43), 07 (47) o 0A (4A). */
        fun dtcs(resp: String, header: Int): List<String> {
            val out = linkedSetOf<String>()
            for (m in messages(resp)) {
                if (m.isEmpty() || m[0] != header) continue
                var data = m.copyOfRange(1, m.size)
                // En CAN el primer byte es el número de códigos (quedaría impar)
                if (data.size % 2 == 1) data = data.copyOfRange(1, data.size)
                var i = 0
                while (i + 1 < data.size) {
                    val a = data[i]; val b = data[i + 1]
                    if (a != 0 || b != 0) out += decodeDtc(a, b)
                    i += 2
                }
            }
            return out.toList()
        }

        /**
         * Memoria de averías propia de la centralita (UDS, servicio 19 02): "59 02 máscara [H M L estado]…".
         * Es la que leen Autel, VCDS o los talleres. null si la centralita no contestó a la petición.
         */
        fun udsDtcs(resp: String): List<UdsDtc>? {
            var answered = false
            val out = linkedMapOf<String, Int>()
            val ftbs = mutableMapOf<String, Int>()
            for (m in messages(resp)) {
                if (m.size < 3 || m[0] != 0x59 || m[1] != 0x02) continue
                answered = true
                var i = 3
                while (i + 3 < m.size) {
                    val h = m[i]; val mid = m[i + 1]; val ftb = m[i + 2]; val status = m[i + 3]
                    // Solo averías de verdad: fallando ahora (bit 0), pendiente (bit 2) o confirmada (bit 3).
                    // Las que solo tienen "prueba no completada" (bits 4 y 6), que salen todas tras un borrado, no lo son.
                    if ((h != 0 || mid != 0) && (status and 0x0D) != 0) {
                        val code = decodeDtc(h, mid)
                        out[code] = (out[code] ?: 0) or status
                        if (code !in ftbs || (status and 0x01) != 0) ftbs[code] = ftb
                    }
                    i += 4
                }
            }
            return if (answered) out.map { UdsDtc(it.key, it.value, ftbs[it.key] ?: 0) } else null
        }

        /** ¿Hay respuesta positiva al servicio [sid]? (la positiva es sid + 0x40). */
        fun positive(resp: String, sid: Int): Boolean = messages(resp).any { it.isNotEmpty() && it[0] == sid + 0x40 }

        /** Código de rechazo ("7F sid código") del servicio [sid], sin contar el "espera" (78). */
        fun nrc(resp: String, sid: Int): Int? =
            messages(resp).firstOrNull { it.size >= 3 && it[0] == 0x7F && it[1] == sid && it[2] != 0x78 }?.get(2)

        /** Motivo de rechazo en palabras. */
        fun nrcText(code: Int?): String = when (code) {
            null -> "sin respuesta"
            0x11, 0x12 -> "no admite esta orden"
            0x13 -> "orden mal formada"
            0x22 -> "condiciones no válidas: motor en marcha o algo en curso"
            0x31 -> "fuera de rango"
            0x33 -> "acceso protegido"
            0x7E, 0x7F -> "no se admite en esta sesión"
            else -> "rechazado (%02X)".format(code)
        }

        fun decodeDtc(a: Int, b: Int): String {
            val letter = "PCBU"[a shr 6]
            return "%c%d%X%02X".format(letter, (a shr 4) and 0x3, a and 0xF, b)
        }

        /** Número de bastidor (modo 09 PID 02). */
        fun vin(resp: String): String? {
            val bytes = messages(resp).flatMap { it.toList() }
            val idx = bytes.windowed(2).indexOfFirst { it[0] == 0x49 && it[1] == 0x02 }
            if (idx < 0) return null
            val chars = bytes.drop(idx + 2)
                .filter { it in 0x30..0x5A }
                .map { it.toChar() }
                .joinToString("")
            return if (chars.length >= 17) chars.takeLast(17) else chars.ifEmpty { null }
        }
    }
}

/**
 * Avería de la memoria propia de la centralita (UDS). [status] es el byte de estado ISO 14229 y [ftb]
 * el tipo de fallo SAE J2012 (circuito abierto, cortocircuito a masa…).
 */
data class UdsDtc(val code: String, val status: Int, val ftb: Int = 0) {
    /** El fallo está presente ahora mismo. */
    val active: Boolean get() = (status and 0x01) != 0
    val pending: Boolean get() = (status and 0x04) != 0
    val confirmed: Boolean get() = (status and 0x08) != 0
    /** La centralita pide encender el testigo de avería. */
    val mil: Boolean get() = (status and 0x80) != 0
    /** Ha fallado alguna vez desde el último borrado, pero ahora no. */
    val sporadic: Boolean get() = !active && (confirmed || (status and 0x20) != 0)
    val label: String get() = when {
        active -> "Activa ahora: el fallo sigue presente"
        confirmed -> "Guardada · ya no está activa"
        pending -> "Pendiente de confirmar"
        else -> "En el historial"
    }
}
