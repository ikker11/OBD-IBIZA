package com.ikker.obdibiza

import android.hardware.usb.UsbDeviceConnection
import com.hoho.android.usbserial.driver.UsbSerialPort
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.IOException

/**
 * Comunicación con un adaptador ELM327 (u OBDLink/STN compatible) por USB-serie.
 * Todas las órdenes pasan por un Mutex, así el sondeo en tiempo real y las órdenes
 * manuales (leer averías, consola…) nunca se pisan.
 */
class Elm327(
    private val port: UsbSerialPort,
    private val connection: UsbDeviceConnection,
    private val onLog: (String) -> Unit,
) {
    private val lock = Mutex()
    private val buf = ByteArray(1024)
    var logTraffic = false
    /** Últimos bytes recibidos tal cual (para diagnosticar). */
    @Volatile private var lastRx = ""

    suspend fun send(cmd: String, timeoutMs: Long = 2500): String = lock.withLock {
        withContext(Dispatchers.IO) { raw(cmd, timeoutMs) }
    }

    @Throws(IOException::class)
    private fun raw(cmd: String, timeoutMs: Long): String {
        // Vaciar restos de respuestas anteriores
        try {
            var guard = 0
            while (port.read(buf, 20) > 0 && guard++ < 20) { /* descartar */ }
        } catch (_: Exception) { }

        port.write((cmd + "\r").toByteArray(Charsets.US_ASCII), 1000)
        val sb = StringBuilder()
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            val n = port.read(buf, 100)
            if (n > 0) {
                sb.append(String(buf, 0, n, Charsets.ISO_8859_1))
                if (sb.indexOf(">") >= 0) break
            }
        }
        lastRx = sb.toString()
        val cleaned = sb.toString()
            .replace(">", "")
            .replace("\u0000", "")
            .split('\r', '\n')
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.equals(cmd, ignoreCase = true) }
            .filterNot { it.startsWith("SEARCHING", true) || it.startsWith("BUS INIT", true) }
            .joinToString("\n")
        if (logTraffic) onLog("> $cmd\n${cleaned.ifEmpty { "(sin respuesta)" }}")
        return cleaned
    }

    /**
     * Saludo al adaptador. El OBDLink EX trabaja siempre a 115200 baudios, así que no se prueba
     * ninguna otra velocidad: se fija esa, se vacían los buffers y se reinicia con ATZ.
     * Si no contesta, un segundo intento por la misma velocidad (por si seguía ocupado con algo
     * anterior). Devuelve la versión o null.
     */
    suspend fun handshake(): String? {
        try {
            port.setParameters(BAUD, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
        } catch (ex: Exception) {
            onLog("No se pudo fijar $BAUD baudios: ${ex.message}")
            return null
        }
        try { port.purgeHwBuffers(true, true) } catch (_: Exception) { }
        delay(300)   // deja que el chip USB termine de arrancar tras abrir el puerto
        onLog("Conectando a $BAUD baudios…")
        for (attempt in 1..2) {
            send("", 300)   // corta lo que hubiera a medias
            val r = send("ATZ", 3500)
            if (isAdapter(r)) {
                onLog("Adaptador encontrado: " + (r.lines().lastOrNull { isAdapter(it) } ?: r))
                return r.lines().lastOrNull { isAdapter(it) } ?: r
            }
            // Lo que llegó del adaptador, en hexadecimal, para saber si está mudo o contesta otra cosa
            val hex = lastRx.toByteArray(Charsets.ISO_8859_1).joinToString(" ") { "%02X".format(it) }
            onLog("ATZ ($attempt) → " + hex.take(90).ifEmpty { "(silencio, 0 bytes)" })
        }
        return null
    }

    private fun isAdapter(r: String) = r.contains("ELM", true) || r.contains("STN", true) || r.contains("OBDLINK", true)

    fun close() {
        try { port.close() } catch (_: Exception) { }
        try { connection.close() } catch (_: Exception) { }
    }

    companion object {
        /** Única velocidad usada con el adaptador. */
        const val BAUD = 115200

        private val ERRORS = listOf("NO DATA", "UNABLE TO CONNECT", "CAN ERROR", "BUS ERROR", "STOPPED", "ERROR", "?")

        fun isError(r: String) = r.isBlank() || ERRORS.any { r.trim().uppercase().startsWith(it) }

        private val frameIndex = Regex("^[0-9A-F]:")

        /** Convierte la respuesta en mensajes (lista de bytes). Junta tramas CAN multi-frame. */
        fun messages(resp: String): List<IntArray> {
            val lines = resp.uppercase().lines().map { it.replace(" ", "") }.filter { it.isNotEmpty() }
            val multi = lines.any { frameIndex.containsMatchIn(it) }
            val hexLines = if (multi) {
                listOf(lines.filter { frameIndex.containsMatchIn(it) }.joinToString("") { it.substring(2) })
            } else lines
            return hexLines.mapNotNull { l ->
                if (l.isEmpty() || l.length % 2 != 0 || !l.all { it in "0123456789ABCDEF" }) null
                else IntArray(l.length / 2) { i -> l.substring(i * 2, i * 2 + 2).toInt(16) }
            }
        }

        /** Datos de un PID del modo 01 ("41 PID A B …"). */
        fun mode01(resp: String, pid: Int): IntArray? {
            val need = Params.bytesFor(pid)
            for (m in messages(resp)) {
                if (m.size >= 2 + need && m[0] == 0x41 && m[1] == pid) return m.copyOfRange(2, 2 + need)
            }
            return null
        }

        /** Respuesta a una petición con varios PIDs ("01 0C 0D 05"): "41 0C xx xx 0D xx 05 xx" → mapa PID → datos. */
        fun mode01Multi(resp: String, wanted: List<Int>): Map<Int, IntArray> {
            val out = mutableMapOf<Int, IntArray>()
            for (m in messages(resp)) {
                if (m.size < 3 || m[0] != 0x41) continue
                var i = 1
                while (i < m.size) {
                    val pid = m[i]
                    if (pid !in wanted) break
                    val n = Params.bytesFor(pid)
                    if (i + 1 + n > m.size) break
                    out[pid] = m.copyOfRange(i + 1, i + 1 + n)
                    i += 1 + n
                }
            }
            return out
        }

        /** Mapa de PIDs soportados (0100, 0120, …). */
        fun supported(resp: String, base: Int): Set<Int> {
            val out = mutableSetOf<Int>()
            for (m in messages(resp)) {
                if (m.size >= 6 && m[0] == 0x41 && m[1] == base) {
                    for (i in 0 until 32) {
                        val byte = m[2 + i / 8]
                        if (byte and (0x80 shr (i % 8)) != 0) out += base + i + 1
                    }
                }
            }
            return out
        }

        /** Datos de un ReadDataByIdentifier UDS ("62 DID_H DID_L A B …"). */
        fun mode22(resp: String, did: Int): IntArray? {
            for (m in messages(resp)) {
                if (m.size >= 4 && m[0] == 0x62 && m[1] == (did shr 8) && m[2] == (did and 0xFF)) return m.copyOfRange(3, m.size)
            }
            return null
        }

        /** Respuesta a "0100": PIDs 01-20 soportados, o null si el coche no ha contestado. */
        fun mode01Supported(resp: String): Set<Int>? =
            if (messages(resp).any { it.size >= 6 && it[0] == 0x41 && it[1] == 0x00 }) supported(resp, 0x00) else null

        /** Códigos de avería de los modos 03 (43), 07 (47) o 0A (4A). */
        fun dtcs(resp: String, header: Int): List<String> {
            val out = linkedSetOf<String>()
            for (m in messages(resp)) {
                if (m.isEmpty() || m[0] != header) continue
                var data = m.copyOfRange(1, m.size)
                // En CAN el primer byte es el número de códigos (quedaría impar)
                if (data.size % 2 == 1) data = data.copyOfRange(1, data.size)
                var i = 0
                while (i + 1 < data.size) {
                    val a = data[i]; val b = data[i + 1]
                    if (a != 0 || b != 0) out += decodeDtc(a, b)
                    i += 2
                }
            }
            return out.toList()
        }

        fun decodeDtc(a: Int, b: Int): String {
            val letter = "PCBU"[a shr 6]
            return "%c%d%X%02X".format(letter, (a shr 4) and 0x3, a and 0xF, b)
        }

        /** Número de bastidor (modo 09 PID 02). */
        fun vin(resp: String): String? {
            val bytes = messages(resp).flatMap { it.toList() }
            val idx = bytes.windowed(2).indexOfFirst { it[0] == 0x49 && it[1] == 0x02 }
            if (idx < 0) return null
            val chars = bytes.drop(idx + 2)
                .filter { it in 0x30..0x5A }
                .map { it.toChar() }
                .joinToString("")
            return if (chars.length >= 17) chars.takeLast(17) else chars.ifEmpty { null }
        }
    }
}
