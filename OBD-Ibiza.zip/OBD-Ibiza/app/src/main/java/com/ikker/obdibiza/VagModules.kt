package com.ikker.obdibiza

import kotlinx.coroutines.delay

// ═══════════════════════════════════════════════════════════════════ Otras centralitas (VAG)
// En el Ibiza 6J (PQ25, 2011) conviven dos formas de hablar con las centralitas:
//  · UDS sobre ISO-TP, como el motor, cada una con su par de direcciones CAN (petición / respuesta).
//  · KWP2000 sobre TP 2.0, la forma antigua de VAG: se abre un canal con la centralita por la 0x200 y se
//    hablan tramas numeradas con acuse de recibo.
// La app prueba primero UDS y, si no contesta, TP 2.0. Solo LEE y BORRA averías y lee valores de medida:
// nunca codifica ni cambia nada en las centralitas.

enum class VagProto(val text: String) { UDS("UDS"), TP20("KWP2000 · TP 2.0"), NONE("No contesta") }

/** Centralita conocida de este coche: dirección lógica VAG y, si se sabe, sus direcciones CAN de UDS. */
class VagModule(val addr: Int, val name: String, val udsTx: Int? = null, val udsRx: Int? = null) {
    val label: String get() = if (addr >= 0x100) "TP %02X · %s".format(addr and 0xFF, name) else "%02X · %s".format(addr, name)
}

object VagModules {
    /** Sin el motor (01), que ya se lee por OBD. */
    val all = listOf(
        VagModule(0x03, "ABS / ESP", 0x713, 0x77D),
        VagModule(0x15, "Airbag", 0x715, 0x77F),
        VagModule(0x17, "Cuadro de instrumentos", 0x714, 0x77E),
        VagModule(0x19, "Pasarela CAN (gateway)", 0x710, 0x77A),
        VagModule(0x09, "Electrónica central", 0x70E, 0x778),
        VagModule(0x08, "Climatizador", 0x746, 0x7B0),
        VagModule(0x44, "Dirección asistida", 0x712, 0x77C),
        // Del autoscan VCDS de otro Ibiza 6J que encontró ella (12-nov): 4B lleva el 6J0959441 "MF-Modul"
        VagModule(0x4B, "Módulo multifunción"),
        // La 54 dice "SW Version Media: 0240" en su grupo 7 y la tensión de la batería en el 1, como una radio:
        // seguramente la caja CAN de la pantalla Android, que se hace pasar por la radio original
        VagModule(0x56, "Radio (caja CAN de la pantalla)"),
        // Teléfono: contesta por UDS (7P6035730F, J412), visto con Car Scanner el 12-nov
        VagModule(0x77, "Teléfono", 0x76B, 0x7D5),
        // Sin cambio (02, el suyo es manual), confort (46, va dentro de la electrónica central) ni radio (56, la pantalla no es de Seat)
    )

    fun byAddr(a: Int) = all.firstOrNull { it.addr == a }

    /**
     * Dirección lógica TP 2.0 de cada centralita (la que va en la apertura del canal por 0x200).
     * NO es la dirección de VCDS: en su coche el ABS no está en la 03 (contesta un "00 D0 A3" corto, igual
     * que a Car Scanner), y las que abren canal de verdad son 1F, 20, 2C, 39 y 54. Se rellena al buscar,
     * según lo que diga cada una de sí misma (1A 9B), y se guarda.
     */
    val tp = java.util.concurrent.ConcurrentHashMap<Int, Int>()

    /** Centralita de una fila: la conocida o, si es una que solo se ha encontrado por TP 2.0, una con su nombre. */
    /**
     * Las centralitas de su coche, ya sabidas (12-nov): salen siempre en Averías, debajo del motor, sin buscar.
     * Orden: ABS, airbag, cuadro, pasarela, electrónica central, climatizador, dirección, multifunción, radio, teléfono.
     */
    fun herCar(): List<ModuleState> = listOf(
        ModuleState(0x03, VagProto.TP20, part = "TP 1.6", wheelGroup = 1),
        ModuleState(0x15, VagProto.UDS),
        ModuleState(0x17, VagProto.UDS),
        ModuleState(0x19, VagProto.TP20, tp = 0x1F),
        ModuleState(0x09, VagProto.TP20, tp = 0x20),
        ModuleState(0x08, VagProto.TP20, tp = 0x2C),
        ModuleState(0x44, VagProto.TP20, part = "TP 1.6"),
        ModuleState(0x4B, VagProto.TP20, tp = 0x39),
        ModuleState(0x56, VagProto.TP20, tp = 0x54),
        ModuleState(0x77, VagProto.UDS),
    )

    fun forState(st: ModuleState): VagModule =
        byAddr(st.addr) ?: VagModule(st.addr, st.name.ifBlank { "Centralita TP 2.0 · %02X".format(st.addr and 0xFF) })

    /** Las cinco que abren canal en su coche (comprobado con Car Scanner y con la app el 12-nov). */
    val tpKnown = listOf(0x1F, 0x20, 0x2C, 0x39, 0x54)

    /** Direcciones lógicas TP 2.0 que se prueban en la búsqueda completa (las de su coche primero). */
    val tpProbeList: List<Int> = (tpKnown + (0x01..0x6F)).distinct()

    /**
     * Qué es cada una en su coche (comprobado el 12-nov con la grabación del puente: Car Scanner, al pedirle
     * cada centralita por su nombre, prueba esa dirección TP 2.0 y luego la UDS de esa misma centralita):
     * 1F → pasarela (19, y UDS 710), 20 → electrónica central (09, UDS 70E), 2C → climatizador (08, UDS 746).
     * 39 se identifica sola (6J0959441A MF-Modul) → módulo multifunción (4B, como en el autoscan VCDS de otro 6J). 54 sin saber.
     * El ABS (Car Scanner usa la 03) y la dirección asistida (la 09) solo contestan el "00 D0 xx" corto,
     * también a Car Scanner: así no se pueden leer.
     */
    val tpGuess = mapOf(0x1F to 0x19, 0x20 to 0x09, 0x2C to 0x08, 0x39 to 0x4B, 0x54 to 0x56)

    /** Las que solo contestan el "00 D0 xx" corto (ni la app ni Car Scanner pueden leerlas así). */
    val tpShortOnly = setOf(0x03, 0x44)

    /**
     * Centralitas que hablan TP 1.6 (SAE J3054, que ella pasó el 12-nov) y su dirección TP 1.6 (TAp).
     * El "00 D0 A3" corto ERA la respuesta correcta de TP 1.6: apertura de 3 bytes [destino][C0/D0][canal];
     * la centralita contesta por 0x700 + su canal (A3 → 0x7A3) y el comprobador manda por 0x700 + el suyo.
     * ABS = 03 (contesta A3), dirección asistida = 09 (contesta A9).
     */
    val tp16 = mapOf(0x03 to 0x03, 0x44 to 0x09)

    /** A qué centralita conocida corresponde, por lo que dice de sí misma (identificación 1A 9B). */
    fun classify(ident: String): Int? {
        val t = ident.uppercase()
        return when {
            listOf("ABS", "ESP", "MK60", "MK25", "MK70", "ASR").any { it in t } -> 0x03
            listOf("AIRBAG").any { it in t } -> 0x15
            listOf("KOMBI", "INSTR", "CLUSTER").any { it in t } -> 0x17
            listOf("GATEWAY", "J533", "GATEW").any { it in t } -> 0x19
            listOf("BORDNETZ", "J519", "BCM", "BN-SG", "BNSG", "ZENTRAL", "CENTRAL").any { it in t } -> 0x09
            listOf("CLIMA", "KLIMA", "CLIMATIC", "CLIMATRONIC", "HEIZ", "AC ").any { it in t } -> 0x08
            listOf("MF-MODUL", "MULTIFUNK", "959441").any { it in t } -> 0x4B
            listOf("LENKSAEULE", "LENKSÄULE", "LSE", "COLUMN", "J527", "MFL").any { it in t } -> 0x16
            listOf("LENKHILFE", "LENKUNG", "EPS", "STEER", "SERVO", "EPHS", "EML").any { it in t } -> 0x44
            else -> null
        }
    }
}

/** Avería de otra centralita. [code] tal como lo enseña VCDS/Autel (VAG de 5 cifras en KWP, P/C/B/U en UDS). */
data class ModDtc(val code: String, val status: Int, val active: Boolean, val text: String)

/** Resultado de leer una centralita. */
data class ModuleState(
    /** Dirección VCDS (03 = ABS…) o 0x100 + dirección lógica TP 2.0 si es una que no está en la lista. */
    val addr: Int,
    val proto: VagProto,
    val part: String = "",
    /** null = no se han podido leer las averías. */
    val dtcs: List<ModDtc>? = null,
    val message: String = "",
    /** Grupo de medida con la velocidad de las cuatro ruedas (solo ABS por KWP). */
    val wheelGroup: Int? = null,
    /** Dirección lógica TP 2.0 por la que contesta (si habla TP 2.0). */
    val tp: Int? = null,
    /** Cómo se identifica ella misma (1A 9B), para las que no están en la lista. */
    val name: String = "",
)

/** Un valor de un bloque de medida KWP ya convertido. */
data class MeasureValue(val value: Double?, val text: String, val unit: String)

object Kwp {
    /**
     * Valor de medida VAG (tipo, a, b) → número y unidad. Son las fórmulas estándar de los bloques de medida
     * de KWP1281/KWP2000 que usan VCDS y los lectores. Las que no se conocen salen en crudo.
     */
    fun decode(t: Int, a: Int, b: Int): MeasureValue {
        fun v(x: Double, u: String, dec: Int = 1) = MeasureValue(x, "%.${dec}f".format(java.util.Locale("es", "ES"), x), u)
        return when (t) {
            1 -> v(0.2 * a * b, "rpm", 0)
            2 -> v(a * 0.002 * b, "%")
            3 -> v(0.002 * a * b, "°")
            4 -> v(Math.abs(b - 127) * 0.01 * a, "° ATDC")
            5 -> v(a * (b - 100) * 0.1, "°C")
            6, 21 -> v(0.001 * a * b, "V", 2)
            7 -> v(0.01 * a * b, "km/h", 2)
            8 -> v(0.1 * a * b, "")
            9 -> v((b - 127) * 0.02 * a, "°")
            11 -> v(0.0001 * a * (b - 128) + 1, "", 3)
            12 -> v(0.001 * a * b, "Ω", 2)
            13 -> v((b - 127) * 0.001 * a, "mm", 2)
            14 -> v(0.005 * a * b, "bar", 2)
            15 -> v(0.01 * a * b, "ms", 2)
            18 -> v(0.04 * a * b, "mbar", 0)
            19 -> v(0.01 * a * b, "l", 2)
            20 -> v(a * (b - 128) / 128.0, "%")
            22 -> v(0.001 * a * b, "ms", 2)
            23 -> v(b / 256.0 * a, "%")
            24 -> v(0.001 * a * b, "A", 2)
            25 -> v(b * 1.421 + a / 182.0, "g/s")
            26 -> v((b - a).toDouble(), "°C", 0)
            27 -> v(Math.abs(b - 128) * 0.01 * a, "°")
            33 -> v(if (a == 0) 100.0 * b else 100.0 * b / a, "%")
            34 -> v((b - 128) * 0.01 * a, "kW")
            35 -> v(0.01 * a * b, "l/h", 2)
            36 -> v(a * 2560.0 + b * 10, "km", 0)
            40 -> v(b * 0.1 + 25.5 * a - 400, "A")
            43 -> v(b * 0.1 + 25.5 * a, "V")
            45 -> v(0.1 * a * b / 100, "", 2)
            48 -> v(b + a * 255.0, "", 0)
            50 -> v(if (a == 0) 0.0 else (b - 128) / (0.01 * a), "mbar", 0)
            52 -> v(b * 0.02 * a - a, "Nm")
            54 -> v(a * 256.0 + b, "", 0)
            55 -> v(a * b / 200.0, "s", 2)
            59 -> v((a * 256.0 + b) / 32768, "g/s", 3)
            60 -> v((a * 256.0 + b) * 0.01, "s", 2)
            64 -> v((a + b).toDouble(), "Ω", 0)
            65 -> v(0.01 * a * (b - 127), "mm", 2)
            67 -> v(640.0 * a + b * 2.5, "°", 1)
            68 -> v((256.0 * a + b) / 7.365, "°/s", 1)
            70 -> v((256.0 * a + b) * 0.192, "m/s²", 2)
            16 -> MeasureValue(null, Integer.toBinaryString(b).padStart(8, '0'), "")
            17 -> MeasureValue(null, "${a.toChar()}${b.toChar()}".trim(), "")
            0x25 -> MeasureValue(null, "%02X %02X".format(a, b), "")   // valor interno (bits), sin unidad
            0xA1 -> MeasureValue(null, Integer.toBinaryString(a).padStart(8, '0') + " " + Integer.toBinaryString(b).padStart(8, '0'), "")   // campo de bits
            else -> MeasureValue(null, "%02X %02X".format(a, b), "tipo $t")
        }
    }

    /** Respuesta 61 GG [t a b]×n → valores. null si no es un bloque de medida. */
    fun measuring(payload: IntArray, group: Int): List<MeasureValue>? {
        if (payload.size < 2 || payload[0] != 0x61 || payload[1] != group) return null
        val out = mutableListOf<MeasureValue>()
        var i = 2
        while (i + 2 < payload.size) {
            if (payload[i] == 0x5F) {
                // Tipo 5F: texto (longitud y letras), p. ej. "SW Version Media: 0240 000.000"
                val n = payload[i + 1]
                val txt = payload.drop(i + 2).take(n).map { c -> if (c in 32..126) c.toChar() else ' ' }.joinToString("").trim()
                out += MeasureValue(null, txt, "")
                break
            }
            out += decode(payload[i], payload[i + 1], payload[i + 2]); i += 3
        }
        return out
    }

    /** Respuesta 58 n [H L estado]×n → averías (código VAG de 5 cifras). */
    fun dtcs(payload: IntArray): List<ModDtc>? {
        if (payload.isEmpty() || payload[0] != 0x58) return null
        val out = mutableListOf<ModDtc>()
        var i = 2
        while (i + 2 < payload.size) {
            val code = payload[i] * 256 + payload[i + 1]
            val st = payload[i + 2]
            if (code != 0 && code != 0xFFFF) {
                // En KWP2000 de VAG el bit 5 del estado indica que el fallo está presente ahora
                // El estado se enseña tal cual: en KWP2000 de VAG no se sabe con seguridad qué bit es "activa"
                out += ModDtc("%05d".format(code), st, false, VagDtcText.describe(code))
            }
            i += 3
        }
        return out
    }

    /** ¿Es una lista de 4 velocidades (las cuatro ruedas)? Devuelve las 4 en km/h. */
    fun wheelSpeeds(values: List<MeasureValue>): List<Double>? {
        val kmh = values.filter { it.unit == "km/h" && it.value != null }.map { it.value!! }
        return if (kmh.size >= 4) kmh.take(4) else null
    }
}

/** Textos de las averías VAG más habituales (las demás salen con su número). */
object VagDtcText {
    private val known = mapOf(
        546 to "Datos de la unidad de control del motor",
        1044 to "Codificación de la unidad de control incorrecta",
        1276 to "Bomba hidráulica del ABS",
        1314 to "Unidad de control del motor: sin comunicación",
        1316 to "Unidad de control del ABS: sin comunicación",
        1317 to "Cuadro de instrumentos: sin comunicación",
        1321 to "Unidad de control del airbag: sin comunicación",
        1423 to "Sensor de presión de frenado",
        1435 to "Sensor del ángulo de dirección",
        1826 to "Sensor de lluvia y luz",
        16955 to "Conmutador de las luces de freno",
        18010 to "Tensión de la batería demasiado baja",
        18265 to "Sensor de carga (generador)",
        49155 to "Sin señal o comunicación del bus CAN",
        65535 to "Unidad de control averiada",
        283 to "Sensor de velocidad delantero izquierdo",
        285 to "Sensor de velocidad delantero derecho",
        287 to "Sensor de velocidad trasero derecho",
        290 to "Sensor de velocidad trasero izquierdo",
        532 to "Tensión de alimentación",
        588 to "Encendido del airbag del conductor",
        589 to "Encendido del airbag del acompañante",
        595 to "Datos de accidente guardados",
        1217 to "Encendido del airbag lateral del conductor",
        1218 to "Encendido del airbag lateral del acompañante",
        1280 to "Pretensor del cinturón del conductor",
        1281 to "Pretensor del cinturón del acompañante",
        1578 to "Testigo de airbag",
        771 to "Sensor del nivel de combustible",
        1039 to "Sensor de temperatura del refrigerante",
        778 to "Sensor del ángulo de dirección",
        1130 to "Modo ABS: funcionamiento con fallos",
        1304 to "Radio: sin comunicación",
        457 to "Unidad de control de la red de a bordo (J519)",
    )

    fun describe(code: Int): String = known[code] ?: "Avería VAG %05d".format(code)

    /** Averías que en su coche son normales y no hay que arreglar, con su explicación. */
    private val explained = mapOf(
        1304 to "Normal en tu coche: la radio original de Seat se cambió por la pantalla Android y la centralita ya no la encuentra. No afecta a nada y volverá a salir aunque la borres.",
    )

    /** Lo mismo para los códigos UDS (letra + 4 cifras). */
    private val explainedUds = mapOf(
        "B104E" to "Normal en tu coche: es el teléfono (Bluetooth de fábrica), que mandaba el sonido y los datos a la radio original de Seat. Como la radio se cambió por la pantalla Android, no la encuentra. No afecta a nada y volverá a salir aunque la borres.",
    )

    fun explain(code: String): String? {
        val c = code.trim().uppercase()
        return explainedUds[c] ?: c.toIntOrNull()?.let { explained[it] }
    }
}

/**
 * Habla con las otras centralitas a través del adaptador. Cambia la configuración del ELM327 (cabecera,
 * filtro de recepción, formato CAN) y la deja como estaba para el motor con [restore].
 */
class VagBus(private val e: Elm327, private val log: (String) -> Unit) {

    private fun hex(r: String): List<IntArray> = r.uppercase().lines().mapNotNull { l ->
        val s = l.replace(" ", "").trim()
        if (s.isEmpty() || s.length % 2 != 0 || s.any { it !in "0123456789ABCDEF" }) null
        else IntArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16) }
    }

    /** Líneas con cabecera y longitud (ATH1 ATD1 ATS0): "203" + "7" + datos. Devuelve (identificador, datos). */
    private fun headed(r: String): List<Pair<Int, IntArray>> = r.uppercase().lines().mapNotNull { l ->
        val s = l.replace(" ", "").trim()
        if (s.length < 4 || s.any { it !in "0123456789ABCDEF" }) return@mapNotNull null
        val id = s.substring(0, 3).toInt(16)
        val dlc = s.substring(3, 4).toInt(16)
        val body = s.substring(4)
        if (body.length % 2 != 0) return@mapNotNull null
        val d = IntArray(body.length / 2) { body.substring(it * 2, it * 2 + 2).toInt(16) }
        // Si la longitud anunciada no cuadra con los bytes, se marca con la longitud real (se ve en pantalla)
        id to (if (dlc in 0..8 && d.size >= dlc) d.copyOf(dlc) else d)
    }

    /** Por qué no contestó la última centralita (lo que devolvió el adaptador), para enseñarlo en pantalla. */
    var why: String = ""

    private var prepared = false

    /**
     * Antes de hablar con otras centralitas: sin tiempos adaptativos. Con ATAT2 el adaptador aprende lo rápido
     * que contesta el motor y deja de esperar enseguida; las centralitas que van a través de la pasarela
     * (ABS, clima…) tardan más y su respuesta se perdía.
     */
    private suspend fun prepare() {
        if (prepared) return
        // ATCSM0: que el adaptador confirme (ACK) las tramas que recibe. Si no las confirma, la centralita
        // repite la misma trama una y otra vez, que es lo que se vio con el ABS (00 D0 A3 repetido)
        for (c in listOf("ATAT0", "ATR1", "ATCSM0")) e.send(c, 1500)
        prepared = true
    }

    /** Lo que devolvió el adaptador, entero (todas las líneas), para la pantalla. */
    private fun short(r: String): String {
        val l = r.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (l.isEmpty()) return "sin respuesta"
        val t = l.joinToString(" | ")
        return if (t.length > 90) t.take(90) + "…" else t
    }

    /** Vuelve a dejar el adaptador hablando con el motor (UDS/OBD por 7E0). */
    suspend fun restore() {
        // Vuelve al protocolo del motor (CAN 11 bit 500 kbps): para TP 2.0 se usa el protocolo B, como Car Scanner
        e.send("ATSP6", 1500)
        protoB = false; inSetup = false
        for (c in listOf("ATCAF1", "ATFCSM0", "ATCRA", "ATH0", "ATD0", "ATCSM1", "ATSH7E0", "ATAT2", "ATST 32")) e.send(c, 1500)
        open = null
        prepared = false
    }

    // ── UDS ─────────────────────────────────────────────────────────────────────────

    private suspend fun udsTarget(m: VagModule) {
        val tx = m.udsTx ?: return
        val rx = m.udsRx ?: return
        prepare()
        if (protoB) {
            // Venimos de TP 2.0 (protocolo B): se vuelve al del motor
            open?.let { tpClose(it) }
            for (c in listOf("ATSP6", "ATH0", "ATD0")) e.send(c, 1500)
            protoB = false; inSetup = false
        }
        for (c in listOf("ATCAF1", "ATST 4B", "ATSH%03X".format(tx), "ATCRA%03X".format(rx), "ATFCSH%03X".format(tx), "ATFCSD300000", "ATFCSM1")) e.send(c, 1500)
    }

    /** ¿Contesta por UDS? Devuelve la referencia de pieza si la da. */
    suspend fun udsProbe(m: VagModule): String? {
        if (m.udsTx == null) { why = ""; return null }
        udsTarget(m)
        val r = e.send("22F187", 2500)
        val ms = Elm327.messages(r)
        val pos = ms.firstOrNull { it.size >= 3 && it[0] == 0x62 && it[1] == 0xF1 && it[2] == 0x87 }
        if (pos != null) return pos.drop(3).map { c -> if (c in 32..126) c.toChar() else ' ' }.joinToString("").trim().ifEmpty { "—" }
        // Un rechazo (7F 22 ..) también es que la centralita existe y habla UDS
        if (ms.any { it.size >= 2 && it[0] == 0x7F }) return "—"
        // Segunda pregunta, la más simple que hay ("sigo aquí"): la contestan todas las UDS
        val r2 = e.send("3E00", 1500)
        if (Elm327.messages(r2).any { it.isNotEmpty() && (it[0] == 0x7E || it[0] == 0x7F) }) return "—"
        why = "UDS: " + short(r)
        return null
    }

    /** Códigos U de red (SAE, iguales en todas las marcas) que han salido en su coche. */
    private val udsKnown = mapOf(
        "U0423" to "Datos no válidos recibidos del cuadro de instrumentos (fallo de comunicación por la red CAN; suele quedar guardado tras un bajón de batería o al desconectar algo)",
        "U0155" to "Sin comunicación con el cuadro de instrumentos",
        "U0100" to "Sin comunicación con la centralita del motor",
        "U0121" to "Sin comunicación con el ABS",
        "U0151" to "Sin comunicación con la centralita del airbag",
    )

    suspend fun udsDtcs(m: VagModule): List<ModDtc>? {
        udsTarget(m)
        val list = Elm327.udsDtcs(e.send("1902FF", 6000)) ?: return null
        return list.map { d ->
            // Los códigos propios del fabricante solo tienen la descripción genérica por la letra (B = carrocería…),
            // que despista en otras centralitas: mejor decir de quién es
            val t = udsKnown[d.code.uppercase()] ?: DtcInfo.describe(d.code)
            ModDtc(d.code, d.status, d.active, if (t.endsWith(": avería")) "Avería propia de ${m.name.lowercase()} (código del fabricante, sin descripción pública)" else t)
        }
    }

    suspend fun udsClear(m: VagModule): Boolean {
        udsTarget(m)
        var r = e.send("14FFFFFF", 8000)
        if (!Elm327.positive(r, 0x14)) {
            if (Elm327.positive(e.send("1003", 3000), 0x10)) {
                r = e.send("14FFFFFF", 8000)
                e.send("1001", 3000)
            }
        }
        return Elm327.positive(r, 0x14)
    }

    // ── TP 2.0 ──────────────────────────────────────────────────────────────────────

    private class Channel(val addr: Int, val tx: Int, val rx: Int, val tp16: Boolean = false) { var seq = 0; var lastMs = 0L; var kwOk = false; var kwFixed = true }
    /** Adaptador en el protocolo B (el de TP 2.0) y en modo apertura (cabecera y longitud a la vista). */
    private var protoB = false
    private var inSetup = false
    private var open: Channel? = null

    /** Abre el canal TP 2.0 con la centralita. */
    private fun fmt(frames: List<Pair<Int, IntArray>>): String =
        frames.map { (id, d) -> "%03X[%d] %s".format(id, d.size, d.joinToString(" ") { b -> "%02X".format(b) }) }
            .groupingBy { it }.eachCount().entries.joinToString(" | ") { (t, n) -> if (n > 1) "$t ×$n" else t }

    private fun cut(t: String, n: Int) = if (t.length > n) t.take(n) + "…" else t

    /** Dirección lógica TP 2.0 de una fila (las encontradas al buscar; si no, la misma). */
    private fun logical(key: Int): Int = VagModules.tp[key] ?: if (key >= 0x100) key - 0x100 else key

    /**
     * Abre el canal TP 2.0. Copiado de cómo lo hace Car Scanner con su mismo cable (grabado con el modo puente
     * el 12-nov): protocolo B de usuario (ATPBC001: 11 bit, longitud variable, sin formato ISO, 500 kbps),
     * apertura con "1" al final (volver con la primera respuesta), espera de datos corta (ATST09) y acuses
     * con "0" al final (no esperar nada).
     */
    private suspend fun tpOpen(key: Int, attempts: Int = 3): Channel? {
        VagModules.tp16[key]?.let { return tp16Open(key, it) }
        val l = logical(key)
        open?.let { if (it.addr == key && System.currentTimeMillis() - it.lastMs < 900) return it }
        open?.let { tpClose(it) }
        prepare()
        // La primera vez, todo; si ya estamos en modo apertura (búsqueda), solo lo que cambia
        val cmds = if (inSetup) listOf("ATSH200", "ATST06", "ATCRA%03X".format(0x200 + l))
            else listOf("ATCAF0", "ATFCSM0", "ATSH200", "ATPBC001", "ATSPB", "ATST06", "ATCRA%03X".format(0x200 + l), "ATH1", "ATD1")
        for (c in cmds) e.send(c, 1500)
        protoB = true; inSetup = true
        var opened = false
        var f: IntArray? = null
        var setupSeen = ""
        try {
            for (attempt in 0 until attempts) {
                val req = "%02XC00010000301".format(l)
                var r = e.send(req + "1", 1500)
                if (r.contains("?")) r = e.send(req, 1500)
                val frames = headed(r)
                setupSeen = if (frames.isEmpty()) short(r) else fmt(frames)
                f = frames.firstOrNull { (id, d) -> id == 0x200 + l && d.size >= 6 && d[0] == 0x00 && d[1] == 0xD0 }?.second
                if (f != null) break
                frames.firstOrNull { (id, d) -> id == 0x200 + l && d.size >= 2 && d[1] in 0xD6..0xD8 }?.let { (_, d) ->
                    why = "TP2.0: rechaza el canal (%02X)".format(d[1]); return null
                }
                if (attempt < attempts - 1) delay(150)
            }
            val ff = f ?: run { why = "TP2.0 (%02X): ".format(l) + cut(setupSeen, 80); return null }
            val ecuTx = ff[2] or (ff[3] shl 8)    // por donde contesta la centralita (lo que escuchamos), p. ej. 300
            val ecuRx = ff[4] or (ff[5] shl 8)    // por donde escucha la centralita (a donde mandamos), p. ej. 32E
            for (c in listOf("ATSH%03X".format(ecuRx and 0x7FF), "ATST32", "ATCRA%03X".format(ecuTx and 0x7FF))) e.send(c, 1500)
            var p = e.send("A00F8AFF32FF", 2000)
            if (headed(p).none { (_, d) -> d.isNotEmpty() && d[0] == 0xA1 }) p = e.send("A00F8AFF32FF", 2000)
            if (headed(p).none { (_, d) -> d.isNotEmpty() && d[0] == 0xA1 }) {
                why = cut("TP2.0 (%02X): abre pero no sigue (".format(l) + short(p) + ")", 120)
                return null
            }
            open = Channel(key, ecuRx, ecuTx).also { it.lastMs = System.currentTimeMillis() }
            opened = true
        } finally {
            // Si no abre se sigue en modo apertura (para probar la siguiente rápido); si abre, a modo datos
            if (opened) { e.send("ATH0", 1500); e.send("ATD0", 1500); inSetup = false }
        }
        e.send("ATST09", 1500)   // como Car Scanner: la centralita contesta enseguida y el acuse sale a tiempo
        return open
    }

    /**
     * Canal TP 1.6 (SAE J3054):
     * - Apertura por 0x200 con 3 bytes [TAp][C0][canal nuestro = 0x40 + 0]. La respuesta llega por
     *   0x200 + TAp con [00][D0][canal suyo] (o D8 si no puede).
     * - Nosotros mandamos por 0x700 + nuestro canal y escuchamos 0x700 + el suyo.
     * - Después, conexión A0/A1 (BS, T1, T2, T3, T4; T3 nuestro de al menos 10 ms) y datos con las mismas
     *   tramas y acuses que el TP 2.0. No tiene "A3" (prueba de canal).
     */
    /**
     * TP 1.6 con KWP2000 (manual del TestManager de MCD Elektronik, apartado 13.12.1.2, encontrado por ella el
     * 12-nov): después de conectar (A0/A1) hay que hacer el intercambio de palabras clave, como el arranque de la
     * línea K, pero dentro del canal:
     *   nosotros 10 [dirección] → ella B1 y 10 55 KB1 KB2 → nosotros B1 y 10 [KB2 invertido] → ella B1 y
     *   10 [dirección invertida] → nosotros B1.
     * Después, el KWP2000 va con cabecera de la línea K: [80+long][destino][F1][datos][suma], sin los 2 bytes
     * de longitud del TP 2.0. Por eso el ABS colgaba a todo: le faltaba este paso.
     * La dirección de las palabras clave de su ABS no se sabe: se prueban (primero las más probables) y la que
     * contesta se recuerda.
     */
    private class Kw(val addr: Int, val fixedSeq: Boolean) { var target = -1 }
    /** Lo que ya se sabe de su coche (registro del 12-nov 16:12): ABS dirección 83, palabras clave 6B 8F, destino 28, secuencia fija. */
    private val kw = mutableMapOf(0x03 to Kw(0x83, true).also { it.target = 0x28 })
    private val kwFailed = mutableSetOf<Int>()
    private val NOADDR = -2

    private fun kwCandidates(tap: Int): List<Int> =
        (listOf(tap or 0x80, tap, tap + 0x20, tap + 0x10, tap + 0x30, tap + 0x40, tap + 0x50, tap + 0x60, tap + 0x70, 0x57, 0x01, 0x10, 0x33)
            .map { it and 0xFF } + (0x00..0xFF)).distinct()

    private suspend fun tp16Open(key: Int, tap: Int): Channel? {
        open?.let { if (it.addr == key && it.kwOk && System.currentTimeMillis() - it.lastMs < 3000) return it }
        if (key in kwFailed) { why = "TP1.6 (%02X): no acepta ninguna dirección de palabras clave".format(tap); return null }
        val known = kw[key]
        val cands = known?.let { listOf(it.addr) } ?: kwCandidates(tap)
        if (known == null) log("TP1.6 %02X: buscando la dirección de las palabras clave (puede tardar hasta 2 minutos la primera vez)".format(tap))
        var tried = 0
        for (a in cands) {
            for (fixed in known?.let { listOf(it.fixedSeq) } ?: listOf(true, false)) {
                // La dirección asistida a veces tarda en volver a aceptar la apertura después de un intento malo
                var ch: Channel? = null
                for (t in 0 until (if (known == null) 8 else 1)) { ch = tp16OpenRaw(key, tap); if (ch != null) break; delay(1000) }
                if (ch == null) return null
                val r = kwHandshake(ch, tap, a, fixed)
                if (r == 1) {
                    ch.kwOk = true; ch.kwFixed = fixed
                    if (known == null) kw[key] = Kw(a, fixed)
                    return ch
                }
                if (open === ch) { try { e.send("A80", 600) } catch (_: Exception) { }; open = null }
                if (r == 0) break
            }
            if (++tried % 32 == 0) log("TP1.6 %02X: probadas %d direcciones".format(tap, tried))
        }
        kwFailed += key
        why = "TP1.6 (%02X): no acepta ninguna dirección de palabras clave".format(tap)
        log(why)
        return null
    }

    private fun isData(f: IntArray) = f.isNotEmpty() && (f[0] shr 4) in 0..3
    private fun hx(b: IntArray) = b.joinToString("") { "%02X".format(it) }

    /** Manda una trama de datos y recoge lo que llega hasta la última trama de la centralita (o A8). */
    private suspend fun tp16Exchange(frame: IntArray, waitMs: Long = 1500): List<IntArray> {
        val fr = hex(e.send(hx(frame), 1500)).toMutableList()
        if (fr.none { (isData(it) && (it[0] shr 4) in listOf(1, 3)) || (it.isNotEmpty() && it[0] == 0xA8) }) fr += listen(waitMs)
        return fr
    }

    private suspend fun tp16Ack(frames: List<IntArray>) {
        frames.lastOrNull { isData(it) && (it[0] shr 4) in listOf(0, 1) }?.let { e.send("B%X0".format(((it[0] and 0x0F) + 1) and 0x0F), 300) }
    }

    /** 1 = hecho; 0 = no contesta las palabras clave (dirección mala); 2 = contesta pero falla el segundo paso. */
    private suspend fun kwHandshake(ch: Channel, tap: Int, a: Int, fixed: Boolean): Int {
        var seq = 0
        suspend fun data(b: Int): List<IntArray> {
            val f = intArrayOf(0x10 or (seq and 0x0F), b)
            if (!fixed) seq = (seq + 1) and 0x0F
            return tp16Exchange(f)
        }
        val r1 = data(a)
        val d1 = r1.firstOrNull { isData(it) }
        if (d1 == null || d1.size < 4 || d1[1] != 0x55) {
            if (a == tap || kw.containsKey(ch.addr)) log("TP1.6 %02X: palabras clave con dirección %02X · llegó: ".format(tap, a) + r1.joinToString(" | ") { hx(it) })
            return 0
        }
        tp16Ack(r1)
        val kb1 = d1[2]; val kb2 = d1[3]
        log("TP1.6 %02X: ¡contesta a la dirección %02X! sincronía 55, palabras clave %02X %02X".format(tap, a, kb1, kb2))
        val r2 = data(kb2.inv() and 0xFF)
        val d2 = r2.firstOrNull { isData(it) }
        if (d2 == null || d2.size < 2) {
            log("TP1.6 %02X: segundo paso (%s) · llegó: ".format(tap, if (fixed) "secuencia fija" else "secuencia que sube") + r2.joinToString(" | ") { hx(it) })
            return 2
        }
        tp16Ack(r2)
        log("TP1.6 %02X: diagnosis abierta (dirección invertida %02X, esperada %02X)".format(tap, d2[1], a.inv() and 0xFF))
        ch.seq = if (fixed) 0 else seq
        ch.lastMs = System.currentTimeMillis()
        return 1
    }

    /** Petición KWP2000 con cabecera de línea K dentro del canal TP 1.6. Devuelve los datos (sin cabecera). */
    private suspend fun kwRequest(ch: Channel, kwp: IntArray, target: Int, timeoutMs: Long): IntArray? {
        val msg0 = if (target == NOADDR) intArrayOf(kwp.size) + kwp else intArrayOf(0x80 or kwp.size, target, 0xF1) + kwp
        val msg = msg0 + intArrayOf(msg0.sum() and 0xFF)
        if (ch.kwFixed) ch.seq = 0
        val chunks = msg.toList().chunked(7)
        var resp: List<IntArray> = emptyList()
        for ((i, c) in chunks.withIndex()) {
            val last = i == chunks.size - 1
            val f = intArrayOf((if (last) 0x10 else 0x20) or (ch.seq and 0x0F)) + c.toIntArray()
            ch.seq = (ch.seq + 1) and 0x0F
            if (last) resp = tp16Exchange(f, timeoutMs) else e.send(hx(f) + "0", 300)
        }
        val payload = mutableListOf<Int>()
        for (f in resp) if (isData(f)) payload += f.drop(1)
        tp16Ack(resp)
        if (resp.any { it.isNotEmpty() && it[0] == 0xA8 }) { if (open === ch) open = null }
        if (payload.isEmpty()) return null
        ch.lastMs = System.currentTimeMillis()
        val fmtB = payload[0]
        var i = 1 + (if (fmtB and 0xC0 != 0) 2 else 0)
        var len = fmtB and 0x3F
        if (len == 0 && i < payload.size) { len = payload[i]; i++ }
        val out = payload.drop(i).take(len).toIntArray()
        if (out.size >= 3 && out[0] == 0x7F && out[2] == 0x78) {
            // Espera: la respuesta buena llega sola
            val more = listen(4000)
            val p2 = mutableListOf<Int>(); for (f in more) if (isData(f)) p2 += f.drop(1)
            tp16Ack(more)
            if (p2.isEmpty()) return null
            val f2 = p2[0]; var j = 1 + (if (f2 and 0xC0 != 0) 2 else 0); var l2 = f2 and 0x3F
            if (l2 == 0 && j < p2.size) { l2 = p2[j]; j++ }
            return p2.drop(j).take(l2).toIntArray()
        }
        return out
    }

    private suspend fun tp16OpenRaw(key: Int, tap: Int): Channel? {
        open?.let { tpClose(it) }
        prepare()
        for (c in listOf("ATCAF0", "ATFCSM0", "ATSH200", "ATPBC001", "ATSPB", "ATST19", "ATCRA%03X".format(0x200 + tap), "ATH1", "ATD1")) e.send(c, 1500)
        protoB = true; inSetup = false
        var seen = ""
        try {
            // En su coche el ABS solo contestó a la conexión con nuestro canal A0 (12-nov): se prueba primero
            for (mine in listOf(0xA0, 0x40, 0x60, 0x80, 0xA0, 0x40)) {
                val req = "%02XC0%02X".format(tap, mine)
                var r = e.send(req + "1", 1500)
                if (r.contains("?")) r = e.send(req, 1500)
                val frames = headed(r)
                seen = if (frames.isEmpty()) short(r) else fmt(frames)
                val ack = frames.firstOrNull { (id, d) -> id == 0x200 + tap && d.size >= 3 && d[1] == 0xD0 }?.second
                if (frames.any { (id, d) -> id == 0x200 + tap && d.size >= 2 && d[1] == 0xD8 }) { delay(150); continue }
                if (ack == null) { delay(250); continue }
                val tx = 0x700 + mine
                var rx = 0x700 + ack[2]
                // Para la conexión se escucha todo (ATCRA sin filtro): así se ve si contesta por otro identificador
                for (c in listOf("ATSH%03X".format(tx), "ATCRA", "ATST19")) e.send(c, 1500)
                var a1: Pair<Int, IntArray>? = null
                var pSeen = ""
                for (cs in listOf("A00F8AFF4AFF", "A00F8AFF4AFF", "A00FC3FF4AFF")) {
                    val p = e.send(cs, 2000)
                    val fr = headed(p)
                    pSeen = if (fr.isEmpty()) short(p) else fmt(fr)
                    a1 = fr.firstOrNull { (id, d) -> id in 0x700..0x7FF && d.isNotEmpty() && d[0] == 0xA1 }
                    if (a1 != null) break
                    delay(120)
                }
                if (a1 == null) {
                    // Se cierra este intento y se prueba con el siguiente canal nuestro
                    why = cut("TP1.6 (%02X): abre %03X→%03X pero no conecta (".format(tap, tx, rx) + pSeen + ")", 140)
                    try { e.send("A80", 600) } catch (_: Exception) { }
                    for (c in listOf("ATSH200", "ATST19", "ATCRA%03X".format(0x200 + tap))) e.send(c, 1500)
                    delay(300)
                    continue
                }
                rx = a1.first
                e.send("ATCRA%03X".format(rx), 1500)
                e.send("ATH0", 1500); e.send("ATD0", 1500)
                e.send("ATST09", 1500)
                log("TP1.6 %02X: canal %03X → %03X".format(tap, tx, rx))
                val chan = Channel(key, tx, rx, tp16 = true).also { it.lastMs = System.currentTimeMillis(); open = it }
                if (EXPERIMENTS && key !in tp16Listened) {
                    // Prueba (v63): por si la centralita habla primero (como en KW1281) en vez de esperar la pregunta
                    tp16Listened += key
                    val fr = listen(2500, stopAtLast = false)
                    log("TP1.6 %02X: escucha de 2,5 s tras conectar · llegó: ".format(tap) +
                        (if (fr.isEmpty()) "nada" else fr.joinToString(" | ") { f -> f.joinToString("") { "%02X".format(it) } }))
                    val lsn = fr.lastOrNull { it.isNotEmpty() && (it[0] shr 4) in listOf(0, 1) }?.let { it[0] and 0x0F }
                    if (lsn != null) e.send("B%X0".format((lsn + 1) and 0x0F), 300)
                    if (fr.any { it.isNotEmpty() && it[0] == 0xA8 }) { open = null; return tp16OpenRaw(key, tap) }
                }
                return chan
            }
            if (!why.startsWith("TP1.6")) why = "TP1.6 (%02X): ".format(tap) + cut(seen, 90)
            return null
        } finally {
            if (open?.addr != key) { try { e.send("ATH0", 1500); e.send("ATD0", 1500) } catch (_: Exception) { } }
        }
    }

    /** ¿Abre canal TP 2.0 la dirección lógica [l]? (un solo intento, para buscar rápido) */
    suspend fun tpFind(l: Int): Boolean = tpOpen(0x100 + l, attempts = 1) != null

    /** Cómo se identifica la centralita de la dirección lógica [l] (texto de 1A 9B), con el canal ya abierto. */
    suspend fun tpIdentify(l: Int): String? {
        val ch = tpOpen(0x100 + l, attempts = 1) ?: return null
        tpRequest(ch, intArrayOf(0x10, 0x89))
        // Con la espera corta (ATST09): con más espera el acuse llega tarde y la centralita cierra el canal
        for (sub in listOf(0x9B, 0x9A, 0x91)) {
            val c = tpOpen(0x100 + l, attempts = 1) ?: return null
            val id = tpRequest(c, intArrayOf(0x1A, sub)) ?: continue
            if (id.size < 3 || id[0] != 0x5A) continue
            val txt = id.drop(2).map { x -> if (x in 32..126) x.toChar() else ' ' }.joinToString("").replace(Regex("\\s+"), " ").trim()
            if (txt.count { it.isLetterOrDigit() } >= 4) return txt
        }
        return null
    }

    /** Averías de la dirección lógica [l] (para las que no están en la lista). */
    suspend fun tpDtcsLogical(l: Int): List<ModDtc>? {
        val ch = tpOpen(0x100 + l, attempts = 1) ?: return null
        val r = tpRequest(ch, intArrayOf(0x18, 0x02, 0xFF, 0x00), 4000) ?: return null
        return Kwp.dtcs(r)
    }

    private suspend fun tpClose(ch: Channel) {
        try { e.send("A80", 600) } catch (_: Exception) { }
        if (open === ch) open = null
    }

    /** Mantiene vivo el canal abierto (si lo hay). */
    suspend fun keepAlive() {
        val ch = open ?: return
        if (ch.tp16) return
        val r = e.send("A3", 800)
        if (hex(r).any { it.isNotEmpty() && it[0] == 0xA1 }) ch.lastMs = System.currentTimeMillis() else open = null
    }

    /** Manda un mensaje KWP por el canal y devuelve la respuesta ya montada (sin cabecera de longitud). */
    private suspend fun tpRequest(ch: Channel, kwp: IntArray, timeoutMs: Long = 2500): IntArray? {
        if (ch.tp16) return tp16Request(ch, kwp, timeoutMs)
        // Peticiones cortas: caben en una trama (tipo 1 = última, espera acuse)
        val frame = intArrayOf(0x10 or (ch.seq and 0x0F), 0x00, kwp.size) + kwp
        ch.seq = (ch.seq + 1) and 0x0F
        var resp = e.send(frame.joinToString("") { "%02X".format(it) }, timeoutMs)
        val data = mutableListOf<Int>()
        var total = -1
        var guard = 0
        while (guard++ < 12) {
            var needAck = -1
            var last = false
            var ecuTest = false
            for (f in hex(resp)) {
                if (f.isEmpty()) continue
                if (f[0] == 0xA3) { ecuTest = true; continue }   // la centralita pregunta si seguimos ahí
                val type = f[0] shr 4
                if (type == 0xB || type == 0x9 || type == 0xA) continue   // acuses y control del canal
                if (type > 3) continue
                val payload = f.drop(1)
                if (total < 0 && payload.size >= 2) {
                    // El bit alto del primer byte es una marca (la 54 manda 80 03 = 3 bytes)
                    total = ((payload[0] and 0x7F) shl 8) or payload[1]
                    data += payload.drop(2)
                } else data += payload
                if (type == 0 || type == 1) needAck = (f[0] and 0x0F) + 1
                if (type == 1 || type == 3) last = true
            }
            // Como Car Scanner: a su "¿sigues ahí?" (A3) se contesta con nuestros parámetros, sin esperar nada
            if (ecuTest) e.send("A10F8AFF4AFF0", 300)
            if (needAck >= 0) {
                val ack = "B%X".format(needAck and 0x0F)
                if (last) { e.send(ack + "0", 300); break }
                resp = e.send(ack, timeoutMs)
                continue
            }
            if (last || (total >= 0 && data.size >= total)) break
            if (resp.isBlank()) break
            if (ch.tp16) break   // TP 1.6 no tiene prueba de canal
            resp = e.send("A3", 800)   // nada más: se pide al canal que siga
        }
        if (total < 0) {
            // No ha contestado: el canal se da por muerto, así la siguiente petición lo vuelve a abrir
            // (antes se seguía usando y fallaba todo lo que venía detrás)
            if (open === ch) { try { e.send("A80", 600) } catch (_: Exception) { }; open = null }
            return null
        }
        ch.lastMs = System.currentTimeMillis()
        val out = data.take(total).toIntArray()
        // 7F xx 78 = "espera": la respuesta buena llega después
        if (out.size >= 3 && out[0] == 0x7F && out[2] == 0x78) {
            // No se vuelve a pedir (eso la liaba): la respuesta buena llega sola, así que se escucha
            for (w in 0 until 4) {
                val fr = listen(4000)
                val d = mutableListOf<Int>(); var tot = -1; var lsn = -1
                for (f in fr) {
                    if (f.isEmpty()) continue
                    val type = f[0] shr 4
                    if (type > 3) continue
                    val payload = f.drop(1)
                    if (tot < 0 && payload.size >= 2) { tot = ((payload[0] and 0x7F) shl 8) or payload[1]; d += payload.drop(2) } else d += payload
                    if (type == 0 || type == 1) lsn = f[0] and 0x0F
                }
                if (lsn >= 0) e.send("B%X0".format((lsn + 1) and 0x0F), 300)
                if (tot < 0) break
                val o = d.take(tot).toIntArray()
                if (o.size >= 3 && o[0] == 0x7F && o[2] == 0x78) continue
                ch.lastMs = System.currentTimeMillis()
                return o
            }
            log("TP: la centralita pidió esperar y no llegó la respuesta")
            if (open === ch) { try { e.send("A80", 600) } catch (_: Exception) { }; open = null }
            return null
        }
        return out
    }

    /** Escucha el canal (solo el identificador de la centralita) hasta la última trama, A8 o [ms]. */
    private suspend fun listen(ms: Long, stopAtLast: Boolean = true): List<IntArray> {
        val frames = mutableListOf<IntArray>()
        val t0 = System.currentTimeMillis()
        var mon = "STMA"
        for (attempt in 0 until 2) {
            val ended = e.monitor(mon, { l ->
                val c = l.replace(" ", "").uppercase()
                if (c.length % 2 == 0 && c.isNotEmpty() && c.all { it in "0123456789ABCDEF" })
                    frames += IntArray(c.length / 2) { i -> c.substring(i * 2, i * 2 + 2).toInt(16) }
            }) {
                (stopAtLast && frames.any { it.isNotEmpty() && ((it[0] shr 4) in listOf(1, 3) || it[0] == 0xA8) }) ||
                    System.currentTimeMillis() - t0 > ms
            }
            if (ended?.trim() == "?" && mon == "STMA") { mon = "ATMA"; continue }
            break
        }
        return frames
    }

    /**
     * Petición por TP 1.6. Aquí no hay "¿sigues ahí?" (A3) para hacer que el adaptador vuelva a escuchar, y la
     * centralita puede tardar en contestar después de su acuse. Así que, tras mandar la petición, el adaptador se
     * pone a escuchar (monitor, solo el canal de la centralita) hasta que llega la última trama, y entonces se
     * manda el acuse enseguida.
     */
    /** Centralitas TP 1.6 en las que el KWP va sin los 2 bytes de longitud delante (se descubre probando). */
    private val tp16NoLen = mutableMapOf<Int, Boolean>()
    private val tp16Tried = mutableSetOf<Int>()
    private val tp16Listened = mutableSetOf<Int>()
    private var tp16Dropped = false

    private suspend fun tp16Request(ch0: Channel, kwp: IntArray, timeoutMs: Long): IntArray? {
        // Si ya ha colgado a todo en esta sesión (el ABS de su coche lo hace, 12-nov), no se insiste: así la
        // búsqueda no pierde 20 s reabriendo el canal para cada grupo
        if (ch0.addr in tp16Refused) { if (open === ch0) { try { e.send("A80", 600) } catch (_: Exception) { }; open = null }; return null }
        val ch = open?.takeIf { it.addr == ch0.addr && it.tp16 } ?: ch0
        if (ch.kwOk) {
            val info = kw[ch.addr] ?: return null
            val tap = VagModules.tp16[ch.addr] ?: return null
            if (info.target != -1) {
                val c = open?.takeIf { it.addr == ch.addr && it.kwOk } ?: tpOpen(ch.addr) ?: return null
                return kwRequest(c, kwp, info.target, timeoutMs)
            }
            // Destino de la cabecera: no se sabe; se prueban los más probables (el ejemplo de MCD usa otro número)
            // Direcciones físicas de la línea K (SAE J2178): 28–2F frenos, 30–37 dirección
            val iso = if (tap == 0x09) (0x30..0x37).toList() else (0x28..0x2F).toList()
            for (t in (iso + listOf(info.addr, tap, NOADDR, 0x80 or tap, 0x10 or tap, 0x82, 0x01, 0x10) + (0x28..0x3F)).distinct()) {
                val c = open?.takeIf { it.addr == ch.addr && it.kwOk } ?: tpOpen(ch.addr) ?: return null
                val r = kwRequest(c, kwp, t, timeoutMs)
                log("TP1.6 %02X: KWP con destino %s → ".format(tap, if (t == NOADDR) "sin dirección" else "%02X".format(t)) +
                    (r?.joinToString(" ") { "%02X".format(it) } ?: "nada"))
                if (r != null) { info.target = t; return r }
            }
            tp16Refused += ch.addr
            return null
        }
        var r = tp16RequestOnce(ch, kwp, timeoutMs)
        // Si la centralita acusa y cuelga (B1 y luego A8), puede que no quiera el prefijo de longitud
        // (o que lo quiera): se cambia y se prueba una vez, con un canal nuevo
        if (r == null && tp16Dropped && ch.addr !in tp16Tried) {
            tp16Tried += ch.addr
            tp16NoLen[ch.addr] = !(tp16NoLen[ch.addr] ?: false)
            log("TP1.6: la centralita cuelga; se prueba " + if (tp16NoLen[ch.addr] == true) "sin el prefijo de longitud" else "con el prefijo de longitud")
            val c2 = tpOpen(ch.addr) ?: return null
            r = tp16RequestOnce(c2, kwp, timeoutMs)
            if (r == null) tp16NoLen[ch.addr] = !(tp16NoLen[ch.addr] ?: false)
        }
        if (r == null && tp16Dropped) { tp16Refused += ch.addr; log("TP1.6: la centralita acusa y cuelga a todo; no se le pregunta más en esta búsqueda") }
        if (r == null && EXPERIMENTS && ch.addr !in tp16KwTried) { tp16KwTried += ch.addr; kw1281Probe(ch.addr) }
        return r
    }

    private val tp16KwTried = mutableSetOf<Int>()
    private val tp16Refused = mutableSetOf<Int>()
    /** Pruebas a ciegas de la v63–v66 (escucha, KW1281, cable entero): ya hechas, apagadas. */
    private val EXPERIMENTS = false

    /**
     * Prueba (v64): TP 1.6 también llevaba KW1281 (el idioma antiguo de la línea K), según ACTIA. Se mandan
     * peticiones KW1281 de varias formas (pedir averías = título 07, grupo 1 = título 29 01), cada una con un
     * canal nuevo, y se apunta en el registro lo que contesta. Solo sirve para averiguar el formato.
     */
    private suspend fun kw1281Probe(key: Int) {
        val tap = VagModules.tp16[key] ?: return
        val variants = listOf(
            "bloque K completo, averías" to intArrayOf(0x03, 0x01, 0x07, 0x03),
            "solo título, averías" to intArrayOf(0x07),
            "longitud + título, averías" to intArrayOf(0x00, 0x01, 0x07),
            "bloque K sin fin, averías" to intArrayOf(0x03, 0x01, 0x07),
            "acuse K (09)" to intArrayOf(0x03, 0x01, 0x09, 0x03),
            "solo título, grupo 1" to intArrayOf(0x29, 0x01),
            "longitud + título, grupo 1" to intArrayOf(0x00, 0x02, 0x29, 0x01),
        )
        for ((name, body) in variants) {
            open = null
            val ch = tp16OpenRaw(key, tap) ?: run { log("KW1281 %02X (%s): no abre canal".format(tap, name)); delay(500); null } ?: continue
            val frame = intArrayOf(0x10 or (ch.seq and 0x0F)) + body
            ch.seq = (ch.seq + 1) and 0x0F
            val frames = hex(e.send(frame.joinToString("") { "%02X".format(it) }, 1500)).toMutableList()
            if (frames.none { it.isNotEmpty() && ((it[0] shr 4) in listOf(1, 3) || it[0] == 0xA8) }) frames += listen(2500)
            val lsn = frames.lastOrNull { it.isNotEmpty() && (it[0] shr 4) in listOf(0, 1) }?.let { it[0] and 0x0F }
            if (lsn != null) e.send("B%X0".format((lsn + 1) and 0x0F), 300)
            log("KW1281 %02X (%s): ".format(tap, name) + frame.joinToString(" ") { "%02X".format(it) } + " · llegó: " +
                (if (frames.isEmpty()) "nada" else frames.joinToString(" | ") { f -> f.joinToString("") { "%02X".format(it) } }))
            if (open === ch) { try { e.send("A80", 600) } catch (_: Exception) { }; open = null }
            delay(300)
        }
        // Prueba (v66): se escucha TODO el cable (todos los identificadores, con cabecera) mientras se pide 10 89,
        // por si la centralita contesta por otro identificador distinto del de su canal
        open = null
        val ch = tp16OpenRaw(key, tap) ?: return
        val frame = intArrayOf(0x10 or (ch.seq and 0x0F), 0x00, 0x02, 0x10, 0x89)
        ch.seq = (ch.seq + 1) and 0x0F
        for (c in listOf("ATCRA", "ATH1", "ATD1")) e.send(c, 1500)
        val lines = mutableListOf<String>()
        lines += e.send(frame.joinToString("") { "%02X".format(it) }, 1500).lines().map { it.trim() }.filter { it.isNotEmpty() }
        val t0 = System.currentTimeMillis()
        var mon = "STMA"
        for (attempt in 0 until 2) {
            val ended = e.monitor(mon, { l -> l.trim().takeIf { it.isNotEmpty() }?.let { lines += it } }) { System.currentTimeMillis() - t0 > 3000 || lines.size > 200 }
            if (ended?.trim() == "?" && mon == "STMA") { mon = "ATMA"; continue }
            break
        }
        log("CABLE ENTERO %02X (10 89, 3 s, todos los identificadores): ".format(tap) + (if (lines.isEmpty()) "nada" else lines.joinToString(" | ")))
        for (c in listOf("ATH0", "ATD0", "ATCRA%03X".format(ch.rx))) e.send(c, 1500)
        if (open === ch) { try { e.send("A80", 600) } catch (_: Exception) { }; open = null }
    }

    private suspend fun tp16RequestOnce(ch: Channel, kwp: IntArray, timeoutMs: Long): IntArray? {
        val noLen = tp16NoLen[ch.addr] == true
        tp16Dropped = false
        val frame = if (noLen) intArrayOf(0x10 or (ch.seq and 0x0F)) + kwp
            else intArrayOf(0x10 or (ch.seq and 0x0F), 0x00, kwp.size) + kwp
        ch.seq = (ch.seq + 1) and 0x0F
        val frames = mutableListOf<IntArray>()
        // Sin "1": con ATST09 el adaptador recoge el acuse y, si la centralita es rápida, también la respuesta
        frames += hex(e.send(frame.joinToString("") { "%02X".format(it) }, 1500))
        fun done() = frames.any { it.isNotEmpty() && ((it[0] shr 4) in listOf(1, 3) || it[0] == 0xA8) }
        if (!done()) {
            val t0 = System.currentTimeMillis()
            var mon = "STMA"
            for (attempt in 0 until 2) {
                val ended = e.monitor(mon, { l ->
                    val c = l.replace(" ", "").uppercase()
                    if (c.length % 2 == 0 && c.isNotEmpty() && c.all { it in "0123456789ABCDEF" })
                        frames += IntArray(c.length / 2) { i -> c.substring(i * 2, i * 2 + 2).toInt(16) }
                }) { done() || System.currentTimeMillis() - t0 > timeoutMs }
                if (ended?.trim() == "?" && mon == "STMA") { mon = "ATMA"; continue }
                break
            }
        }
        val data = mutableListOf<Int>()
        var total = -1
        var lastSn = -1
        var gotData = false
        for (f in frames) {
            if (f.isEmpty()) continue
            if (f[0] == 0xA8) { tp16Dropped = true; continue }
            val type = f[0] shr 4
            if (type > 3) continue   // acuses (Bx/9x) y control
            gotData = true
            val payload = f.drop(1)
            if (!noLen && total < 0 && payload.size >= 2) { total = ((payload[0] and 0x7F) shl 8) or payload[1]; data += payload.drop(2) } else data += payload
            if (type == 0 || type == 1) lastSn = f[0] and 0x0F
        }
        if (noLen && gotData) total = data.size
        if (lastSn >= 0) e.send("B%X0".format((lastSn + 1) and 0x0F), 300)
        if (total < 0) {
            log("TP1.6: sin respuesta a " + kwp.joinToString(" ") { "%02X".format(it) } + " · llegó: " + frames.joinToString(" | ") { f -> f.joinToString("") { "%02X".format(it) } })
            if (open === ch) { try { e.send("A80", 600) } catch (_: Exception) { }; open = null }
            return null
        }
        ch.lastMs = System.currentTimeMillis()
        val out = data.take(total).toIntArray()
        if (out.size >= 3 && out[0] == 0x7F && out[2] == 0x78) { delay(400); return tp16RequestOnce(ch, kwp, timeoutMs) }
        return out
    }

    /** ¿Contesta por TP 2.0? Devuelve la referencia de pieza si la da. */
    suspend fun tpProbe(m: VagModule): String? {
        val ch = tpOpen(m.addr) ?: return null
        tpRequest(ch, intArrayOf(0x10, 0x89))   // sesión de diagnóstico normal de VAG
        val id = tpRequest(ch, intArrayOf(0x1A, 0x9B))
        val part = id?.takeIf { it.size > 2 && it[0] == 0x5A }?.drop(2)?.take(12)?.map { c -> if (c in 32..126) c.toChar() else ' ' }?.joinToString("")?.trim()
        return part?.ifEmpty { "—" } ?: "—"
    }

    suspend fun tpDtcs(m: VagModule): List<ModDtc>? {
        val ch = tpOpen(m.addr) ?: return null
        val r = tpRequest(ch, intArrayOf(0x18, 0x02, 0xFF, 0x00), 4000)
        Kwp.dtcs(r ?: IntArray(0))?.let { return it }
        if (m.addr !in VagModules.tp16) return null
        // TP 1.6 (ABS, dirección): si no contesta a la petición normal, otras formas de pedir las averías
        log("Averías %02X: 18 02 FF 00 → ".format(m.addr) + (r?.joinToString(" ") { "%02X".format(it) } ?: "nada"))
        for (alt in listOf(
            intArrayOf(0x10, 0x89), intArrayOf(0x18, 0x02, 0xFF, 0x00),
            intArrayOf(0x18, 0x00, 0xFF, 0x00), intArrayOf(0x18, 0x02, 0x00, 0x00), intArrayOf(0x17, 0xFF, 0x00),
        )) {
            val c = tpOpen(m.addr) ?: return null
            val r2 = tpRequest(c, alt, 4000)
            log("Averías %02X: ".format(m.addr) + alt.joinToString(" ") { "%02X".format(it) } + " → " + (r2?.joinToString(" ") { "%02X".format(it) } ?: "nada"))
            if (alt[0] == 0x10) continue
            Kwp.dtcs(r2 ?: IntArray(0))?.let { return it }
        }
        return null
    }

    suspend fun tpClear(m: VagModule): Boolean {
        val ch = tpOpen(m.addr) ?: return false
        val r = tpRequest(ch, intArrayOf(0x14, 0xFF, 0x00), 6000) ?: return false
        return r.isNotEmpty() && r[0] == 0x54
    }

    /** Bloque de medida [group] (1–255) por TP 2.0. */
    suspend fun tpMeasure(m: VagModule, group: Int): List<MeasureValue>? {
        val ch = tpOpen(m.addr) ?: return null
        val r = tpRequest(ch, intArrayOf(0x21, group)) ?: return null
        return Kwp.measuring(r, group)
    }

    suspend fun closeAll() { open?.let { tpClose(it) } }
}

// ═══════════════════════════════════════════════════════════════════ Ruedas con poco aire
// Igual que el control de presión del coche: una rueda con menos aire tiene el radio un poco menor y, a la
// misma velocidad del coche, gira más rápido que las otras. Se aprende cómo giran con las ruedas bien
// (calibrar) y se compara después. Si pierden las cuatro por igual, se nota comparándolas con el GPS.

class TyreMonitor(saved: String?) {
    /** Relación de cada rueda (DI, DD, TI, TD) con la media, y de la media con el GPS, al calibrar. */
    var base: DoubleArray? = null; private set
    var baseGps: Double? = null; private set
    var calDate: String = ""; private set
    private val sum = DoubleArray(4)
    private var sumGps = 0.0
    private var nGps = 0
    var samples = 0; private set
    /** Medias de ahora (desde que se calibró o del último rato). */
    private val now = DoubleArray(4) { 1.0 }
    private var nowGps = 1.0
    private var nowN = 0

    init {
        saved?.split("|")?.let { p ->
            if (p.size >= 6) {
                base = doubleArrayOf(p[0].toDouble(), p[1].toDouble(), p[2].toDouble(), p[3].toDouble())
                baseGps = p[4].toDoubleOrNull()
                calDate = p[5]
                samples = LEARN_SAMPLES
            }
        }
    }

    fun save(): String? = base?.let { b -> (b.map { "%.6f".format(java.util.Locale.US, it) } + ((baseGps?.let { "%.6f".format(java.util.Locale.US, it) }) ?: "") + calDate).joinToString("|") }

    /** Empezar de nuevo: aprende durante unos minutos de conducción normal. */
    fun calibrate(date: String) {
        base = null; baseGps = null; calDate = date
        sum.fill(0.0); sumGps = 0.0; nGps = 0; samples = 0
        now.fill(1.0); nowGps = 1.0; nowN = 0
    }

    val learning: Int get() = if (base != null) 100 else (samples * 100 / LEARN_SAMPLES).coerceAtMost(99)

    /**
     * Una lectura de las cuatro ruedas (km/h) con la velocidad del GPS si la hay. Solo cuenta en condiciones
     * buenas: entre 30 y 130 km/h y casi en recta (las ruedas de cada eje casi iguales).
     */
    fun sample(w: List<Double>, gps: Double?) {
        if (w.size < 4) return
        val mean = w.average()
        if (mean < 30 || mean > 130) return
        if (Math.abs(w[0] - w[1]) / mean > 0.03 || Math.abs(w[2] - w[3]) / mean > 0.03) return   // curva
        val r = DoubleArray(4) { w[it] / mean }
        val g = gps?.takeIf { it > 25 }?.let { mean / it }
        val b = base
        if (b == null) {
            for (i in 0..3) sum[i] += r[i]
            if (g != null) { sumGps += g; nGps++ }
            samples++
            if (samples >= LEARN_SAMPLES) {
                base = DoubleArray(4) { sum[it] / samples }
                baseGps = if (nGps >= LEARN_SAMPLES / 3) sumGps / nGps else null
            }
            return
        }
        // Media móvil lenta: un bache o una curva no la mueven
        val k = 1.0 / 60
        for (i in 0..3) now[i] += (r[i] - now[i]) * (if (nowN < 60) 1.0 / (nowN + 1) else k)
        if (g != null) nowGps += (g - nowGps) * (if (nowN < 60) 1.0 / (nowN + 1) else k)
        nowN++
    }

    /** Desviación de cada rueda respecto a cuando se calibró, en % (positivo = gira más rápido). */
    fun deviations(): DoubleArray? {
        val b = base ?: return null
        if (nowN < 30) return null
        return DoubleArray(4) { (now[it] / b[it] - 1) * 100 }
    }

    /** Ruedas con poco aire (0 = DI, 1 = DD, 2 = TI, 3 = TD) según la sensibilidad (0 baja, 1 normal, 2 alta). */
    fun flats(sens: Int): List<Int> {
        val d = deviations() ?: return emptyList()
        val th = when (sens) { 0 -> 0.6; 2 -> 0.25; else -> 0.4 }
        val bg = baseGps
        // Las cuatro a la vez: todas giran más rápido que al calibrar comparadas con el GPS
        if (bg != null && nowN >= 60 && (nowGps / bg - 1) * 100 > th * 2.5) return listOf(0, 1, 2, 3)
        return d.indices.filter { d[it] > th }
    }

    companion object { const val LEARN_SAMPLES = 150 }
}
