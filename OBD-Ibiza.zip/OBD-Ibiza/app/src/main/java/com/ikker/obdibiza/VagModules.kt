package com.ikker.obdibiza

import kotlinx.coroutines.delay

// ═══════════════════════════════════════════════════════════════════ Otras centralitas (VAG)
// En el Ibiza 6J (PQ25, 2011) conviven dos formas de hablar con las centralitas:
//  · UDS sobre ISO-TP, como el motor, cada una con su par de direcciones CAN (petición / respuesta).
//  · KWP2000 sobre TP 2.0, la forma antigua de VAG: se abre un canal con la centralita por la 0x200 y se
//    hablan tramas numeradas con acuse de recibo.
// La app prueba primero UDS y, si no contesta, TP 2.0. Solo LEE y BORRA averías y lee valores de medida:
// nunca codifica ni cambia nada en las centralitas.

enum class VagProto(val text: String) { UDS("UDS"), TP20("KWP2000 · TP 2.0"), NONE("No contesta") }

/** Centralita conocida de este coche: dirección lógica VAG y, si se sabe, sus direcciones CAN de UDS. */
class VagModule(val addr: Int, val name: String, val udsTx: Int? = null, val udsRx: Int? = null) {
    val label: String get() = "%02X · %s".format(addr, name)
}

object VagModules {
    /** Sin el motor (01), que ya se lee por OBD. */
    val all = listOf(
        VagModule(0x03, "ABS / ESP", 0x713, 0x77D),
        VagModule(0x15, "Airbag", 0x715, 0x77F),
        VagModule(0x17, "Cuadro de instrumentos", 0x714, 0x77E),
        VagModule(0x19, "Pasarela CAN (gateway)", 0x710, 0x77A),
        VagModule(0x09, "Electrónica central", 0x70E, 0x778),
        VagModule(0x08, "Climatizador", 0x746, 0x7B0),
        VagModule(0x44, "Dirección asistida", 0x712, 0x77C),
        VagModule(0x16, "Electrónica de la columna", 0x70C, 0x776),
        // Sin cambio (02, el suyo es manual), confort (46, va dentro de la electrónica central) ni radio (56, la pantalla no es de Seat)
    )

    fun byAddr(a: Int) = all.firstOrNull { it.addr == a }
}

/** Avería de otra centralita. [code] tal como lo enseña VCDS/Autel (VAG de 5 cifras en KWP, P/C/B/U en UDS). */
data class ModDtc(val code: String, val status: Int, val active: Boolean, val text: String)

/** Resultado de leer una centralita. */
data class ModuleState(
    val addr: Int,
    val proto: VagProto,
    val part: String = "",
    /** null = no se han podido leer las averías. */
    val dtcs: List<ModDtc>? = null,
    val message: String = "",
    /** Grupo de medida con la velocidad de las cuatro ruedas (solo ABS por KWP). */
    val wheelGroup: Int? = null,
)

/** Un valor de un bloque de medida KWP ya convertido. */
data class MeasureValue(val value: Double?, val text: String, val unit: String)

object Kwp {
    /**
     * Valor de medida VAG (tipo, a, b) → número y unidad. Son las fórmulas estándar de los bloques de medida
     * de KWP1281/KWP2000 que usan VCDS y los lectores. Las que no se conocen salen en crudo.
     */
    fun decode(t: Int, a: Int, b: Int): MeasureValue {
        fun v(x: Double, u: String, dec: Int = 1) = MeasureValue(x, "%.${dec}f".format(java.util.Locale("es", "ES"), x), u)
        return when (t) {
            1 -> v(0.2 * a * b, "rpm", 0)
            2 -> v(a * 0.002 * b, "%")
            3 -> v(0.002 * a * b, "°")
            4 -> v(Math.abs(b - 127) * 0.01 * a, "° ATDC")
            5 -> v(a * (b - 100) * 0.1, "°C")
            6, 21 -> v(0.001 * a * b, "V", 2)
            7 -> v(0.01 * a * b, "km/h", 2)
            8 -> v(0.1 * a * b, "")
            9 -> v((b - 127) * 0.02 * a, "°")
            11 -> v(0.0001 * a * (b - 128) + 1, "", 3)
            12 -> v(0.001 * a * b, "Ω", 2)
            13 -> v((b - 127) * 0.001 * a, "mm", 2)
            14 -> v(0.005 * a * b, "bar", 2)
            15 -> v(0.01 * a * b, "ms", 2)
            18 -> v(0.04 * a * b, "mbar", 0)
            19 -> v(0.01 * a * b, "l", 2)
            20 -> v(a * (b - 128) / 128.0, "%")
            22 -> v(0.001 * a * b, "ms", 2)
            23 -> v(b / 256.0 * a, "%")
            24 -> v(0.001 * a * b, "A", 2)
            25 -> v(b * 1.421 + a / 182.0, "g/s")
            26 -> v((b - a).toDouble(), "°C", 0)
            27 -> v(Math.abs(b - 128) * 0.01 * a, "°")
            33 -> v(if (a == 0) 100.0 * b else 100.0 * b / a, "%")
            34 -> v((b - 128) * 0.01 * a, "kW")
            35 -> v(0.01 * a * b, "l/h", 2)
            36 -> v(a * 2560.0 + b * 10, "km", 0)
            40 -> v(b * 0.1 + 25.5 * a - 400, "A")
            43 -> v(b * 0.1 + 25.5 * a, "V")
            45 -> v(0.1 * a * b / 100, "", 2)
            48 -> v(b + a * 255.0, "", 0)
            50 -> v(if (a == 0) 0.0 else (b - 128) / (0.01 * a), "mbar", 0)
            52 -> v(b * 0.02 * a - a, "Nm")
            54 -> v(a * 256.0 + b, "", 0)
            55 -> v(a * b / 200.0, "s", 2)
            59 -> v((a * 256.0 + b) / 32768, "g/s", 3)
            60 -> v((a * 256.0 + b) * 0.01, "s", 2)
            64 -> v((a + b).toDouble(), "Ω", 0)
            65 -> v(0.01 * a * (b - 127), "mm", 2)
            67 -> v(640.0 * a + b * 2.5, "°", 1)
            68 -> v((256.0 * a + b) / 7.365, "°/s", 1)
            70 -> v((256.0 * a + b) * 0.192, "m/s²", 2)
            16 -> MeasureValue(null, Integer.toBinaryString(b).padStart(8, '0'), "")
            17 -> MeasureValue(null, "${a.toChar()}${b.toChar()}".trim(), "")
            else -> MeasureValue(null, "%02X %02X".format(a, b), "tipo $t")
        }
    }

    /** Respuesta 61 GG [t a b]×n → valores. null si no es un bloque de medida. */
    fun measuring(payload: IntArray, group: Int): List<MeasureValue>? {
        if (payload.size < 2 || payload[0] != 0x61 || payload[1] != group) return null
        val out = mutableListOf<MeasureValue>()
        var i = 2
        while (i + 2 < payload.size) { out += decode(payload[i], payload[i + 1], payload[i + 2]); i += 3 }
        return out
    }

    /** Respuesta 58 n [H L estado]×n → averías (código VAG de 5 cifras). */
    fun dtcs(payload: IntArray): List<ModDtc>? {
        if (payload.isEmpty() || payload[0] != 0x58) return null
        val out = mutableListOf<ModDtc>()
        var i = 2
        while (i + 2 < payload.size) {
            val code = payload[i] * 256 + payload[i + 1]
            val st = payload[i + 2]
            if (code != 0 && code != 0xFFFF) {
                // En KWP2000 de VAG el bit 5 del estado indica que el fallo está presente ahora
                // El estado se enseña tal cual: en KWP2000 de VAG no se sabe con seguridad qué bit es "activa"
                out += ModDtc("%05d".format(code), st, false, VagDtcText.describe(code))
            }
            i += 3
        }
        return out
    }

    /** ¿Es una lista de 4 velocidades (las cuatro ruedas)? Devuelve las 4 en km/h. */
    fun wheelSpeeds(values: List<MeasureValue>): List<Double>? {
        val kmh = values.filter { it.unit == "km/h" && it.value != null }.map { it.value!! }
        return if (kmh.size >= 4) kmh.take(4) else null
    }
}

/** Textos de las averías VAG más habituales (las demás salen con su número). */
object VagDtcText {
    private val known = mapOf(
        546 to "Datos de la unidad de control del motor",
        1044 to "Codificación de la unidad de control incorrecta",
        1276 to "Bomba hidráulica del ABS",
        1314 to "Unidad de control del motor: sin comunicación",
        1316 to "Unidad de control del ABS: sin comunicación",
        1317 to "Cuadro de instrumentos: sin comunicación",
        1321 to "Unidad de control del airbag: sin comunicación",
        1423 to "Sensor de presión de frenado",
        1435 to "Sensor del ángulo de dirección",
        1826 to "Sensor de lluvia y luz",
        16955 to "Conmutador de las luces de freno",
        18010 to "Tensión de la batería demasiado baja",
        18265 to "Sensor de carga (generador)",
        49155 to "Sin señal o comunicación del bus CAN",
        65535 to "Unidad de control averiada",
        283 to "Sensor de velocidad delantero izquierdo",
        285 to "Sensor de velocidad delantero derecho",
        287 to "Sensor de velocidad trasero derecho",
        290 to "Sensor de velocidad trasero izquierdo",
        532 to "Tensión de alimentación",
        588 to "Encendido del airbag del conductor",
        589 to "Encendido del airbag del acompañante",
        595 to "Datos de accidente guardados",
        1217 to "Encendido del airbag lateral del conductor",
        1218 to "Encendido del airbag lateral del acompañante",
        1280 to "Pretensor del cinturón del conductor",
        1281 to "Pretensor del cinturón del acompañante",
        1578 to "Testigo de airbag",
        771 to "Sensor del nivel de combustible",
        1039 to "Sensor de temperatura del refrigerante",
        778 to "Sensor del ángulo de dirección",
        1130 to "Modo ABS: funcionamiento con fallos",
    )

    fun describe(code: Int): String = known[code] ?: "Avería VAG %05d".format(code)
}

/**
 * Habla con las otras centralitas a través del adaptador. Cambia la configuración del ELM327 (cabecera,
 * filtro de recepción, formato CAN) y la deja como estaba para el motor con [restore].
 */
class VagBus(private val e: Elm327, private val log: (String) -> Unit) {

    private fun hex(r: String): List<IntArray> = r.uppercase().lines().mapNotNull { l ->
        val s = l.replace(" ", "").trim()
        if (s.isEmpty() || s.length % 2 != 0 || s.any { it !in "0123456789ABCDEF" }) null
        else IntArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16) }
    }

    /** Por qué no contestó la última centralita (lo que devolvió el adaptador), para enseñarlo en pantalla. */
    var why: String = ""

    private var prepared = false

    /**
     * Antes de hablar con otras centralitas: sin tiempos adaptativos. Con ATAT2 el adaptador aprende lo rápido
     * que contesta el motor y deja de esperar enseguida; las centralitas que van a través de la pasarela
     * (ABS, clima…) tardan más y su respuesta se perdía.
     */
    private suspend fun prepare() {
        if (prepared) return
        for (c in listOf("ATAT0", "ATR1")) e.send(c, 1500)
        prepared = true
    }

    /** Lo primero que devolvió el adaptador, corto, para la pantalla. */
    private fun short(r: String): String {
        val l = r.lines().map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: return "sin respuesta"
        return if (l.length > 24) l.take(24) + "…" else l
    }

    /** Vuelve a dejar el adaptador hablando con el motor (UDS/OBD por 7E0). */
    suspend fun restore() {
        for (c in listOf("ATCAF1", "ATFCSM0", "ATCRA", "ATSH7E0", "ATAT2", "ATST 32")) e.send(c, 1500)
        open = null
        prepared = false
    }

    // ── UDS ─────────────────────────────────────────────────────────────────────────

    private suspend fun udsTarget(m: VagModule) {
        val tx = m.udsTx ?: return
        val rx = m.udsRx ?: return
        prepare()
        for (c in listOf("ATCAF1", "ATST 4B", "ATSH%03X".format(tx), "ATCRA%03X".format(rx), "ATFCSH%03X".format(tx), "ATFCSD300000", "ATFCSM1")) e.send(c, 1500)
    }

    /** ¿Contesta por UDS? Devuelve la referencia de pieza si la da. */
    suspend fun udsProbe(m: VagModule): String? {
        if (m.udsTx == null) { why = ""; return null }
        udsTarget(m)
        val r = e.send("22F187", 2500)
        val ms = Elm327.messages(r)
        val pos = ms.firstOrNull { it.size >= 3 && it[0] == 0x62 && it[1] == 0xF1 && it[2] == 0x87 }
        if (pos != null) return pos.drop(3).map { c -> if (c in 32..126) c.toChar() else ' ' }.joinToString("").trim().ifEmpty { "—" }
        // Un rechazo (7F 22 ..) también es que la centralita existe y habla UDS
        if (ms.any { it.size >= 2 && it[0] == 0x7F }) return "—"
        // Segunda pregunta, la más simple que hay ("sigo aquí"): la contestan todas las UDS
        val r2 = e.send("3E00", 1500)
        if (Elm327.messages(r2).any { it.isNotEmpty() && (it[0] == 0x7E || it[0] == 0x7F) }) return "—"
        why = "UDS: " + short(r)
        return null
    }

    suspend fun udsDtcs(m: VagModule): List<ModDtc>? {
        udsTarget(m)
        val list = Elm327.udsDtcs(e.send("1902FF", 6000)) ?: return null
        return list.map { ModDtc(it.code, it.status, it.active, DtcInfo.describe(it.code)) }
    }

    suspend fun udsClear(m: VagModule): Boolean {
        udsTarget(m)
        var r = e.send("14FFFFFF", 8000)
        if (!Elm327.positive(r, 0x14)) {
            if (Elm327.positive(e.send("1003", 3000), 0x10)) {
                r = e.send("14FFFFFF", 8000)
                e.send("1001", 3000)
            }
        }
        return Elm327.positive(r, 0x14)
    }

    // ── TP 2.0 ──────────────────────────────────────────────────────────────────────

    private class Channel(val addr: Int, val tx: Int, val rx: Int) { var seq = 0; var lastMs = 0L }
    private var open: Channel? = null

    /** Abre el canal TP 2.0 con la centralita. */
    private suspend fun tpOpen(addr: Int): Channel? {
        open?.let { if (it.addr == addr && System.currentTimeMillis() - it.lastMs < 900) return it }
        open?.let { tpClose(it) }
        prepare()
        // Espera larga (ATST FF ≈ 1 s) para la apertura: la respuesta pasa por la pasarela
        for (c in listOf("ATCAF0", "ATFCSM0", "ATST FF", "ATSH200", "ATCRA%03X".format(0x200 + addr))) e.send(c, 1500)
        var f: IntArray? = null
        var r = ""
        for (attempt in 0 until 2) {
            r = e.send("%02XC00010000301".format(addr), 2500)
            val frames = hex(r)
            f = frames.firstOrNull { it.size >= 6 && it[1] == 0xD0 }
            if (f != null) break
            // D6/D7/D8: la centralita existe pero no abre el canal
            frames.firstOrNull { it.size >= 2 && it[1] in 0xD6..0xD8 }?.let { why = "TP2.0: rechaza el canal (%02X)".format(it[1]); return null }
            delay(150)
        }
        if (f == null) { why = "TP2.0: " + short(r); return null }
        val ecuTx = f[2] or (f[3] shl 8)    // por donde contesta la centralita (lo que escuchamos)
        val ecuRx = f[4] or (f[5] shl 8)    // por donde escucha la centralita (a donde mandamos)
        e.send("ATSH%03X".format(ecuRx and 0x7FF), 1500)
        e.send("ATCRA%03X".format(ecuTx and 0x7FF), 1500)
        e.send("ATST 4B", 1500)
        // Parámetros del canal: bloque de 15 tramas, tiempos normales
        var p = e.send("A00F8AFF32FF", 2000)
        if (hex(p).none { it.isNotEmpty() && it[0] == 0xA1 }) p = e.send("A00F8AFF32FF", 2000)
        if (hex(p).none { it.isNotEmpty() && it[0] == 0xA1 }) {
            why = "TP2.0: abre pero no sigue (" + short(p) + ")"
            log("TP2.0 %02X: sin parámetros de canal".format(addr)); return null
        }
        return Channel(addr, ecuRx, ecuTx).also { it.lastMs = System.currentTimeMillis(); open = it }
    }

    private suspend fun tpClose(ch: Channel) {
        try { e.send("A8", 600) } catch (_: Exception) { }
        if (open === ch) open = null
    }

    /** Mantiene vivo el canal abierto (si lo hay). */
    suspend fun keepAlive() {
        val ch = open ?: return
        val r = e.send("A3", 800)
        if (hex(r).any { it.isNotEmpty() && it[0] == 0xA1 }) ch.lastMs = System.currentTimeMillis() else open = null
    }

    /** Manda un mensaje KWP por el canal y devuelve la respuesta ya montada (sin cabecera de longitud). */
    private suspend fun tpRequest(ch: Channel, kwp: IntArray, timeoutMs: Long = 2500): IntArray? {
        // Peticiones cortas: caben en una trama (tipo 1 = última, espera acuse)
        val frame = intArrayOf(0x10 or (ch.seq and 0x0F), 0x00, kwp.size) + kwp
        ch.seq = (ch.seq + 1) and 0x0F
        var resp = e.send(frame.joinToString("") { "%02X".format(it) }, timeoutMs)
        val data = mutableListOf<Int>()
        var total = -1
        var guard = 0
        while (guard++ < 12) {
            var needAck = -1
            var last = false
            for (f in hex(resp)) {
                if (f.isEmpty()) continue
                val type = f[0] shr 4
                if (type == 0xB || type == 0x9 || type == 0xA) continue   // acuses y control del canal
                if (type > 3) continue
                val payload = f.drop(1)
                if (total < 0 && payload.size >= 2) {
                    total = (payload[0] shl 8) or payload[1]
                    data += payload.drop(2)
                } else data += payload
                if (type == 0 || type == 1) needAck = (f[0] and 0x0F) + 1
                if (type == 1 || type == 3) last = true
            }
            if (needAck >= 0) {
                val ack = "B%X".format(needAck and 0x0F)
                if (last) { e.send(ack, 300); break }
                resp = e.send(ack, timeoutMs)
                continue
            }
            if (last || (total >= 0 && data.size >= total)) break
            if (resp.isBlank()) break
            resp = e.send("A3", 800)   // nada más: se pide al canal que siga
        }
        ch.lastMs = System.currentTimeMillis()
        if (total < 0) return null
        val out = data.take(total).toIntArray()
        // 7F xx 78 = "espera": la respuesta buena llega después
        if (out.size >= 3 && out[0] == 0x7F && out[2] == 0x78) {
            delay(400)
            return tpRequest(ch, kwp, timeoutMs)
        }
        return out
    }

    /** ¿Contesta por TP 2.0? Devuelve la referencia de pieza si la da. */
    suspend fun tpProbe(m: VagModule): String? {
        val ch = tpOpen(m.addr) ?: return null
        tpRequest(ch, intArrayOf(0x10, 0x89))   // sesión de diagnóstico normal de VAG
        val id = tpRequest(ch, intArrayOf(0x1A, 0x9B))
        val part = id?.takeIf { it.size > 2 && it[0] == 0x5A }?.drop(2)?.take(12)?.map { c -> if (c in 32..126) c.toChar() else ' ' }?.joinToString("")?.trim()
        return part?.ifEmpty { "—" } ?: "—"
    }

    suspend fun tpDtcs(m: VagModule): List<ModDtc>? {
        val ch = tpOpen(m.addr) ?: return null
        val r = tpRequest(ch, intArrayOf(0x18, 0x02, 0xFF, 0x00), 4000) ?: return null
        return Kwp.dtcs(r)
    }

    suspend fun tpClear(m: VagModule): Boolean {
        val ch = tpOpen(m.addr) ?: return false
        val r = tpRequest(ch, intArrayOf(0x14, 0xFF, 0x00), 6000) ?: return false
        return r.isNotEmpty() && r[0] == 0x54
    }

    /** Bloque de medida [group] (1–255) por TP 2.0. */
    suspend fun tpMeasure(m: VagModule, group: Int): List<MeasureValue>? {
        val ch = tpOpen(m.addr) ?: return null
        val r = tpRequest(ch, intArrayOf(0x21, group)) ?: return null
        return Kwp.measuring(r, group)
    }

    suspend fun closeAll() { open?.let { tpClose(it) } }
}

// ═══════════════════════════════════════════════════════════════════ Ruedas con poco aire
// Igual que el control de presión del coche: una rueda con menos aire tiene el radio un poco menor y, a la
// misma velocidad del coche, gira más rápido que las otras. Se aprende cómo giran con las ruedas bien
// (calibrar) y se compara después. Si pierden las cuatro por igual, se nota comparándolas con el GPS.

class TyreMonitor(saved: String?) {
    /** Relación de cada rueda (DI, DD, TI, TD) con la media, y de la media con el GPS, al calibrar. */
    var base: DoubleArray? = null; private set
    var baseGps: Double? = null; private set
    var calDate: String = ""; private set
    private val sum = DoubleArray(4)
    private var sumGps = 0.0
    private var nGps = 0
    var samples = 0; private set
    /** Medias de ahora (desde que se calibró o del último rato). */
    private val now = DoubleArray(4) { 1.0 }
    private var nowGps = 1.0
    private var nowN = 0

    init {
        saved?.split("|")?.let { p ->
            if (p.size >= 6) {
                base = doubleArrayOf(p[0].toDouble(), p[1].toDouble(), p[2].toDouble(), p[3].toDouble())
                baseGps = p[4].toDoubleOrNull()
                calDate = p[5]
                samples = LEARN_SAMPLES
            }
        }
    }

    fun save(): String? = base?.let { b -> (b.map { "%.6f".format(java.util.Locale.US, it) } + ((baseGps?.let { "%.6f".format(java.util.Locale.US, it) }) ?: "") + calDate).joinToString("|") }

    /** Empezar de nuevo: aprende durante unos minutos de conducción normal. */
    fun calibrate(date: String) {
        base = null; baseGps = null; calDate = date
        sum.fill(0.0); sumGps = 0.0; nGps = 0; samples = 0
        now.fill(1.0); nowGps = 1.0; nowN = 0
    }

    val learning: Int get() = if (base != null) 100 else (samples * 100 / LEARN_SAMPLES).coerceAtMost(99)

    /**
     * Una lectura de las cuatro ruedas (km/h) con la velocidad del GPS si la hay. Solo cuenta en condiciones
     * buenas: entre 30 y 130 km/h y casi en recta (las ruedas de cada eje casi iguales).
     */
    fun sample(w: List<Double>, gps: Double?) {
        if (w.size < 4) return
        val mean = w.average()
        if (mean < 30 || mean > 130) return
        if (Math.abs(w[0] - w[1]) / mean > 0.03 || Math.abs(w[2] - w[3]) / mean > 0.03) return   // curva
        val r = DoubleArray(4) { w[it] / mean }
        val g = gps?.takeIf { it > 25 }?.let { mean / it }
        val b = base
        if (b == null) {
            for (i in 0..3) sum[i] += r[i]
            if (g != null) { sumGps += g; nGps++ }
            samples++
            if (samples >= LEARN_SAMPLES) {
                base = DoubleArray(4) { sum[it] / samples }
                baseGps = if (nGps >= LEARN_SAMPLES / 3) sumGps / nGps else null
            }
            return
        }
        // Media móvil lenta: un bache o una curva no la mueven
        val k = 1.0 / 60
        for (i in 0..3) now[i] += (r[i] - now[i]) * (if (nowN < 60) 1.0 / (nowN + 1) else k)
        if (g != null) nowGps += (g - nowGps) * (if (nowN < 60) 1.0 / (nowN + 1) else k)
        nowN++
    }

    /** Desviación de cada rueda respecto a cuando se calibró, en % (positivo = gira más rápido). */
    fun deviations(): DoubleArray? {
        val b = base ?: return null
        if (nowN < 30) return null
        return DoubleArray(4) { (now[it] / b[it] - 1) * 100 }
    }

    /** Ruedas con poco aire (0 = DI, 1 = DD, 2 = TI, 3 = TD) según la sensibilidad (0 baja, 1 normal, 2 alta). */
    fun flats(sens: Int): List<Int> {
        val d = deviations() ?: return emptyList()
        val th = when (sens) { 0 -> 0.6; 2 -> 0.25; else -> 0.4 }
        val bg = baseGps
        // Las cuatro a la vez: todas giran más rápido que al calibrar comparadas con el GPS
        if (bg != null && nowN >= 60 && (nowGps / bg - 1) * 100 > th * 2.5) return listOf(0, 1, 2, 3)
        return d.indices.filter { d[it] > th }
    }

    companion object { const val LEARN_SAMPLES = 150 }
}
