package com.ikker.obdibiza

import android.app.Application
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withLock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Conn { DESCONECTADO, CONECTANDO, CONECTADO }

/**
 * Un reloj colocado en una página: dato, posición del centro (fracción del ancho y del alto
 * de la zona de relojes) y diámetro (fracción del alto).
 */
data class GaugeItem(val id: String, val x: Float, val y: Float, val size: Float)

/** Disposición inicial: dos relojes laterales y uno grande en el centro. */
fun defaultLayout(ids: List<String>): List<GaugeItem> = listOf(
    GaugeItem(ids[0], 0.17f, 0.5f, 0.70f),
    GaugeItem(ids[1], 0.5f, 0.5f, 0.84f),
    GaugeItem(ids[2], 0.83f, 0.5f, 0.70f),
)

/** Ordenador de viaje: se calcula integrando la velocidad (y el consumo, si el coche lo da). */
data class Trip(
    val startMs: Long = System.currentTimeMillis(),
    val distanceKm: Double = 0.0,
    val movingSeconds: Double = 0.0,
    val maxSpeed: Double = 0.0,
    val fuelLitres: Double? = null,
) {
    val avgSpeed: Double? get() = if (movingSeconds > 10) distanceKm / (movingSeconds / 3600) else null
    val avgConsumption: Double? get() = fuelLitres?.let { f -> if (distanceKm > 0.5) f / distanceKm * 100 else null }
}

enum class AccelMode(val title: String, val from: Double, val to: Double) {
    ZERO_100("0 – 100 km/h", 0.0, 100.0),
    ZERO_60("0 – 60 km/h", 0.0, 60.0),
    MID_80_120("80 – 120 km/h", 80.0, 120.0),
}

enum class AccelState { PARADO, PREPARADO, MIDIENDO, HECHO }

/** Cronómetro de aceleración. Los tiempos de cruce se interpolan entre lecturas para afinar. */
data class Accel(
    val mode: AccelMode = AccelMode.ZERO_100,
    val state: AccelState = AccelState.PARADO,
    val startMs: Long = 0,
    val resultS: Double? = null,
    val best: Map<AccelMode, Double> = emptyMap(),
)

/** Posible identificador de temperatura de aceite encontrado al rastrear la centralita. */
data class OilCandidate(val did: Int, val formula: Int, val value: Double)

/** Ajustes de los avisos (límite de velocidad, radares y mapa). Se guardan como números en los ajustes. */
enum class AlertKey(val def: Int) {
    RADAR_ON(1), RADAR_DIST(2), RADAR_SOUND(1), RADAR_TONE(1), RADAR_REPEAT(0), RADAR_VOL(2), RADAR_BLINK(2),
    LIMIT_EST(1), LIMIT_TONE(0), LIMIT_REPEAT(3), LIMIT_VOL(2), LIMIT_BLINK(2),
    AUTO_FETCH(1), WIFI_UPDATE(1),
    /** Tamaño de los números digitales de los relojes: 80 % … 150 % (índice 4 = 120 %). */
    LCD_SIZE(4),
    /** Música durante el aviso de radar: 0 = bajarla, 1 = pararla. */
    RADAR_DUCK(0),
    /** Corrección del consumo para igualarlo con el cuadro, en % (100 = sin corregir). */
    FUEL_CAL(100),
    /** Lo mismo pero con el coche parado y el motor al ralentí (el cálculo por carga se pasa al ralentí). */
    FUEL_IDLE(100),
    /** Aviso de rueda con poco aire: encendido y sensibilidad (0 baja, 1 normal, 2 alta). */
    TYRE_ON(1), TYRE_SENS(1),
}

/** Textos y valores de cada opción. */
object AlertOptions {
    val tones = listOf("Pitido", "Doble pitido", "Triple tono", "Aviso suave", "Alarma")
    val toneIds = intArrayOf(
        android.media.ToneGenerator.TONE_PROP_BEEP, android.media.ToneGenerator.TONE_PROP_BEEP2,
        android.media.ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, android.media.ToneGenerator.TONE_PROP_ACK,
        android.media.ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK,
    )
    val toneMs = intArrayOf(300, 500, 700, 400, 1200)
    val volumes = listOf("Bajo", "Medio", "Alto")
    val volumeLevels = intArrayOf(45, 75, 100)
    val radarDistances = listOf(300, 500, 1000, 1500, 2000)
    val radarRepeats = listOf("Una vez", "Cada 5 s", "Cada 10 s", "Cada 20 s", "Más seguido al acercarse")
    val limitRepeats = listOf("Una vez", "Cada 5 s", "Cada 10 s", "Cada 15 s", "Cada 30 s")
    val limitRepeatMs = longArrayOf(Long.MAX_VALUE, 5_000, 10_000, 15_000, 30_000)
    val radarBlinks = listOf("Sin parpadeo", "Lento", "Rápido", "Más rápido al acercarse")
    val limitBlinks = listOf("Sin parpadeo", "Lento", "Rápido")
    val lcdSizes = listOf("80 %", "90 %", "100 %", "110 %", "120 %", "130 %", "140 %", "150 %")
    fun lcdScale(i: Int) = 0.8f + 0.1f * i.coerceIn(0, lcdSizes.size - 1)
    fun distanceText(m: Int) = if (m >= 1000) String.format(Locale("es", "ES"), "%s km", if (m % 1000 == 0) "${m / 1000}" else "%.1f".format(Locale("es", "ES"), m / 1000.0)) else "$m m"
}

/** Un candidato a presión del turbo, para enseñarlo en Ajustes. */
data class BoostView(val did: Int, val formula: Int, val live: Double?, val n: Int, val meanErr: Double?, val ambient: Boolean, val discarded: Boolean)

/** Resultado de una comprobación del diagnóstico. */
enum class CheckLevel { OK, AVISO, MAL, INFO }

/** Una línea del diagnóstico: qué se ha mirado, qué valor tiene, si está bien o mal y por qué. */
data class DiagCheck(val name: String, val level: CheckLevel, val value: String, val why: String)

data class UiState(
    val conn: Conn = Conn.DESCONECTADO,
    val status: String = "Enchufa el cable OBD y pulsa Conectar",
    val adapter: String = "",
    val protocol: String = "",
    val vin: String = "",
    val supportedPids: Set<Int> = emptySet(),
    val values: Map<String, Double> = emptyMap(),
    val peaks: Map<String, Double> = emptyMap(),
    val mil: Boolean? = null,
    val dtcCount: Int? = null,
    val dtcs: List<String>? = null,
    val pendingDtcs: List<String>? = null,
    val permanentDtcs: List<String>? = null,
    /** Memoria propia de la centralita (UDS 19 02), la que leen Autel o VCDS. null = no leída o no contesta. */
    val udsDtcs: List<UdsDtc>? = null,
    /** Cuándo se leyeron (o borraron) las averías por última vez. Se guarda entre arranques. */
    val dtcReadAt: Long? = null,
    val dtcBusy: Boolean = false,
    // ---- Otras centralitas (ABS, airbag, cuadro…)
    val modules: List<ModuleState> = emptyList(),
    val modBusy: Boolean = false,
    val modMessage: String = "",
    /** Lectura en vivo de una centralita (solo ABS y cuadro, en Datos en vivo): dirección y valores por grupo. */
    val liveMod: Int? = null,
    val liveGroups: Map<Int, List<MeasureValue>> = emptyMap(),
    val liveMessage: String = "",
    /** Grupos de medida leídos a mano de cada centralita (para saber qué es cada una). */
    val modGroups: Map<Int, List<String>> = emptyMap(),
    /** Archivo con el tráfico de la última vez que se habló con las otras centralitas. */
    val modFile: String = "",
    // ---- Ruedas con poco aire
    /** 0 = DI, 1 = DD, 2 = TI, 3 = TD. */
    val tyreFlats: List<Int> = emptyList(),
    val tyreDev: List<Double>? = null,
    val tyreLearn: Int = 0,
    val tyreCal: String = "",
    /** ¿Se pueden leer las cuatro ruedas del ABS? null = sin buscar todavía. */
    val tyreAvailable: Boolean? = null,
    /** Lectura de todos los datos propios de VAG del motor (22 1000–2FFF) a un archivo, para buscar datos nuevos. */
    val engDumpProgress: Float? = null,
    val engDumpMessage: String = "",
    val engDumpFile: String = "",
    /** Modo escucha (grabar lo que hace otro aparato, como el Autel, conectado con un cable en Y). */
    val sniffOn: Boolean = false,
    val sniffFrames: Int = 0,
    val sniffIds: Int = 0,
    val sniffSecs: Int = 0,
    val sniffMessage: String = "",
    val sniffFile: String = "",
    /** Modo puente: otra app (Car Scanner) usa el cable a través de esta, como si fuera un adaptador wifi. */
    val bridgeOn: Boolean = false,
    val bridgeClient: Boolean = false,
    val bridgeCmds: Int = 0,
    val bridgeSecs: Int = 0,
    val bridgeMessage: String = "",
    val bridgeFile: String = "",
    val bridgeAddr: String = "",
    val dtcMessage: String = "",
    /** Diagnóstico completo de la última lectura de averías. */
    val checks: List<DiagCheck> = emptyList(),
    /** Valor en vivo de cada candidato de aceite (se lee solo con Ajustes abierto). */
    val candLive: Map<Int, Double> = emptyMap(),
    val log: List<String> = emptyList(),
    val dashboard: List<String> = Params.defaultDashboard,
    val columns: Int = 3,
    val refreshHz: Double = 0.0,
    val traffic: Boolean = false,
    val demo: Boolean = false,
    /** Reloj grande principal, valor del centro y segundo reloj. */
    /** Páginas del panel: cada una con 3 relojes (izquierda, centro, derecha). */
    val pages: List<List<GaugeItem>> = Params.defaultPages.map { defaultLayout(it) },
    val pageNames: List<String> = Params.defaultPageNames,
    /** Imagen elegida por el usuario para el reloj principal (null = ninguna). */
    val logo: androidx.compose.ui.graphics.ImageBitmap? = null,
    val page: Int = 0,
    val ringMain: String = "rpm",
    val ringCenter: String = "speed",
    val ringSecond: String = Params.BOOST,
    val ringThird: String = "oil",
    /** De dónde sale la temperatura del aceite ("" = no encontrada). */
    val oilSource: String = "",
    val oilCustomDid: String = "",
    val oilCustomFormula: Int = 0,
    val oilTestMessage: String = "",
    /** Rastreo de identificadores: progreso 0..1 (null = parado) y candidatos encontrados. */
    val oilScanProgress: Float? = null,
    val oilCandidates: List<OilCandidate> = emptyList(),
    /** Datos que pide la pantalla abierta (gráficas, barras…), además de la página de relojes. */
    val focus: List<String> = emptyList(),
    val trip: Trip = Trip(),
    val accel: Accel = Accel(),
    /** Revoluciones a las que se encienden del todo las luces de cambio. */
    val shiftRpm: Int = 4000,
    /** Presión a la que se calibraron las ruedas (bar): la presión de cada una se estima a partir de ella. */
    val tyreBar: Double = 2.5,
    /** Últimos valores de cada dato para las mini-gráficas. */
    val history: Map<String, List<Float>> = emptyMap(),
    // ---- Límite de velocidad (GPS + OpenStreetMap)
    val limitOn: Boolean = true,
    /** Km/h por encima del límite a partir de los que avisa. */
    val limitMargin: Int = 5,
    val limitSound: Boolean = false,
    val limitPermission: Boolean = false,
    val limitStatus: String = "",
    /** Límite de la vía por la que vas (null = desconocido). */
    val speedLimit: Int? = null,
    /** true = deducido por el tipo de vía; false = apuntado en el mapa. */
    val limitEstimated: Boolean = false,
    val limitRoad: String = "",
    val gpsSpeed: Double? = null,
    /** Ajustes de avisos (ver [AlertKey]). */
    val alerts: Map<AlertKey, Int> = emptyMap(),
    /** Radar por delante: distancia (m) y su límite. */
    val radarM: Double? = null,
    val radarKmh: Int? = null,
    val radarCount: Int = 0,
    val radarTramo: Boolean = false,
    val radarMine: Int = 0,
    val radarNearestM: Double? = null,
    /** Radares guardados a mano, en el orden en que se guardaron. */
    val myRadars: List<Radar> = emptyList(),
    /** El límite actual es una corrección tuya, y cuántas hay guardadas. */
    val limitCorrected: Boolean = false,
    val limitFixCount: Int = 0,
    val mapUpdated: String = "",
    /** Mapa de límites guardado en la pantalla. */
    val limitSaved: String = "",
    val limitRegionProgress: Float? = null,
    val limitRegionText: String = "",
    /** Radio de la zona a descargar, en km. */
    val limitRegionKm: Int = 50,
    // ---- Presión del turbo precisa
    /** De dónde sale la presión del turbo. */
    val boostSource: String = "",
    val boostMessage: String = "",
    /** Rastreo de la centralita: progreso 0..1 (null = parado). */
    val boostScanProgress: Float? = null,
    /** Hay candidatos esperando a confirmarse conduciendo. */
    val boostValidating: Boolean = false,
    /** El dato estándar está en su tope (255 kPa): el turbo puede ir por encima de lo que marca. */
    val boostCapped: Boolean = false,
    /** Candidatos a presión del turbo, con su valor en directo (mientras se mira Ajustes). */
    val boostCands: List<BoostView> = emptyList(),
    /** Referencias en directo: presión del colector estándar y atmosférica, en hPa. */
    val boostRefHpa: Double? = null,
    val baroRefHpa: Double? = null,
    // ---- Diagnóstico USB
    val usbInfo: List<Pair<String, String>> = emptyList(),
    /** De dónde sale el consumo ahora mismo (null = sin conectar). */
    val fuelSrc: FuelSource? = null,
    /** null = sin comprobar. */
    val rootOk: Boolean? = null,
    val usbBus: String = "",
    val usbBusy: Boolean = false,
    val usbMessage: String = "",
    val autoUsbReset: Boolean = false,
    val usbLog: List<String> = emptyList(),
) {
    /** Todo lo que se ve en el panel y por tanto se lee en cada vuelta. */
    val live: List<String> get() = ((pages.getOrNull(page)?.map { it.id } ?: emptyList()) + focus + "speed").distinct()
}

class ObdViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    private val usb = app.getSystemService(Context.USB_SERVICE) as UsbManager
    private val prefs = app.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
    private var elm: Elm327? = null
    private var pollJob: Job? = null
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    // Registro de desconexiones (va antes de init porque init ya apunta sucesos)
    private val usbLog = EventLog(java.io.File(app.filesDir, "usb_registro.txt"))
    private val appStartMs = System.currentTimeMillis()
    /** null hasta que se enciende la pantalla con la app ya abierta. */
    private var screenOnMs: Long? = null
    /** Últimas tensiones de batería (hora, voltios), para saber si hubo un bajón al fallar. */
    private val volts = ArrayDeque<Pair<Long, Double>>()
    private var hadDevice = false
    private var lostAtMs = 0L
    private var lastResetMs = 0L
    private var resetsThisRun = 0

    // Presión del turbo precisa (van antes de init porque init las carga de los ajustes guardados)
    private var boostDid: Int? = null
    private var boostFormula = 0
    private var ambDid: Int? = null
    private var ambFormula = 0
    private var calibrator: BoostCalibrator? = null
    private var calRot = 0
    private var boostFails = 0
    private var boostScanJob: Job? = null

    /** GPS + OpenStreetMap: límite de la vía por la que vas. Va antes de init porque init lo arranca. */
    private val limits = SpeedLimitWatcher(app, viewModelScope, { log(it) }) { u ->
        _state.update {
            it.copy(
                limitStatus = u.status, speedLimit = u.kmh, limitEstimated = u.estimated,
                limitRoad = u.road, gpsSpeed = u.gpsKmh, limitPermission = u.permission,
                limitSaved = u.saved, limitRegionProgress = u.regionProgress, limitRegionText = u.regionText,
                radarM = u.radarM, radarKmh = u.radarKmh, radarCount = u.radarCount,
                radarTramo = u.radarTramo, radarMine = u.radarMine, radarNearestM = u.radarNearestM, myRadars = u.myRadars,
                limitCorrected = u.corrected, limitFixCount = u.fixCount, mapUpdated = u.updated,
            )
        }
        checkOverspeed()
        checkRadar()
    }


    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                ACTION_PERMISSION -> {
                    if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) tryConnect(quiet = false)
                    else setStatus("Permiso USB denegado. Vuelve a pulsar Conectar y acepta.")
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    event("Android ha perdido el cable USB (corte eléctrico o del puerto)", kernel = true)
                    if (elm != null) disconnect("Cable OBD desenchufado")
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> event("Cable USB detectado")
                Intent.ACTION_SCREEN_OFF -> event("Pantalla apagada (contacto quitado o reposo)")
                Intent.ACTION_SCREEN_ON -> { screenOnMs = System.currentTimeMillis(); event("Pantalla encendida (sale del reposo)") }
            }
        }
    }

    init {
        val f = IntentFilter().apply {
            addAction(ACTION_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        ContextCompat.registerReceiver(app, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        val saved = prefs.getString("widgets", null)
            ?.split(",")?.filter { it in Params.byId }
            ?.takeIf { it.isNotEmpty() }
        // Temperatura de aceite: 22 11 BE a la centralita de motor, fórmula "décimas de kelvin".
        // Si lo guardado estaba vacío o era el 1111 (valor fijo de 80 °C, no es el aceite), se sustituye.
        val oilDidPref = (prefs.getString("oilDid", "") ?: "").uppercase()
        val migrate = oilDidPref.isEmpty() || oilDidPref == "1111"
        val savedOilDid = if (migrate) OIL_DID else oilDidPref
        val savedOilFormula = if (migrate) OIL_FORMULA else prefs.getInt("oilFormula", OIL_FORMULA)
        if (migrate) prefs.edit().putString("oilDid", savedOilDid).putInt("oilFormula", savedOilFormula).apply()
        _state.update {
            it.copy(
                dashboard = saved ?: Params.defaultDashboard,
                columns = prefs.getInt("columnas", 3),
                pages = loadPages(),
                pageNames = prefs.getString("pageNames", null)?.split("|") ?: Params.defaultPageNames,
                logo = loadLogo(),
                ringMain = prefs.getString("ringMain", null)?.takeIf { id -> id in Params.byId } ?: "rpm",
                ringCenter = prefs.getString("ringCenter", null)?.takeIf { id -> id in Params.byId } ?: "speed",
                ringSecond = prefs.getString("ringSecond", null)?.takeIf { id -> id in Params.byId } ?: Params.BOOST,
                ringThird = prefs.getString("ringThird", null)?.takeIf { id -> id in Params.byId } ?: "oil",
                oilCustomDid = savedOilDid,
                oilCustomFormula = savedOilFormula,
                shiftRpm = prefs.getInt("shiftRpm", 4000),
                tyreBar = prefs.getFloat("tyreBar", 2.5f).toDouble(),
                oilSource = OIL_SOURCE,
                limitOn = prefs.getBoolean("limitOn", true),
                limitMargin = prefs.getInt("limitMargin", 5),
                limitSound = prefs.getBoolean("limitSound", false),
                limitRegionKm = prefs.getInt("limitRegionKm", 50),
                alerts = AlertKey.values().associateWith { k -> prefs.getInt("al_" + k.name, k.def) },
            )
        }
        applyAlerts()
        if (_state.value.limitOn) limits.start()
        loadBoost()
        loadDtcs()
        _state.update {
            it.copy(
                autoUsbReset = prefs.getBoolean("autoUsbReset", false),
                rootOk = if (prefs.contains("rootOk")) prefs.getBoolean("rootOk", false) else null,
                usbBus = prefs.getString("usbBusText", "") ?: "",
                usbLog = usbLog.last(40),
            )
        }
        // Si la app se cierra por un error, que quede apuntado por qué
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, ex ->
            try {
                val where = ex.stackTrace.firstOrNull { it.className.startsWith("com.ikker") }?.let { " en ${it.fileName}:${it.lineNumber}" } ?: ""
                usbLog.add("LA APP SE HA CERRADO POR UN ERROR: ${ex.javaClass.simpleName}: ${ex.message ?: ""}$where")
            } catch (_: Throwable) { }
            prev?.uncaughtException(t, ex)
        }
        event("App abierta")
    }

    // ------------------------------------------------------------ Diagnóstico USB y registro de desconexiones

    /** Apunta un suceso con lo que pasaba alrededor (batería, pantalla). Con root añade los mensajes del USB del sistema. */
    private fun event(what: String, kernel: Boolean = false) {
        val now = System.currentTimeMillis()
        val es = Locale("es", "ES")
        val ctx = buildList {
            volts.lastOrNull()?.let { (t, v) ->
                val recent = volts.filter { now - it.first < 60_000 }.map { it.second }
                val min = recent.minOrNull()
                add(String.format(es, "batería %.1f V", v) + (min?.takeIf { it < v - 0.3 }?.let { String.format(es, " (mín %.1f V en el último minuto)", it) } ?: "") +
                    if (now - t > 30_000) " hace ${(now - t) / 1000} s" else "")
            }
            // Arranque real de la pantalla (si es de hace segundos, la pantalla se ha reiniciado entera)
            add("pantalla arrancada hace " + mins(android.os.SystemClock.elapsedRealtime()))
            add("app abierta hace " + mins(now - appStartMs))
            screenOnMs?.let { add("salió del reposo hace " + mins(now - it)) }
        }
        val line = what + " · " + ctx.joinToString(" · ")
        val root = _state.value.rootOk == true
        if (kernel && root) {
            viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                usbLog.add(line, UsbDoctor.kernelUsbLines(true, 25).map { "núcleo: $it" })
                _state.update { it.copy(usbLog = usbLog.last(40)) }
            }
        } else {
            usbLog.add(line)
            _state.update { it.copy(usbLog = usbLog.last(40)) }
        }
    }

    private fun mins(ms: Long): String = when {
        ms < 60_000 -> "${ms / 1000} s"
        ms < 3_600_000 -> "${ms / 60_000} min"
        else -> String.format(Locale("es", "ES"), "%.1f h", ms / 3_600_000.0)
    }

    /** Datos de la pantalla (se piden al abrir el diagnóstico). */
    fun loadUsbInfo() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val info = UsbDoctor.deviceInfo()
            _state.update { it.copy(usbInfo = info) }
        }
    }

    /** Pide root (sale el aviso del gestor de root) y lo recuerda. */
    fun checkRoot() {
        if (_state.value.usbBusy) return
        viewModelScope.launch {
            _state.update { it.copy(usbBusy = true, usbMessage = "Comprobando root… si sale un aviso en la pantalla, pulsa Permitir") }
            val ok = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { UsbDoctor.rootGranted() }
            prefs.edit().putBoolean("rootOk", ok).apply()
            _state.update {
                it.copy(
                    usbBusy = false, rootOk = ok,
                    usbMessage = if (ok) "La pantalla tiene root: se puede reiniciar el USB."
                    else if (UsbDoctor.suInstalled()) "Hay un programa de root pero no ha dado permiso a la app. Acéptalo en el gestor de root y vuelve a probar."
                    else "La pantalla no tiene root. Sin root Android no deja reiniciar el USB.",
                )
            }
            event(if (ok) "Root comprobado: disponible" else "Root comprobado: no disponible")
            if (ok) rememberControllers()
        }
    }

    /** Con root y el cable funcionando: guarda qué controlador USB lleva el cable, por si luego se cuelga. */
    private fun rememberControllers() {
        if (_state.value.rootOk != true) return
        val bus = prefs.getInt("usbBus", -1).takeIf { it > 0 }
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val c = UsbDoctor.controllers(bus)
            if (c.isNotEmpty()) prefs.edit().putString("usbCtrl", c.joinToString("|")).apply()
        }
    }

    fun setAutoUsbReset(on: Boolean) {
        prefs.edit().putBoolean("autoUsbReset", on).apply()
        _state.update { it.copy(autoUsbReset = on) }
    }

    fun clearUsbLog() {
        usbLog.clear()
        _state.update { it.copy(usbLog = emptyList()) }
    }

    fun usbLogText(): String = usbLog.all()

    /** Reinicia el USB de la pantalla (con root), de lo más suave a lo más fuerte, y comprueba si vuelve el cable. */
    fun resetUsb(auto: Boolean = false) {
        if (_state.value.usbBusy) return
        if (_state.value.rootOk != true) {
            _state.update { it.copy(usbMessage = "Hace falta root: pulsa COMPROBAR primero.") }
            return
        }
        lastResetMs = System.currentTimeMillis(); resetsThisRun++
        viewModelScope.launch {
            _state.update { it.copy(usbBusy = true, usbMessage = "Reiniciando el USB…") }
            if (elm != null) disconnect("Reiniciando el USB")
            val bus = prefs.getInt("usbBus", -1).takeIf { it > 0 }
            val result = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val steps = ArrayList<String>()
                fun cableBack(): Boolean {
                    for (i in 0 until 8) {
                        Thread.sleep(1000)
                        if (UsbSerialProber.getDefaultProber().findAllDrivers(usb).isNotEmpty()) return true
                    }
                    return false
                }
                // 1) El controlador USB del cable: se desconecta de su driver y se vuelve a conectar
                val ctrls = UsbDoctor.controllers(bus).ifEmpty {
                    (prefs.getString("usbCtrl", "") ?: "").split("|").filter { it.isNotBlank() }
                }
                for (c in ctrls) steps += "controlador: " + UsbDoctor.rebind(c)
                if (ctrls.isNotEmpty() && cableBack()) return@withContext steps to true
                // 2) Lo que hay por encima del controlador (en muchas pantallas, el bloque USB del chip)
                for (c in ctrls) steps += "bloque USB: " + UsbDoctor.rebind(c.substringBeforeLast('/'))
                if (ctrls.isNotEmpty() && cableBack()) return@withContext steps to true
                // 3) El bus entero
                steps += UsbDoctor.resetBus(bus)
                steps to cableBack()
            }
            val (steps, ok) = result
            val msg = if (ok) "USB reiniciado: el cable vuelve a estar visible." else "Reiniciado, pero el cable no ha vuelto. Mira el registro: dice qué ha fallado."
            event((if (auto) "Reinicio automático del USB · " else "Reinicio del USB · ") + if (ok) "el cable ha vuelto" else "el cable NO ha vuelto")
            usbLog.add("   pasos: " + steps.joinToString(" | ").take(400))
            _state.update { it.copy(usbBusy = false, usbMessage = msg, usbLog = usbLog.last(40)) }
            if (ok) tryConnect(quiet = false)
        }
    }

    /** Si está activado y hay root: reinicia el USB solo cuando se cuelga (como mucho 3 veces y con pausa). */
    private fun maybeAutoReset(reason: String) {
        val st = _state.value
        if (!st.autoUsbReset || st.rootOk != true || st.usbBusy) return
        val now = System.currentTimeMillis()
        if (resetsThisRun >= 3 || now - lastResetMs < 90_000) return
        event("Cuelgue detectado ($reason): se reinicia el USB")
        resetUsb(auto = true)
    }

    // ------------------------------------------------------------ Presión del turbo precisa
    //
    // El 010B no pasa de 255 kPa (1,54 bar de turbo). Por orden de preferencia se usa:
    //  1) la presión real de la memoria de la centralita (22XXXX, 2 bytes en hPa), encontrada con BUSCAR
    //  2) los PID ampliados 0170 / 0187 (2 bytes) si el coche los da
    //  3) el 010B estándar, avisando cuando llega a su tope

    private fun loadBoost() {
        // Fijo, como el aceite: en este Ibiza (CFHD) la presión real del turbo es la 22 11 49 en hPa.
        boostDid = FIXED_BOOST_DID; boostFormula = 0
        calibrator = null
        ambDid = prefs.getString("ambDid", null)?.toIntOrNull(16)
        ambFormula = prefs.getInt("ambFormula", 0)
        prefs.edit().remove("boostDid").remove("boostFormula").remove("boostCands").remove("boostStd")
            .remove("boostScanPos").remove("boostScanFound").apply()
        updateBoostSource()
    }

    private fun updateBoostSource() {
        val sup = _state.value.supportedPids
        val src = when {
            boostDid != null -> "Centralita 22%04X · precisión 1 hPa".format(boostDid) +
                (ambDid?.let { " · ambiental 22%04X".format(it) } ?: "")
            0x70 in sup -> "OBD ampliado (0170) · sin tope"
            0x87 in sup -> "OBD ampliado (0187) · sin tope"
            sup.isEmpty() -> "—"
            else -> "OBD estándar (010B) · tope 1,54 bar"
        }
        _state.update {
            it.copy(
                boostSource = src, boostValidating = calibrator != null && boostDid == null,
                boostCapped = if (boostDid != null) false else it.boostCapped,
            )
        }
    }

    /** Busca en la centralita (solo lectura) los datos de 2 bytes que valen lo mismo que la presión del colector. */
    fun scanBoost() {
        val e = elm ?: return _state.update { it.copy(boostMessage = "Conecta primero con el coche") }
        if (_state.value.boostScanProgress != null || _state.value.oilScanProgress != null) return
        val order = (0x1000..0x2FFF).toList()
        boostScanJob = viewModelScope.launch {
            // Si la búsqueda anterior se cortó, sigue donde se quedó (con lo que ya había encontrado)
            val savedPos = prefs.getInt("boostScanPos", 0).takeIf { it in 1 until order.size } ?: 0
            val found = mutableListOf<BoostCandidate>()
            if (savedPos > 0) (prefs.getString("boostScanFound", "") ?: "").split(",").forEach { t ->
                val f = t.split(":")
                val did = f.getOrNull(0)?.toIntOrNull(16); val fo = f.getOrNull(1)?.toIntOrNull()
                if (did != null && fo != null) found += BoostCandidate(did, fo)
            }
            _state.update {
                it.copy(
                    boostScanProgress = savedPos / order.size.toFloat(),
                    boostMessage = if (savedPos > 0) "Sigue donde se quedó la otra vez…" else "Probando la centralita…",
                )
            }
            // La búsqueda manda; los relojes se siguen leyendo entre medias (más despacio)
            pollJob?.cancelAndJoin(); pollJob = null
            var hung = false
            var pos = savedPos
            fun saveProgress() {
                prefs.edit().putInt("boostScanPos", pos)
                    .putString("boostScanFound", found.joinToString(",") { "%04X:%d".format(it.did, it.formula) }).apply()
            }
            /** Relojes básicos (presión, velocidad, revoluciones) para que no se congelen y para la referencia. */
            suspend fun gauges(): Double? {
                val nv = mutableMapOf<String, Double>()
                var map: Double? = null
                Elm327.mode01(e.send("010B", 1000), 0x0B)?.let { map = it[0].toDouble(); nv["map"] = it[0].toDouble() }
                Elm327.mode01(e.send("010D", 1000), 0x0D)?.let { nv["speed"] = it[0].toDouble() }
                Elm327.mode01(e.send("010C", 1000), 0x0C)?.let { nv["rpm"] = (it[0] * 256 + it.getOrElse(1) { 0 }) / 4.0 }
                map?.let { m -> nv[Params.BOOST] = (m - (_state.value.values["baro"] ?: 101.3)) / 100.0 }
                if (nv.isNotEmpty()) applyValues(nv)
                _state.update { it.copy(boostRefHpa = map?.let { m -> m * 10 }) }
                return map
            }
            /** Lo encontrado hasta ahora, en directo. */
            suspend fun liveFound() {
                for (k in 0 until minOf(6, found.size)) {
                    val c = found[(boostLiveRot + k) % found.size]
                    val d = Elm327.mode22(e.send("22%04X".format(c.did), 500), c.did) ?: continue
                    PressureFormula.hpa(d, c.formula)?.let { boostLive[c.did] = it }
                }
                boostLiveRot = (boostLiveRot + 6) % maxOf(1, found.size)
            }
            try {
                if (probeUds(e) == 0) {
                    _state.update { it.copy(boostScanProgress = null, boostMessage = "La centralita no contesta a lecturas UDS: se queda el dato estándar.") }
                    return@launch
                }
                var mapRef: Double? = null
                var silent = 0
                e.send("ATST 20")
                while (pos < order.size) {
                    val did = order[pos]
                    if (elm !== e || _state.value.boostScanProgress == null) break
                    // Con el coche en marcha la referencia no vale: espera, pero sin dejar de leer los relojes
                    while (elm === e && _state.value.boostScanProgress != null && (_state.value.values["speed"] ?: 0.0) > 3.0) {
                        _state.update { it.copy(boostMessage = "En pausa: el coche se mueve. Sigue sola al parar.") }
                        gauges()
                        if (found.isNotEmpty()) { liveFound(); publishBoost(BoostCalibrator(found), boostLive) }
                        delay(700)
                    }
                    if (_state.value.boostScanProgress == null) break
                    if (pos % 16 == 0 || mapRef == null) {
                        mapRef = gauges() ?: mapRef
                        if (pos % 64 == 0 && found.isNotEmpty()) liveFound()
                    }
                    val ref = mapRef
                    if (ref == null) {
                        // Ni el dato estándar contesta: el adaptador se ha quedado mudo
                        if (++silent >= 8) { hung = true; break }
                        delay(300); continue
                    }
                    val r = e.send("22%04X".format(did), 500)
                    // Sin un solo byte de vuelta (ni siquiera "NO DATA") muchas veces seguidas = adaptador colgado
                    if (r.isBlank()) { if (++silent >= 25) { hung = true; break } } else silent = 0
                    val data = Elm327.mode22(r, did)
                    if (data != null && found.size < 40) {
                        for (f in 0 until PressureFormula.COUNT) {
                            val h = PressureFormula.hpa(data, f) ?: continue
                            if (h in 850.0..1150.0 && Math.abs(h - ref * 10) <= 40) {
                                found += BoostCandidate(did, f)
                                boostLive[did] = h
                                log("Candidato presión 22%04X = %.0f hPa".format(did, h))
                                break
                            }
                        }
                    }
                    pos++
                    if (pos % 32 == 0) {
                        saveProgress()
                        _state.update { it.copy(boostScanProgress = pos / order.size.toFloat(), boostMessage = "Buscando… ${found.size} posibles") }
                        publishBoost(BoostCalibrator(found), boostLive)
                    }
                }
                if (elm === e && !hung) { try { e.send("ATST 32") } catch (_: Exception) { } }
                if (hung) {
                    saveProgress()
                    event("El adaptador dejó de contestar buscando la presión (iba por 22%04X)".format(order.getOrElse(pos) { 0 }))
                    _state.update {
                        it.copy(
                            boostScanProgress = null,
                            boostMessage = "El adaptador dejó de contestar a mitad de la búsqueda (iba por el ${pos * 100 / order.size} %). " +
                                "Se reinicia solo; al volver a pulsar BUSCAR sigue desde ahí.",
                        )
                    }
                    return@launch
                }
                if (pos < order.size) {
                    // Parada a mano: se guarda por dónde iba
                    saveProgress()
                    publishBoost(BoostCalibrator(found), boostLive)
                    _state.update {
                        it.copy(boostScanProgress = null, boostMessage = "Parada al ${pos * 100 / order.size} % con ${found.size} posibles. Al pulsar BUSCAR sigue desde ahí.")
                    }
                    if (found.isNotEmpty()) {
                        calibrator = BoostCalibrator(found); calRot = 0
                        prefs.edit().putString("boostCands", found.joinToString(",") { "%04X:%d".format(it.did, it.formula) }).apply()
                        updateBoostSource()
                    }
                    return@launch
                }
                prefs.edit().remove("boostScanPos").remove("boostScanFound").apply()
                if (found.isEmpty()) {
                    _state.update { it.copy(boostScanProgress = null, boostMessage = "No se encontró ningún dato de presión en la centralita: se queda el dato estándar.") }
                    return@launch
                }
                prefs.edit().putString("boostCands", found.joinToString(",") { "%04X:%d".format(it.did, it.formula) }).apply()
                calibrator = BoostCalibrator(found)
                calRot = 0
                publishBoost(calibrator!!, boostLive)
                _state.update {
                    it.copy(
                        boostScanProgress = null,
                        boostMessage = "${found.size} posibles. Ahora conduce y acelera fuerte un par de veces (por ejemplo en 3.ª): la app elige sola el bueno.",
                    )
                }
                updateBoostSource()
            } catch (ex: Exception) {
                saveProgress()
                _state.update { it.copy(boostScanProgress = null) }
                if (elm === e) disconnect("Error buscando la presión: ${ex.message}")
            } finally {
                _state.update { it.copy(boostScanProgress = null) }
                if (elm === e && pollJob == null && _state.value.conn == Conn.CONECTADO) {
                    lastDataMs = System.currentTimeMillis()
                    // Si el adaptador se quedó mudo, se reinicia sin soltar el USB; si no, vuelven los relojes
                    if (hung) recoverInPlace() else startPolling()
                }
            }
        }
    }

    // ---- Candidatos en directo (con Ajustes abierto) y elección a mano

    @Volatile private var watchBoost = false
    private var boostLiveRot = 0
    private val boostLive = HashMap<Int, Double>()

    fun watchBoostCandidates(on: Boolean) { watchBoost = on }

    private fun publishBoost(cal: BoostCalibrator, live: Map<Int, Double>) {
        _state.update {
            it.copy(
                boostCands = cal.cands.map { c ->
                    BoostView(c.did, c.formula, live[c.did], c.n, if (c.n > 0) c.meanErr else null, c.isAmbient, c.discarded)
                }.sortedWith(compareBy<BoostView> { it.discarded }.thenBy { it.meanErr ?: Double.MAX_VALUE }),
            )
        }
    }

    /** Botón USAR: se queda con ese identificador como presión real del turbo. */
    fun useBoostCandidate(did: Int, formula: Int) {
        boostDid = did; boostFormula = formula
        calibrator = null
        prefs.edit().remove("boostStd").putString("boostDid", "%04X".format(did)).putInt("boostFormula", formula).remove("boostCands").apply()
        val msg = "Elegida a mano: la presión real es 22%04X.".format(did)
        log(msg)
        _state.update { it.copy(boostMessage = msg, boostCands = emptyList()) }
        updateBoostSource()
    }

    fun stopBoostScan() = _state.update { it.copy(boostScanProgress = null) }

    /** Vuelve al dato estándar y olvida lo encontrado. */
    fun forgetBoost() {
        boostDid = null; ambDid = null; calibrator = null
        prefs.edit().putBoolean("boostStd", true).remove("boostDid").remove("boostFormula").remove("ambDid").remove("ambFormula").remove("boostCands").remove("boostScanPos").remove("boostScanFound").apply()
        _state.update { it.copy(boostMessage = "Se usa el dato estándar.", boostCands = emptyList()) }
        updateBoostSource()
    }

    private fun adoptBoost(cal: BoostCalibrator) {
        val b = cal.boost ?: return
        val a = cal.ambient
        boostDid = b.did; boostFormula = b.formula
        ambDid = a?.did; ambFormula = a?.formula ?: 0
        calibrator = null
        prefs.edit()
            .remove("boostStd").putString("boostDid", "%04X".format(b.did)).putInt("boostFormula", b.formula)
            .apply {
                if (a != null) putString("ambDid", "%04X".format(a.did)).putInt("ambFormula", a.formula)
                else remove("ambDid")
            }
            .remove("boostCands").apply()
        val msg = "Confirmada: la presión real es 22%04X (se desvía %.0f hPa de media del dato estándar)".format(b.did, b.meanErr) +
            (a?.let { ". Presión ambiental: 22%04X.".format(it.did) } ?: ".")
        log(msg)
        _state.update { it.copy(boostMessage = msg, boostCands = emptyList()) }
        updateBoostSource()
    }

    // ------------------------------------------------------------ Límite de velocidad

    fun setLimitOn(on: Boolean) {
        prefs.edit().putBoolean("limitOn", on).apply()
        _state.update { it.copy(limitOn = on) }
        if (on) limits.start() else limits.stop()
    }

    fun setLimitMargin(v: Int) {
        val m = v.coerceIn(0, 20)
        prefs.edit().putInt("limitMargin", m).apply()
        _state.update { it.copy(limitMargin = m) }
    }

    fun setLimitSound(on: Boolean) {
        prefs.edit().putBoolean("limitSound", on).apply()
        _state.update { it.copy(limitSound = on) }
        if (on) beep()   // para oír cómo suena
    }

    /** Radios de descarga: 25, 50 o 100 km. */
    fun stepLimitRegionKm(dir: Int) {
        val opts = listOf(25, 50, 100)
        val i = (opts.indexOf(_state.value.limitRegionKm).coerceAtLeast(0) + dir).coerceIn(0, opts.size - 1)
        prefs.edit().putInt("limitRegionKm", opts[i]).apply()
        _state.update { it.copy(limitRegionKm = opts[i]) }
    }

    fun downloadLimitRegion() = limits.downloadRegion(_state.value.limitRegionKm)
    /** Con wifi: vuelve a bajar del mapa de hoy los alrededores (aunque ya estén guardados). */
    fun updateLimitRegion() = limits.downloadRegion(_state.value.limitRegionKm, force = true)
    fun fixLimit(kmh: Int, wholeStreet: Boolean) = limits.addFix(kmh, wholeStreet)
    fun removeLimitFix() = limits.removeFix()
    fun clearLimitFixes() = limits.clearFixes()
    fun mapLimitNow(): LimitInfo? = limits.mapLimitNow()
    fun addRadar(tramo: Boolean): String = limits.addRadar(tramo).also { log(it) }
    fun removeNearRadar(): String = limits.removeNearRadar().also { log(it) }
    fun clearMyRadars() = limits.clearMine()
    fun updateMyRadar(i: Int, change: (Radar) -> Radar) = limits.updateMine(i, change)
    fun deleteMyRadar(i: Int) = limits.deleteMine(i)
    fun myRadarNear(): Boolean = limits.mineNear()
    fun stopLimitRegion() = limits.stopRegion()
    fun clearLimitMaps() = limits.clearSaved()
    fun importLimitMap(uri: android.net.Uri) = limits.importMap(uri)

    /** Tras conceder el permiso de ubicación (o al volver a la app): arranca el GPS y lo deja vivo en segundo plano. */
    fun refreshLocation() {
        val ok = limits.hasPermission()
        _state.update { it.copy(limitPermission = ok) }
        if (ok && _state.value.limitOn) {
            limits.start()
            if (autoReconnect) startKeepAlive()   // el servicio pasa a incluir la ubicación
        }
    }

    fun setAlert(k: AlertKey, v: Int) {
        prefs.edit().putInt("al_" + k.name, v).apply()
        _state.update { it.copy(alerts = it.alerts + (k to v)) }
        applyAlerts()
    }

    /** Pasa al vigilante del GPS la distancia de aviso de radares y si descarga zonas nuevas. */
    private fun applyAlerts() {
        val st = _state.value
        limits.radarMaxM = if (st.opt(AlertKey.RADAR_ON) == 1)
            AlertOptions.radarDistances.getOrElse(st.opt(AlertKey.RADAR_DIST)) { 1000 }.toDouble() else 0.0
        limits.autoFetch = st.opt(AlertKey.AUTO_FETCH) == 1
        limits.wifiUpdate = st.opt(AlertKey.WIFI_UPDATE) == 1
    }

    // ---- Sonidos

    private val tones = HashMap<Int, android.media.ToneGenerator>()

    /**
     * Aviso de radar por encima de lo demás: se pide a Android el foco de audio como hace un navegador GPS,
     * así la música (radio, Spotify…) baja de volumen o se para mientras suena el pitido.
     */
    private fun playPriority(tone: Int, volume: Int) {
        val am = getApplication<Application>().getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        val pause = _state.value.opt(AlertKey.RADAR_DUCK) == 1
        val gain = if (pause) android.media.AudioManager.AUDIOFOCUS_GAIN_TRANSIENT else android.media.AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
        val i = tone.coerceIn(0, AlertOptions.toneIds.size - 1)
        val holdMs = AlertOptions.toneMs[i].toLong() + 400
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                val req = android.media.AudioFocusRequest.Builder(gain)
                    .setAudioAttributes(
                        android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build(),
                    ).build()
                am.requestAudioFocus(req)
                playTone(tone, volume)
                viewModelScope.launch { delay(holdMs); try { am.abandonAudioFocusRequest(req) } catch (_: Exception) { } }
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(null, android.media.AudioManager.STREAM_MUSIC, gain)
                playTone(tone, volume)
                @Suppress("DEPRECATION")
                viewModelScope.launch { delay(holdMs); try { am.abandonAudioFocus(null) } catch (_: Exception) { } }
            }
        } catch (_: Exception) { playTone(tone, volume) }
    }

    private fun playTone(tone: Int, volume: Int) {
        try {
            val level = AlertOptions.volumeLevels.getOrElse(volume) { 100 }
            val t = tones.getOrPut(level) { android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, level) }
            val i = tone.coerceIn(0, AlertOptions.toneIds.size - 1)
            t.startTone(AlertOptions.toneIds[i], AlertOptions.toneMs[i])
        } catch (_: Exception) { }
    }

    /** Botón PROBAR de los ajustes. */
    fun testSound(radar: Boolean) {
        val st = _state.value
        if (radar) playPriority(st.opt(AlertKey.RADAR_TONE), st.opt(AlertKey.RADAR_VOL))
        else playTone(st.opt(AlertKey.LIMIT_TONE), st.opt(AlertKey.LIMIT_VOL))
    }

    private fun beep() = testSound(radar = false)

    private var wasOver = false
    private var lastBeepMs = 0L

    /** Suena al pasarte del límite y, si sigues pasado, cada el intervalo elegido. */
    private fun checkOverspeed() {
        val st = _state.value
        val over = st.overLimit()
        val now = System.currentTimeMillis()
        val every = AlertOptions.limitRepeatMs.getOrElse(st.opt(AlertKey.LIMIT_REPEAT)) { 15_000 }
        if (over && st.limitSound && (!wasOver || now - lastBeepMs >= every)) {
            lastBeepMs = now
            playTone(st.opt(AlertKey.LIMIT_TONE), st.opt(AlertKey.LIMIT_VOL))
        }
        wasOver = over
    }

    private var radarSince = 0L
    private var lastRadarBeep = 0L

    /** Suena al entrar en la distancia de aviso de un radar y, según el ajuste, se repite. */
    private fun checkRadar() {
        val st = _state.value
        val d = st.radarM
        if (d == null || !st.radarAlert()) { radarSince = 0; return }
        val now = System.currentTimeMillis()
        val first = radarSince == 0L
        if (first) radarSince = now
        if (st.opt(AlertKey.RADAR_SOUND) == 0) return
        val maxM = AlertOptions.radarDistances.getOrElse(st.opt(AlertKey.RADAR_DIST)) { 1000 }.toDouble()
        val every = when (st.opt(AlertKey.RADAR_REPEAT)) {
            0 -> Long.MAX_VALUE
            1 -> 5_000L
            2 -> 10_000L
            3 -> 20_000L
            else -> (1_000 + (d / maxM).coerceIn(0.0, 1.0) * 7_000).toLong()   // más seguido cuanto más cerca
        }
        if (first || now - lastRadarBeep >= every) {
            lastRadarBeep = now
            playPriority(st.opt(AlertKey.RADAR_TONE), st.opt(AlertKey.RADAR_VOL))
        }
    }

    // ------------------------------------------------------------ Panel personalizable

    fun setDashboard(ids: List<String>) {
        prefs.edit().putString("widgets", ids.joinToString(",")).apply()
        _state.update { it.copy(dashboard = ids) }
    }

    // Formato guardado: "id@x@y@tamaño,id@x@y@tamaño;…" (una página por ";")
    private fun loadPages(): List<List<GaugeItem>> =
        prefs.getString("layout", null)
            ?.split(";")
            ?.map { pg ->
                pg.split(",").mapNotNull { g ->
                    val f = g.split("@")
                    if (f.size == 4 && f[0] in Params.byId) {
                        GaugeItem(f[0], f[1].toFloatOrNull() ?: 0.5f, f[2].toFloatOrNull() ?: 0.5f, f[3].toFloatOrNull() ?: 0.6f)
                    } else null
                }
            }
            ?.filter { it.isNotEmpty() }
            ?.takeIf { it.isNotEmpty() }
            ?: Params.defaultPages.map { defaultLayout(it) }

    fun setPages(pages: List<List<GaugeItem>>) {
        val clean = pages.filter { it.isNotEmpty() }.ifEmpty { Params.defaultPages.map { defaultLayout(it) } }
        prefs.edit().putString(
            "layout",
            clean.joinToString(";") { pg -> pg.joinToString(",") { "${it.id}@${it.x}@${it.y}@${it.size}" } },
        ).apply()
        _state.update { it.copy(pages = clean, page = it.page.coerceIn(0, clean.size - 1)) }
    }

    fun pageName(st: UiState, i: Int) = st.pageNames.getOrNull(i)?.takeIf { it.isNotBlank() } ?: "Página ${i + 1}"

    private fun saveNames(names: List<String>) {
        prefs.edit().putString("pageNames", names.joinToString("|") { it.replace("|", "/") }).apply()
        _state.update { it.copy(pageNames = names) }
    }

    fun renamePage(i: Int, name: String) {
        val st = _state.value
        val names = List(st.pages.size) { j -> if (j == i) name.take(24) else st.pageNames.getOrElse(j) { "" } }
        saveNames(names)
    }

    fun addPage() {
        val st = _state.value
        setPages(st.pages + listOf(defaultLayout(listOf("coolant", "rpm", "oil"))))
        saveNames(List(st.pages.size) { j -> st.pageNames.getOrElse(j) { "" } } + "Página ${st.pages.size + 1}")
    }

    fun removePage(i: Int) {
        val st = _state.value
        if (st.pages.size <= 1) return
        setPages(st.pages.filterIndexed { j, _ -> j != i })
        saveNames(List(st.pages.size) { j -> st.pageNames.getOrElse(j) { "" } }.filterIndexed { j, _ -> j != i })
    }

    fun resetPages() {
        setPages(Params.defaultPages.map { defaultLayout(it) })
        saveNames(Params.defaultPageNames)
    }

    /** Guarda la página actual tal como ha quedado al moverla en el editor. */
    fun setCurrentPage(items: List<GaugeItem>) {
        val st = _state.value
        setPages(st.pages.mapIndexed { i, pg -> if (i == st.page) items else pg })
    }

    fun resetCurrentPage() {
        val st = _state.value
        val def = Params.defaultPages[st.page % Params.defaultPages.size]
        setCurrentPage(defaultLayout(def))
    }

    // ------------------------------------------------------------ Logo propio en el reloj principal

    private val logoFile get() = java.io.File(getApplication<Application>().filesDir, "logo.png")

    private fun loadLogo(): androidx.compose.ui.graphics.ImageBitmap? = try {
        if (logoFile.exists()) android.graphics.BitmapFactory.decodeFile(logoFile.path)?.asImageBitmap() else null
    } catch (_: Exception) { null }

    /** Copia la imagen elegida, la reduce y la guarda dentro de la app. */
    fun setLogo(uri: android.net.Uri) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val app = getApplication<Application>()
                val src = app.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it) } ?: return@launch
                val scale = minOf(1f, 400f / maxOf(src.width, src.height))
                val bmp = android.graphics.Bitmap.createScaledBitmap(src, (src.width * scale).toInt().coerceAtLeast(1), (src.height * scale).toInt().coerceAtLeast(1), true)
                logoFile.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
                _state.update { it.copy(logo = bmp.asImageBitmap()) }
            } catch (ex: Exception) {
                log("No se pudo cargar la imagen: ${ex.message}")
            }
        }
    }

    fun clearLogo() {
        logoFile.delete()
        _state.update { it.copy(logo = null) }
    }

    /** ANTERIOR / SIGUIENTE: cambia de página de relojes (da la vuelta). */
    fun movePage(delta: Int) = _state.update {
        val n = it.pages.size
        it.copy(page = ((it.page + delta) % n + n) % n)
    }

    /** Flechas de cada reloj: cambia el dato de ese reloj al anterior o siguiente de la lista. */
    fun cycleGauge(slot: Int, dir: Int) {
        val st = _state.value
        val cur = st.pages.getOrNull(st.page) ?: return
        val item = cur.getOrNull(slot) ?: return
        val ids = Params.all.map { it.id }
        val idx = ids.indexOf(item.id).coerceAtLeast(0)
        val next = ids[((idx + dir) % ids.size + ids.size) % ids.size]
        setCurrentPage(cur.mapIndexed { j, g -> if (j == slot) g.copy(id = next) else g })
    }

    fun setRings(main: String, center: String, second: String, third: String) {
        prefs.edit().putString("ringMain", main).putString("ringCenter", center)
            .putString("ringSecond", second).putString("ringThird", third).apply()
        _state.update { it.copy(ringMain = main, ringCenter = center, ringSecond = second, ringThird = third) }
    }

    // ------------------------------------------------------------ Temperatura del aceite
    //
    // El PID estándar 015C casi nunca lo da un TDI de VAG de 2011. Se prueba en este orden:
    //  1) 015C estándar   2) 22F45C (el mismo dato pedido por UDS a la centralita de motor)
    //  3) un identificador propio que se puede escribir en Ajustes (22XXXX)

    /** Temperatura del aceite: FIJA en 22 11 BE, décimas de kelvin (comprobada con Autel). No se cambia nunca. */
    private val oilDid: Int = OIL_DID_FIXED
    private val oilFormula = OIL_FORMULA

    fun setOilCustom(did: String, formula: Int) {
        val clean = did.uppercase().filter { it in "0123456789ABCDEF" }.take(4)
        prefs.edit().putString("oilDid", clean).putInt("oilFormula", formula).apply()
        _state.update { it.copy(oilCustomDid = clean, oilCustomFormula = formula) }
    }

    fun retestOil() {
        val e = elm ?: return _state.update { it.copy(oilTestMessage = "Conecta primero con el coche") }
        viewModelScope.launch {
            _state.update { it.copy(oilTestMessage = "Probando…") }
            try { detectOil(e) } catch (ex: Exception) { disconnect("Error: ${ex.message}") }
        }
    }

    /** Al conectar: comprueba que la centralita contesta al 22 11 BE. El identificador no cambia aunque falle. */
    private suspend fun detectOil(e: Elm327) {
        val t = Elm327.mode22(e.send("22%04X".format(oilDid), 2000), oilDid)?.let { oilCalc(it, oilFormula) }
        if (t != null) log("Temperatura del aceite (22 11 BE): %.1f °C".format(t))
        _state.update {
            it.copy(
                oilSource = OIL_SOURCE,
                oilTestMessage = if (t != null) "Leyendo: %.1f °C".format(t) else "La centralita no ha contestado ahora; se sigue pidiendo en cada lectura",
            )
        }
    }

    // ---- Rastreo de la temperatura del aceite
    //
    // Corre en segundo plano (puedes salir de la app), no para el panel, se pausa si el coche se mueve y,
    // si se interrumpe, BUSCAR continúa por donde iba. Solo lee datos (servicio 22): no cambia nada del coche.

    private var scanJob: Job? = null
    private var scanPos = 0
    private var scanAnswered = 0
    private val scanFound = mutableListOf<OilCandidate>()

    /** Orden del rastreo: primero lo más probable en VAG, después rangos más amplios. */
    private val scanOrder: List<Int> by lazy {
        (0x2000..0x20FF) + (0x1000..0x1FFF) + (0xF400..0xF4FF) + (0x2100..0x2FFF) + (0x0100..0x0FFF) + (0xF100..0xF3FF)
    }

    /**
     * Pregunta cuatro identificadores UDS que casi toda centralita VAG contesta (bastidor, referencias…).
     * Devuelve cuántos contestaron, aunque sea con un "no soportado": si ninguno, rastrear no sirve de nada.
     */
    private suspend fun probeUds(e: Elm327): Int {
        var answered = 0
        for (did in listOf(0xF190, 0xF187, 0xF18C, 0xF40D)) {
            val r = e.send("22%04X".format(did), 1500)
            val ms = Elm327.messages(r)
            val ok = ms.any { it.size >= 3 && it[0] == 0x62 } ||
                ms.any { it.size >= 3 && it[0] == 0x7F && it[1] == 0x22 }
            if (ok) answered++
            log("Sonda 22%04X: %s".format(did, r.replace("\n", " ").ifEmpty { "sin respuesta" }))
        }
        return answered
    }

    /** Qué fórmulas probar según los bytes que devuelve el identificador. */
    private fun oilFormulasFor(size: Int): List<Int> = when {
        size == 1 -> listOf(0, 4, 3)
        size == 2 -> listOf(1, 5)
        size in 3..8 -> listOf(1, 5, 0)
        else -> emptyList()
    }

    fun scanOil() {
        val e = elm ?: return _state.update { it.copy(oilTestMessage = "Conecta primero con el coche") }
        if (_state.value.oilScanProgress != null || _state.value.boostScanProgress != null) return
        val total = scanOrder.size
        scanJob = viewModelScope.launch {
            if (scanPos <= 0 || scanPos >= total) { scanPos = 0; scanFound.clear(); scanAnswered = 0 }
            _state.update {
                it.copy(
                    oilScanProgress = scanPos / total.toFloat(), oilCandidates = scanFound.take(40).toList(),
                    oilTestMessage = if (scanPos > 0) "Continuando el rastreo…" else "Probando la centralita…",
                )
            }
            try {
                if (scanPos == 0 && probeUds(e) == 0) {
                    _state.update {
                        it.copy(
                            oilScanProgress = null,
                            oilTestMessage = "La centralita de motor no contesta a lecturas UDS (22). Rastrear aquí no sirve: " +
                                "el dato debe de estar en otro módulo. Mira el registro en Ajustes.",
                        )
                    }
                    return@launch
                }
                val coolant = Elm327.mode01(e.send("0105"), 0x05)?.let { it[0] - 40.0 } ?: _state.value.values["coolant"]
                e.send("ATST 20")   // espera menos a los identificadores que no existen
                while (elm === e && scanPos < total && _state.value.oilScanProgress != null) {
                    // En pausa mientras el coche se mueve
                    while (elm === e && _state.value.oilScanProgress != null && (_state.value.values["speed"] ?: 0.0) > 3.0) {
                        _state.update { it.copy(oilTestMessage = "En pausa: el coche se mueve. Sigue al parar.") }
                        delay(1500)
                    }
                    if (elm !== e || _state.value.oilScanProgress == null) break
                    val did = scanOrder[scanPos]
                    val data = Elm327.mode22(e.send("22%04X".format(did), 500), did)
                    if (data != null) {
                        scanAnswered++
                        for (f in oilFormulasFor(data.size)) {
                            val t = oilCalc(data, f) ?: continue
                            val near = coolant == null || kotlin.math.abs(t - coolant) <= 25
                            if (t in 15.0..150.0 && near && did != 0xF405) {
                                scanFound += OilCandidate(did, f, t)
                                log("Candidato 22%04X = %.1f °C (fórmula %d)".format(did, t, f))
                                break
                            }
                        }
                    }
                    scanPos++
                    if (scanPos % 16 == 0 || data != null) {
                        _state.update {
                            it.copy(
                                oilScanProgress = scanPos / total.toFloat(), oilCandidates = scanFound.take(40).toList(),
                                oilTestMessage = "Rastreando… respondieron $scanAnswered identificadores",
                            )
                        }
                    }
                }
                if (elm === e) { try { e.send("ATST 32") } catch (_: Exception) { } }
                val finished = scanPos >= total
                val percent = (scanPos * 100L / total).toInt()
                if (finished) scanPos = 0
                _state.update {
                    it.copy(
                        oilScanProgress = null, oilCandidates = scanFound.take(40).toList(),
                        oilTestMessage = when {
                            scanFound.isNotEmpty() -> "Elige el que coincida con Carly"
                            finished -> "Rastreo completo: no se encontró ninguno ($scanAnswered respondieron)."
                            else -> "Rastreo parado al $percent %. BUSCAR continúa desde ahí."
                        },
                    )
                }
            } catch (ex: Exception) {
                _state.update { it.copy(oilScanProgress = null) }
                if (elm === e) disconnect("Error rastreando: ${ex.message}")
            }
        }
    }

    fun stopOilScan() = _state.update { it.copy(oilScanProgress = null) }

    @Volatile private var watchCand = false
    private var candRot = 0

    /** Con Ajustes abierto, lee en vivo los candidatos para ver cuál se comporta como el aceite. */
    fun watchCandidates(on: Boolean) {
        watchCand = on
        if (!on) _state.update { it.copy(candLive = emptyMap()) }
    }

    /** El aceite está fijo en 22 11 BE: elegir otro candidato ya no cambia nada. */
    @Suppress("UNUSED_PARAMETER")
    fun useOilCandidate(c: OilCandidate) { }

    /**
     * Fórmulas: 0 = A−40 · 1 = (A·256+B−2731)/10 (décimas de kelvin) · 2 = (A·256+B)/10−273,1 ·
     * 3 = A directo en °C · 4 = A·0,75−48 (habitual en VAG) · 5 = (A·256+B)/10 con signo (décimas de °C)
     */
    private fun oilCalc(d: IntArray, f: Int): Double? = when (f) {
        0 -> if (d.isNotEmpty()) d[0] - 40.0 else null
        1 -> if (d.size >= 2) (d[0] * 256 + d[1] - 2731) / 10.0 else null
        2 -> if (d.size >= 2) (d[0] * 256 + d[1]) / 10.0 - 273.1 else null
        3 -> if (d.isNotEmpty()) d[0].toDouble() else null
        4 -> if (d.isNotEmpty()) d[0] * 0.75 - 48.0 else null
        5 -> if (d.size >= 2) (d[0] * 256 + d[1]).toShort().toInt() / 10.0 else null
        else -> null
    }

    fun setShiftRpm(rpm: Int) {
        val v = rpm.coerceIn(2000, 5000)
        prefs.edit().putInt("shiftRpm", v).apply()
        _state.update { it.copy(shiftRpm = v) }
    }

    /** Guarda valores nuevos, máximos e historial (60 muestras) de cada dato. */
    fun setFocus(ids: List<String>) = _state.update { it.copy(focus = ids) }

    fun resetTrip() = _state.update { it.copy(trip = Trip()) }

    fun setAccelMode(m: AccelMode) = _state.update { it.copy(accel = it.accel.copy(mode = m, state = AccelState.PARADO, resultS = null)) }

    /** Deja el cronómetro esperando la salida. */
    fun armAccel() = _state.update { it.copy(accel = it.accel.copy(state = AccelState.PREPARADO, resultS = null)) }

    fun cancelAccel() = _state.update { it.copy(accel = it.accel.copy(state = AccelState.PARADO)) }

    private var lastSpeed: Double? = null
    private var lastSpeedMs = 0L

    /** Viaje y cronómetro: se actualizan con cada lectura nueva de velocidad. */
    private fun onSpeed(s: UiState, v: Double, fuelRate: Double?): UiState {
        val now = System.currentTimeMillis()
        val pv = lastSpeed
        val pt = lastSpeedMs
        lastSpeed = v; lastSpeedMs = now
        if (pv == null || now - pt > 3000) return s
        val dt = (now - pt) / 1000.0
        // Viaje
        val t = s.trip
        val mid = (pv + v) / 2
        val trip = t.copy(
            distanceKm = t.distanceKm + mid * dt / 3600,
            movingSeconds = t.movingSeconds + if (mid > 1) dt else 0.0,
            maxSpeed = maxOf(t.maxSpeed, v),
            fuelLitres = fuelRate?.let { (t.fuelLitres ?: 0.0) + it * dt / 3600 } ?: t.fuelLitres,
        )
        // Cronómetro
        fun cross(target: Double) = pt + ((target - pv) / (v - pv) * (now - pt)).toLong()
        var a = s.accel
        when (a.state) {
            AccelState.PREPARADO -> {
                val m = a.mode
                if (m.from == 0.0 && pv < 0.5 && v >= 0.5) a = a.copy(state = AccelState.MIDIENDO, startMs = pt)
                else if (m.from > 0 && pv < m.from && v >= m.from) a = a.copy(state = AccelState.MIDIENDO, startMs = cross(m.from))
            }
            AccelState.MIDIENDO -> {
                val m = a.mode
                if (v >= m.to && pv < m.to) {
                    val r = (cross(m.to) - a.startMs) / 1000.0
                    val best = a.best[m]
                    a = a.copy(state = AccelState.HECHO, resultS = r, best = if (best == null || r < best) a.best + (m to r) else a.best)
                } else if (v < 0.5 || (m.from > 0 && v < m.from - 5)) {
                    a = a.copy(state = AccelState.PREPARADO)
                }
            }
            else -> {}
        }
        return s.copy(trip = trip, accel = a)
    }

    private fun applyValues(newValues: Map<String, Double>, replace: Boolean = false, hz: Double? = null, fresh: Boolean = true) {
        if (fresh && newValues.isNotEmpty()) lastDataMs = System.currentTimeMillis()
        if ("speed" in newValues) checkOverspeedLater = true
        _state.update { s0 ->
            val s = newValues["speed"]?.let { onSpeed(s0, it, newValues["fuelrate"] ?: s0.values["fuelrate"]) } ?: s0
            val peaks = s.peaks.toMutableMap()
            val hist = s.history.toMutableMap()
            newValues.forEach { (k, v) ->
                if (v > (peaks[k] ?: Double.NEGATIVE_INFINITY)) peaks[k] = v
                hist[k] = ((hist[k] ?: emptyList()) + v.toFloat()).takeLast(HISTORY)
            }
            s.copy(
                values = if (replace) newValues else s.values + newValues,
                peaks = peaks, history = hist, refreshHz = hz ?: s.refreshHz,
            )
        }
        if (checkOverspeedLater) { checkOverspeedLater = false; checkOverspeed() }
    }

    private var checkOverspeedLater = false

    fun setColumns(n: Int) {
        prefs.edit().putInt("columnas", n).apply()
        _state.update { it.copy(columns = n) }
    }

    fun setTraffic(on: Boolean) {
        elm?.logTraffic = on
        _state.update { it.copy(traffic = on) }
    }

    fun resetPeaks() = _state.update { it.copy(peaks = emptyMap()) }

    // ------------------------------------------------------------ Conexión

    /** Si está activa, la app conecta sola y vuelve a conectar cuando se pierde. Solo la apaga el botón DESCONECTAR. */
    private var autoReconnect = prefs.getBoolean("autoReconnect", true)
    private var lastDataMs = 0L
    /** Datos de consumo que el coche dice dar pero no contesta (se saltan). */
    private val fuelDead = mutableSetOf<Int>()
    private var fuelMiss = 0

    // ------------------------------------------------------------ Otras centralitas

    private var vagBus: VagBus? = null
    private var autoAllDone = false
    private var liveJob: Job? = null
    private val tyres = TyreMonitor(prefs.getString("tyreBase", null))
    private var lastTyreMs = 0L

    // Va después de las propiedades de arriba (en Kotlin se inicializan en orden)
    init { loadModules() }

    /** ABS con las 4 ruedas por TP 2.0: dirección del grupo de medida (guardado de la última búsqueda). */
    /**
     * Las centralitas de su coche siempre con su forma de hablar conocida: aunque una búsqueda las haya dado por
     * muertas (NONE), se vuelven a intentar (si no, LEER AVERÍAS ni lo probaba y salía «no contesta» sin preguntar).
     */
    private fun herCarMerge(found: List<ModuleState>): List<ModuleState> {
        val by = found.associateBy { it.addr }
        return VagModules.herCar().map { d ->
            if (d.proto == VagProto.NONE) return@map d
            by[d.addr]?.takeIf { it.proto != VagProto.NONE }?.let { f -> f.copy(wheelGroup = f.wheelGroup ?: d.wheelGroup, tp = f.tp ?: d.tp) } ?: d.copy(dtcs = by[d.addr]?.dtcs, message = by[d.addr]?.message.orEmpty().takeIf { it == "No contesta" }.orEmpty())
        }
    }

    private fun wheelGroup(): Int? = herCarMerge(_state.value.modules).firstOrNull { it.addr == 0x03 && it.proto == VagProto.TP20 }?.wheelGroup

    private fun loadModules() {
        val list = (prefs.getString("vagModules", "") ?: "").split(",").mapNotNull { t ->
            val f = t.split(":")
            val a = f.getOrNull(0)?.toIntOrNull(16) ?: return@mapNotNull null
            if (a < 0x100 && VagModules.byAddr(a) == null) return@mapNotNull null   // las que ya no se buscan (cambio, confort, radio)
            val pr = VagProto.values().firstOrNull { it.name == f.getOrNull(1) } ?: return@mapNotNull null
            val tp = f.getOrNull(4)?.toIntOrNull(16)
            if (tp != null) VagModules.tp[a] = tp
            ModuleState(a, pr, part = f.getOrNull(3).orEmpty(), wheelGroup = f.getOrNull(2)?.toIntOrNull(), tp = tp, name = f.getOrNull(5).orEmpty())
        }.let { saved ->
            // Siempre las de su coche, en su orden (lo guardado solo aporta el texto de la pieza)
            val byAddr = saved.associateBy { it.addr }
            VagModules.herCar().map { d ->
                val sv = byAddr[d.addr]
                if (sv != null && sv.proto != VagProto.NONE && sv.part.isNotBlank()) d.copy(part = sv.part) else d
            }.also { l -> l.forEach { m -> m.tp?.let { t -> VagModules.tp[m.addr] = t } } }
        }
        _state.update {
            it.copy(
                modules = list, tyreAvailable = if (list.isEmpty()) null else list.any { m -> m.addr == 0x03 && m.wheelGroup != null },
                tyreLearn = tyres.learning, tyreCal = tyres.calDate,
            )
        }
    }

    private fun saveModules(list: List<ModuleState>) {
        prefs.edit().putString("vagModules", list.joinToString(",") { m ->
            "%02X:%s:%s:%s:%s:%s".format(
                m.addr, m.proto.name, m.wheelGroup?.toString() ?: "", m.part.replace(",", " ").replace(":", " "),
                m.tp?.let { "%02X".format(it) } ?: "", m.name.replace(",", " ").replace(":", " "),
            )
        }).apply()
    }

    /** Hace algo con las otras centralitas parando un momento los relojes y dejando el adaptador como estaba. */
    private fun withBus(busyText: String, block: suspend (VagBus) -> Unit) {
        val e = elm ?: return _state.update { it.copy(modMessage = "Conecta primero con el coche") }
        if (_state.value.modBusy || _state.value.dtcBusy || _state.value.sniffOn || _state.value.bridgeOn) return
        stopLive()
        viewModelScope.launch {
            _state.update { it.copy(modBusy = true, modMessage = busyText) }
            pollJob?.cancelAndJoin(); pollJob = null
            // El mismo bus que lee las ruedas en segundo plano: si el canal del ABS sigue abierto se aprovecha
            // (abrir otro a la vez lo rechaza el ABS)
            val bus = vagBus ?: VagBus(e) { log(it) }.also { vagBus = it }
            bus.resetFailures()
            // Mientras se habla con las otras centralitas se apunta todo en el registro, para poder ver qué contestan,
            // y además en un archivo en Descargas que se puede compartir
            try {
                val name = "obd-centralitas-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".txt"
                val (o, where, uri) = newDownload(name)
                busUri = uri
                busFile = o.bufferedWriter(Charsets.UTF_8).also { it.write("# OBD Ibiza · $busyText · ${Date()}\n") }
                _state.update { it.copy(modFile = where) }
            } catch (_: Exception) { busFile = null }
            e.logTraffic = true
            try {
                block(bus)
            } catch (ex: Exception) {
                log("Otras centralitas: ${ex.message}")
                _state.update { it.copy(modMessage = "Error hablando con las centralitas: ${ex.message ?: ex.javaClass.simpleName}") }
            } finally {
                try { bus.closeAll(); bus.restore() } catch (_: Exception) { }
                busFile?.let { w -> try { synchronized(w) { w.flush(); w.close() } } catch (_: Exception) { } }
                busFile = null
                e.logTraffic = _state.value.traffic
                _state.update { it.copy(modBusy = false) }
                if (elm === e && pollJob == null && _state.value.conn == Conn.CONECTADO) {
                    lastDataMs = System.currentTimeMillis()
                    startPolling()
                }
            }
        }
    }

    /** Busca qué centralitas contestan, en qué protocolo, y lee sus averías. Solo lee. */
    /** [full] = probar todas las direcciones TP 2.0; si no, solo las cinco que tiene su coche (mucho más rápido). */
    fun scanModules(full: Boolean = false) = withBus("Buscando centralitas…") { bus ->
        val out = linkedMapOf<Int, ModuleState>()
        val whyOf = mutableMapOf<Int, String>()
        fun ordered(): List<ModuleState> =
            VagModules.all.mapNotNull { out[it.addr] } + out.values.filter { VagModules.byAddr(it.addr) == null }
        // 1) Las que hablan UDS (airbag, cuadro…), por sus direcciones CAN de VAG
        for ((k, m) in VagModules.all.withIndex()) {
            _state.update { it.copy(modMessage = "Buscando ${m.name} (UDS)… ${k + 1} de ${VagModules.all.size}") }
            bus.why = ""
            val uds = bus.udsProbe(m)
            if (uds != null) {
                out[m.addr] = ModuleState(m.addr, VagProto.UDS, part = uds, dtcs = bus.udsDtcs(m))
                log("Centralita ${m.label}: UDS · $uds")
                _state.update { it.copy(modules = ordered()) }
            } else whyOf[m.addr] = bus.why
        }
        // 2) Las de TP 2.0: se prueban las direcciones lógicas (no son las de VCDS) y cada una dice quién es
        VagModules.tp.clear()
        val probes = if (full) VagModules.tpProbeList else VagModules.tpKnown
        for ((k, l) in probes.withIndex()) {
            val found = out.values.count { it.proto == VagProto.TP20 }
            _state.update { it.copy(modMessage = "Buscando centralitas TP 2.0… ${k + 1} de ${probes.size} · encontradas $found") }
            bus.why = ""
            if (!bus.tpFind(l)) continue
            // Primero lo corto y seguro (datos y averías); la identificación, que es larga, al final
            val probe = VagModule(0x100 + l, "")
            VagModules.tp[probe.addr] = l
            var wg: Int? = null
            var group1 = ""
            for (g in 1..8) {
                val v = bus.tpMeasure(probe, g) ?: continue
                if (group1.isEmpty()) group1 = "Grupo $g: " + v.joinToString(" · ") { x -> (x.text + " " + x.unit).trim() }
                if (Kwp.wheelSpeeds(v) != null) { wg = g; break }
            }
            val dtcs = bus.tpDtcs(probe)
            val ident = bus.tpIdentify(l)
            VagModules.tp.remove(probe.addr)
            bus.closeAll()
            // Quién es: por lo que dice de sí misma o, si no lo dice, el ABS es el que da las cuatro ruedas
            var addr = ident?.let { VagModules.classify(it) }?.takeIf { it !in out }
            if (addr == null && wg != null && 0x03 !in out) addr = 0x03
            if (addr == null) VagModules.tpGuess[l]?.takeIf { it !in out }?.let { addr = it }
            val key = addr ?: (0x100 + l)
            VagModules.tp[key] = l
            val st0 = ModuleState(key, VagProto.TP20, tp = l, name = ident.orEmpty())
            val m = VagModules.forState(st0)
            val shown = ident ?: group1.ifBlank { "sin identificación" }
            out[key] = st0.copy(part = if (shown.length > 60) shown.take(60) + "…" else shown, dtcs = dtcs, wheelGroup = if (key == 0x03) wg else null)
            log("Centralita TP 2.0 %02X → ${m.label}: ".format(l) + (ident ?: "sin identificación") + (dtcs?.let { " · ${it.size} averías" } ?: ""))
            _state.update { it.copy(modules = ordered()) }
        }
        // 3) ABS y dirección asistida por TP 1.6 (SAE J3054)
        for ((addr, tap) in VagModules.tp16) {
            if (addr in out) continue
            val m = VagModules.byAddr(addr) ?: continue
            _state.update { it.copy(modMessage = "Probando ${m.name} por TP 1.6…") }
            bus.why = ""
            val part = bus.tpProbe(m)
            if (part == null) { whyOf[addr] = bus.why; log("Centralita ${m.label} por TP 1.6 (%02X): ".format(tap) + bus.why); continue }
            var wg: Int? = null
            var group1 = ""
            for (g in 1..8) {
                val v = bus.tpMeasure(m, g) ?: continue
                if (group1.isEmpty()) group1 = "Grupo $g: " + v.joinToString(" · ") { x -> (x.text + " " + x.unit).trim() }
                if (addr == 0x03 && Kwp.wheelSpeeds(v) != null) { wg = g; break }
            }
            val dtcs = bus.tpDtcs(m)
            bus.closeAll()
            val shown = "TP 1.6 · " + (part.takeIf { it != "—" } ?: group1.ifBlank { "conectada" })
            out[addr] = ModuleState(addr, VagProto.TP20, part = if (shown.length > 60) shown.take(60) + "…" else shown, dtcs = dtcs, wheelGroup = wg)
            log("Centralita ${m.label}: TP 1.6 · $shown" + (dtcs?.let { " · ${it.size} averías" } ?: ""))
            _state.update { it.copy(modules = ordered()) }
        }
        // 4) Las de la lista que no han contestado de ninguna forma
        for (m in VagModules.all) if (m.addr !in out) {
            val msg = if (m.addr in VagModules.tpShortOnly)
                whyOf[m.addr].orEmpty().takeIf { it.startsWith("TP1.6") } ?: "Contesta solo en modo reducido, también a Car Scanner: falta ver cómo entra el Autel"
            else listOf(whyOf[m.addr].orEmpty(), "TP 2.0: no se ha encontrado").filter { it.isNotBlank() }.joinToString(" · ")
            out[m.addr] = ModuleState(m.addr, VagProto.NONE, message = msg)
        }
        val list = herCarMerge(ordered())
        saveModules(list)
        val found = list.count { it.proto != VagProto.NONE }
        val faults = list.sumOf { m -> m.dtcs?.count { VagDtcText.explain(it.code) == null } ?: 0 }
        _state.update {
            it.copy(
                modules = list, tyreAvailable = list.any { m -> m.addr == 0x03 && m.wheelGroup != null },
                modMessage = "$found centralitas contestan · " + if (faults == 0) "sin averías" else "$faults averías",
            )
        }
    }

    /** Lee los grupos de medida 1–16 de una centralita TP 2.0 y los enseña en su fila. */
    /** Vuelve a probar solo una centralita TP 1.6 (la dirección asistida a veces no contesta a la primera). */
    fun retryTp16(addr: Int) = withBus("Probando otra vez la centralita…") { bus ->
        val m = VagModules.byAddr(addr) ?: return@withBus
        if (addr !in VagModules.tp16) return@withBus
        _state.update { it.copy(modMessage = "Probando ${m.name} por TP 1.6…") }
        bus.why = ""
        val part = bus.tpProbe(m)
        val ns = if (part == null) {
            log("Centralita ${m.label} por TP 1.6: " + bus.why)
            ModuleState(addr, VagProto.NONE, message = bus.why.ifBlank { "No contesta" })
        } else {
            var wg: Int? = null
            var group1 = ""
            for (g in 1..8) {
                val v = bus.tpMeasure(m, g) ?: continue
                if (group1.isEmpty()) group1 = "Grupo $g: " + v.joinToString(" · ") { x -> (x.text + " " + x.unit).trim() }
                if (addr == 0x03 && Kwp.wheelSpeeds(v) != null) { wg = g; break }
            }
            val dtcs = bus.tpDtcs(m)
            bus.closeAll()
            val shown = "TP 1.6 · " + (part.takeIf { it != "—" } ?: group1.ifBlank { "conectada" })
            log("Centralita ${m.label}: $shown" + (dtcs?.let { " · ${it.size} averías" } ?: ""))
            ModuleState(addr, VagProto.TP20, part = if (shown.length > 60) shown.take(60) + "…" else shown, dtcs = dtcs, wheelGroup = wg)
        }
        val list = herCarMerge(_state.value.modules.map { if (it.addr == addr) ns else it })
        saveModules(list)
        _state.update {
            it.copy(
                modules = list, tyreAvailable = list.any { x -> x.addr == 0x03 && x.wheelGroup != null },
                modMessage = if (ns.proto == VagProto.NONE) "${m.name}: sigue sin contestar" else "${m.name}: conectada",
            )
        }
    }

    fun readModuleGroups(addr: Int) = withBus("Leyendo datos de la centralita…") { bus ->
        val st = _state.value.modules.firstOrNull { it.addr == addr && it.proto == VagProto.TP20 } ?: return@withBus
        val m = VagModules.forState(st)
        val lines = mutableListOf<String>()
        for (g in 1..16) {
            _state.update { it.copy(modMessage = "Leyendo datos de ${m.name}… grupo $g de 16") }
            val v = bus.tpMeasure(m, g) ?: continue
            lines += "Grupo %03d: ".format(g) + v.joinToString(" · ") { x -> (x.text + " " + x.unit).trim() }
            _state.update { it.copy(modGroups = it.modGroups + (addr to lines.toList())) }
        }
        if (lines.isEmpty()) lines += "No da datos de medida"
        _state.update { it.copy(modGroups = it.modGroups + (addr to lines.toList()), modMessage = "${m.name}: ${lines.size} grupos leídos") }
    }

    /** Vuelve a leer las averías de las centralitas que contestaron. */
    fun readModuleDtcs() = withBus("Leyendo averías de las centralitas…") { bus ->
        val list = herCarMerge(_state.value.modules).map { st ->
            val m = VagModules.forState(st)
            _state.update { it.copy(modMessage = "Leyendo ${m.name}…") }
            val d = when (st.proto) { VagProto.UDS -> bus.udsDtcs(m); VagProto.TP20 -> bus.tpDtcs(m).also { bus.closeAll() }; VagProto.NONE -> null }
            log("Averías ${m.label}: " + (d?.let { "${it.size}" } ?: "no contesta"))
            st.copy(dtcs = d, message = if (d == null) (if (st.proto == VagProto.NONE && st.message.isNotBlank()) st.message else "No contesta") else "")
        }
        val real = list.sumOf { m -> m.dtcs?.count { VagDtcText.explain(it.code) == null } ?: 0 }
        _state.update { it.copy(modules = list, modMessage = "Leídas · " + if (real == 0) "sin averías en las centralitas" else "$real averías en las centralitas") }
    }

    /** LEER AVERÍAS: primero el motor y después todas las centralitas (si no se han buscado nunca, se buscan). */
    fun readAllDtcs(thenPoll: Boolean = false) {
        val e = elm ?: return setDtcMessage("Conecta primero con el coche")
        viewModelScope.launch {
            readDtcs()
            delay(400)
            while (_state.value.dtcBusy) { lastDataMs = System.currentTimeMillis(); delay(300) }
            if (elm !== e) return@launch
            readModuleDtcs()
            delay(400)
            while (_state.value.modBusy) delay(300)
            // Al abrir la app: ahora sí, los relojes (si la lectura no los ha arrancado ya)
            if (thenPoll && elm === e && pollJob == null && _state.value.conn == Conn.CONECTADO) {
                lastDataMs = System.currentTimeMillis()
                _state.update { it.copy(status = "Conectado · ${it.protocol}") }
                startPolling()
            }
        }
    }

    /** BORRAR TODAS LAS AVERÍAS: motor y todas las centralitas que contestan; después vuelve a leer todo. */
    fun clearAllDtcs() {
        val e = elm ?: return setDtcMessage("Conecta primero con el coche")
        viewModelScope.launch {
            clearDtcs()
            delay(400)
            while (_state.value.dtcBusy) delay(300)
            if (elm !== e) return@launch
            clearAllModules()
        }
    }

    private fun clearAllModules() = withBus("Borrando averías de todas las centralitas…") { bus ->
        val mods = _state.value.modules.filter { it.proto != VagProto.NONE }
        for (st in mods) {
            val m = VagModules.forState(st)
            _state.update { it.copy(modMessage = "Borrando ${m.name}…") }
            val ok = when (st.proto) { VagProto.UDS -> bus.udsClear(m); VagProto.TP20 -> bus.tpClear(m).also { bus.closeAll() }; VagProto.NONE -> false }
            log("Borrar ${m.name}: " + if (ok) "aceptado" else "no aceptado")
        }
        delay(1200)
        val list = herCarMerge(_state.value.modules).map { st ->
            val m = VagModules.forState(st)
            _state.update { it.copy(modMessage = "Comprobando ${m.name}…") }
            val d = when (st.proto) { VagProto.UDS -> bus.udsDtcs(m); VagProto.TP20 -> bus.tpDtcs(m).also { bus.closeAll() }; VagProto.NONE -> null }
            st.copy(dtcs = d ?: st.dtcs)
        }
        val left = list.sumOf { m -> m.dtcs?.count { VagDtcText.explain(it.code) == null } ?: 0 }
        _state.update { it.copy(modules = list, modMessage = "Borradas · " + if (left == 0) "no queda ninguna avería en las centralitas" else "quedan $left (siguen presentes)") }
    }

    /** Borra las averías de una centralita y comprueba qué queda. */
    fun clearModuleDtcs(addr: Int) = withBus("Borrando averías…") { bus ->
        val st = _state.value.modules.firstOrNull { it.addr == addr } ?: return@withBus
        val m = VagModules.forState(st)
        val ok = when (st.proto) { VagProto.UDS -> bus.udsClear(m); VagProto.TP20 -> bus.tpClear(m); VagProto.NONE -> false }
        delay(1200)
        val left = when (st.proto) { VagProto.UDS -> bus.udsDtcs(m); VagProto.TP20 -> bus.tpDtcs(m); VagProto.NONE -> null }
        val msg = when {
            !ok && left.isNullOrEmpty().not() -> "${m.name}: no aceptó el borrado. Prueba con el contacto puesto y el motor parado."
            left == null -> "${m.name}: borrado enviado, pero no se pudo comprobar."
            left.isEmpty() -> "${m.name}: averías borradas. Comprobado: la memoria está vacía."
            left.all { it.active } -> "${m.name}: borradas las resueltas. Siguen las activas (el fallo sigue presente)."
            else -> "${m.name}: quedan ${left.size} averías."
        }
        log(msg)
        _state.update { s -> s.copy(modMessage = msg, modules = s.modules.map { if (it.addr == addr) it.copy(dtcs = left ?: it.dtcs) else it }) }
    }

    // ---- En vivo (solo en el menú Datos en vivo)

    /** Centralitas que salen en Datos en vivo y qué grupos de medida se leen de cada una. */
    val liveGroupsOf = mapOf(0x03 to (1..6).toList(), 0x17 to (1..3).toList())

    /** Lee en bucle los grupos de medida de una centralita (KWP) mientras está desplegada. Los relojes se paran mientras tanto. */
    fun startLive(addr: Int) {
        val e = elm ?: return
        if (_state.value.modBusy || _state.value.dtcBusy) return
        val m = VagModules.byAddr(addr) ?: return
        val groups = liveGroupsOf[addr] ?: return
        liveJob?.cancel()
        _state.update { it.copy(liveMod = addr, liveGroups = emptyMap(), liveMessage = "Leyendo ${m.name}…") }
        liveJob = viewModelScope.launch {
            pollJob?.cancelAndJoin(); pollJob = null
            val bus = VagBus(e) { log(it) }
            val dead = mutableSetOf<Int>()
            try {
                var k = 0
                while (isActive && _state.value.liveMod == addr) {
                    val todo = groups.filter { it !in dead }
                    if (todo.isEmpty()) { _state.update { it.copy(liveMessage = "No da valores de medida") }; break }
                    val g = todo[k++ % todo.size]
                    val v = bus.tpMeasure(m, g)
                    if (v == null) {
                        // Si un grupo no contesta y ya hay otros, se deja de pedir
                        if (_state.value.liveGroups.isNotEmpty() || k > todo.size * 2) dead += g
                    } else {
                        _state.update { it.copy(liveGroups = it.liveGroups + (g to v), liveMessage = "") }
                    }
                    delay(150)
                }
            } catch (ex: Exception) {
                _state.update { it.copy(liveMessage = "Error: ${ex.message ?: ex.javaClass.simpleName}") }
            } finally {
                try { bus.closeAll(); bus.restore() } catch (_: Exception) { }
                if (elm === e && pollJob == null && _state.value.conn == Conn.CONECTADO && !_state.value.modBusy) {
                    lastDataMs = System.currentTimeMillis()
                    startPolling()
                }
            }
        }
    }

    fun stopLive() {
        if (_state.value.liveMod == null) return
        _state.update { it.copy(liveMod = null) }
        liveJob?.cancel(); liveJob = null
    }

    // ---- Ruedas

    fun setTyreBar(v: Double) {
        val b = (Math.round(v * 10) / 10.0).coerceIn(1.5, 3.5)
        prefs.edit().putFloat("tyreBar", b.toFloat()).apply()
        _state.update { it.copy(tyreBar = b) }
    }

    fun calibrateTyres() {
        val date = java.text.SimpleDateFormat("d MMM yyyy · HH:mm", Locale("es", "ES")).format(java.util.Date())
        tyres.calibrate(date)
        prefs.edit().remove("tyreBase").apply()
        _state.update { it.copy(tyreFlats = emptyList(), tyreDev = null, tyreLearn = 0, tyreCal = date) }
        log("Ruedas: calibrando (conduce unos minutos en recta, entre 30 y 130 km/h)")
    }

    /** Desde el bucle de lectura: cada 2 s lee las cuatro ruedas del ABS (si se puede) y actualiza el aviso. */
    /** Pestaña ABS / ESP abierta: se leen también los demás grupos, por turnos, sin parar los relojes. */
    @Volatile private var absTab = false
    private var absTurn = 0
    private val absDead = mutableSetOf<Int>()
    private val absFails = mutableMapOf<Int, Int>()

    fun setAbsTab(on: Boolean) {
        absTab = on
        if (on) { absDead.clear(); absFails.clear(); _state.update { it.copy(liveMessage = if (it.liveGroups.isEmpty()) "Leyendo ABS / ESP…" else "") } }
    }

    /** El cable se cambia al ABS dentro de una lectura de ruedas: nada más del motor puede ir a la vez. */
    private val absLock = kotlinx.coroutines.sync.Mutex()

    private suspend fun sampleTyres(e: Elm327, st: UiState) {
        if (_state.value.dtcBusy || _state.value.modBusy) return
        if (!absLock.tryLock()) return
        try { sampleTyresLocked(e, st) } finally { absLock.unlock() }
    }

    private suspend fun sampleTyresLocked(e: Elm327, st: UiState) {
        // Siempre que el ABS contesta (para Datos en vivo → Ruedas); el aviso de poco aire solo si está activado
        val wg = wheelGroup() ?: return
        if (st.liveMod != null) return
        val now = System.currentTimeMillis()
        if (now - lastTyreMs < (if (absTab) 700 else 2000)) return
        lastTyreMs = now
        val m = VagModules.byAddr(0x03) ?: return
        val bus = vagBus ?: VagBus(e) { log(it) }.also { vagBus = it }
        // Con la pestaña abierta: rueda, otro grupo, rueda, otro grupo…
        val others = (liveGroupsOf[0x03] ?: emptyList()).filter { it != wg && it !in absDead }
        val g = if (absTab && others.isNotEmpty() && absTurn++ % 2 == 1) others[(absTurn / 2) % others.size] else wg
        try {
            val v = bus.tpMeasure(m, g)
            if (v != null) _state.update { it.copy(liveGroups = it.liveGroups + (g to v), liveMessage = "") }
            else if (g != wg) { val n = (absFails[g] ?: 0) + 1; absFails[g] = n; if (n >= 4) absDead += g }
            // Si el ABS no contesta, no se insiste cada 2 s (frenaría los relojes): se vuelve a probar en 15 s
            else { lastTyreMs = now + 13000; if (absTab) _state.update { it.copy(liveMessage = "El ABS no contesta ahora; se vuelve a probar en unos segundos") } }
            val speeds = if (g == wg) v?.let { Kwp.wheelSpeeds(it) } else null
            if (speeds != null) applyValues(Params.WHEELS.zip(speeds).toMap(), fresh = false)
            if (speeds != null && st.opt(AlertKey.TYRE_ON) == 1) {
                val wasLearning = tyres.base == null
                val before = tyres.samples
                tyres.sample(speeds, st.gpsSpeed)
                if (wasLearning && tyres.base != null) tyres.save()?.let { prefs.edit().putString("tyreBase", it).apply(); log("Ruedas: calibrado") }
                // Mientras aprende, se guarda el progreso cada 10 lecturas buenas (así no se pierde al cerrar la app)
                else if (wasLearning && tyres.samples != before && tyres.samples % 10 == 0) prefs.edit().putString("tyreBase", tyres.saveProgress()).apply()
                val flats = tyres.flats(st.opt(AlertKey.TYRE_SENS))
                _state.update { it.copy(tyreFlats = flats, tyreDev = tyres.deviations()?.toList(), tyreLearn = tyres.learning) }
            }
        } finally {
            // El canal del ABS se queda abierto: la siguiente lectura (2 s después) no tiene que llamar ni saludar
            bus.restore(keepChannel = true)
        }
    }
    private var permissionAskedMs = 0L
    /** Veces seguidas que el adaptador no ha contestado, y cuándo se reinició el puerto USB por última vez. */
    private var muteFails = 0
    private var lastCloseMs = 0L
    private var supervisorJob: Job? = null

    private fun setAutoReconnect(on: Boolean) {
        autoReconnect = on
        prefs.edit().putBoolean("autoReconnect", on).apply()
    }

    /** Botón CONECTAR, apertura de la app o cable enchufado: conecta y mantiene la conexión viva. */
    fun connect() {
        setAutoReconnect(true)
        startKeepAlive()
        tryConnect(quiet = false)
    }

    /** Botón DESCONECTAR: se desconecta y no vuelve a conectar sola hasta que pulses CONECTAR. */
    fun userDisconnect() {
        if (!_state.value.demo) {
            setAutoReconnect(false)
            stopKeepAlive()
        }
        disconnect("Desconectado")
    }

    /** Servicio en primer plano: evita que Android cierre la app al irte a la radio, YouTube o el GPS. */
    private fun startKeepAlive() {
        try {
            val app = getApplication<Application>()
            ContextCompat.startForegroundService(app, Intent(app, ObdService::class.java))
        } catch (ex: Exception) {
            log("No se pudo iniciar el servicio en segundo plano: ${ex.message}")
        }
    }

    private fun stopKeepAlive() {
        try {
            val app = getApplication<Application>()
            app.stopService(Intent(app, ObdService::class.java))
        } catch (_: Exception) { }
    }

    /**
     * Vigila la conexión: si no la hay, la intenta de nuevo sola (cada vez más despacio si el coche está
     * apagado); si el coche deja de contestar, la reinicia.
     */
    fun startSupervisor() {
        if (supervisorJob?.isActive == true) return
        supervisorJob = viewModelScope.launch {
            var failures = 0
            var connectingSince = 0L
            while (isActive) {
                val st = _state.value
                var wait = 2000L
                if (st.conn == Conn.CONECTANDO && !st.demo) {
                    val now = System.currentTimeMillis()
                    if (connectingSince == 0L) connectingSince = now
                    else if (now - connectingSince > CONNECTING_MAX_MS) {
                        connectingSince = 0L
                        event("Se quedó más de 1 minuto conectando: se suelta el USB y se vuelve a abrir")
                        disconnect("Se quedó conectando · se vuelve a abrir el USB")
                    }
                } else connectingSince = 0L
                if (!st.demo) {
                    when (st.conn) {
                        Conn.DESCONECTADO -> {
                            if (autoReconnect) {
                                tryConnect(quiet = failures > 0)
                                failures++
                                wait = if (failures < 6) 3000L else if (failures < 20) 6000L else 15000L
                            }
                        }
                        Conn.CONECTADO -> {
                            failures = 0
                            if (!st.dtcBusy && !st.modBusy && !st.sniffOn && !st.bridgeOn && st.liveMod == null && st.boostScanProgress == null && st.engDumpProgress == null && System.currentTimeMillis() - lastDataMs > NO_DATA_MS) {
                                recoverInPlace()
                            }
                        }
                        Conn.CONECTANDO -> { }
                    }
                }
                delay(wait)
            }
        }
    }

    private fun tryConnect(quiet: Boolean) {
        if (_state.value.conn != Conn.DESCONECTADO) return
        // Tras soltar el USB se deja respirar al adaptador antes de volver a abrirlo
        if (quiet && System.currentTimeMillis() - lastCloseMs < REOPEN_GAP_MS) return
        val driver = UsbSerialProber.getDefaultProber().findAllDrivers(usb).firstOrNull()
        if (driver == null) {
            val now = System.currentTimeMillis()
            if (hadDevice && lostAtMs == 0L) {
                lostAtMs = now
                event("La pantalla no ve el cable OBD", kernel = true)
            }
            // Sigue sin verlo pasados 15 s: es un cuelgue del USB de la pantalla
            if (hadDevice && lostAtMs > 0 && now - lostAtMs > 15_000) maybeAutoReset("la pantalla no ve el cable")
            val msg = "No encuentro el cable OBD USB. ¿Está enchufado a la pantalla?"
            if (!quiet || _state.value.status != msg) setStatus(msg)
            if (!quiet) {
                val others = usb.deviceList.values.joinToString { "%04X:%04X".format(it.vendorId, it.productId) }
                if (others.isNotEmpty()) log("Dispositivos USB vistos (no reconocidos como serie): $others")
            }
            return
        }
        val device: UsbDevice = driver.device
        if (lostAtMs > 0) {
            event("La pantalla vuelve a ver el cable tras " + mins(System.currentTimeMillis() - lostAtMs))
            lostAtMs = 0
        }
        if (!hadDevice) {
            hadDevice = true
            UsbDoctor.busOf(device.deviceName)?.let { b ->
                val txt = "Bus $b · %04X:%04X".format(device.vendorId, device.productId) + (device.productName?.let { n -> " · $n" } ?: "")
                prefs.edit().putInt("usbBus", b).putString("usbBusText", txt).apply()
                _state.update { it.copy(usbBus = txt) }
            }
            rememberControllers()
        }
        if (!usb.hasPermission(device)) {
            val now = System.currentTimeMillis()
            // Al reintentar sola no se vuelve a abrir el aviso de permiso a cada rato
            if (quiet && now - permissionAskedMs < 20_000) return
            permissionAskedMs = now
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(
                getApplication(), 0,
                Intent(ACTION_PERMISSION).setPackage(getApplication<Application>().packageName), flags,
            )
            setStatus("Acepta el permiso USB en la pantalla…")
            usb.requestPermission(device, pi)
            return
        }
        val connection = usb.openDevice(device)
        if (connection == null) {
            val msg = "No se pudo abrir el cable USB"
            if (!quiet || _state.value.status != msg) setStatus(msg)
            return
        }
        _state.update { it.copy(conn = Conn.CONECTANDO, status = "Buscando adaptador…") }
        log("Cable USB: ${driver.javaClass.simpleName.removeSuffix("SerialDriver")} %04X:%04X".format(device.vendorId, device.productId))

        // Identifica este intento: si mientras tanto se desconecta o se empieza otro, el viejo no debe tocar nada
        val gen = ++connGen
        viewModelScope.launch {
            try {
                doConnect(driver, connection, gen)
            } catch (ex: Exception) {
                if (gen == connGen) disconnect("Error de comunicación: ${ex.message ?: ex.javaClass.simpleName}")
                // Si el puerto no llegó a abrirse, la conexión USB quedaría abierta y bloquearía el siguiente intento
                try { connection.close() } catch (_: Exception) { }
            }
        }
    }

    /** Número del intento de conexión en curso. Cada desconexión lo cambia, invalidando los intentos antiguos. */
    private var connGen = 0

    private suspend fun doConnect(driver: UsbSerialDriver, connection: UsbDeviceConnection, gen: Int) {
        val port = driver.ports[0]
        port.open(connection)
        try { port.setDTR(true); port.setRTS(true) } catch (_: Exception) { }
        val e = Elm327(port, connection) { log(it) }
        e.logTraffic = _state.value.traffic
        elm = e

        // Una sola velocidad (115200) y un solo saludo; nada de barridos
        val version = e.handshake()
        if (gen != connGen) return   // mientras tanto se desconectó o empezó otro intento
        if (version == null) {
            muteFails++
            if (muteFails == 4) { event("El adaptador no contesta (4 intentos seguidos)", kernel = true); maybeAutoReset("el adaptador no contesta") }
            disconnect(
                if (muteFails >= 4) "El adaptador no contesta · quita y pon el cable si sigue así"
                else "El adaptador no contesta · reintentando…",
            )
            return
        }
        muteFails = 0
        _state.update { it.copy(adapter = version, status = "Conectando con el coche…") }
        connectToCar(e, gen)
    }

    /**
     * Habla con el coche con el adaptador ya abierto. Si el coche no contesta (contacto quitado),
     * NO suelta el USB: espera y vuelve a preguntar, comprobando de paso que el adaptador sigue vivo.
     */
    private suspend fun connectToCar(e: Elm327, gen: Int) {
        vagBus = null
        fuelDead.clear(); fuelMiss = 0
        // Turbo fijo: si en la conexión anterior dejó de contestar, se vuelve a probar
        if (boostDid == null) { boostDid = FIXED_BOOST_DID; boostFormula = 0; boostFails = 0; updateBoostSource() }
        while (gen == connGen && elm === e) {
            if (initCar(e, gen)) return
            if (gen != connGen || elm !== e) return
            _state.update { it.copy(conn = Conn.CONECTANDO, status = "Esperando al coche · pon el contacto") }
            delay(3000)
            if (gen != connGen || elm !== e) return
            if (e.send("ATI", 1500).isBlank()) {
                disconnect("El adaptador dejó de contestar · reconectando…")
                return
            }
        }
    }

    /** Configura el adaptador y arranca la lectura. Devuelve false si el coche no contestó. */
    private suspend fun initCar(e: Elm327, gen: Int): Boolean {
        batching = true; batchMisses = 0; suffixOk = true
        for (c in listOf("ATE0", "ATL0", "ATS0", "ATH0", "ATAT2", "ATST 32")) e.send(c)
        // Un solo protocolo: el que ya funcionó (guardado) o CAN 11 bit 500 kbps, el del Ibiza 6J
        val proto = prefs.getString("protoNum", null) ?: "6"
        e.send("ATSP$proto")
        var r = e.send("0100", 6000)
        if (Elm327.mode01Supported(r) == null) {
            delay(500)
            r = e.send("0100", 6000)
        }
        if (gen != connGen || elm !== e) return false
        val first = Elm327.mode01Supported(r) ?: return false
        val protocol = e.send("ATDP").removePrefix("AUTO,").trim()
        e.send("ATDPN").trim().removePrefix("A").takeIf { it.length == 1 && it[0].isLetterOrDigit() }
            ?.let { prefs.edit().putString("protoNum", it).apply() }

        // PIDs soportados
        val supported = first.toMutableSet()
        for (base in listOf(0x20, 0x40, 0x60, 0x80, 0xA0)) {
            if (base !in supported) break
            val s = Elm327.supported(e.send("01%02X".format(base)), base)
            if (s.isEmpty()) break
            supported += s
        }
        log("PIDs soportados: " + supported.sorted().joinToString(" ") { "%02X".format(it) })

        // En CAN, hablar solo con la centralita de motor (7E0): respuestas limpias y permite UDS
        if (protocol.contains("15765")) e.send("ATSH7E0")
        val vin = Elm327.vin(e.send("0902", 5000)) ?: ""
        if (gen != connGen || elm !== e) return false
        lastDataMs = System.currentTimeMillis()
        _state.update {
            it.copy(
                conn = Conn.CONECTADO, protocol = protocol, vin = vin, supportedPids = supported,
                status = "Conectado · $protocol",
            )
        }
        event("Conectado al coche")
        readStatus()
        detectOil(e)
        updateBoostSource()
        // Al conectar se leen las averías solas, como hace un equipo de taller. La primera vez desde que se abre la
        // app: PRIMERO el motor y todas las centralitas y DESPUÉS empiezan los relojes y las ruedas (así no se cruzan);
        // en las reconexiones, los relojes al momento y solo las averías del motor
        if (!autoAllDone) {
            autoAllDone = true
            _state.update { it.copy(status = "Leyendo averías de todas las centralitas…") }
            readAllDtcs(thenPoll = true)
        } else {
            startPolling()
            viewModelScope.launch {
                delay(2500)
                if (elm === e && gen == connGen && !_state.value.dtcBusy) readDtcs()
            }
        }
        return true
    }

    /**
     * El coche dejó de dar datos: se reinicia el adaptador y se vuelve a hablar con el coche SIN cerrar
     * el USB (cerrarlo y reabrirlo era lo que dejaba al adaptador mudo). Solo si el adaptador tampoco
     * contesta se suelta el USB y se reconecta desde cero.
     */
    private fun recoverInPlace() {
        val e = elm ?: return
        val gen = connGen
        pollJob?.cancel(); pollJob = null
        _state.update {
            it.copy(conn = Conn.CONECTANDO, status = "Sin datos del coche · reiniciando adaptador…", refreshHz = 0.0, oilScanProgress = null, boostScanProgress = null, engDumpProgress = null)
        }
        log("Sin datos del coche · reiniciando el adaptador sin soltar el USB")
        event("El coche dejó de dar datos: se reinicia el adaptador")
        viewModelScope.launch {
            try {
                val version = e.handshake()
                if (gen != connGen) return@launch
                if (version == null) { disconnect("Sin datos del coche · reconectando…"); return@launch }
                connectToCar(e, gen)
            } catch (ex: Exception) {
                if (gen == connGen) disconnect("Error de comunicación: ${ex.message ?: ex.javaClass.simpleName}")
            }
        }
    }

    fun disconnect(reason: String = "Desconectado") {
        if (reason != "Desconectado" && elm != null) event("Se suelta el USB: $reason")
        connGen++
        pollJob?.cancel(); pollJob = null
        elm?.close(); elm = null
        lastCloseMs = System.currentTimeMillis()
        _state.update {
            it.copy(conn = Conn.DESCONECTADO, status = reason, refreshHz = 0.0, demo = false, oilScanProgress = null, boostScanProgress = null, engDumpProgress = null)
        }
        log(reason)
    }

    // ------------------------------------------------------------ Modo demo (sin cable)

    /** Simula un coche en marcha para probar la app sin cable ni coche. */
    fun startDemo() {
        if (_state.value.conn != Conn.DESCONECTADO) return
        _state.update {
            it.copy(
                conn = Conn.CONECTADO, demo = true, status = "MODO DEMO · datos simulados",
                adapter = "Simulador", protocol = "Demo", vin = "VSSZZZ6JZBR000000", oilSource = "Demo",
                supportedPids = Params.byPid.keys, mil = true, dtcCount = 2,
            )
        }
        log("Modo demo iniciado")
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            var t = 0.0
            while (isActive) {
                t += 0.1
                // Aceleraciones y retenciones cíclicas
                val ph = ((kotlin.math.sin(t * 0.45) + 1) / 2).let { it * it }
                val noise = { a: Double -> (Math.random() - 0.5) * a }
                val map = 101 + ph * 135 + noise(3.0)
                val v = mapOf(
                    "rpm" to 850 + ph * 3300 + noise(40.0),
                    "speed" to maxOf(0.0, -12 + ph * 135),
                    "load" to ph * 95 + noise(2.0),
                    "absload" to ph * 90,
                    "pedal" to ph * 100,
                    "pedal2" to ph * 50,
                    "throttle" to 20 + ph * 80,
                    "throttlecmd" to 20 + ph * 80,
                    "relthrottle" to ph * 80,
                    "torquedem" to ph * 100,
                    "torque" to ph * 96,
                    "torqueref" to 320.0,
                    "map" to map,
                    "baro" to 101.0,
                    Params.BOOST to (map - 101) / 100,
                    "maf" to 9 + ph * 150 + noise(2.0),
                    "egrcmd" to (1 - ph) * 55,
                    "egrerr" to noise(6.0),
                    "rail" to 280 + ph * 1450 + noise(20.0),
                    "fuelrate" to 0.9 + ph * 16,
                    "fuellevel" to 63.0,
                    "injtiming" to 2 + ph * 9,
                    "coolant" to 89 + kotlin.math.sin(t * 0.05) * 3,
                    "iat" to 28 + ph * 14,
                    "ambient" to 19.0,
                    "oil" to minOf(52 + t * 0.6, 97.0) + ph * 4,
                    Params.BATTERY to 14.1 + noise(0.15),
                    "modvolt" to 14.0 + noise(0.1),
                    "runtime" to t / 6,
                    "distmil" to 37.0,
                    "timemil" to 52.0,
                    "distclr" to 1240.0,
                    "timeclr" to 1530.0,
                    "warmups" to 41.0,
                )
                applyValues(v, replace = true, hz = 30.0)
                delay(100)
            }
        }
    }

    // ------------------------------------------------------------ Lectura en tiempo real

    private var batching = true
    private var batchMisses = 0
    private var suffixOk = true

    /** Lee un dato. Con el "1" final el adaptador contesta en cuanto llega la primera respuesta, sin esperar al tiempo límite. */
    private suspend fun readPid(e: Elm327, pid: Int): IntArray? {
        val base = "01%02X".format(pid)
        if (suffixOk) {
            val r = e.send(base + "1", 1500)
            if (r.trim().startsWith("?")) {
                suffixOk = false
                log("El adaptador no admite el atajo de respuesta única; se desactiva")
            } else return Elm327.mode01(r, pid)
        }
        return Elm327.mode01(e.send(base, 1500), pid)
    }

    private fun startPolling() {
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            var cycle = 0
            var rotate = 0
            var emptyCycles = 0
            var t0 = System.currentTimeMillis()
            var reads = 0
            try {
                while (isActive) {
                    val e = elm ?: break
                    val st = _state.value
                    val supported = st.supportedPids

                    // 1) Lo que hay en el panel, en cada vuelta
                    val wantPressure = Params.BOOST in st.live || "map" in st.live
                    val bDid = boostDid
                    val cal = if (bDid == null) calibrator else null
                    val ext = if (bDid == null) (if (0x70 in supported) 0x70 else if (0x87 in supported) 0x87 else null) else null
                    // El 010B solo hace falta si no hay nada mejor o para confirmar los candidatos
                    val use0B = cal != null || (bDid == null && ext == null)
                    val pids = linkedSetOf<Int>()
                    for (id in st.live) {
                        when (id) {
                            Params.BOOST -> {
                                if (use0B) pids += 0x0B
                                if (cycle % 20 == 0 && 0x33 in supported && ambDid == null) pids += 0x33
                            }
                            else -> Params.byId[id]?.pid?.let { if (it in supported && (it != 0x0B || use0B)) pids += it }
                        }
                    }
                    // Consumo: lo que haga falta para calcularlo (en cada vuelta si está en pantalla; si no,
                    // una de cada dos para que el ordenador de viaje lo sume siempre)
                    // Si el coche dice que da un dato pero luego no contesta, se pasa al siguiente método
                    val fuelSrc = Fuel.source(supported - fuelDead)
                    if (fuelSrc != st.fuelSrc) _state.update { it.copy(fuelSrc = fuelSrc) }
                    val wantFuel = fuelSrc != FuelSource.NONE && ("fuelrate" in st.live || cycle % 2 == 0)
                    if (wantFuel) {
                        fuelSrc.pids.forEach { pids += it }
                        if (fuelSrc == FuelSource.TORQUE && "torqueref" !in st.values && 0x63 in supported && cycle % 10 == 0) pids += 0x63
                        if (0x0D in supported) pids += 0x0D
                    }
                    // Mientras hay candidatos por confirmar se lee el 010B aunque el turbo no esté en pantalla
                    if (cal != null) pids += 0x0B
                    // 2) Solo se lee lo que hay en pantalla. Del resto, uno cada pocas vueltas para ir
                    //    rellenando los demás menús sin frenar los relojes.
                    if (cycle % 5 == 0) {
                        val rest = Params.all.mapNotNull { it.pid }.filter { it in supported && it !in pids && (it != 0x0B || use0B) }
                        if (rest.isNotEmpty()) pids += rest[rotate++ % rest.size]
                    }

                    val newValues = mutableMapOf<String, Double>()
                    val list = pids.toList()
                    var idx = 0
                    while (idx < list.size) {
                        val chunk = list.subList(idx, minOf(idx + BATCH, list.size))
                        idx += chunk.size
                        val got = mutableMapOf<Int, IntArray>()
                        if (batching && chunk.size >= 2) {
                            // Varios datos en una sola petición: mucho más rápido
                            val cmd = "01" + chunk.joinToString("") { "%02X".format(it) }
                            got += Elm327.mode01Multi(e.send(cmd, 1500), chunk)
                            if (got.size < chunk.size) {
                                if (++batchMisses >= 2) {
                                    batching = false
                                    log("La centralita no admite varios datos por petición; se leen de uno en uno")
                                }
                            } else batchMisses = 0
                        }
                        // Lo que falte (o todo, si no hay lotes) se lee de uno en uno
                        for (pid in chunk) {
                            if (pid !in got) readPid(e, pid)?.let { got[pid] = it }
                        }
                        for ((pid, data) in got) {
                            val p = Params.byPid[pid] ?: continue
                            newValues[p.id] = p.calc(data)
                            reads++
                        }
                    }
                    // ¿Contestó el coche a las lecturas normales? (el aceite por UDS no cuenta)
                    val gotStd = newValues.isNotEmpty()
                    if (gotStd) emptyCycles = 0
                    else if (pids.isNotEmpty() && ++emptyCycles >= 3) {
                        // Los relojes se quedarían congelados: se reconfigura el adaptador sin desconectar
                        log("Sin respuesta a las lecturas normales · reconfigurando el adaptador")
                        emptyCycles = 0
                        for (c in listOf("ATE0", "ATL0", "ATS0", "ATH0", "ATAT2", "ATST 32")) e.send(c, 1500)
                        if (st.protocol.contains("15765")) e.send("ATSH7E0", 1500)
                    }
                    // Confirmación de candidatos: solo cuando el turbo sopla sin llegar al tope del 010B
                    val map0B = newValues["map"]
                    if (cal != null && map0B != null && BoostCalibrator.usable(map0B)) {
                        val baroK = newValues["baro"] ?: st.values["baro"] ?: 101.3
                        val pend = cal.pending()
                        for (k in 0 until minOf(6, pend.size)) {
                            val c = pend[(calRot + k) % pend.size]
                            val d = Elm327.mode22(e.send("22%04X".format(c.did), 600), c.did) ?: continue
                            PressureFormula.hpa(d, c.formula)?.let { cal.sample(c, it, map0B, baroK) }
                        }
                        calRot += 6
                        publishBoost(cal, boostLive)
                        when (cal.decide()) {
                            Calib.HECHO -> adoptBoost(cal)
                            Calib.FALLIDO -> {
                                calibrator = null
                                prefs.edit().remove("boostCands").apply()
                                _state.update { it.copy(boostMessage = "Ninguno de los datos encontrados sigue a la presión del turbo: se queda el dato estándar.") }
                                updateBoostSource()
                            }
                            Calib.ESPERANDO -> _state.update {
                                it.copy(boostMessage = "Comprobando conduciendo… ${cal.done()} de ${cal.cands.size}. Sigue acelerando con ganas de vez en cuando.")
                            }
                        }
                    }
                    // Candidatos en directo mientras se mira la lista en Ajustes
                    if (cal != null && watchBoost && cycle % 2 == 0) {
                        val list = cal.cands
                        for (k in 0 until minOf(4, list.size)) {
                            val c = list[(boostLiveRot + k) % list.size]
                            val d = Elm327.mode22(e.send("22%04X".format(c.did), 600), c.did) ?: continue
                            PressureFormula.hpa(d, c.formula)?.let { boostLive[c.did] = it }
                        }
                        boostLiveRot = (boostLiveRot + 4) % maxOf(1, list.size)
                        publishBoost(cal, boostLive)
                        val refMap = newValues["map"] ?: st.values["map"]
                        val refBaro = newValues["baro"] ?: st.values["baro"]
                        _state.update { it.copy(boostRefHpa = refMap?.let { m -> m * 10 }, baroRefHpa = refBaro?.let { b -> b * 10 }) }
                    }
                    // Presión real del turbo con precisión de 1 hPa
                    var precise = false
                    if (bDid != null && wantPressure) {
                        val h = Elm327.mode22(e.send("22%04X".format(bDid), 1500), bDid)?.let { PressureFormula.hpa(it, boostFormula) }
                        if (h != null && h in 300.0..4500.0) {
                            newValues["map"] = h / 10.0
                            precise = true; boostFails = 0; reads++
                        } else if (++boostFails >= 10) {
                            log("La centralita no da la presión por 22%04X · vuelvo al dato estándar".format(bDid))
                            boostDid = null; boostFails = 0
                            updateBoostSource()
                        }
                    } else if (ext != null && wantPressure) {
                        Elm327.extendedMap(e.send("01%02X".format(ext), 1500), ext)?.let { newValues["map"] = it; precise = true; reads++ }
                    }
                    // Presión ambiental con precisión de 1 hPa
                    val aDid = ambDid
                    if (aDid != null && (cycle % 20 == 0 || "baro" in st.live) && (wantPressure || "baro" in st.live)) {
                        Elm327.mode22(e.send("22%04X".format(aDid), 1500), aDid)?.let { PressureFormula.hpa(it, ambFormula) }
                            ?.takeIf { it in 500.0..1100.0 }?.let { newValues["baro"] = it / 10.0 }
                    }
                    // ¿Está el dato estándar en su tope? (entonces el turbo puede ir por encima de lo que se ve)
                    newValues["map"]?.let { m ->
                        val capped = !precise && m >= 254.5
                        if (capped != st.boostCapped) _state.update { it.copy(boostCapped = capped) }
                    }
                    // Aceite por UDS (si el PID estándar no existe)
                    val did = oilDid
                    if (did != null && ("oil" in st.live || cycle % 10 == 5)) {
                        Elm327.mode22(e.send("22%04X".format(did), 1500), did)?.let { d ->
                            oilCalc(d, oilFormula)?.let { newValues["oil"] = it; reads++ }
                        }
                    }
                    // Datos fijos y de prueba de la centralita por UDS (solo se leen si están en pantalla)
                    for ((pid, did, kind) in UDS_EXTRA) {
                        if (pid !in st.live) continue
                        val d = Elm327.mode22(e.send("22%04X".format(did), 800), did) ?: continue
                        if (d.size < 2) continue
                        val raw = d[0] * 256 + d[1]
                        newValues[pid] = if (kind == 'T') (raw - 2731) / 10.0 else raw / 10.0
                        reads++
                    }
                    // Consumo por cantidad inyectada (prueba): 22 11 68 (A) y 22 10 47 (B)
                    val wantInj = listOf("injA", "lphA", "l100A", "injB", "lphB", "l100B").any { it in st.live }
                    if (wantInj || cycle % 4 == 2) {
                        for ((injDid, key) in listOf(0x1168 to "A", 0x1047 to "B")) {
                            val d = Elm327.mode22(e.send("22%04X".format(injDid), 800), injDid) ?: continue
                            if (d.size < 2) continue
                            val mg = (d[0] * 256 + d[1]) * 0.02
                            newValues["inj$key"] = mg
                            val rpmNow = newValues["rpm"] ?: st.values["rpm"] ?: continue
                            // 4 cilindros, una inyección cada 2 vueltas: mg/h = mg × rpm/2 × 4 × 60; gasóleo 0,832 kg/l
                            val lph = mg * rpmNow * 120.0 / 1e6 / 0.832
                            newValues["lph$key"] = lph
                            val spd = newValues["speed"] ?: st.values["speed"]
                            if (spd != null && spd >= 5) newValues["l100$key"] = lph / spd * 100.0
                        }
                    }
                    // Candidatos de aceite en vivo (solo mientras se mira la lista en Ajustes)
                    if (watchCand && scanFound.isNotEmpty() && cycle % 2 == 0) {
                        val cands = scanFound.take(40)
                        val live = _state.value.candLive.toMutableMap()
                        // 8 por vuelta, rotando, para que todos se actualicen sin frenar los relojes
                        for (k in 0 until minOf(8, cands.size)) {
                            val cd = cands[(candRot + k) % cands.size]
                            val d = Elm327.mode22(e.send("22%04X".format(cd.did), 800), cd.did) ?: continue
                            oilCalc(d, cd.formula)?.let { live[cd.did] = it }
                        }
                        candRot = (candRot + 8) % cands.size
                        _state.update { it.copy(candLive = live) }
                    }
                    // Turbo relativo = MAP - presión atmosférica
                    val map = newValues["map"] ?: st.values["map"]
                    val baro = newValues["baro"] ?: st.values["baro"] ?: 101.3
                    if (map != null && "map" in newValues) newValues[Params.BOOST] = (map - baro) / 100.0

                    // Consumo instantáneo (l/h), con la corrección para igualarlo con el cuadro
                    if (wantFuel) {
                        val rpm = newValues["rpm"] ?: st.values["rpm"]
                        val parado = (newValues["speed"] ?: st.values["speed"] ?: 0.0) < 3 && (rpm ?: 0.0) < 1100
                        val fuelK = st.opt(AlertKey.FUEL_CAL) / 100.0 * (if (parado) st.opt(AlertKey.FUEL_IDLE) / 100.0 else 1.0)
                        val lph: Double? = when (fuelSrc) {
                            FuelSource.PID -> newValues["fuelrate"]
                            FuelSource.TORQUE -> newValues["torque"]?.let { tq ->
                                val ref = (newValues["torqueref"] ?: st.values["torqueref"])?.takeIf { it in 100.0..1000.0 } ?: Fuel.DEFAULT_REF_NM
                                rpm?.let { Fuel.fromTorque(tq, ref, it) }
                            }
                            FuelSource.LOAD -> newValues["load"]?.let { l -> rpm?.let { Fuel.fromLoad(l, it) } }
                            FuelSource.MAF_O2, FuelSource.MAF_LAMBDA -> {
                                val maf = newValues["maf"]
                                val lam = if (fuelSrc == FuelSource.MAF_O2) newValues["lambdas"] else newValues["lambda"]
                                if (maf == null || lam == null) null
                                // Lambda fuera de rango (diésel con poca carga): se tira de la carga si la hay
                                else Fuel.fromMaf(maf, lam) ?: (st.values["load"] ?: newValues["load"])?.let { l -> rpm?.let { Fuel.fromLoad(l, it) } }
                                    ?: Fuel.fromMafLean(maf)
                            }
                            FuelSource.NONE -> null
                        }
                        if (lph != null) {
                            newValues["fuelrate"] = lph * fuelK
                            fuelMiss = 0
                        } else if (gotStd && ++fuelMiss >= 8) {
                            // El dato principal de este método no llega: se descarta y se prueba el siguiente
                            fuelSrc.pids.firstOrNull()?.let { fuelDead += it }
                            fuelMiss = 0
                            log("Consumo: ${fuelSrc.text} no contesta · se prueba otro método")
                        }
                    }

                    // Ruedas: velocidad de las cuatro ruedas del ABS, cada 2 s (si se ha encontrado)
                    try { withContext(NonCancellable) { sampleTyres(e, st) } } catch (ex: Exception) { log("Ruedas: ${ex.message}") }

                    // Batería (la mide el propio adaptador)
                    if (cycle % 10 == 0 || (Params.BATTERY in st.live && cycle % 3 == 0)) {
                        e.send("ATRV", 800).replace("V", "").trim().toDoubleOrNull()?.let {
                            newValues[Params.BATTERY] = it
                            volts.addLast(System.currentTimeMillis() to it)
                            while (volts.size > 120) volts.removeFirst()
                        }
                    }

                    if (newValues.isNotEmpty()) applyValues(newValues, fresh = gotStd || precise)
                    val now = System.currentTimeMillis()
                    if (now - t0 >= 2000) {
                        val hz = reads * 1000.0 / (now - t0)
                        _state.update { it.copy(refreshHz = hz) }
                        t0 = now; reads = 0
                    }
                    cycle++
                    if (pids.isEmpty()) delay(300)
                }
            } catch (ex: Exception) {
                if (isActive) disconnect("Conexión perdida: ${ex.message ?: ex.javaClass.simpleName}")
            }
        }
    }

    // ------------------------------------------------------------ Averías

    // ---- Última lectura de averías guardada (para que lo borrado siga borrado al volver a arrancar)

    private fun saveDtcs() {
        val st = _state.value
        if (st.demo) return
        fun l(x: List<String>?) = x?.joinToString(",")
        prefs.edit()
            .putString("dtcStored", l(st.dtcs)).putString("dtcPending", l(st.pendingDtcs))
            .putString("dtcPermanent", l(st.permanentDtcs))
            .putString("dtcUds", st.udsDtcs?.joinToString(",") { "${it.code}:${it.status}:${it.ftb}" })
            .putString("dtcMil", st.mil?.toString())
            .putString("dtcAt", (st.dtcReadAt ?: System.currentTimeMillis()).toString())
            .apply()
    }

    private fun loadDtcs() {
        fun l(k: String): List<String>? = prefs.getString(k, null)?.split(",")?.filter { it.isNotBlank() }
        val at = prefs.getString("dtcAt", null)?.toLongOrNull() ?: return
        val uds = prefs.getString("dtcUds", null)?.split(",")?.mapNotNull { t ->
            val f = t.split(":")
            if (f.size == 3) UdsDtc(f[0], f[1].toIntOrNull() ?: 0, f[2].toIntOrNull() ?: 0) else null
        }
        _state.update {
            it.copy(
                dtcs = l("dtcStored"), pendingDtcs = l("dtcPending"), permanentDtcs = l("dtcPermanent"), udsDtcs = uds,
                mil = prefs.getString("dtcMil", null)?.toBooleanStrictOrNull(), dtcReadAt = at,
                dtcMessage = "Última lectura guardada · " + SimpleDateFormat("d MMM HH:mm", Locale("es", "ES")).format(Date(at)),
            )
        }
    }

    private suspend fun readStatus() {
        val e = elm ?: return
        val m = Elm327.messages(e.send("0101")).firstOrNull { it.size >= 3 && it[0] == 0x41 && it[1] == 0x01 }
        if (m != null) _state.update { it.copy(mil = (m[2] and 0x80) != 0, dtcCount = m[2] and 0x7F) }
    }

    fun readDtcs() {
        if (_state.value.demo) {
            _state.update {
                it.copy(
                    dtcs = listOf("P0401", "P2002"), pendingDtcs = listOf("P0299"), permanentDtcs = emptyList(),
                    mil = true, dtcCount = 2, dtcMessage = "Averías de ejemplo (modo demo)",
                    checks = listOf(
                        DiagCheck("Comunicación con la centralita", CheckLevel.OK, "Responde", "La centralita del motor contesta con normalidad."),
                        DiagCheck("Testigo de avería del motor", CheckLevel.MAL, "Encendido", "La centralita tiene guardada una avería que enciende el testigo."),
                        DiagCheck("Averías confirmadas", CheckLevel.MAL, "P0401 P2002", "La centralita ha confirmado 2 avería(s)."),
                        DiagCheck("Averías pendientes", CheckLevel.AVISO, "P0299", "Fallo detectado pero todavía sin confirmar."),
                        DiagCheck("Temperatura del refrigerante", CheckLevel.OK, "89 °C", "Temperatura normal de trabajo."),
                    ),
                )
            }
            return
        }
        val e = elm ?: return setDtcMessage("Conecta primero con el coche")
        if (_state.value.dtcBusy) return
        // Si se están buscando las otras centralitas, el adaptador está hablando con ellas: las preguntas al motor
        // se mezclarían y saldría "sin respuesta". Se espera a que acabe y entonces se lee.
        if (_state.value.modBusy || _state.value.sniffOn || _state.value.bridgeOn || _state.value.liveMod != null) {
            if (waitingDtcs) return
            waitingDtcs = true
            setDtcMessage("Se leerá en cuanto acabe con las otras centralitas…")
            viewModelScope.launch {
                while (_state.value.modBusy || _state.value.sniffOn || _state.value.bridgeOn || _state.value.liveMod != null) delay(300)
                delay(300)
                waitingDtcs = false
                if (elm === e) readDtcs()
            }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(dtcBusy = true, dtcMessage = "Leyendo averías…", checks = emptyList()) }
            try {
                // Mientras se leen las averías del motor no se lee el ABS (cambiaría el cable a mitad)
                absLock.withLock { runCheckup(e) }
            } catch (ex: Exception) {
                _state.update { it.copy(dtcBusy = false) }
                disconnect("Error leyendo averías: ${ex.message}")
            }
        }
    }

    private var waitingDtcs = false

    private fun step(msg: String) = _state.update { it.copy(dtcMessage = msg) }
    private fun addCheck(name: String, level: CheckLevel, value: String, why: String) =
        _state.update { it.copy(checks = it.checks + DiagCheck(name, level, value, why)) }

    private suspend fun readPidOnce(e: Elm327, pid: Int): IntArray? =
        Elm327.mode01(e.send("01%02X".format(pid), 1500), pid)

    /**
     * Diagnóstico completo: lee estado, averías y varios datos en vivo, y para cada cosa dice si está
     * bien o mal y por qué. Va añadiendo líneas a medida que las lee.
     */
    private suspend fun runCheckup(e: Elm327) {
        // 1) Comunicación y estado general (testigo, controles)
        step("Comprobando la comunicación con la centralita…")
        var s01 = Elm327.messages(e.send("0101")).firstOrNull { it.size >= 6 && it[0] == 0x41 && it[1] == 0x01 }
        if (s01 == null) {
            // Segundo intento dejando el adaptador como para el motor (por si se quedó a medias con otra centralita)
            try {
                for (c in listOf("ATCAF1", "ATH0", "ATCRA")) e.send(c, 1500)
                if (_state.value.protocol.contains("15765")) e.send("ATSH7E0", 1500)
            } catch (_: Exception) { }
            delay(200)
            s01 = Elm327.messages(e.send("0101")).firstOrNull { it.size >= 6 && it[0] == 0x41 && it[1] == 0x01 }
        }
        if (s01 == null) {
            addCheck(
                "Comunicación con la centralita", CheckLevel.MAL, "Sin respuesta",
                "La centralita del motor no contestó. Pon el contacto y comprueba que el cable está bien enchufado.",
            )
            _state.update { it.copy(dtcBusy = false, dtcMessage = "No se pudo leer la centralita") }
            return
        }
        addCheck("Comunicación con la centralita", CheckLevel.OK, "Responde", "La centralita del motor contesta con normalidad.")
        val mil = (s01[2] and 0x80) != 0
        val count = s01[2] and 0x7F
        _state.update { it.copy(mil = mil, dtcCount = count) }
        if (mil) addCheck(
            "Testigo de avería del motor", CheckLevel.MAL, "Encendido",
            "La centralita tiene guardada una avería que enciende el testigo. Mira las averías confirmadas más abajo.",
        ) else addCheck(
            "Testigo de avería del motor", CheckLevel.OK, "Apagado", "No hay ninguna avería que obligue a encender el testigo.",
        )

        // 2) Averías
        step("Leyendo averías confirmadas…")
        val stored = Elm327.dtcs(e.send("03", 6000), 0x43)
        if (stored.isEmpty()) addCheck("Averías confirmadas", CheckLevel.OK, "Ninguna", "No hay averías guardadas en la memoria de la centralita.")
        else addCheck(
            "Averías confirmadas", CheckLevel.MAL, stored.joinToString(" "),
            "La centralita ha confirmado ${stored.size} avería(s). Tienen que revisarse: el detalle de cada una está en la lista de abajo.",
        )
        step("Leyendo averías pendientes…")
        val pending = Elm327.dtcs(e.send("07", 6000), 0x47)
        if (pending.isEmpty()) addCheck("Averías pendientes", CheckLevel.OK, "Ninguna", "No hay fallos detectados que estén aún sin confirmar.")
        else addCheck(
            "Averías pendientes", CheckLevel.AVISO, pending.joinToString(" "),
            "Se ha detectado un fallo pero todavía no se ha repetido lo suficiente para confirmarlo. Si vuelve a pasar, se convertirá en avería confirmada.",
        )
        step("Leyendo averías permanentes…")
        val permanent = Elm327.dtcs(e.send("0A", 6000), 0x4A)
        if (permanent.isEmpty()) addCheck("Averías permanentes", CheckLevel.OK, "Ninguna", "No hay averías permanentes (las que solo se borran al reparar y pasar los controles).")
        else addCheck(
            "Averías permanentes", CheckLevel.MAL, permanent.joinToString(" "),
            "Son averías que no se pueden borrar con el lector: desaparecen solas cuando se repara el fallo y la centralita lo comprueba.",
        )
        val uds = if (_state.value.protocol.contains("15765")) {
            step("Leyendo la memoria de averías de la centralita…")
            Elm327.udsDtcs(e.send("1902FF", 6000))
        } else null
        when {
            uds == null -> {}
            uds.isEmpty() -> addCheck("Memoria de la centralita (VAG)", CheckLevel.OK, "Vacía", "La memoria propia de la centralita, la que leen Autel o VCDS, no tiene ninguna avería.")
            uds.any { it.active } -> addCheck(
                "Memoria de la centralita (VAG)", CheckLevel.MAL, uds.joinToString(" ") { it.code },
                "Hay ${uds.count { it.active }} avería(s) activa(s) ahora mismo: el fallo sigue presente. Las demás están guardadas de antes y se pueden borrar.",
            )
            else -> addCheck(
                "Memoria de la centralita (VAG)", CheckLevel.AVISO, uds.joinToString(" ") { it.code },
                "Son averías guardadas de antes que ya no están activas (ya resueltas). Se quitan con BORRAR.",
            )
        }
        _state.update { it.copy(dtcs = stored, pendingDtcs = pending, permanentDtcs = permanent, udsDtcs = uds, dtcReadAt = System.currentTimeMillis()) }
        saveDtcs()

        // 3) Controles de preparación (los de la ITV)
        step("Leyendo los controles de preparación…")
        val b = s01[3]; val c = s01[4]; val d = s01[5]
        val diesel = (b and 0x08) != 0
        fun mon(name: String, supported: Boolean, incomplete: Boolean) {
            if (!supported) return
            if (!incomplete) addCheck("Control: $name", CheckLevel.OK, "Completado", "La centralita ya ha comprobado este sistema y está correcto.")
            else addCheck(
                "Control: $name", CheckLevel.INFO, "Pendiente",
                "Aún no ha terminado su autocomprobación. No es una avería: es normal si se han borrado averías hace poco o se ha conducido poco.",
            )
        }
        mon("Fallos de combustión", (b and 0x01) != 0, (b and 0x10) != 0)
        mon("Sistema de combustible", (b and 0x02) != 0, (b and 0x20) != 0)
        mon("Componentes del motor", (b and 0x04) != 0, (b and 0x40) != 0)
        val names = if (diesel) {
            listOf("Catalizador", "Catalizador NOx/SCR", "", "Presión del turbo", "", "Sensores de gases de escape", "Filtro de partículas (FAP)", "EGR / distribución variable")
        } else {
            listOf("Catalizador", "Catalizador calefactado", "Sistema evaporativo", "Aire secundario", "Aire acondicionado", "Sonda lambda", "Calentador de sonda", "EGR")
        }
        for (i in 0..7) if (names[i].isNotEmpty()) mon(names[i], (c shr i) and 1 == 1, (d shr i) and 1 == 1)

        // 4) Datos en vivo con su valoración
        step("Comprobando datos en vivo…")
        val rpm = readPidOnce(e, 0x0C)?.let { (it[0] * 256 + it[1]) / 4.0 }
        val running = rpm != null && rpm > 400
        val secs = readPidOnce(e, 0x1F)?.let { (it[0] * 256 + it[1]).toDouble() }

        val coolant = readPidOnce(e, 0x05)?.let { it[0] - 40.0 }
        if (coolant != null) {
            val v = "%.0f °C".format(coolant)
            when {
                coolant >= 106 -> addCheck("Temperatura del refrigerante", CheckLevel.MAL, v, "Demasiado alta: riesgo de sobrecalentamiento. Para el motor, y revisa nivel de líquido, ventilador y termostato.")
                coolant >= 80 -> addCheck("Temperatura del refrigerante", CheckLevel.OK, v, "Temperatura normal de trabajo.")
                running && secs != null && secs > 600 -> addCheck("Temperatura del refrigerante", CheckLevel.AVISO, v, "Lleva más de 10 minutos en marcha y no llega a 80 °C. Puede ser un termostato que se queda abierto.")
                else -> addCheck("Temperatura del refrigerante", CheckLevel.INFO, v, "El motor todavía se está calentando.")
            }
        }

        val volt = e.send("ATRV", 800).replace("V", "").trim().toDoubleOrNull()
            ?: readPidOnce(e, 0x42)?.let { (it[0] * 256 + it[1]) / 1000.0 }
        if (volt != null) {
            val v = "%.1f V".format(volt)
            if (running) {
                when {
                volt > 15.0 -> addCheck("Tensión de la batería", CheckLevel.MAL, v, "Demasiado alta con el motor en marcha: el regulador del alternador puede estar fallando y dañar la batería.")
                volt >= 13.2 -> addCheck("Tensión de la batería", CheckLevel.OK, v, "El alternador carga bien.")
                volt >= 12.6 -> addCheck("Tensión de la batería", CheckLevel.AVISO, v, "El alternador carga poco con el motor en marcha. Con muchos consumos puede ser normal; si se repite, hay que revisarlo.")
                else -> addCheck("Tensión de la batería", CheckLevel.MAL, v, "Con el motor en marcha debería estar sobre 13,5–14,5 V. El alternador no carga o hay mala conexión.")
                }
            } else {
                when {
                volt >= 12.4 -> addCheck("Tensión de la batería", CheckLevel.OK, v, "Batería bien cargada (motor parado).")
                volt >= 12.0 -> addCheck("Tensión de la batería", CheckLevel.AVISO, v, "Batería algo baja con el motor parado. Conviene arrancar y comprobar que carga.")
                else -> addCheck("Tensión de la batería", CheckLevel.MAL, v, "Batería descargada o en mal estado.")
                }
            }
        }

        if (running) {
            val rail = readPidOnce(e, 0x23)?.let { (it[0] * 256 + it[1]) / 10.0 }
            if (rail != null && rpm != null && rpm < 1300) {
                val v = "%.0f bar".format(rail)
                if (rail in 180.0..650.0) addCheck("Presión del rail de inyección (ralentí)", CheckLevel.OK, v, "Presión normal para el ralentí.")
                else if (rail < 180) addCheck("Presión del rail de inyección (ralentí)", CheckLevel.AVISO, v, "Baja para el ralentí. Puede indicar filtro de gasoil sucio, aire en el circuito o bomba floja.")
                else addCheck("Presión del rail de inyección (ralentí)", CheckLevel.AVISO, v, "Alta para el ralentí. Puede ser el regulador de presión o el sensor.")
            }
        } else {
            addCheck("Presión del rail de inyección", CheckLevel.INFO, "Motor parado", "Se valora con el motor en marcha y al ralentí.")
        }

        val iat = readPidOnce(e, 0x0F)?.let { it[0] - 40.0 }
        if (iat != null) {
            val v = "%.0f °C".format(iat)
            if (iat >= 60) addCheck("Temperatura del aire de admisión", CheckLevel.AVISO, v, "Alta: el aire llega muy caliente. Revisa el intercooler y sus manguitos.")
            else addCheck("Temperatura del aire de admisión", CheckLevel.OK, v, "Valor normal.")
        }

        val oil = _state.value.values["oil"]
        if (oil != null) {
            val v = "%.0f °C".format(oil)
            when {
                oil >= 135 -> addCheck("Temperatura del aceite", CheckLevel.MAL, v, "Demasiado alta: el aceite pierde capacidad de lubricar. Baja el ritmo y revisa el nivel.")
                oil >= 120 -> addCheck("Temperatura del aceite", CheckLevel.AVISO, v, "Alta. Es normal solo con mucha carga mantenida.")
                oil >= 70 -> addCheck("Temperatura del aceite", CheckLevel.OK, v, "Temperatura normal de trabajo.")
                else -> addCheck("Temperatura del aceite", CheckLevel.INFO, v, "El aceite todavía está frío: evita revolucionar el motor.")
            }
        } else {
            addCheck("Temperatura del aceite", CheckLevel.INFO, "No se lee", "Todavía no se ha configurado de dónde sale este dato (Ajustes → Temperatura del aceite).")
        }

        val sinceClear = readPidOnce(e, 0x31)?.let { (it[0] * 256 + it[1]).toDouble() }
        if (sinceClear != null) {
            val v = "%.0f km".format(sinceClear)
            if (sinceClear < 50) addCheck("Km desde el último borrado de averías", CheckLevel.INFO, v, "Se borraron hace muy poco. Los controles de preparación pueden estar incompletos y habría que conducir un rato.")
            else addCheck("Km desde el último borrado de averías", CheckLevel.OK, v, "Hace tiempo que se borraron o nunca se han borrado: el historial es fiable.")
        }

        // 5) Resumen
        val cs = _state.value.checks
        val ok = cs.count { it.level == CheckLevel.OK }
        val warn = cs.count { it.level == CheckLevel.AVISO }
        val bad = cs.count { it.level == CheckLevel.MAL }
        _state.update {
            it.copy(
                dtcBusy = false,
                dtcMessage = "$ok bien · $warn avisos · $bad mal · ${timeFmt.format(Date())}",
            )
        }
    }

    /**
     * Borra las averías de verdad en la centralita, no solo en la pantalla:
     *  1) Borrado OBD-II (modo 04) a todas las centralitas (7DF) y a la de motor (7E0).
     *  2) Borrado de la memoria propia de la centralita (UDS 14 FF FF FF), la que leen Autel o VCDS.
     *     Si no lo acepta en la sesión normal, se repite en la sesión de diagnóstico ampliada (10 03).
     *  3) Vuelve a leer las dos memorias para comprobar qué ha quedado.
     * Las averías que sigan activas (el fallo sigue presente) vuelven a guardarse solas: se avisa de ello.
     */
    fun clearDtcs() {
        if (_state.value.demo) {
            _state.update {
                it.copy(
                    dtcs = emptyList(), pendingDtcs = emptyList(), permanentDtcs = emptyList(), udsDtcs = emptyList(),
                    mil = false, dtcCount = 0, dtcMessage = "Averías borradas (modo demo)",
                )
            }
            return
        }
        val e = elm ?: return setDtcMessage("Conecta primero con el coche")
        if (_state.value.dtcBusy) return
        if (_state.value.modBusy || _state.value.sniffOn || _state.value.bridgeOn || _state.value.liveMod != null) return setDtcMessage("Espera a que acabe con las otras centralitas y vuelve a probar")
        viewModelScope.launch {
            _state.update { it.copy(dtcBusy = true, dtcMessage = "Borrando averías…") }
            // Se paran los relojes mientras tanto: el borrado cambia la dirección y la sesión de diagnóstico
            pollJob?.cancelAndJoin(); pollJob = null
            try {
                val can = _state.value.protocol.contains("15765")

                // 1) OBD-II estándar
                step("Borrando averías OBD…")
                if (can) e.send("ATSH7DF")
                var r = e.send("04", 6000)
                log("Borrado OBD a todas (04): ${r.replace("\n", " ").ifEmpty { "sin respuesta" }}")
                var obdOk = Elm327.positive(r, 0x04)
                var obdNrc = Elm327.nrc(r, 0x04)
                if (can) {
                    e.send("ATSH7E0")
                    r = e.send("04", 6000)
                    log("Borrado OBD al motor (04): ${r.replace("\n", " ").ifEmpty { "sin respuesta" }}")
                    obdOk = obdOk || Elm327.positive(r, 0x04)
                    if (obdNrc == null) obdNrc = Elm327.nrc(r, 0x04)
                }

                // 2) Memoria propia de la centralita de motor
                var udsOk = false
                var udsNrc: Int? = null
                if (can) {
                    step("Borrando la memoria de la centralita…")
                    r = e.send("14FFFFFF", 8000)
                    log("Borrado memoria centralita (14FFFFFF): ${r.replace("\n", " ").ifEmpty { "sin respuesta" }}")
                    udsOk = Elm327.positive(r, 0x14)
                    udsNrc = Elm327.nrc(r, 0x14)
                    if (!udsOk && udsNrc != 0x22) {
                        val ses = e.send("1003", 3000)
                        log("Sesión ampliada (1003): ${ses.replace("\n", " ").ifEmpty { "sin respuesta" }}")
                        if (Elm327.positive(ses, 0x10)) {
                            r = e.send("14FFFFFF", 8000)
                            log("Borrado memoria centralita (14FFFFFF): ${r.replace("\n", " ").ifEmpty { "sin respuesta" }}")
                            udsOk = Elm327.positive(r, 0x14)
                            Elm327.nrc(r, 0x14)?.let { udsNrc = it }
                            e.send("1001", 3000)   // vuelta a la sesión normal
                        }
                    }
                }

                // 3) Comprobación: qué queda en cada memoria
                step("Comprobando qué ha quedado en la centralita…")
                delay(1500)
                val stored = Elm327.dtcs(e.send("03", 6000), 0x43)
                val pending = Elm327.dtcs(e.send("07", 6000), 0x47)
                val permanent = Elm327.dtcs(e.send("0A", 6000), 0x4A)
                val uds = if (can) Elm327.udsDtcs(e.send("1902FF", 6000)) else null
                val left = (stored + pending + (uds?.map { it.code } ?: emptyList())).distinct()
                val active = uds?.filter { it.active }?.map { it.code } ?: emptyList()
                val refused = !obdOk && !udsOk
                val msg = when {
                    refused && (obdNrc == 0x22 || udsNrc == 0x22) ->
                        "La centralita no deja borrar ahora (${Elm327.nrcText(0x22)}). Apaga el motor, deja el contacto puesto y vuelve a pulsar BORRAR."
                    refused && left.isNotEmpty() ->
                        "La centralita no aceptó el borrado (${Elm327.nrcText(udsNrc ?: obdNrc)}). Siguen: ${left.joinToString(" ")}. Prueba con el contacto puesto y el motor parado."
                    left.isEmpty() ->
                        "Averías borradas en la centralita. Comprobado: las memorias están vacías." +
                            if (permanent.isNotEmpty()) " Las permanentes (${permanent.joinToString(" ")}) se van solas al conducir." else ""
                    active.isNotEmpty() && active.containsAll(left) ->
                        "Borradas las resueltas. ${active.joinToString(" ")} ${if (active.size == 1) "sigue activa" else "siguen activas"}: el fallo sigue presente (revisa el conector o el sensor) y se vuelve a guardar."
                    else ->
                        "Siguen en la centralita: ${left.joinToString(" ")}. Apaga el motor, deja el contacto puesto y vuelve a borrar."
                }
                log(msg)
                _state.update {
                    it.copy(
                        dtcBusy = false, dtcMessage = msg,
                        dtcs = stored, pendingDtcs = pending, permanentDtcs = permanent, udsDtcs = uds ?: it.udsDtcs,
                        dtcReadAt = System.currentTimeMillis(),
                    )
                }
                readStatus()
                saveDtcs()
            } catch (ex: Exception) {
                _state.update { it.copy(dtcBusy = false) }
                if (elm === e) disconnect("Error borrando averías: ${ex.message}")
            } finally {
                // Los relojes vuelven a leer (sin que el vigilante crea que el coche se ha callado)
                if (elm === e && pollJob == null && _state.value.conn == Conn.CONECTADO) {
                    _state.update { it.copy(dtcBusy = false) }
                    try { if (_state.value.protocol.contains("15765")) e.send("ATSH7E0") } catch (_: Exception) { }
                    lastDataMs = System.currentTimeMillis()
                    startPolling()
                }
            }
        }
    }

    private fun setDtcMessage(m: String) = _state.update { it.copy(dtcMessage = m) }

    // ------------------------------------------------------------ Consola

    fun sendRaw(cmd: String) {
        val e = elm ?: return log("No conectado")
        viewModelScope.launch {
            try { log("> $cmd\n" + e.send(cmd.trim().uppercase(), 5000).ifEmpty { "(sin respuesta)" }) }
            catch (ex: Exception) { disconnect("Error: ${ex.message}") }
        }
    }

    // ------------------------------------------------------------ Utilidades

    private fun setStatus(s: String) { _state.update { it.copy(status = s) }; log(s) }

    private fun log(s: String) {
        val line = "${timeFmt.format(Date())}  $s"
        _state.update { it.copy(log = (it.log + line).takeLast(400)) }
        busFile?.let { w -> try { synchronized(w) { w.write(line); w.write("\n") } } catch (_: Exception) { } }
    }

    /** Mientras se habla con las otras centralitas, todo el tráfico se guarda también en un archivo (Descargas). */
    @Volatile private var busFile: java.io.Writer? = null
    private var busUri: android.net.Uri? = null

    fun shareBusLog() = shareFile(busUri, _state.value.modFile) { m -> _state.update { it.copy(modMessage = m) } }

    // ── Modo escucha ──────────────────────────────────────────────────────────────────
    // Con un cable OBD en Y, el adaptador se queda en silencio y apunta todo lo que se dicen otro aparato
    // (el Autel) y las centralitas. Sirve para ver cómo entra el Autel en el ABS y copiarlo.
    @Volatile private var sniffStop = false
    // ---- Datos del motor: leer todos los propios de VAG a un archivo (pasada 1 al ralentí, pasada 2 acelerado)

    private var engDumpUri: android.net.Uri? = null

    /**
     * Pasada 1 (ralentí): prueba 22 1000–2FFF uno a uno y apunta los que contestan, con sus bytes. Guarda la lista.
     * Pasada 2 (a unas 2.500 rpm): vuelve a leer solo los de la lista (mucho más rápido). Comparando las dos se ve
     * qué dato es cada uno (inyección, hollín del filtro, correcciones de inyectores…). Solo lectura.
     */
    fun dumpEngine(pass: Int) {
        val e = elm ?: return _state.update { it.copy(engDumpMessage = "Conecta primero con el coche") }
        val s0 = _state.value
        if (s0.demo) return _state.update { it.copy(engDumpMessage = "No funciona en el modo demo") }
        if (s0.engDumpProgress != null || s0.boostScanProgress != null || s0.oilScanProgress != null || s0.modBusy || s0.dtcBusy || s0.sniffOn || s0.bridgeOn || s0.liveMod != null)
            return _state.update { it.copy(engDumpMessage = "Espera a que acabe lo que está haciendo y vuelve a probar") }
        val saved = (prefs.getString("engDids", "") ?: "").split(",").mapNotNull { it.trim().toIntOrNull(16) }
        if (pass == 2 && saved.isEmpty()) return _state.update { it.copy(engDumpMessage = "Haz primero la pasada 1, al ralentí") }
        val order = if (pass == 2) saved else (0x1000..0x2FFF).toList()
        _state.update { it.copy(engDumpProgress = 0f, engDumpMessage = "Preparando…") }
        viewModelScope.launch {
            pollJob?.cancelAndJoin(); pollJob = null
            var out: java.io.OutputStream? = null
            var hung = false
            try {
                val name = "obd-motor-pasada$pass-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".txt"
                val (o, where, uri) = newDownload(name)
                out = o; engDumpUri = uri
                _state.update { it.copy(engDumpFile = where) }
                fun w(t: String) { o.write((t + "\n").toByteArray()) }
                w("# OBD Ibiza · datos del motor · pasada $pass (" + (if (pass == 1) "ralentí" else "acelerado") + ") · " + Date())
                w("# Cada línea: identificador = bytes. Las líneas # rpm son las revoluciones en ese momento")
                e.send("ATST 20")
                var found = 0
                val list = mutableListOf<Int>()
                var silent = 0
                for ((i, did) in order.withIndex()) {
                    if (elm !== e || _state.value.engDumpProgress == null) break
                    if (i % 64 == 0) {
                        Elm327.mode01(e.send("010C", 1000), 0x0C)?.let { r ->
                            val rpm = (r[0] * 256 + r.getOrElse(1) { 0 }) / 4.0
                            w("# rpm %.0f".format(Locale.US, rpm))
                            applyValues(mapOf("rpm" to rpm))
                        }
                        lastDataMs = System.currentTimeMillis()
                    }
                    val r = e.send("22%04X".format(did), 500)
                    if (r.isBlank()) { if (++silent >= 25) { hung = true; break } } else silent = 0
                    val d = Elm327.mode22(r, did)
                    if (d != null) {
                        found++; list += did
                        w("%04X = %s".format(did, d.joinToString(" ") { b -> "%02X".format(b) }))
                    }
                    if (i % 32 == 0) _state.update { it.copy(engDumpProgress = i / order.size.toFloat(), engDumpMessage = "Leyendo… $found datos") }
                }
                w("# fin: $found datos")
                val complete = _state.value.engDumpProgress != null && !hung
                if (pass == 1 && complete && list.isNotEmpty()) prefs.edit().putString("engDids", list.joinToString(",") { "%04X".format(it) }).apply()
                _state.update {
                    it.copy(
                        engDumpMessage = when {
                            hung -> "El adaptador dejó de contestar ($found datos leídos). Comparte lo que hay."
                            !complete -> "Parada a mano: $found datos. Comparte lo que hay."
                            pass == 1 -> "Pasada 1 hecha: $found datos. Ahora mantén unas 2.500 vueltas parada y haz la pasada 2."
                            else -> "Pasada 2 hecha: $found datos. Pulsa COMPARTIR y mándame los dos archivos."
                        },
                    )
                }
            } catch (ex: Exception) {
                _state.update { it.copy(engDumpMessage = "Error: ${ex.message ?: ex.javaClass.simpleName}") }
            } finally {
                try { out?.close() } catch (_: Exception) { }
                try { if (elm === e && !hung) e.send("ATST 32") } catch (_: Exception) { }
                _state.update { it.copy(engDumpProgress = null) }
                if (elm === e && pollJob == null && _state.value.conn == Conn.CONECTADO) {
                    lastDataMs = System.currentTimeMillis()
                    if (hung) recoverInPlace() else startPolling()
                }
            }
        }
    }

    fun stopEngineDump() = _state.update { it.copy(engDumpProgress = null) }

    fun shareEngineDump() = shareFile(engDumpUri, _state.value.engDumpFile) { m -> _state.update { it.copy(engDumpMessage = m) } }

    private var sniffUri: android.net.Uri? = null

    fun startSniff() {
        val e = elm ?: return _state.update { it.copy(sniffMessage = "Conecta primero con el coche") }
        val s0 = _state.value
        if (s0.sniffOn || s0.bridgeOn) return
        if (s0.modBusy || s0.dtcBusy) return _state.update { it.copy(sniffMessage = "Espera a que acabe lo que está haciendo y vuelve a probar") }
        stopLive()
        sniffStop = false
        viewModelScope.launch {
            _state.update { it.copy(sniffOn = true, sniffFrames = 0, sniffIds = 0, sniffSecs = 0, sniffMessage = "Preparando…", sniffFile = "") }
            pollJob?.cancelAndJoin(); pollJob = null
            val app = getApplication<Application>()
            val name = "obd-escucha-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".txt"
            var out: java.io.OutputStream? = null
            var where = ""
            sniffUri = null
            try {
                // En Descargas (Android 10 o más, sin pedir permisos); si no se puede, en la carpeta de la app
                if (Build.VERSION.SDK_INT >= 29) {
                    val cv = android.content.ContentValues().apply {
                        put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name)
                        put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                        put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri = app.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                    if (uri != null) {
                        out = app.contentResolver.openOutputStream(uri)
                        if (out != null) { sniffUri = uri; where = "Descargas / $name" }
                    }
                }
                if (out == null) {
                    val f = java.io.File(app.getExternalFilesDir(null) ?: app.filesDir, name)
                    out = java.io.FileOutputStream(f)
                    where = f.absolutePath
                }
            } catch (ex: Exception) {
                _state.update { it.copy(sniffOn = false, sniffMessage = "No se pudo crear el archivo: ${ex.message ?: ex.javaClass.simpleName}") }
                if (elm === e && pollJob == null && _state.value.conn == Conn.CONECTADO) { lastDataMs = System.currentTimeMillis(); startPolling() }
                return@launch
            }
            val w = out!!.bufferedWriter(Charsets.UTF_8)
            val t0 = System.currentTimeMillis()
            val ids = HashSet<String>()
            var frames = 0
            var lastUi = 0L
            var endedWith = ""
            fun tooLong() = System.currentTimeMillis() - t0 > SNIFF_MAX_MS || frames > SNIFF_MAX_FRAMES
            try {
                w.write("# OBD Ibiza · modo escucha · ${Date()}\n")
                w.write("# Coche: Seat Ibiza 6J 2.0 TDI CFHD · adaptador: ${_state.value.adapter}\n")
                w.write("# Cada línea: milisegundos desde el inicio, identificador CAN, longitud y bytes\n")
                // Silencio total (ATCSM1: no confirma nada ni manda nada), sin filtro, con cabecera y longitud
                for (c in listOf("ATCAF0", "ATCRA", "ATH1", "ATD1", "ATS1", "ATCSM1")) e.send(c, 1500)
                _state.update { it.copy(sniffMessage = "Escuchando · entra ahora con el Autel en el ABS") }
                var cmd = "STMA"
                var rounds = 0
                while (!sniffStop && !tooLong() && rounds++ < 100) {
                    val ended = e.monitor(cmd, { line ->
                        val ms = System.currentTimeMillis() - t0
                        w.write("$ms $line\n")
                        frames++
                        line.substringBefore(' ').takeIf { it.length == 3 }?.let { ids += it }
                    }, {
                        val ms = System.currentTimeMillis() - t0
                        if (ms - lastUi > 500) {
                            lastUi = ms
                            _state.update { it.copy(sniffFrames = frames, sniffIds = ids.size, sniffSecs = (ms / 1000).toInt()) }
                        }
                        sniffStop || tooLong()
                    }) ?: break
                    w.write("# ${System.currentTimeMillis() - t0} el adaptador dice: $ended\n")
                    if (ended.trim() == "?" && cmd == "STMA") { cmd = "ATMA"; continue }   // ELM sin órdenes ST
                    endedWith = ended
                    // BUFFER FULL u otro corte: se vuelve a escuchar enseguida
                }
                if (tooLong()) endedWith = "se paró solo al llegar al máximo"
            } catch (ex: Exception) {
                endedWith = "error: ${ex.message ?: ex.javaClass.simpleName}"
                try { w.write("# error: $endedWith\n") } catch (_: Exception) { }
            } finally {
                try { w.flush(); w.close() } catch (_: Exception) { }
                try {
                    for (c in listOf("ATS0", "ATH0", "ATD0", "ATCAF1", "ATCRA")) e.send(c, 1500)
                    if (_state.value.protocol.contains("15765")) e.send("ATSH7E0", 1500)
                } catch (_: Exception) { }
                val secs = ((System.currentTimeMillis() - t0) / 1000).toInt()
                _state.update {
                    it.copy(
                        sniffOn = false, sniffFrames = frames, sniffIds = ids.size, sniffSecs = secs, sniffFile = where,
                        sniffMessage = (if (frames == 0) "No ha llegado nada. ¿Está el Autel conectado y hablando con el coche?" else "Grabado: $frames tramas de ${ids.size} identificadores en ${secs / 60} min ${secs % 60} s") +
                            (if (endedWith.isNotBlank()) " · $endedWith" else ""),
                    )
                }
                event("Modo escucha: $frames tramas guardadas")
                if (elm === e && pollJob == null && _state.value.conn == Conn.CONECTADO) { lastDataMs = System.currentTimeMillis(); startPolling() }
            }
        }
    }

    fun stopSniff() { sniffStop = true }

    /** Mandar la grabación (WhatsApp, Drive, correo… lo que haya en la pantalla). */
    fun shareSniff() {
        val uri = sniffUri ?: return _state.update { it.copy(sniffMessage = "Este archivo no se puede compartir desde aquí: cógelo de ${it.sniffFile}") }
        try {
            val app = getApplication<Application>()
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            app.startActivity(Intent.createChooser(send, "Mandar la grabación").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (ex: Exception) {
            _state.update { it.copy(sniffMessage = "No hay ninguna app para compartir en la pantalla. El archivo está en ${it.sniffFile}") }
        }
    }

    // ── Modo puente ───────────────────────────────────────────────────────────────────
    // Esta app se hace pasar por un adaptador wifi (como los ELM327 wifi: 192.168.0.10:35000). Car Scanner
    // se conecta a 127.0.0.1:35000, sus órdenes van por aquí a tu cable USB y se apunta todo: así se ve
    // exactamente cómo entra Car Scanner en el ABS y las demás centralitas.
    @Volatile private var bridgeStop = false
    @Volatile private var bridgeServer: java.net.ServerSocket? = null
    private var bridgeUri: android.net.Uri? = null

    private fun localAddrs(): String = try {
        val ips = java.net.NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .filter { it is java.net.Inet4Address && !it.isLoopbackAddress }
            .map { it.hostAddress ?: "" }.filter { it.isNotBlank() }
        (listOf("127.0.0.1") + ips).joinToString(" · ")
    } catch (_: Exception) { "127.0.0.1" }

    /** Crea un archivo de texto en Descargas (o en la carpeta de la app). Devuelve (salida, dónde, uri). */
    private fun newDownload(name: String): Triple<java.io.OutputStream, String, android.net.Uri?> {
        val app = getApplication<Application>()
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = app.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            val o = uri?.let { app.contentResolver.openOutputStream(it) }
            if (uri != null && o != null) return Triple(o, "Descargas / $name", uri)
        }
        val f = java.io.File(app.getExternalFilesDir(null) ?: app.filesDir, name)
        return Triple(java.io.FileOutputStream(f), f.absolutePath, null)
    }

    fun startBridge() {
        val e = elm ?: return _state.update { it.copy(bridgeMessage = "Conecta primero con el coche") }
        val s0 = _state.value
        if (s0.bridgeOn) return
        if (s0.demo) return _state.update { it.copy(bridgeMessage = "No funciona en el modo demo") }
        if (s0.modBusy || s0.dtcBusy || s0.sniffOn) return _state.update { it.copy(bridgeMessage = "Espera a que acabe lo que está haciendo y vuelve a probar") }
        stopLive()
        bridgeStop = false
        viewModelScope.launch {
            _state.update { it.copy(bridgeOn = true, bridgeClient = false, bridgeCmds = 0, bridgeSecs = 0, bridgeFile = "", bridgeAddr = localAddrs(), bridgeMessage = "Preparando…") }
            pollJob?.cancelAndJoin(); pollJob = null
            val name = "obd-puente-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".txt"
            val (out, where, uri) = try { newDownload(name) } catch (ex: Exception) {
                _state.update { it.copy(bridgeOn = false, bridgeMessage = "No se pudo crear el archivo: ${ex.message ?: ex.javaClass.simpleName}") }
                if (elm === e && pollJob == null && _state.value.conn == Conn.CONECTADO) { lastDataMs = System.currentTimeMillis(); startPolling() }
                return@launch
            }
            bridgeUri = uri
            val w = out.bufferedWriter(Charsets.UTF_8)
            val t0 = System.currentTimeMillis()
            var cmds = 0
            var endedWith = ""
            val txBuf = StringBuilder()
            val rxBuf = StringBuilder()
            val wLock = Object()
            fun ms() = System.currentTimeMillis() - t0
            // Se apunta línea a línea: "> orden" lo que manda Car Scanner, "< respuesta" lo que contesta el cable
            fun traffic(fromApp: Boolean, chunk: String) = synchronized(wLock) {
                val buf = if (fromApp) txBuf else rxBuf
                for (c in chunk) {
                    when (c) {
                        '\r', '\n' -> {
                            val l = buf.toString().trim(); buf.setLength(0)
                            if (l.isNotEmpty()) { w.write("${ms()} ${if (fromApp) ">" else "<"} $l\n"); if (fromApp) cmds++ }
                        }
                        '>' -> if (!fromApp) {
                            val l = buf.toString().trim(); buf.setLength(0)
                            if (l.isNotEmpty()) w.write("${ms()} < $l\n")
                            w.write("${ms()} < [>]\n")
                        } else buf.append(c)
                        else -> buf.append(c)
                    }
                }
            }
            try {
                w.write("# OBD Ibiza · modo puente · ${Date()}\n")
                w.write("# Coche: Seat Ibiza 6J 2.0 TDI CFHD · adaptador: ${_state.value.adapter}\n")
                w.write("# Cada línea: milisegundos desde el inicio, > lo que manda la otra app, < lo que contesta el cable\n")
                val server = java.net.ServerSocket()
                server.reuseAddress = true
                server.bind(java.net.InetSocketAddress(BRIDGE_PORT))
                server.soTimeout = 1000
                bridgeServer = server
                _state.update { it.copy(bridgeMessage = "Esperando a Car Scanner · pon IP 127.0.0.1 y puerto $BRIDGE_PORT") }
                while (!bridgeStop && System.currentTimeMillis() - t0 < BRIDGE_MAX_MS) {
                    val sock = try {
                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { server.accept() }
                    } catch (_: java.net.SocketTimeoutException) {
                        _state.update { it.copy(bridgeSecs = (ms() / 1000).toInt()) }
                        continue
                    } catch (ex: Exception) {
                        if (bridgeStop) break else throw ex
                    }
                    sock.tcpNoDelay = true
                    synchronized(wLock) { w.write("# ${ms()} conecta ${sock.inetAddress?.hostAddress}\n") }
                    _state.update { it.copy(bridgeClient = true, bridgeMessage = "Car Scanner conectado · entra en el ABS y en la electrónica central") }
                    var lastUi = 0L
                    try {
                        e.pipe(sock.getInputStream(), sock.getOutputStream(), { a, b -> traffic(a, b) }) {
                            val now = ms()
                            if (now - lastUi > 500) {
                                lastUi = now
                                _state.update { it.copy(bridgeCmds = cmds, bridgeSecs = (now / 1000).toInt()) }
                            }
                            bridgeStop || now > BRIDGE_MAX_MS
                        }
                    } finally {
                        try { sock.close() } catch (_: Exception) { }
                    }
                    synchronized(wLock) { w.write("# ${ms()} se desconecta\n"); w.flush() }
                    _state.update { it.copy(bridgeClient = false, bridgeCmds = cmds, bridgeMessage = "Car Scanner se ha desconectado · esperando a que vuelva (o pulsa PARAR)") }
                }
                if (System.currentTimeMillis() - t0 >= BRIDGE_MAX_MS) endedWith = "se paró solo a los 30 minutos"
            } catch (ex: Exception) {
                endedWith = "error: ${ex.message ?: ex.javaClass.simpleName}"
                try { synchronized(wLock) { w.write("# $endedWith\n") } } catch (_: Exception) { }
            } finally {
                try { bridgeServer?.close() } catch (_: Exception) { }
                bridgeServer = null
                try { synchronized(wLock) { w.flush(); w.close() } } catch (_: Exception) { }
                val secs = (ms() / 1000).toInt()
                _state.update {
                    it.copy(
                        bridgeOn = false, bridgeClient = false, bridgeCmds = cmds, bridgeSecs = secs, bridgeFile = where,
                        bridgeMessage = (if (cmds == 0) "No ha llegado nada de Car Scanner." else "Grabado: $cmds órdenes en ${secs / 60} min ${secs % 60} s") +
                            (if (endedWith.isNotBlank()) " · $endedWith" else ""),
                    )
                }
                event("Modo puente: $cmds órdenes guardadas")
                // Car Scanner ha cambiado los ajustes del adaptador (ATZ, protocolos…): se vuelve a preparar entero
                if (elm === e && _state.value.conn == Conn.CONECTADO) recoverInPlace()
            }
        }
    }

    fun stopBridge() {
        bridgeStop = true
        try { bridgeServer?.close() } catch (_: Exception) { }
    }

    fun shareBridge() = shareFile(bridgeUri, _state.value.bridgeFile) { m -> _state.update { it.copy(bridgeMessage = m) } }

    private fun shareFile(uri: android.net.Uri?, where: String, msg: (String) -> Unit) {
        if (uri == null) return msg("Este archivo no se puede compartir desde aquí: cógelo de $where")
        try {
            val app = getApplication<Application>()
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            app.startActivity(Intent.createChooser(send, "Mandar la grabación").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (_: Exception) {
            msg("No hay ninguna app para compartir en la pantalla. El archivo está en $where")
        }
    }

    override fun onCleared() {
        disconnect()
        limits.stop()
        tones.values.forEach { try { it.release() } catch (_: Exception) { } }
        try { getApplication<Application>().unregisterReceiver(receiver) } catch (_: Exception) { }
    }

    companion object {
        /** Temperatura de aceite del motor: UDS 22 11 BE, (A·256+B−2731)/10 °C. */
        /** (parámetro, identificador UDS 22, tipo): 'T' = décimas de kelvin → °C; 'D' = décimas (bar). */
        val UDS_EXTRA = listOf(
            Triple("rail", 0x1169, 'D'),
            Triple("railreq", 0x116A, 'D'),
            Triple("iatg42", 0x1628, 'T'),
            Triple("iatmaf", 0x1625, 'T'),
            Triple("exhT", 0x1630, 'T'),
            Triple("exhA", 0x1561, 'T'),
            Triple("exhB", 0x1564, 'T'),
        )
        const val OIL_DID = "11BE"
        const val OIL_FORMULA = 1
        const val OIL_DID_FIXED = 0x11BE
        const val OIL_SOURCE = "Centralita de motor · 22 11 BE (fijo)"
        const val HISTORY = 600
        const val ACTION_PERMISSION = "com.ikker.obdibiza.USB_PERMISSION"
        /** Cuántos datos se piden a la vez en una sola petición. */
        const val BATCH = 4
        /** Si el coche no da ningún dato en este tiempo se reinicia la conexión. */
        const val NO_DATA_MS = 15_000L
        /** Modo escucha: como mucho 15 minutos o 400.000 tramas por grabación. */
        const val SNIFF_MAX_MS = 15 * 60_000L
        const val SNIFF_MAX_FRAMES = 400_000
        /** Modo puente: el puerto de los adaptadores ELM327 wifi, y como mucho 30 minutos. */
        const val BRIDGE_PORT = 35000
        const val BRIDGE_MAX_MS = 30 * 60_000L
        const val CONNECTING_MAX_MS = 60_000L
        /** Presión real del turbo de este coche (encontrada y comprobada conduciendo). */
        const val FIXED_BOOST_DID = 0x1149
        /** Pausa mínima entre soltar el USB y volver a abrirlo en los reintentos automáticos. */
        const val REOPEN_GAP_MS = 2_500L
    }
}

// ═══════════════════════════════════════════════════════════════════ Límite de velocidad (GPS + OpenStreetMap)

/** Lo que el vigilante del límite cuenta a la app en cada posición nueva. */
data class LimitUpdate(
    val status: String,
    val kmh: Int?,
    val estimated: Boolean,
    val road: String,
    val gpsKmh: Double?,
    val permission: Boolean,
    /** Resumen del mapa guardado ("312 zonas · 14,2 MB"). */
    val saved: String,
    /** Descarga de la zona: progreso 0..1 (null = parada) y texto. */
    val regionProgress: Float?,
    val regionText: String,
    /** Radar por delante: distancia en metros (null = ninguno) y su límite si se conoce. */
    val radarM: Double? = null,
    val radarKmh: Int? = null,
    val radarCount: Int = 0,
    val radarTramo: Boolean = false,
    /** Radares añadidos a mano y distancia al radar más cercano en cualquier dirección. */
    val radarMine: Int = 0,
    val radarNearestM: Double? = null,
    val myRadars: List<Radar> = emptyList(),
    /** El límite enseñado es una corrección tuya. */
    val corrected: Boolean = false,
    val fixCount: Int = 0,
    /** Última actualización del mapa por wifi (texto). */
    val updated: String = "",
)

fun UiState.opt(k: AlertKey): Int = alerts[k] ?: k.def

/** Límite que se enseña en el reloj. En el modo demo, sin GPS, se enseña 50 de ejemplo. */
fun UiState.shownLimit(): Int? = when {
    !limitOn -> null
    speedLimit != null && limitEstimated && opt(AlertKey.LIMIT_EST) == 0 -> null   // aproximados ocultos
    else -> speedLimit ?: if (demo) 50 else null
}

/** Hay un radar por delante y los avisos de radar están puestos. */
fun UiState.radarAlert(): Boolean = radarM != null && opt(AlertKey.RADAR_ON) == 1

/** Velocidad para comparar con el límite: la del coche si está conectado; si no, la del GPS. */
fun UiState.limitSpeed(): Double? = if (conn == Conn.CONECTADO) values["speed"] ?: gpsSpeed else gpsSpeed

/** ¿Vas por encima del límite más el margen elegido? */
fun UiState.overLimit(): Boolean {
    // Con un radar delante y sin límite de la vía, manda el límite del radar
    val l = shownLimit() ?: (if (radarAlert()) radarKmh else null) ?: return false
    val v = limitSpeed() ?: return false
    return v > l + limitMargin
}

/**
 * Lee la posición del GPS de la pantalla y busca el límite de la vía en el mapa guardado en la propia
 * pantalla (teselas de OpenStreetMap). Funciona sin internet en las zonas descargadas. Si se pasa por una
 * zona que no está guardada y hay internet, la descarga y la guarda para siempre.
 */
class SpeedLimitWatcher(
    private val ctx: Context,
    private val scope: kotlinx.coroutines.CoroutineScope,
    private val log: (String) -> Unit,
    private val onUpdate: (LimitUpdate) -> Unit,
) {
    private val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
    private val prefs = ctx.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
    private val dir = java.io.File(ctx.filesDir, "limites").apply { mkdirs() }
    /** Mapa que viene dentro de la app (Comunitat Valenciana): funciona nada más instalarla, sin internet. */
    private val builtIn: Set<String> = try { ctx.assets.list("limites")?.toSet() ?: emptySet() } catch (_: Exception) { emptySet() }
    /** Radares fijos del mapa integrado. */
    private val radars: List<Radar> = try {
        ctx.assets.open("radares.csv").use { Radars.parse(it.bufferedReader().readText()) }
    } catch (_: Exception) { emptyList() }
    /** Radares añadidos a mano (se guardan para siempre). */
    private var mine: List<Radar> = Radars.decodeMine(prefs.getString("misRadares", null))
    private val allRadars: List<Radar> get() = radars + mine
    private var posLat: Double? = null
    private var posLon: Double? = null
    private var nearestM: Double? = null
    /** Distancia a la que se avisa de un radar (0 = avisos de radar apagados). */
    var radarMaxM = 1000.0
    /** Descargar solas, con internet, las zonas que no estén guardadas. */
    var autoFetch = true
    /** Con wifi, actualizar solas las zonas de alrededor que tengan más de un mes. */
    var wifiUpdate = true
    private var wifiJob: Job? = null
    /** Correcciones del límite hechas a mano (se guardan para siempre). */
    private var fixes: List<LimitFix> = LimitFixes.decode(prefs.getString("limitFixes", null))
    private var lastWay: OsmWay? = null
    private var lastLat = 0.0
    private var lastLon = 0.0
    private var radar: RadarAhead? = null
    private var running = false

    // Teselas cargadas en memoria (las últimas usadas) y las que se están cargando o descargando
    private val mem = LinkedHashMap<Long, List<OsmWay>>(16, 0.75f, true)
    private val busy = HashSet<Long>()
    private var activeKeys: List<Long> = emptyList()
    private var ways: List<OsmWay> = emptyList()
    private var dirty = true

    // Red
    private val net = kotlinx.coroutines.sync.Mutex()
    private var fails = 0
    private var retryAt = 0L
    private var endpoint = 0
    private var lastError = ""

    // Posición
    private var staleJob: Job? = null
    private var lastGpsMs = 0L
    private var lastFixMs = 0L
    private var bearing: Double? = null
    private var gpsKmh: Double? = null
    private var current: LimitInfo? = null
    private var currentMs = 0L
    private var status = ""

    // Descarga de zona y resumen del mapa guardado
    private var regionJob: Job? = null
    private var regionProgress: Float? = null
    private var regionText = ""
    private var saved = ""

    private val listener = object : android.location.LocationListener {
        override fun onLocationChanged(loc: android.location.Location) = onFix(loc)
        override fun onProviderEnabled(provider: String) { }
        override fun onProviderDisabled(provider: String) { }
        @Deprecated("Solo para Android antiguo")
        override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) { }
    }

    init { refreshSaved() }

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED

    private fun gpsOn(): Boolean = try { lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER) } catch (_: Exception) { false }

    private fun emit(st: String = status) {
        status = st
        val c = current
        onUpdate(
            LimitUpdate(
                st, c?.kmh, c?.estimated ?: false, c?.road ?: "", gpsKmh, hasPermission(),
                saved, regionProgress, regionText, radar?.distM, radar?.radar?.kmh, radars.size,
                radar?.radar?.tramo ?: false, mine.size, nearestM, mine,
                c?.corrected ?: false, fixes.size, updatedText(),
            ),
        )
    }

    fun start() {
        if (!hasPermission()) { emit("Falta el permiso de ubicación · pulsa DAR PERMISO"); return }
        if (running) return
        try {
            val providers = lm.allProviders
            var any = false
            if (android.location.LocationManager.GPS_PROVIDER in providers) {
                lm.requestLocationUpdates(android.location.LocationManager.GPS_PROVIDER, 1000L, 0f, listener, android.os.Looper.getMainLooper())
                any = true
            }
            if (android.location.LocationManager.NETWORK_PROVIDER in providers) {
                lm.requestLocationUpdates(android.location.LocationManager.NETWORK_PROVIDER, 2000L, 0f, listener, android.os.Looper.getMainLooper())
                any = true
            }
            if (!any) { emit("Esta pantalla no tiene GPS"); return }
            running = true
            log("Límite de velocidad: GPS en marcha")
            emit(if (gpsOn()) "Buscando señal GPS…" else "Activa la ubicación (GPS) en los ajustes de la pantalla")
            wifiJob?.cancel()
            wifiJob = scope.launch {
                delay(60_000)
                while (isActive) {
                    if (wifiUpdate && onWifi() && regionJob?.isActive != true) refreshOld(25)
                    delay(15 * 60_000L)
                }
            }
            staleJob?.cancel()
            staleJob = scope.launch {
                while (isActive) {
                    delay(2000)
                    if (running && System.currentTimeMillis() - lastFixMs > 10_000) {
                        current = null; gpsKmh = null; radar = null
                        emit(if (gpsOn()) "Sin señal GPS…" else "Activa la ubicación (GPS) en los ajustes de la pantalla")
                    }
                }
            }
        } catch (ex: SecurityException) {
            emit("Falta el permiso de ubicación · pulsa DAR PERMISO")
        } catch (ex: Exception) {
            emit("No se pudo usar el GPS: ${ex.message}")
        }
    }

    fun stop() {
        running = false
        try { lm.removeUpdates(listener) } catch (_: Exception) { }
        staleJob?.cancel(); staleJob = null
        wifiJob?.cancel(); wifiJob = null
        current = null; gpsKmh = null
        emit("Apagado")
    }

    // ------------------------------------------------------------ Posición nueva

    private fun onFix(loc: android.location.Location) {
        if (!running) return
        val now = System.currentTimeMillis()
        val isGps = loc.provider == android.location.LocationManager.GPS_PROVIDER
        if (!isGps && now - lastGpsMs < 5000) return   // con GPS de verdad no se usa la posición por red
        if (isGps) lastGpsMs = now
        lastFixMs = now
        if (loc.hasAccuracy() && loc.accuracy > 50f) {
            emit("Señal GPS débil (±${loc.accuracy.toInt()} m)…")
            return
        }
        gpsKmh = if (loc.hasSpeed()) loc.speed * 3.6 else null
        if (loc.hasBearing() && loc.hasSpeed() && loc.speed > 2.5f) bearing = loc.bearing.toDouble()
        val lat = loc.latitude
        val lon = loc.longitude
        if (isGps) prefs.edit().putString("lastLat", lat.toString()).putString("lastLon", lon.toString()).apply()

        // Radar por delante (no depende del mapa de calles)
        posLat = lat; posLon = lon
        radar = if (radarMaxM > 0) Radars.ahead(allRadars, lat, lon, if ((gpsKmh ?: 0.0) > 8) bearing else null, radarMaxM) else null
        nearestM = Radars.nearest(allRadars, lat, lon)?.distM?.takeIf { it < 50_000 }

        val keys = LimitTiles.around(lat, lon, 400.0)
        // La que toca ahora y, de paso, las de alrededor para cuando llegues
        ensureTiles(keys)
        ensureTiles(LimitTiles.around(lat, lon, 2500.0).filter { it !in keys })
        if (dirty || keys != activeKeys) {
            activeKeys = keys
            ways = keys.flatMap { mem[it] ?: emptyList() }.distinctBy { it.id }
            dirty = false
        }
        val ready = keys.all { it in mem }
        if (!ready && ways.isEmpty()) {
            current = null
            emit(
                when {
                    keys.any { it in busy } -> "Cargando el mapa de esta zona…"
                    else -> "Zona sin descargar y sin internet. Descárgala abajo con wifi" + if (lastError.isNotEmpty()) " ($lastError)" else ""
                },
            )
            return
        }
        val m = SpeedLimits.match(ways, lat, lon, bearing, current?.wayId)
        if (m != null) {
            current = LimitFixes.apply(SpeedLimits.limitFor(m), m.way, lat, lon, fixes)
            currentMs = now
            lastWay = m.way; lastLat = lat; lastLon = lon
        }
        else if (now - currentMs > 6000) current = null   // un cruce o un túnel: se aguanta el último un momento
        emit(
            when {
                current == null -> "No reconozco la vía por la que vas"
                current?.kmh == null -> "Esta vía no tiene límite en el mapa"
                else -> "Funcionando sin internet (mapa guardado)"
            },
        )
    }

    /** Carga del disco (o descarga, si no está y hay internet) las teselas que falten en memoria. */
    private fun ensureTiles(keys: List<Long>) {
        val now = System.currentTimeMillis()
        for (k in keys) {
            if (k in mem || k in busy) continue
            val file = java.io.File(dir, LimitTiles.fileName(k))
            if (!file.exists() && file.name !in builtIn && (now < retryAt || !autoFetch)) continue
            busy += k
            scope.launch {
                val w = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    readTile(file) ?: fetchAndSave(k, file)
                }
                busy -= k
                if (w != null) {
                    mem[k] = w
                    while (mem.size > 16) mem.remove(mem.keys.first())
                    dirty = true
                }
            }
        }
    }

    /** Lee una tesela: primero la descargada (más nueva) y, si no, la que viene dentro de la app. */
    private fun readTile(file: java.io.File): List<OsmWay>? {
        if (file.exists()) {
            val w = try { file.inputStream().use { LimitTiles.read(it)?.first } } catch (_: Exception) { null }
            if (w != null) return w
        }
        if (file.name in builtIn) {
            return try { ctx.assets.open("limites/" + file.name).use { LimitTiles.read(it)?.first } } catch (_: Exception) { null }
        }
        return null
    }

    /** Descarga una tesela de OpenStreetMap y la guarda. Una descarga cada vez, para no saturar el servidor. */
    private suspend fun fetchAndSave(k: Long, file: java.io.File): List<OsmWay>? = net.withLock {
        if (file.exists() || file.name in builtIn) readTile(file)?.let { return@withLock it }
        if (System.currentTimeMillis() < retryAt) return@withLock null
        val w = download(k)
        if (w == null) {
            fails++
            retryAt = System.currentTimeMillis() + minOf(5000L * fails, 60_000L)
            if (fails <= 3 || fails % 10 == 0) log("Límites: no se pudo descargar ($lastError)")
            return@withLock null
        }
        fails = 0; lastError = ""
        try {
            val tmp = java.io.File(file.path + ".tmp")
            tmp.outputStream().use { LimitTiles.write(it, w) }
            tmp.renameTo(file)
        } catch (ex: Exception) {
            log("Límites: no se pudo guardar la zona (${ex.message})")
        }
        refreshSaved()
        w
    }

    // ------------------------------------------------------------ Descargar una zona entera (con wifi)

    /** Descarga y guarda todas las teselas a menos de [km] de la última posición conocida. */
    fun downloadRegion(km: Int, force: Boolean = false) {
        if (regionJob?.isActive == true) return
        val lat = prefs.getString("lastLat", null)?.toDoubleOrNull()
        val lon = prefs.getString("lastLon", null)?.toDoubleOrNull()
        if (lat == null || lon == null) {
            regionText = "Todavía no hay posición GPS. Espera a que el estado diga que hay señal y vuelve a pulsar."
            emit(); return
        }
        regionJob = scope.launch {
            val all = LimitTiles.inRadius(lat, lon, km.toDouble())
            val todo = if (force) all else all.filter { LimitTiles.fileName(it).let { n -> n !in builtIn && !java.io.File(dir, n).exists() } }
            if (todo.isEmpty()) {
                regionText = "Ya tienes guardados los $km km alrededor."
                regionProgress = null; emit(); return@launch
            }
            log("Límites: descargando ${todo.size} zonas ($km km alrededor)")
            retryAt = 0; fails = 0
            var ok = 0
            var row = 0
            for ((i, k) in todo.withIndex()) {
                if (!isActive) break
                regionProgress = i / todo.size.toFloat()
                regionText = "Descargando ${i + 1} de ${todo.size}… Deja la pantalla encendida y con wifi."
                emit()
                val file = java.io.File(dir, LimitTiles.fileName(k))
                retryAt = 0
                if (force) file.delete()
                val w = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { fetchAndSave(k, file) }
                if (w != null) { ok++; row = 0; mem.remove(k); dirty = true } else if (++row >= 5) {
                    regionText = "Parado: no se puede descargar ($lastError). Comprueba el wifi y vuelve a pulsar: sigue donde se quedó."
                    break
                }
                delay(800)   // sin prisa: el servidor es gratuito y compartido
            }
            regionProgress = null
            if (ok > 0) prefs.edit().putLong("mapUpdatedAt", System.currentTimeMillis()).apply()
            if (row < 5) regionText = if (ok == todo.size) (if (force) "Actualizado: $km km alrededor con el mapa de hoy." else "Listo: $km km alrededor guardados. Ya funciona sin internet.")
            else "Descargadas $ok de ${todo.size}. Vuelve a pulsar para terminar."
            refreshSaved(); emit()
            log("Límites: $regionText")
        }
    }

    fun stopRegion() {
        regionJob?.cancel(); regionJob = null
        regionProgress = null
        regionText = "Descarga parada. Al volver a pulsar sigue donde se quedó."
        emit()
    }

    /**
     * Importa un mapa preparado (un .zip con teselas t_X_Y.bin). Se copian a la pantalla y desde ese
     * momento esas zonas funcionan sin internet.
     */
    fun importMap(uri: android.net.Uri) {
        if (regionJob?.isActive == true) return
        regionJob = scope.launch {
            regionProgress = 0f
            regionText = "Importando el mapa…"
            emit()
            val names = Regex("t_-?\\d+_-?\\d+\\.bin")
            var count = 0
            var error: String? = null
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                try {
                    val ins = ctx.contentResolver.openInputStream(uri) ?: throw java.io.IOException("no se puede abrir el archivo")
                    java.util.zip.ZipInputStream(java.io.BufferedInputStream(ins)).use { z ->
                        while (true) {
                            val e = z.nextEntry ?: break
                            val name = e.name.substringAfterLast('/')
                            if (!e.isDirectory && names.matches(name)) {
                                val tmp = java.io.File(dir, "$name.tmp")
                                tmp.outputStream().use { z.copyTo(it) }
                                // Solo se acepta si se puede leer
                                if (tmp.inputStream().use { LimitTiles.read(it) } != null) {
                                    tmp.renameTo(java.io.File(dir, name)); count++
                                } else tmp.delete()
                                if (count % 50 == 0) { regionText = "Importando… $count zonas"; emit() }
                            }
                        }
                    }
                } catch (ex: Exception) {
                    error = ex.message ?: ex.javaClass.simpleName
                }
            }
            mem.clear(); dirty = true
            regionProgress = null
            regionText = when {
                count > 0 -> "Mapa importado: $count zonas. Ya funciona sin internet en toda esa zona."
                error != null -> "No se pudo importar: $error"
                else -> "Ese archivo no es un mapa de la app."
            }
            log("Límites: $regionText")
            refreshSaved(); emit()
        }
    }

    // ------------------------------------------------------------ Correcciones del límite

    /** Corrige el límite de la vía por la que vas: ese tramo o toda la calle (mismo nombre, hasta 5 km). */
    fun addFix(kmh: Int, wholeStreet: Boolean): Boolean {
        val w = lastWay ?: return false
        val name = w.tags["name"]?.takeIf { it.isNotBlank() }
        val keep = fixes.filterNot { f ->
            f.wayId == w.id || (wholeStreet && f.wayId == null && f.name.equals(name, true) && SpeedLimits.distanceM(lastLat, lastLon, f.lat, f.lon) <= LimitFixes.STREET_RADIUS_M)
        }
        fixes = keep + LimitFix(if (wholeStreet && name != null) null else w.id, name, lastLat, lastLon, kmh)
        saveFixes()
        current = current?.let { LimitFixes.apply(it, w, lastLat, lastLon, fixes) }
        emit()
        return true
    }

    /** Quita las correcciones de la vía por la que vas (tramo y calle). */
    fun removeFix() {
        val w = lastWay ?: return
        val name = w.tags["name"]
        fixes = fixes.filterNot { f -> f.wayId == w.id || (f.wayId == null && name != null && f.name.equals(name, true) && SpeedLimits.distanceM(lastLat, lastLon, f.lat, f.lon) <= LimitFixes.STREET_RADIUS_M) }
        saveFixes()
        current = SpeedLimits.limitFor(WayMatch(w, 0.0, true)).let { LimitFixes.apply(it, w, lastLat, lastLon, fixes) }
        emit()
    }

    fun clearFixes() { fixes = emptyList(); saveFixes(); emit() }

    // ------------------------------------------------------------ Radares añadidos a mano

    /** Añade un radar donde estás ahora, para el sentido en el que vas. Devuelve lo que ha pasado, en palabras. */
    fun addRadar(tramo: Boolean): String {
        val lat = posLat ?: return "Todavía no hay posición del GPS"
        val lon = posLon ?: return "Todavía no hay posición del GPS"
        val dir = bearing
        val date = java.text.SimpleDateFormat("d MMM yyyy · HH:mm", Locale("es", "ES")).format(java.util.Date())
        val name = current?.road?.takeIf { it.isNotBlank() } ?: "Radar sin calle"
        mine = mine.filterNot { SpeedLimits.distanceM(lat, lon, it.lat, it.lon) < 40 } +
            Radar(lat, lon, current?.kmh, dir, tramo, mine = true, name = name, date = date)
        saveMine()
        emit()
        return (if (tramo) "Tramo añadido" else "Radar añadido") + " en " + name + if (dir == null) " (sin rumbo: avisará en los dos sentidos)" else ""
    }

    /** Quita el radar tuyo más cercano si está a menos de 300 m. */
    fun removeNearRadar(): String {
        val lat = posLat ?: return "Todavía no hay posición del GPS"
        val lon = posLon ?: return "Todavía no hay posición del GPS"
        val near = mine.minByOrNull { SpeedLimits.distanceM(lat, lon, it.lat, it.lon) }
        if (near == null || SpeedLimits.distanceM(lat, lon, near.lat, near.lon) > 300) return "No hay ningún radar tuyo a menos de 300 m"
        mine = mine - near
        saveMine(); emit()
        return "Radar quitado"
    }

    fun clearMine() { mine = emptyList(); saveMine(); emit() }

    /** Cambia un radar tuyo (por su posición en la lista guardada). */
    fun updateMine(i: Int, change: (Radar) -> Radar) {
        if (i !in mine.indices) return
        mine = mine.toMutableList().also { it[i] = change(it[i]) }
        saveMine(); emit()
    }

    fun deleteMine(i: Int) {
        if (i !in mine.indices) return
        mine = mine.filterIndexed { j, _ -> j != i }
        saveMine(); emit()
    }

    /** ¿Hay un radar tuyo a menos de 300 m? (para enseñar el botón de quitarlo) */
    fun mineNear(): Boolean {
        val lat = posLat ?: return false
        val lon = posLon ?: return false
        return mine.any { SpeedLimits.distanceM(lat, lon, it.lat, it.lon) <= 300 }
    }

    private fun saveMine() { prefs.edit().putString("misRadares", Radars.encodeMine(mine)).apply() }

    /** Lo que dice el mapa (sin corrección) de la vía actual, para enseñarlo al corregir. */
    fun mapLimitNow(): LimitInfo? = lastWay?.let { SpeedLimits.limitFor(WayMatch(it, 0.0, true)) }

    private fun saveFixes() { prefs.edit().putString("limitFixes", LimitFixes.encode(fixes)).apply() }

    // ------------------------------------------------------------ Actualizar el mapa con wifi

    private fun onWifi(): Boolean = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && (caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET))
    } catch (_: Exception) { false }

    private fun updatedText(): String {
        val t = prefs.getLong("mapUpdatedAt", 0L)
        return if (t == 0L) "" else SimpleDateFormat("d MMM yyyy HH:mm", Locale("es", "ES")).format(Date(t))
    }

    /** Con wifi y en segundo plano: vuelve a bajar las zonas de alrededor que tengan más de 30 días. */
    private suspend fun refreshOld(km: Int) {
        val lat = prefs.getString("lastLat", null)?.toDoubleOrNull() ?: return
        val lon = prefs.getString("lastLon", null)?.toDoubleOrNull() ?: return
        val maxAge = 30L * 24 * 3600 * 1000
        val now = System.currentTimeMillis()
        val old = LimitTiles.inRadius(lat, lon, km.toDouble()).filter { k ->
            val f = java.io.File(dir, LimitTiles.fileName(k))
            when {
                f.exists() -> now - f.lastModified() > maxAge
                f.name in builtIn -> now - BUILTIN_MS > maxAge
                else -> true
            }
        }
        if (old.isEmpty()) return
        log("Límites: actualizando ${old.size} zonas con wifi")
        var ok = 0
        for (k in old) {
            if (!onWifi()) break
            val f = java.io.File(dir, LimitTiles.fileName(k))
            f.delete()
            retryAt = 0
            if (kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { fetchAndSave(k, f) } != null) { ok++; mem.remove(k); dirty = true }
            delay(800)
        }
        if (ok > 0) { prefs.edit().putLong("mapUpdatedAt", System.currentTimeMillis()).apply(); refreshSaved(); emit() }
        log("Límites: actualizadas $ok de ${old.size} zonas con wifi")
    }

    /** Borra todo el mapa guardado. */
    fun clearSaved() {
        stopRegion()
        dir.listFiles()?.forEach { it.delete() }
        mem.clear(); dirty = true
        regionText = "Mapa guardado borrado."
        refreshSaved(); emit()
    }

    private fun refreshSaved() {
        val files = dir.listFiles()?.filter { it.name.endsWith(".bin") } ?: emptyList()
        val mb = files.sumOf { it.length() } / 1_048_576.0
        val parts = ArrayList<String>()
        if (builtIn.isNotEmpty()) parts += "Comunitat Valenciana incluida"
        if (files.isNotEmpty()) parts += String.format(Locale("es", "ES"), "%d zonas descargadas · %.1f MB", files.size, mb)
        saved = parts.joinToString(" + ").ifEmpty { "Nada guardado todavía" }
    }

    // ------------------------------------------------------------ OpenStreetMap

    /** Pide a OpenStreetMap (Overpass) las vías de coches de una tesela. Prueba otro servidor si uno falla. */
    private fun download(k: Long): List<OsmWay>? {
        val b = LimitTiles.bbox(k)
        val q = "[out:json][timeout:60];way(%.4f,%.4f,%.4f,%.4f)[\"highway\"~\"^(%s)$\"];out tags geom;"
            .format(Locale.US, b[0], b[1], b[2], b[3], SpeedLimits.HIGHWAYS)
        val body = ("data=" + java.net.URLEncoder.encode(q, "UTF-8")).toByteArray()
        repeat(OVERPASS.size) {
            val url = OVERPASS[endpoint % OVERPASS.size]
            var c: java.net.HttpURLConnection? = null
            try {
                c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 10_000
                c.readTimeout = 70_000
                c.setRequestProperty("User-Agent", "OBD-Ibiza/1.0 (app Android personal)")
                c.setRequestProperty("Accept", "application/json")
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                c.outputStream.use { it.write(body) }
                val code = c.responseCode
                if (code == 200) {
                    val txt = c.inputStream.bufferedReader().use { it.readText() }
                    parse(txt)?.let { return it }
                    lastError = "respuesta incompleta de ${host(url)}"
                } else {
                    lastError = "error $code de ${host(url)}" + when (code) {
                        429 -> ": demasiadas peticiones"
                        504 -> ": servidor saturado"
                        else -> ""
                    }
                }
            } catch (ex: java.net.UnknownHostException) {
                lastError = "sin internet: no se encuentra ${host(url)}"
            } catch (ex: java.net.SocketTimeoutException) {
                lastError = "${host(url)} no contesta"
            } catch (ex: javax.net.ssl.SSLException) {
                lastError = "fallo de conexión segura con ${host(url)}: ¿la fecha y hora de la pantalla son correctas?"
            } catch (ex: Exception) {
                lastError = (ex.message ?: ex.javaClass.simpleName) + " (${host(url)})"
            } finally {
                try { c?.disconnect() } catch (_: Exception) { }
            }
            endpoint++
        }
        return null
    }

    private fun host(url: String) = url.removePrefix("https://").substringBefore('/')

    private fun parse(txt: String): List<OsmWay>? {
        val root = org.json.JSONObject(txt)
        if (root.optString("remark").contains("error", ignoreCase = true)) return null
        val els = root.optJSONArray("elements") ?: return null
        val out = ArrayList<OsmWay>(els.length())
        for (i in 0 until els.length()) {
            val o = els.optJSONObject(i) ?: continue
            if (o.optString("type") != "way") continue
            val g = o.optJSONArray("geometry") ?: continue
            val tj = o.optJSONObject("tags")
            val tags = HashMap<String, String>()
            if (tj != null) {
                val keys = tj.keys()
                while (keys.hasNext()) { val k = keys.next(); if (k in LimitTiles.KEEP) tags[k] = tj.optString(k) }
            }
            val la = ArrayList<Double>(g.length())
            val lo = ArrayList<Double>(g.length())
            for (j in 0 until g.length()) {
                val p = g.optJSONObject(j) ?: continue
                la += p.optDouble("lat"); lo += p.optDouble("lon")
            }
            if (la.size >= 2) out += OsmWay(o.optLong("id"), tags, la.toDoubleArray(), lo.toDoubleArray())
        }
        return out
    }

    companion object {
        /** Fecha de los datos del mapa integrado (Geofabrik, 2-nov-2026). */
        private const val BUILTIN_MS = 1_793_577_600_000L
        private val OVERPASS = listOf(
            "https://overpass-api.de/api/interpreter",
            "https://overpass.private.coffee/api/interpreter",
            "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter",
        )
    }
}
