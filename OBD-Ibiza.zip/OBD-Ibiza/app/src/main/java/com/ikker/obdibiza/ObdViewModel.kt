package com.ikker.obdibiza

import android.app.Application
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Conn { DESCONECTADO, CONECTANDO, CONECTADO }

/**
 * Un reloj colocado en una página: dato, posición del centro (fracción del ancho y del alto
 * de la zona de relojes) y diámetro (fracción del alto).
 */
data class GaugeItem(val id: String, val x: Float, val y: Float, val size: Float)

/** Disposición inicial: dos relojes laterales y uno grande en el centro. */
fun defaultLayout(ids: List<String>): List<GaugeItem> = listOf(
    GaugeItem(ids[0], 0.17f, 0.5f, 0.70f),
    GaugeItem(ids[1], 0.5f, 0.5f, 0.84f),
    GaugeItem(ids[2], 0.83f, 0.5f, 0.70f),
)

/** Ordenador de viaje: se calcula integrando la velocidad (y el consumo, si el coche lo da). */
data class Trip(
    val startMs: Long = System.currentTimeMillis(),
    val distanceKm: Double = 0.0,
    val movingSeconds: Double = 0.0,
    val maxSpeed: Double = 0.0,
    val fuelLitres: Double? = null,
) {
    val avgSpeed: Double? get() = if (movingSeconds > 10) distanceKm / (movingSeconds / 3600) else null
    val avgConsumption: Double? get() = fuelLitres?.let { f -> if (distanceKm > 0.5) f / distanceKm * 100 else null }
}

enum class AccelMode(val title: String, val from: Double, val to: Double) {
    ZERO_100("0 – 100 km/h", 0.0, 100.0),
    ZERO_60("0 – 60 km/h", 0.0, 60.0),
    MID_80_120("80 – 120 km/h", 80.0, 120.0),
}

enum class AccelState { PARADO, PREPARADO, MIDIENDO, HECHO }

/** Cronómetro de aceleración. Los tiempos de cruce se interpolan entre lecturas para afinar. */
data class Accel(
    val mode: AccelMode = AccelMode.ZERO_100,
    val state: AccelState = AccelState.PARADO,
    val startMs: Long = 0,
    val resultS: Double? = null,
    val best: Map<AccelMode, Double> = emptyMap(),
)

/** Posible identificador de temperatura de aceite encontrado al rastrear la centralita. */
data class OilCandidate(val did: Int, val formula: Int, val value: Double)

/** Resultado de una comprobación del diagnóstico. */
enum class CheckLevel { OK, AVISO, MAL, INFO }

/** Una línea del diagnóstico: qué se ha mirado, qué valor tiene, si está bien o mal y por qué. */
data class DiagCheck(val name: String, val level: CheckLevel, val value: String, val why: String)

data class UiState(
    val conn: Conn = Conn.DESCONECTADO,
    val status: String = "Enchufa el cable OBD y pulsa Conectar",
    val adapter: String = "",
    val protocol: String = "",
    val vin: String = "",
    val supportedPids: Set<Int> = emptySet(),
    val values: Map<String, Double> = emptyMap(),
    val peaks: Map<String, Double> = emptyMap(),
    val mil: Boolean? = null,
    val dtcCount: Int? = null,
    val dtcs: List<String>? = null,
    val pendingDtcs: List<String>? = null,
    val permanentDtcs: List<String>? = null,
    val dtcBusy: Boolean = false,
    val dtcMessage: String = "",
    /** Diagnóstico completo de la última lectura de averías. */
    val checks: List<DiagCheck> = emptyList(),
    /** Valor en vivo de cada candidato de aceite (se lee solo con Ajustes abierto). */
    val candLive: Map<Int, Double> = emptyMap(),
    val log: List<String> = emptyList(),
    val dashboard: List<String> = Params.defaultDashboard,
    val columns: Int = 3,
    val refreshHz: Double = 0.0,
    val traffic: Boolean = false,
    val demo: Boolean = false,
    /** Reloj grande principal, valor del centro y segundo reloj. */
    /** Páginas del panel: cada una con 3 relojes (izquierda, centro, derecha). */
    val pages: List<List<GaugeItem>> = Params.defaultPages.map { defaultLayout(it) },
    val pageNames: List<String> = Params.defaultPageNames,
    /** Imagen elegida por el usuario para el reloj principal (null = ninguna). */
    val logo: androidx.compose.ui.graphics.ImageBitmap? = null,
    val page: Int = 0,
    val ringMain: String = "rpm",
    val ringCenter: String = "speed",
    val ringSecond: String = Params.BOOST,
    val ringThird: String = "oil",
    /** De dónde sale la temperatura del aceite ("" = no encontrada). */
    val oilSource: String = "",
    val oilCustomDid: String = "",
    val oilCustomFormula: Int = 0,
    val oilTestMessage: String = "",
    /** Rastreo de identificadores: progreso 0..1 (null = parado) y candidatos encontrados. */
    val oilScanProgress: Float? = null,
    val oilCandidates: List<OilCandidate> = emptyList(),
    /** Datos que pide la pantalla abierta (gráficas, barras…), además de la página de relojes. */
    val focus: List<String> = emptyList(),
    val trip: Trip = Trip(),
    val accel: Accel = Accel(),
    /** Revoluciones a las que se encienden del todo las luces de cambio. */
    val shiftRpm: Int = 4000,
    /** Últimos valores de cada dato para las mini-gráficas. */
    val history: Map<String, List<Float>> = emptyMap(),
) {
    /** Todo lo que se ve en el panel y por tanto se lee en cada vuelta. */
    val live: List<String> get() = ((pages.getOrNull(page)?.map { it.id } ?: emptyList()) + focus + "speed").distinct()
}

class ObdViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    private val usb = app.getSystemService(Context.USB_SERVICE) as UsbManager
    private val prefs = app.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
    private var elm: Elm327? = null
    private var pollJob: Job? = null
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                ACTION_PERMISSION -> {
                    if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) tryConnect(quiet = false)
                    else setStatus("Permiso USB denegado. Vuelve a pulsar Conectar y acepta.")
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    if (elm != null) disconnect("Cable OBD desenchufado")
                }
            }
        }
    }

    init {
        val f = IntentFilter().apply {
            addAction(ACTION_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(app, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        val saved = prefs.getString("widgets", null)
            ?.split(",")?.filter { it in Params.byId }
            ?.takeIf { it.isNotEmpty() }
        _state.update {
            it.copy(
                dashboard = saved ?: Params.defaultDashboard,
                columns = prefs.getInt("columnas", 3),
                pages = loadPages(),
                pageNames = prefs.getString("pageNames", null)?.split("|") ?: Params.defaultPageNames,
                logo = loadLogo(),
                ringMain = prefs.getString("ringMain", null)?.takeIf { id -> id in Params.byId } ?: "rpm",
                ringCenter = prefs.getString("ringCenter", null)?.takeIf { id -> id in Params.byId } ?: "speed",
                ringSecond = prefs.getString("ringSecond", null)?.takeIf { id -> id in Params.byId } ?: Params.BOOST,
                ringThird = prefs.getString("ringThird", null)?.takeIf { id -> id in Params.byId } ?: "oil",
                oilCustomDid = prefs.getString("oilDid", "") ?: "",
                oilCustomFormula = prefs.getInt("oilFormula", 0),
                shiftRpm = prefs.getInt("shiftRpm", 4000),
            )
        }
    }

    // ------------------------------------------------------------ Panel personalizable

    fun setDashboard(ids: List<String>) {
        prefs.edit().putString("widgets", ids.joinToString(",")).apply()
        _state.update { it.copy(dashboard = ids) }
    }

    // Formato guardado: "id@x@y@tamaño,id@x@y@tamaño;…" (una página por ";")
    private fun loadPages(): List<List<GaugeItem>> =
        prefs.getString("layout", null)
            ?.split(";")
            ?.map { pg ->
                pg.split(",").mapNotNull { g ->
                    val f = g.split("@")
                    if (f.size == 4 && f[0] in Params.byId) {
                        GaugeItem(f[0], f[1].toFloatOrNull() ?: 0.5f, f[2].toFloatOrNull() ?: 0.5f, f[3].toFloatOrNull() ?: 0.6f)
                    } else null
                }
            }
            ?.filter { it.isNotEmpty() }
            ?.takeIf { it.isNotEmpty() }
            ?: Params.defaultPages.map { defaultLayout(it) }

    fun setPages(pages: List<List<GaugeItem>>) {
        val clean = pages.filter { it.isNotEmpty() }.ifEmpty { Params.defaultPages.map { defaultLayout(it) } }
        prefs.edit().putString(
            "layout",
            clean.joinToString(";") { pg -> pg.joinToString(",") { "${it.id}@${it.x}@${it.y}@${it.size}" } },
        ).apply()
        _state.update { it.copy(pages = clean, page = it.page.coerceIn(0, clean.size - 1)) }
    }

    fun pageName(st: UiState, i: Int) = st.pageNames.getOrNull(i)?.takeIf { it.isNotBlank() } ?: "Página ${i + 1}"

    private fun saveNames(names: List<String>) {
        prefs.edit().putString("pageNames", names.joinToString("|") { it.replace("|", "/") }).apply()
        _state.update { it.copy(pageNames = names) }
    }

    fun renamePage(i: Int, name: String) {
        val st = _state.value
        val names = List(st.pages.size) { j -> if (j == i) name.take(24) else st.pageNames.getOrElse(j) { "" } }
        saveNames(names)
    }

    fun addPage() {
        val st = _state.value
        setPages(st.pages + listOf(defaultLayout(listOf("coolant", "rpm", "oil"))))
        saveNames(List(st.pages.size) { j -> st.pageNames.getOrElse(j) { "" } } + "Página ${st.pages.size + 1}")
    }

    fun removePage(i: Int) {
        val st = _state.value
        if (st.pages.size <= 1) return
        setPages(st.pages.filterIndexed { j, _ -> j != i })
        saveNames(List(st.pages.size) { j -> st.pageNames.getOrElse(j) { "" } }.filterIndexed { j, _ -> j != i })
    }

    fun resetPages() {
        setPages(Params.defaultPages.map { defaultLayout(it) })
        saveNames(Params.defaultPageNames)
    }

    /** Guarda la página actual tal como ha quedado al moverla en el editor. */
    fun setCurrentPage(items: List<GaugeItem>) {
        val st = _state.value
        setPages(st.pages.mapIndexed { i, pg -> if (i == st.page) items else pg })
    }

    fun resetCurrentPage() {
        val st = _state.value
        val def = Params.defaultPages[st.page % Params.defaultPages.size]
        setCurrentPage(defaultLayout(def))
    }

    // ------------------------------------------------------------ Logo propio en el reloj principal

    private val logoFile get() = java.io.File(getApplication<Application>().filesDir, "logo.png")

    private fun loadLogo(): androidx.compose.ui.graphics.ImageBitmap? = try {
        if (logoFile.exists()) android.graphics.BitmapFactory.decodeFile(logoFile.path)?.asImageBitmap() else null
    } catch (_: Exception) { null }

    /** Copia la imagen elegida, la reduce y la guarda dentro de la app. */
    fun setLogo(uri: android.net.Uri) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val app = getApplication<Application>()
                val src = app.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it) } ?: return@launch
                val scale = minOf(1f, 400f / maxOf(src.width, src.height))
                val bmp = android.graphics.Bitmap.createScaledBitmap(src, (src.width * scale).toInt().coerceAtLeast(1), (src.height * scale).toInt().coerceAtLeast(1), true)
                logoFile.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
                _state.update { it.copy(logo = bmp.asImageBitmap()) }
            } catch (ex: Exception) {
                log("No se pudo cargar la imagen: ${ex.message}")
            }
        }
    }

    fun clearLogo() {
        logoFile.delete()
        _state.update { it.copy(logo = null) }
    }

    /** ANTERIOR / SIGUIENTE: cambia de página de relojes (da la vuelta). */
    fun movePage(delta: Int) = _state.update {
        val n = it.pages.size
        it.copy(page = ((it.page + delta) % n + n) % n)
    }

    /** Flechas de cada reloj: cambia el dato de ese reloj al anterior o siguiente de la lista. */
    fun cycleGauge(slot: Int, dir: Int) {
        val st = _state.value
        val cur = st.pages.getOrNull(st.page) ?: return
        val item = cur.getOrNull(slot) ?: return
        val ids = Params.all.map { it.id }
        val idx = ids.indexOf(item.id).coerceAtLeast(0)
        val next = ids[((idx + dir) % ids.size + ids.size) % ids.size]
        setCurrentPage(cur.mapIndexed { j, g -> if (j == slot) g.copy(id = next) else g })
    }

    fun setRings(main: String, center: String, second: String, third: String) {
        prefs.edit().putString("ringMain", main).putString("ringCenter", center)
            .putString("ringSecond", second).putString("ringThird", third).apply()
        _state.update { it.copy(ringMain = main, ringCenter = center, ringSecond = second, ringThird = third) }
    }

    // ------------------------------------------------------------ Temperatura del aceite
    //
    // El PID estándar 015C casi nunca lo da un TDI de VAG de 2011. Se prueba en este orden:
    //  1) 015C estándar   2) 22F45C (el mismo dato pedido por UDS a la centralita de motor)
    //  3) un identificador propio que se puede escribir en Ajustes (22XXXX)

    private var oilDid: Int? = null
    private var oilFormula = 0

    fun setOilCustom(did: String, formula: Int) {
        val clean = did.uppercase().filter { it in "0123456789ABCDEF" }.take(4)
        prefs.edit().putString("oilDid", clean).putInt("oilFormula", formula).apply()
        _state.update { it.copy(oilCustomDid = clean, oilCustomFormula = formula) }
    }

    fun retestOil() {
        val e = elm ?: return _state.update { it.copy(oilTestMessage = "Conecta primero con el coche") }
        viewModelScope.launch {
            _state.update { it.copy(oilTestMessage = "Probando…") }
            try { detectOil(e) } catch (ex: Exception) { disconnect("Error: ${ex.message}") }
        }
    }

    private suspend fun detectOil(e: Elm327) {
        val st = _state.value
        if (0x5C in st.supportedPids) {
            oilDid = null
            _state.update { it.copy(oilSource = "OBD estándar (015C)", oilTestMessage = "") }
            return
        }
        val candidates = buildList {
            st.oilCustomDid.toIntOrNull(16)?.let { add(it to st.oilCustomFormula) }
            add(0xF45C to 0)
        }
        for ((did, f) in candidates) {
            val data = Elm327.mode22(e.send("22%04X".format(did), 2000), did) ?: continue
            val t = oilCalc(data, f) ?: continue
            if (t in -40.0..170.0) {
                oilDid = did; oilFormula = f
                log("Temperatura de aceite encontrada en 22%04X: %.1f °C".format(did, t))
                _state.update { it.copy(oilSource = "UDS 22%04X".format(did), oilTestMessage = "Leyendo: %.0f °C".format(t)) }
                return
            }
        }
        oilDid = null
        _state.update {
            it.copy(oilSource = "", oilTestMessage = "Tu centralita no da la temperatura del aceite con estos identificadores")
        }
    }

    // ---- Rastreo de la temperatura del aceite
    //
    // Corre en segundo plano (puedes salir de la app), no para el panel, se pausa si el coche se mueve y,
    // si se interrumpe, BUSCAR continúa por donde iba. Solo lee datos (servicio 22): no cambia nada del coche.

    private var scanJob: Job? = null
    private var scanPos = 0
    private var scanAnswered = 0
    private val scanFound = mutableListOf<OilCandidate>()

    /** Orden del rastreo: primero lo más probable en VAG, después rangos más amplios. */
    private val scanOrder: List<Int> by lazy {
        (0x2000..0x20FF) + (0x1000..0x1FFF) + (0xF400..0xF4FF) + (0x2100..0x2FFF) + (0x0100..0x0FFF) + (0xF100..0xF3FF)
    }

    /**
     * Pregunta cuatro identificadores UDS que casi toda centralita VAG contesta (bastidor, referencias…).
     * Devuelve cuántos contestaron, aunque sea con un "no soportado": si ninguno, rastrear no sirve de nada.
     */
    private suspend fun probeUds(e: Elm327): Int {
        var answered = 0
        for (did in listOf(0xF190, 0xF187, 0xF18C, 0xF40D)) {
            val r = e.send("22%04X".format(did), 1500)
            val ms = Elm327.messages(r)
            val ok = ms.any { it.size >= 3 && it[0] == 0x62 } ||
                ms.any { it.size >= 3 && it[0] == 0x7F && it[1] == 0x22 }
            if (ok) answered++
            log("Sonda 22%04X: %s".format(did, r.replace("\n", " ").ifEmpty { "sin respuesta" }))
        }
        return answered
    }

    /** Qué fórmulas probar según los bytes que devuelve el identificador. */
    private fun oilFormulasFor(size: Int): List<Int> = when {
        size == 1 -> listOf(0, 4, 3)
        size == 2 -> listOf(1, 5)
        size in 3..8 -> listOf(1, 5, 0)
        else -> emptyList()
    }

    fun scanOil() {
        val e = elm ?: return _state.update { it.copy(oilTestMessage = "Conecta primero con el coche") }
        if (_state.value.oilScanProgress != null) return
        val total = scanOrder.size
        scanJob = viewModelScope.launch {
            if (scanPos <= 0 || scanPos >= total) { scanPos = 0; scanFound.clear(); scanAnswered = 0 }
            _state.update {
                it.copy(
                    oilScanProgress = scanPos / total.toFloat(), oilCandidates = scanFound.take(40).toList(),
                    oilTestMessage = if (scanPos > 0) "Continuando el rastreo…" else "Probando la centralita…",
                )
            }
            try {
                if (scanPos == 0 && probeUds(e) == 0) {
                    _state.update {
                        it.copy(
                            oilScanProgress = null,
                            oilTestMessage = "La centralita de motor no contesta a lecturas UDS (22). Rastrear aquí no sirve: " +
                                "el dato debe de estar en otro módulo. Mira el registro en Ajustes.",
                        )
                    }
                    return@launch
                }
                val coolant = Elm327.mode01(e.send("0105"), 0x05)?.let { it[0] - 40.0 } ?: _state.value.values["coolant"]
                e.send("ATST 20")   // espera menos a los identificadores que no existen
                while (elm === e && scanPos < total && _state.value.oilScanProgress != null) {
                    // En pausa mientras el coche se mueve
                    while (elm === e && _state.value.oilScanProgress != null && (_state.value.values["speed"] ?: 0.0) > 3.0) {
                        _state.update { it.copy(oilTestMessage = "En pausa: el coche se mueve. Sigue al parar.") }
                        delay(1500)
                    }
                    if (elm !== e || _state.value.oilScanProgress == null) break
                    val did = scanOrder[scanPos]
                    val data = Elm327.mode22(e.send("22%04X".format(did), 500), did)
                    if (data != null) {
                        scanAnswered++
                        for (f in oilFormulasFor(data.size)) {
                            val t = oilCalc(data, f) ?: continue
                            val near = coolant == null || kotlin.math.abs(t - coolant) <= 25
                            if (t in 15.0..150.0 && near && did != 0xF405) {
                                scanFound += OilCandidate(did, f, t)
                                log("Candidato 22%04X = %.1f °C (fórmula %d)".format(did, t, f))
                                break
                            }
                        }
                    }
                    scanPos++
                    if (scanPos % 16 == 0 || data != null) {
                        _state.update {
                            it.copy(
                                oilScanProgress = scanPos / total.toFloat(), oilCandidates = scanFound.take(40).toList(),
                                oilTestMessage = "Rastreando… respondieron $scanAnswered identificadores",
                            )
                        }
                    }
                }
                if (elm === e) { try { e.send("ATST 32") } catch (_: Exception) { } }
                val finished = scanPos >= total
                val percent = (scanPos * 100L / total).toInt()
                if (finished) scanPos = 0
                _state.update {
                    it.copy(
                        oilScanProgress = null, oilCandidates = scanFound.take(40).toList(),
                        oilTestMessage = when {
                            scanFound.isNotEmpty() -> "Elige el que coincida con Carly"
                            finished -> "Rastreo completo: no se encontró ninguno ($scanAnswered respondieron)."
                            else -> "Rastreo parado al $percent %. BUSCAR continúa desde ahí."
                        },
                    )
                }
            } catch (ex: Exception) {
                _state.update { it.copy(oilScanProgress = null) }
                if (elm === e) disconnect("Error rastreando: ${ex.message}")
            }
        }
    }

    fun stopOilScan() = _state.update { it.copy(oilScanProgress = null) }

    @Volatile private var watchCand = false

    /** Con Ajustes abierto, lee en vivo los candidatos para ver cuál se comporta como el aceite. */
    fun watchCandidates(on: Boolean) {
        watchCand = on
        if (!on) _state.update { it.copy(candLive = emptyMap()) }
    }

    fun useOilCandidate(c: OilCandidate) {
        setOilCustom("%04X".format(c.did), c.formula)
        oilDid = c.did; oilFormula = c.formula
        _state.update { it.copy(oilSource = "UDS 22%04X".format(c.did), oilTestMessage = "Guardado: 22%04X".format(c.did)) }
    }

    /**
     * Fórmulas: 0 = A−40 · 1 = (A·256+B−2731)/10 (décimas de kelvin) · 2 = (A·256+B)/10−273,1 ·
     * 3 = A directo en °C · 4 = A·0,75−48 (habitual en VAG) · 5 = (A·256+B)/10 con signo (décimas de °C)
     */
    private fun oilCalc(d: IntArray, f: Int): Double? = when (f) {
        0 -> if (d.isNotEmpty()) d[0] - 40.0 else null
        1 -> if (d.size >= 2) (d[0] * 256 + d[1] - 2731) / 10.0 else null
        2 -> if (d.size >= 2) (d[0] * 256 + d[1]) / 10.0 - 273.1 else null
        3 -> if (d.isNotEmpty()) d[0].toDouble() else null
        4 -> if (d.isNotEmpty()) d[0] * 0.75 - 48.0 else null
        5 -> if (d.size >= 2) (d[0] * 256 + d[1]).toShort().toInt() / 10.0 else null
        else -> null
    }

    fun setShiftRpm(rpm: Int) {
        val v = rpm.coerceIn(2000, 5000)
        prefs.edit().putInt("shiftRpm", v).apply()
        _state.update { it.copy(shiftRpm = v) }
    }

    /** Guarda valores nuevos, máximos e historial (60 muestras) de cada dato. */
    fun setFocus(ids: List<String>) = _state.update { it.copy(focus = ids) }

    fun resetTrip() = _state.update { it.copy(trip = Trip()) }

    fun setAccelMode(m: AccelMode) = _state.update { it.copy(accel = it.accel.copy(mode = m, state = AccelState.PARADO, resultS = null)) }

    /** Deja el cronómetro esperando la salida. */
    fun armAccel() = _state.update { it.copy(accel = it.accel.copy(state = AccelState.PREPARADO, resultS = null)) }

    fun cancelAccel() = _state.update { it.copy(accel = it.accel.copy(state = AccelState.PARADO)) }

    private var lastSpeed: Double? = null
    private var lastSpeedMs = 0L

    /** Viaje y cronómetro: se actualizan con cada lectura nueva de velocidad. */
    private fun onSpeed(s: UiState, v: Double, fuelRate: Double?): UiState {
        val now = System.currentTimeMillis()
        val pv = lastSpeed
        val pt = lastSpeedMs
        lastSpeed = v; lastSpeedMs = now
        if (pv == null || now - pt > 3000) return s
        val dt = (now - pt) / 1000.0
        // Viaje
        val t = s.trip
        val mid = (pv + v) / 2
        val trip = t.copy(
            distanceKm = t.distanceKm + mid * dt / 3600,
            movingSeconds = t.movingSeconds + if (mid > 1) dt else 0.0,
            maxSpeed = maxOf(t.maxSpeed, v),
            fuelLitres = fuelRate?.let { (t.fuelLitres ?: 0.0) + it * dt / 3600 } ?: t.fuelLitres,
        )
        // Cronómetro
        fun cross(target: Double) = pt + ((target - pv) / (v - pv) * (now - pt)).toLong()
        var a = s.accel
        when (a.state) {
            AccelState.PREPARADO -> {
                val m = a.mode
                if (m.from == 0.0 && pv < 0.5 && v >= 0.5) a = a.copy(state = AccelState.MIDIENDO, startMs = pt)
                else if (m.from > 0 && pv < m.from && v >= m.from) a = a.copy(state = AccelState.MIDIENDO, startMs = cross(m.from))
            }
            AccelState.MIDIENDO -> {
                val m = a.mode
                if (v >= m.to && pv < m.to) {
                    val r = (cross(m.to) - a.startMs) / 1000.0
                    val best = a.best[m]
                    a = a.copy(state = AccelState.HECHO, resultS = r, best = if (best == null || r < best) a.best + (m to r) else a.best)
                } else if (v < 0.5 || (m.from > 0 && v < m.from - 5)) {
                    a = a.copy(state = AccelState.PREPARADO)
                }
            }
            else -> {}
        }
        return s.copy(trip = trip, accel = a)
    }

    private fun applyValues(newValues: Map<String, Double>, replace: Boolean = false, hz: Double? = null, fresh: Boolean = true) {
        if (fresh && newValues.isNotEmpty()) lastDataMs = System.currentTimeMillis()
        _state.update { s0 ->
            val s = newValues["speed"]?.let { onSpeed(s0, it, newValues["fuelrate"] ?: s0.values["fuelrate"]) } ?: s0
            val peaks = s.peaks.toMutableMap()
            val hist = s.history.toMutableMap()
            newValues.forEach { (k, v) ->
                if (v > (peaks[k] ?: Double.NEGATIVE_INFINITY)) peaks[k] = v
                hist[k] = ((hist[k] ?: emptyList()) + v.toFloat()).takeLast(HISTORY)
            }
            s.copy(
                values = if (replace) newValues else s.values + newValues,
                peaks = peaks, history = hist, refreshHz = hz ?: s.refreshHz,
            )
        }
    }

    fun setColumns(n: Int) {
        prefs.edit().putInt("columnas", n).apply()
        _state.update { it.copy(columns = n) }
    }

    fun setTraffic(on: Boolean) {
        elm?.logTraffic = on
        _state.update { it.copy(traffic = on) }
    }

    fun resetPeaks() = _state.update { it.copy(peaks = emptyMap()) }

    // ------------------------------------------------------------ Conexión

    /** Si está activa, la app conecta sola y vuelve a conectar cuando se pierde. Solo la apaga el botón DESCONECTAR. */
    private var autoReconnect = prefs.getBoolean("autoReconnect", true)
    private var lastDataMs = 0L
    private var permissionAskedMs = 0L
    /** Veces seguidas que el adaptador no ha contestado, y cuándo se reinició el puerto USB por última vez. */
    private var muteFails = 0
    private var lastResetMs = 0L
    private var supervisorJob: Job? = null

    private fun setAutoReconnect(on: Boolean) {
        autoReconnect = on
        prefs.edit().putBoolean("autoReconnect", on).apply()
    }

    /** Botón CONECTAR, apertura de la app o cable enchufado: conecta y mantiene la conexión viva. */
    fun connect() {
        setAutoReconnect(true)
        startKeepAlive()
        tryConnect(quiet = false)
    }

    /** Botón DESCONECTAR: se desconecta y no vuelve a conectar sola hasta que pulses CONECTAR. */
    fun userDisconnect() {
        if (!_state.value.demo) {
            setAutoReconnect(false)
            stopKeepAlive()
        }
        disconnect("Desconectado")
    }

    /** Servicio en primer plano: evita que Android cierre la app al irte a la radio, YouTube o el GPS. */
    private fun startKeepAlive() {
        try {
            val app = getApplication<Application>()
            ContextCompat.startForegroundService(app, Intent(app, ObdService::class.java))
        } catch (ex: Exception) {
            log("No se pudo iniciar el servicio en segundo plano: ${ex.message}")
        }
    }

    private fun stopKeepAlive() {
        try {
            val app = getApplication<Application>()
            app.stopService(Intent(app, ObdService::class.java))
        } catch (_: Exception) { }
    }

    /**
     * Vigila la conexión: si no la hay, la intenta de nuevo sola (cada vez más despacio si el coche está
     * apagado); si el coche deja de contestar, la reinicia.
     */
    fun startSupervisor() {
        if (supervisorJob?.isActive == true) return
        supervisorJob = viewModelScope.launch {
            var failures = 0
            while (isActive) {
                val st = _state.value
                var wait = 2000L
                if (!st.demo) {
                    when (st.conn) {
                        Conn.DESCONECTADO -> {
                            if (autoReconnect) {
                                tryConnect(quiet = failures > 0)
                                failures++
                                wait = if (failures < 6) 3000L else if (failures < 20) 6000L else 15000L
                            }
                        }
                        Conn.CONECTADO -> {
                            failures = 0
                            if (!st.dtcBusy && System.currentTimeMillis() - lastDataMs > NO_DATA_MS) {
                                disconnect("Sin datos del coche · reconectando…")
                            }
                        }
                        Conn.CONECTANDO -> { }
                    }
                }
                delay(wait)
            }
        }
    }

    private fun tryConnect(quiet: Boolean) {
        if (_state.value.conn != Conn.DESCONECTADO) return
        val driver = UsbSerialProber.getDefaultProber().findAllDrivers(usb).firstOrNull()
        if (driver == null) {
            val msg = "No encuentro el cable OBD USB. ¿Está enchufado a la pantalla?"
            if (!quiet || _state.value.status != msg) setStatus(msg)
            if (!quiet) {
                val others = usb.deviceList.values.joinToString { "%04X:%04X".format(it.vendorId, it.productId) }
                if (others.isNotEmpty()) log("Dispositivos USB vistos (no reconocidos como serie): $others")
            }
            return
        }
        val device: UsbDevice = driver.device
        if (!usb.hasPermission(device)) {
            val now = System.currentTimeMillis()
            // Al reintentar sola no se vuelve a abrir el aviso de permiso a cada rato
            if (quiet && now - permissionAskedMs < 20_000) return
            permissionAskedMs = now
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(
                getApplication(), 0,
                Intent(ACTION_PERMISSION).setPackage(getApplication<Application>().packageName), flags,
            )
            setStatus("Acepta el permiso USB en la pantalla…")
            usb.requestPermission(device, pi)
            return
        }
        val connection = usb.openDevice(device)
        if (connection == null) {
            val msg = "No se pudo abrir el cable USB"
            if (!quiet || _state.value.status != msg) setStatus(msg)
            return
        }
        _state.update { it.copy(conn = Conn.CONECTANDO, status = "Buscando adaptador…") }
        log("Cable USB: ${driver.javaClass.simpleName.removeSuffix("SerialDriver")} %04X:%04X".format(device.vendorId, device.productId))

        // Si el adaptador se queda mudo, se reinicia el puerto USB (equivale a quitar y poner el cable)
        var didReset = false
        if (muteFails >= 4 && System.currentTimeMillis() - lastResetMs > 30_000) {
            lastResetMs = System.currentTimeMillis()
            log("Adaptador mudo: reiniciando el puerto USB")
            didReset = try { connection.resetDevice() } catch (_: Exception) { false }
        }

        // Identifica este intento: si mientras tanto se desconecta o se empieza otro, el viejo no debe tocar nada
        val gen = ++connGen
        viewModelScope.launch {
            try {
                if (didReset) delay(1200)
                withTimeout(CONNECT_TIMEOUT_MS) { doConnect(driver, connection, gen) }
            } catch (ex: TimeoutCancellationException) {
                if (gen == connGen) { muteFails++; disconnect("Tiempo agotado conectando · reintentando…") }
                try { connection.close() } catch (_: Exception) { }
            } catch (ex: Exception) {
                if (gen == connGen) disconnect("Error de comunicación: ${ex.message ?: ex.javaClass.simpleName}")
                // Si el puerto no llegó a abrirse, la conexión USB quedaría abierta y bloquearía el siguiente intento
                try { connection.close() } catch (_: Exception) { }
            }
        }
    }

    /** Número del intento de conexión en curso. Cada desconexión lo cambia, invalidando los intentos antiguos. */
    private var connGen = 0

    private suspend fun doConnect(driver: UsbSerialDriver, connection: UsbDeviceConnection, gen: Int) {
        val port = driver.ports[0]
        port.open(connection)
        try { port.setDTR(true); port.setRTS(true) } catch (_: Exception) { }
        val e = Elm327(port, connection) { log(it) }
        e.logTraffic = _state.value.traffic
        elm = e

        // Barrido completo de velocidades solo la primera vez o de vez en cuando; normalmente basta la guardada
        val savedBaud = prefs.getInt("baud", 0)
        val version = e.detect(savedBaud, full = savedBaud == 0 || muteFails % 5 == 4)
        if (gen != connGen) return   // mientras tanto se desconectó o empezó otro intento
        if (version == null) {
            muteFails++
            disconnect(
                if (muteFails >= 4) "El adaptador no contesta · reiniciando el puerto USB y reintentando…"
                else "El adaptador no contesta · reintentando…",
            )
            return
        }
        muteFails = 0
        // Se recuerda la velocidad que funcionó, para conectar más rápido la próxima vez
        if (e.baud > 0) prefs.edit().putInt("baud", e.baud).apply()
        _state.update { it.copy(adapter = version, status = "Conectando con el coche…") }

        batching = true; batchMisses = 0; suffixOk = true
        for (c in listOf("ATE0", "ATL0", "ATS0", "ATH0", "ATAT2")) e.send(c)
        // Conexión rápida: se prueba primero el protocolo que funcionó la última vez
        var r = ""
        val savedProto = prefs.getString("protoNum", null)
        if (savedProto != null) {
            e.send("ATSP$savedProto")
            r = e.send("0100", 4000)
        }
        if (Elm327.mode01Supported(r) == null) {
            e.send("ATSP0")
            r = e.send("0100", 12000)
        }
        if (Elm327.mode01Supported(r) == null) {
            log("Búsqueda automática sin respuesta, probando CAN 11 bit 500 kbps…")
            e.send("ATSP6")
            r = e.send("0100", 8000)
        }
        if (gen != connGen) return
        val first = Elm327.mode01Supported(r)
        if (first == null) {
            disconnect("El coche no responde. Pon el contacto (o arranca) y se reintentará solo.")
            return
        }
        val protocol = e.send("ATDP").removePrefix("AUTO,").trim()
        // Se guarda el número de protocolo para conectar más deprisa la próxima vez
        e.send("ATDPN").trim().removePrefix("A").takeIf { it.length == 1 && it[0].isLetterOrDigit() }
            ?.let { prefs.edit().putString("protoNum", it).apply() }

        // PIDs soportados
        val supported = first.toMutableSet()
        for (base in listOf(0x20, 0x40, 0x60, 0x80, 0xA0)) {
            if (base !in supported) break
            val s = Elm327.supported(e.send("01%02X".format(base)), base)
            if (s.isEmpty()) break
            supported += s
        }
        log("PIDs soportados: " + supported.sorted().joinToString(" ") { "%02X".format(it) })

        // En CAN, hablar solo con la centralita de motor (7E0): respuestas limpias y permite UDS
        if (protocol.contains("15765")) e.send("ATSH7E0")
        val vin = Elm327.vin(e.send("0902", 5000)) ?: ""
        if (gen != connGen) return
        lastDataMs = System.currentTimeMillis()
        _state.update {
            it.copy(
                conn = Conn.CONECTADO, protocol = protocol, vin = vin, supportedPids = supported,
                status = "Conectado · $protocol",
            )
        }
        readStatus()
        detectOil(e)
        startPolling()
    }

    fun disconnect(reason: String = "Desconectado") {
        connGen++
        pollJob?.cancel(); pollJob = null
        elm?.close(); elm = null
        _state.update {
            it.copy(conn = Conn.DESCONECTADO, status = reason, refreshHz = 0.0, demo = false, oilScanProgress = null)
        }
        log(reason)
    }

    // ------------------------------------------------------------ Modo demo (sin cable)

    /** Simula un coche en marcha para probar la app sin cable ni coche. */
    fun startDemo() {
        if (_state.value.conn != Conn.DESCONECTADO) return
        _state.update {
            it.copy(
                conn = Conn.CONECTADO, demo = true, status = "MODO DEMO · datos simulados",
                adapter = "Simulador", protocol = "Demo", vin = "VSSZZZ6JZBR000000", oilSource = "Demo",
                supportedPids = Params.byPid.keys, mil = true, dtcCount = 2,
            )
        }
        log("Modo demo iniciado")
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            var t = 0.0
            while (isActive) {
                t += 0.1
                // Aceleraciones y retenciones cíclicas
                val ph = ((kotlin.math.sin(t * 0.45) + 1) / 2).let { it * it }
                val noise = { a: Double -> (Math.random() - 0.5) * a }
                val map = 101 + ph * 135 + noise(3.0)
                val v = mapOf(
                    "rpm" to 850 + ph * 3300 + noise(40.0),
                    "speed" to maxOf(0.0, -12 + ph * 135),
                    "load" to ph * 95 + noise(2.0),
                    "absload" to ph * 90,
                    "pedal" to ph * 100,
                    "pedal2" to ph * 50,
                    "throttle" to 20 + ph * 80,
                    "throttlecmd" to 20 + ph * 80,
                    "relthrottle" to ph * 80,
                    "torquedem" to ph * 100,
                    "torque" to ph * 96,
                    "torqueref" to 320.0,
                    "map" to map,
                    "baro" to 101.0,
                    Params.BOOST to (map - 101) / 100,
                    "maf" to 9 + ph * 150 + noise(2.0),
                    "egrcmd" to (1 - ph) * 55,
                    "egrerr" to noise(6.0),
                    "rail" to 280 + ph * 1450 + noise(20.0),
                    "fuelrate" to 0.9 + ph * 16,
                    "fuellevel" to 63.0,
                    "injtiming" to 2 + ph * 9,
                    "coolant" to 89 + kotlin.math.sin(t * 0.05) * 3,
                    "iat" to 28 + ph * 14,
                    "ambient" to 19.0,
                    "oil" to minOf(52 + t * 0.6, 97.0) + ph * 4,
                    Params.BATTERY to 14.1 + noise(0.15),
                    "modvolt" to 14.0 + noise(0.1),
                    "runtime" to t / 6,
                    "distmil" to 37.0,
                    "timemil" to 52.0,
                    "distclr" to 1240.0,
                    "timeclr" to 1530.0,
                    "warmups" to 41.0,
                )
                applyValues(v, replace = true, hz = 30.0)
                delay(100)
            }
        }
    }

    // ------------------------------------------------------------ Lectura en tiempo real

    private var batching = true
    private var batchMisses = 0
    private var suffixOk = true

    /** Lee un dato. Con el "1" final el adaptador contesta en cuanto llega la primera respuesta, sin esperar al tiempo límite. */
    private suspend fun readPid(e: Elm327, pid: Int): IntArray? {
        val base = "01%02X".format(pid)
        if (suffixOk) {
            val r = e.send(base + "1", 1500)
            if (r.trim().startsWith("?")) {
                suffixOk = false
                log("El adaptador no admite el atajo de respuesta única; se desactiva")
            } else return Elm327.mode01(r, pid)
        }
        return Elm327.mode01(e.send(base, 1500), pid)
    }

    private fun startPolling() {
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            var cycle = 0
            var rotate = 0
            var emptyCycles = 0
            var t0 = System.currentTimeMillis()
            var reads = 0
            try {
                while (isActive) {
                    val e = elm ?: break
                    val st = _state.value
                    val supported = st.supportedPids

                    // 1) Lo que hay en el panel, en cada vuelta
                    val pids = linkedSetOf<Int>()
                    for (id in st.live) {
                        when (id) {
                            Params.BOOST -> { pids += 0x0B; if (cycle % 20 == 0 && 0x33 in supported) pids += 0x33 }
                            else -> Params.byId[id]?.pid?.let { if (it in supported) pids += it }
                        }
                    }
                    // 2) Solo se lee lo que hay en pantalla. Del resto, uno cada pocas vueltas para ir
                    //    rellenando los demás menús sin frenar los relojes.
                    if (cycle % 5 == 0) {
                        val rest = Params.all.mapNotNull { it.pid }.filter { it in supported && it !in pids }
                        if (rest.isNotEmpty()) pids += rest[rotate++ % rest.size]
                    }

                    val newValues = mutableMapOf<String, Double>()
                    val list = pids.toList()
                    var idx = 0
                    while (idx < list.size) {
                        val chunk = list.subList(idx, minOf(idx + BATCH, list.size))
                        idx += chunk.size
                        val got = mutableMapOf<Int, IntArray>()
                        if (batching && chunk.size >= 2) {
                            // Varios datos en una sola petición: mucho más rápido
                            val cmd = "01" + chunk.joinToString("") { "%02X".format(it) }
                            got += Elm327.mode01Multi(e.send(cmd, 1500), chunk)
                            if (got.size < chunk.size) {
                                if (++batchMisses >= 2) {
                                    batching = false
                                    log("La centralita no admite varios datos por petición; se leen de uno en uno")
                                }
                            } else batchMisses = 0
                        }
                        // Lo que falte (o todo, si no hay lotes) se lee de uno en uno
                        for (pid in chunk) {
                            if (pid !in got) readPid(e, pid)?.let { got[pid] = it }
                        }
                        for ((pid, data) in got) {
                            val p = Params.byPid[pid] ?: continue
                            newValues[p.id] = p.calc(data)
                            reads++
                        }
                    }
                    // ¿Contestó el coche a las lecturas normales? (el aceite por UDS no cuenta)
                    val gotStd = newValues.isNotEmpty()
                    if (gotStd) emptyCycles = 0
                    else if (pids.isNotEmpty() && ++emptyCycles >= 3) {
                        // Los relojes se quedarían congelados: se reconfigura el adaptador sin desconectar
                        log("Sin respuesta a las lecturas normales · reconfigurando el adaptador")
                        emptyCycles = 0
                        for (c in listOf("ATE0", "ATL0", "ATS0", "ATH0", "ATAT2", "ATST 32")) e.send(c, 1500)
                        if (st.protocol.contains("15765")) e.send("ATSH7E0", 1500)
                    }
                    // Aceite por UDS (si el PID estándar no existe)
                    val did = oilDid
                    if (did != null && ("oil" in st.live || cycle % 10 == 5)) {
                        Elm327.mode22(e.send("22%04X".format(did), 1500), did)?.let { d ->
                            oilCalc(d, oilFormula)?.let { newValues["oil"] = it; reads++ }
                        }
                    }
                    // Candidatos de aceite en vivo (solo mientras se mira la lista en Ajustes)
                    if (watchCand && scanFound.isNotEmpty() && cycle % 2 == 0) {
                        val live = mutableMapOf<Int, Double>()
                        for (cd in scanFound.take(16)) {
                            val d = Elm327.mode22(e.send("22%04X".format(cd.did), 800), cd.did) ?: continue
                            oilCalc(d, cd.formula)?.let { live[cd.did] = it }
                        }
                        _state.update { it.copy(candLive = live) }
                    }
                    // Turbo relativo = MAP - presión atmosférica
                    val map = newValues["map"] ?: st.values["map"]
                    val baro = newValues["baro"] ?: st.values["baro"] ?: 101.3
                    if (map != null && "map" in newValues) newValues[Params.BOOST] = (map - baro) / 100.0

                    // Batería (la mide el propio adaptador)
                    if (cycle % 10 == 0 || (Params.BATTERY in st.live && cycle % 3 == 0)) {
                        e.send("ATRV", 800).replace("V", "").trim().toDoubleOrNull()?.let { newValues[Params.BATTERY] = it }
                    }

                    if (newValues.isNotEmpty()) applyValues(newValues, fresh = gotStd)
                    val now = System.currentTimeMillis()
                    if (now - t0 >= 2000) {
                        val hz = reads * 1000.0 / (now - t0)
                        _state.update { it.copy(refreshHz = hz) }
                        t0 = now; reads = 0
                    }
                    cycle++
                    if (pids.isEmpty()) delay(300)
                }
            } catch (ex: Exception) {
                if (isActive) disconnect("Conexión perdida: ${ex.message ?: ex.javaClass.simpleName}")
            }
        }
    }

    // ------------------------------------------------------------ Averías

    private suspend fun readStatus() {
        val e = elm ?: return
        val m = Elm327.messages(e.send("0101")).firstOrNull { it.size >= 3 && it[0] == 0x41 && it[1] == 0x01 }
        if (m != null) _state.update { it.copy(mil = (m[2] and 0x80) != 0, dtcCount = m[2] and 0x7F) }
    }

    fun readDtcs() {
        if (_state.value.demo) {
            _state.update {
                it.copy(
                    dtcs = listOf("P0401", "P2002"), pendingDtcs = listOf("P0299"), permanentDtcs = emptyList(),
                    mil = true, dtcCount = 2, dtcMessage = "Averías de ejemplo (modo demo)",
                    checks = listOf(
                        DiagCheck("Comunicación con la centralita", CheckLevel.OK, "Responde", "La centralita del motor contesta con normalidad."),
                        DiagCheck("Testigo de avería del motor", CheckLevel.MAL, "Encendido", "La centralita tiene guardada una avería que enciende el testigo."),
                        DiagCheck("Averías confirmadas", CheckLevel.MAL, "P0401 P2002", "La centralita ha confirmado 2 avería(s)."),
                        DiagCheck("Averías pendientes", CheckLevel.AVISO, "P0299", "Fallo detectado pero todavía sin confirmar."),
                        DiagCheck("Temperatura del refrigerante", CheckLevel.OK, "89 °C", "Temperatura normal de trabajo."),
                    ),
                )
            }
            return
        }
        val e = elm ?: return setDtcMessage("Conecta primero con el coche")
        if (_state.value.dtcBusy) return
        viewModelScope.launch {
            _state.update { it.copy(dtcBusy = true, dtcMessage = "Leyendo averías…", checks = emptyList()) }
            try {
                runCheckup(e)
            } catch (ex: Exception) {
                _state.update { it.copy(dtcBusy = false) }
                disconnect("Error leyendo averías: ${ex.message}")
            }
        }
    }

    private fun step(msg: String) = _state.update { it.copy(dtcMessage = msg) }
    private fun addCheck(name: String, level: CheckLevel, value: String, why: String) =
        _state.update { it.copy(checks = it.checks + DiagCheck(name, level, value, why)) }

    private suspend fun readPidOnce(e: Elm327, pid: Int): IntArray? =
        Elm327.mode01(e.send("01%02X".format(pid), 1500), pid)

    /**
     * Diagnóstico completo: lee estado, averías y varios datos en vivo, y para cada cosa dice si está
     * bien o mal y por qué. Va añadiendo líneas a medida que las lee.
     */
    private suspend fun runCheckup(e: Elm327) {
        // 1) Comunicación y estado general (testigo, controles)
        step("Comprobando la comunicación con la centralita…")
        val s01 = Elm327.messages(e.send("0101")).firstOrNull { it.size >= 6 && it[0] == 0x41 && it[1] == 0x01 }
        if (s01 == null) {
            addCheck(
                "Comunicación con la centralita", CheckLevel.MAL, "Sin respuesta",
                "La centralita del motor no contestó. Pon el contacto y comprueba que el cable está bien enchufado.",
            )
            _state.update { it.copy(dtcBusy = false, dtcMessage = "No se pudo leer la centralita") }
            return
        }
        addCheck("Comunicación con la centralita", CheckLevel.OK, "Responde", "La centralita del motor contesta con normalidad.")
        val mil = (s01[2] and 0x80) != 0
        val count = s01[2] and 0x7F
        _state.update { it.copy(mil = mil, dtcCount = count) }
        if (mil) addCheck(
            "Testigo de avería del motor", CheckLevel.MAL, "Encendido",
            "La centralita tiene guardada una avería que enciende el testigo. Mira las averías confirmadas más abajo.",
        ) else addCheck(
            "Testigo de avería del motor", CheckLevel.OK, "Apagado", "No hay ninguna avería que obligue a encender el testigo.",
        )

        // 2) Averías
        step("Leyendo averías confirmadas…")
        val stored = Elm327.dtcs(e.send("03", 6000), 0x43)
        if (stored.isEmpty()) addCheck("Averías confirmadas", CheckLevel.OK, "Ninguna", "No hay averías guardadas en la memoria de la centralita.")
        else addCheck(
            "Averías confirmadas", CheckLevel.MAL, stored.joinToString(" "),
            "La centralita ha confirmado ${stored.size} avería(s). Tienen que revisarse: el detalle de cada una está en la lista de abajo.",
        )
        step("Leyendo averías pendientes…")
        val pending = Elm327.dtcs(e.send("07", 6000), 0x47)
        if (pending.isEmpty()) addCheck("Averías pendientes", CheckLevel.OK, "Ninguna", "No hay fallos detectados que estén aún sin confirmar.")
        else addCheck(
            "Averías pendientes", CheckLevel.AVISO, pending.joinToString(" "),
            "Se ha detectado un fallo pero todavía no se ha repetido lo suficiente para confirmarlo. Si vuelve a pasar, se convertirá en avería confirmada.",
        )
        step("Leyendo averías permanentes…")
        val permanent = Elm327.dtcs(e.send("0A", 6000), 0x4A)
        if (permanent.isEmpty()) addCheck("Averías permanentes", CheckLevel.OK, "Ninguna", "No hay averías permanentes (las que solo se borran al reparar y pasar los controles).")
        else addCheck(
            "Averías permanentes", CheckLevel.MAL, permanent.joinToString(" "),
            "Son averías que no se pueden borrar con el lector: desaparecen solas cuando se repara el fallo y la centralita lo comprueba.",
        )
        _state.update { it.copy(dtcs = stored, pendingDtcs = pending, permanentDtcs = permanent) }

        // 3) Controles de preparación (los de la ITV)
        step("Leyendo los controles de preparación…")
        val b = s01[3]; val c = s01[4]; val d = s01[5]
        val diesel = (b and 0x08) != 0
        fun mon(name: String, supported: Boolean, incomplete: Boolean) {
            if (!supported) return
            if (!incomplete) addCheck("Control: $name", CheckLevel.OK, "Completado", "La centralita ya ha comprobado este sistema y está correcto.")
            else addCheck(
                "Control: $name", CheckLevel.INFO, "Pendiente",
                "Aún no ha terminado su autocomprobación. No es una avería: es normal si se han borrado averías hace poco o se ha conducido poco.",
            )
        }
        mon("Fallos de combustión", (b and 0x01) != 0, (b and 0x10) != 0)
        mon("Sistema de combustible", (b and 0x02) != 0, (b and 0x20) != 0)
        mon("Componentes del motor", (b and 0x04) != 0, (b and 0x40) != 0)
        val names = if (diesel) {
            listOf("Catalizador", "Catalizador NOx/SCR", "", "Presión del turbo", "", "Sensores de gases de escape", "Filtro de partículas (FAP)", "EGR / distribución variable")
        } else {
            listOf("Catalizador", "Catalizador calefactado", "Sistema evaporativo", "Aire secundario", "Aire acondicionado", "Sonda lambda", "Calentador de sonda", "EGR")
        }
        for (i in 0..7) if (names[i].isNotEmpty()) mon(names[i], (c shr i) and 1 == 1, (d shr i) and 1 == 1)

        // 4) Datos en vivo con su valoración
        step("Comprobando datos en vivo…")
        val rpm = readPidOnce(e, 0x0C)?.let { (it[0] * 256 + it[1]) / 4.0 }
        val running = rpm != null && rpm > 400
        val secs = readPidOnce(e, 0x1F)?.let { (it[0] * 256 + it[1]).toDouble() }

        val coolant = readPidOnce(e, 0x05)?.let { it[0] - 40.0 }
        if (coolant != null) {
            val v = "%.0f °C".format(coolant)
            when {
                coolant >= 106 -> addCheck("Temperatura del refrigerante", CheckLevel.MAL, v, "Demasiado alta: riesgo de sobrecalentamiento. Para el motor, y revisa nivel de líquido, ventilador y termostato.")
                coolant >= 80 -> addCheck("Temperatura del refrigerante", CheckLevel.OK, v, "Temperatura normal de trabajo.")
                running && secs != null && secs > 600 -> addCheck("Temperatura del refrigerante", CheckLevel.AVISO, v, "Lleva más de 10 minutos en marcha y no llega a 80 °C. Puede ser un termostato que se queda abierto.")
                else -> addCheck("Temperatura del refrigerante", CheckLevel.INFO, v, "El motor todavía se está calentando.")
            }
        }

        val volt = e.send("ATRV", 800).replace("V", "").trim().toDoubleOrNull()
            ?: readPidOnce(e, 0x42)?.let { (it[0] * 256 + it[1]) / 1000.0 }
        if (volt != null) {
            val v = "%.1f V".format(volt)
            if (running) {
                when {
                volt > 15.0 -> addCheck("Tensión de la batería", CheckLevel.MAL, v, "Demasiado alta con el motor en marcha: el regulador del alternador puede estar fallando y dañar la batería.")
                volt >= 13.2 -> addCheck("Tensión de la batería", CheckLevel.OK, v, "El alternador carga bien.")
                volt >= 12.6 -> addCheck("Tensión de la batería", CheckLevel.AVISO, v, "El alternador carga poco con el motor en marcha. Con muchos consumos puede ser normal; si se repite, hay que revisarlo.")
                else -> addCheck("Tensión de la batería", CheckLevel.MAL, v, "Con el motor en marcha debería estar sobre 13,5–14,5 V. El alternador no carga o hay mala conexión.")
                }
            } else {
                when {
                volt >= 12.4 -> addCheck("Tensión de la batería", CheckLevel.OK, v, "Batería bien cargada (motor parado).")
                volt >= 12.0 -> addCheck("Tensión de la batería", CheckLevel.AVISO, v, "Batería algo baja con el motor parado. Conviene arrancar y comprobar que carga.")
                else -> addCheck("Tensión de la batería", CheckLevel.MAL, v, "Batería descargada o en mal estado.")
                }
            }
        }

        if (running) {
            val rail = readPidOnce(e, 0x23)?.let { (it[0] * 256 + it[1]) / 10.0 }
            if (rail != null && rpm != null && rpm < 1300) {
                val v = "%.0f bar".format(rail)
                if (rail in 180.0..650.0) addCheck("Presión del rail de inyección (ralentí)", CheckLevel.OK, v, "Presión normal para el ralentí.")
                else if (rail < 180) addCheck("Presión del rail de inyección (ralentí)", CheckLevel.AVISO, v, "Baja para el ralentí. Puede indicar filtro de gasoil sucio, aire en el circuito o bomba floja.")
                else addCheck("Presión del rail de inyección (ralentí)", CheckLevel.AVISO, v, "Alta para el ralentí. Puede ser el regulador de presión o el sensor.")
            }
        } else {
            addCheck("Presión del rail de inyección", CheckLevel.INFO, "Motor parado", "Se valora con el motor en marcha y al ralentí.")
        }

        val iat = readPidOnce(e, 0x0F)?.let { it[0] - 40.0 }
        if (iat != null) {
            val v = "%.0f °C".format(iat)
            if (iat >= 60) addCheck("Temperatura del aire de admisión", CheckLevel.AVISO, v, "Alta: el aire llega muy caliente. Revisa el intercooler y sus manguitos.")
            else addCheck("Temperatura del aire de admisión", CheckLevel.OK, v, "Valor normal.")
        }

        val oil = _state.value.values["oil"]
        if (oil != null) {
            val v = "%.0f °C".format(oil)
            when {
                oil >= 135 -> addCheck("Temperatura del aceite", CheckLevel.MAL, v, "Demasiado alta: el aceite pierde capacidad de lubricar. Baja el ritmo y revisa el nivel.")
                oil >= 120 -> addCheck("Temperatura del aceite", CheckLevel.AVISO, v, "Alta. Es normal solo con mucha carga mantenida.")
                oil >= 70 -> addCheck("Temperatura del aceite", CheckLevel.OK, v, "Temperatura normal de trabajo.")
                else -> addCheck("Temperatura del aceite", CheckLevel.INFO, v, "El aceite todavía está frío: evita revolucionar el motor.")
            }
        } else {
            addCheck("Temperatura del aceite", CheckLevel.INFO, "No se lee", "Todavía no se ha configurado de dónde sale este dato (Ajustes → Temperatura del aceite).")
        }

        val sinceClear = readPidOnce(e, 0x31)?.let { (it[0] * 256 + it[1]).toDouble() }
        if (sinceClear != null) {
            val v = "%.0f km".format(sinceClear)
            if (sinceClear < 50) addCheck("Km desde el último borrado de averías", CheckLevel.INFO, v, "Se borraron hace muy poco. Los controles de preparación pueden estar incompletos y habría que conducir un rato.")
            else addCheck("Km desde el último borrado de averías", CheckLevel.OK, v, "Hace tiempo que se borraron o nunca se han borrado: el historial es fiable.")
        }

        // 5) Resumen
        val cs = _state.value.checks
        val ok = cs.count { it.level == CheckLevel.OK }
        val warn = cs.count { it.level == CheckLevel.AVISO }
        val bad = cs.count { it.level == CheckLevel.MAL }
        _state.update {
            it.copy(
                dtcBusy = false,
                dtcMessage = "$ok bien · $warn avisos · $bad mal · ${timeFmt.format(Date())}",
            )
        }
    }

    fun clearDtcs() {
        if (_state.value.demo) {
            _state.update {
                it.copy(
                    dtcs = emptyList(), pendingDtcs = emptyList(), permanentDtcs = emptyList(),
                    mil = false, dtcCount = 0, dtcMessage = "Averías borradas (modo demo)",
                )
            }
            return
        }
        val e = elm ?: return setDtcMessage("Conecta primero con el coche")
        viewModelScope.launch {
            _state.update { it.copy(dtcBusy = true, dtcMessage = "Borrando averías…") }
            try {
                val r = e.send("04", 6000)
                val ok = Elm327.messages(r).any { it.isNotEmpty() && it[0] == 0x44 }
                _state.update {
                    it.copy(
                        dtcBusy = false,
                        dtcMessage = if (ok) "Averías borradas. Si el fallo sigue presente volverá a aparecer."
                        else "El coche no confirmó el borrado ($r). Prueba con contacto puesto y motor parado.",
                    )
                }
                if (ok) readDtcs()
            } catch (ex: Exception) {
                _state.update { it.copy(dtcBusy = false) }
                disconnect("Error borrando averías: ${ex.message}")
            }
        }
    }

    private fun setDtcMessage(m: String) = _state.update { it.copy(dtcMessage = m) }

    // ------------------------------------------------------------ Consola

    fun sendRaw(cmd: String) {
        val e = elm ?: return log("No conectado")
        viewModelScope.launch {
            try { log("> $cmd\n" + e.send(cmd.trim().uppercase(), 5000).ifEmpty { "(sin respuesta)" }) }
            catch (ex: Exception) { disconnect("Error: ${ex.message}") }
        }
    }

    // ------------------------------------------------------------ Utilidades

    private fun setStatus(s: String) { _state.update { it.copy(status = s) }; log(s) }

    private fun log(s: String) {
        val line = "${timeFmt.format(Date())}  $s"
        _state.update { it.copy(log = (it.log + line).takeLast(400)) }
    }

    override fun onCleared() {
        disconnect()
        try { getApplication<Application>().unregisterReceiver(receiver) } catch (_: Exception) { }
    }

    companion object {
        const val HISTORY = 600
        const val ACTION_PERMISSION = "com.ikker.obdibiza.USB_PERMISSION"
        /** Cuántos datos se piden a la vez en una sola petición. */
        const val BATCH = 4
        /** Si el coche no da ningún dato en este tiempo se reinicia la conexión. */
        const val NO_DATA_MS = 15_000L
        /** Tiempo máximo para completar una conexión antes de abandonarla y reintentar. */
        const val CONNECT_TIMEOUT_MS = 60_000L
    }
}
