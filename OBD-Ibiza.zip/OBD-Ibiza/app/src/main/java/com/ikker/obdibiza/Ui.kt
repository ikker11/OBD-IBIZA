package com.ikker.obdibiza

import android.Manifest
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.Image
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.Typeface
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.cos
import kotlin.math.sin

// ═══════════════════════════════════════════════════════════════════ Estilo
// Inspirado en el monitor de prestaciones de los Leon deportivos: gris grafito con textura,
// barras superior e inferior con líneas rojas en diagonal, relojes de bisel plateado fino,
// aguja roja corta y número grande y fino en un buje cromado.

object K {
    val bgTop = Color(0xFF2A2A2C)
    val bgBottom = Color(0xFF121213)
    val bar = Color(0xFF1C1C1E)
    val barTab = Color(0xFF2E2E31)
    val panel = Color(0xFF1B1B1D)
    val panel2 = Color(0xFF2A2A2D)
    val line = Color(0xFF3A3A3E)
    val label = Color(0xFFEDEDED)
    val label2 = Color(0xFFA0A0A6)
    val label3 = Color(0xFF5A5A60)
    val red = Color(0xFFE2001A)
    val redGlow = Color(0xFFFF2B3F)
    val amber = Color(0xFFFFB020)
    val green = Color(0xFF34C759)
    /** Rojo anaranjado de los displays del cuadro y la radio. */
    val lcd = Color(0xFFFF3A22)
    val silverHi = Color(0xFFF4F4F6)
    val silver = Color(0xFFB9B9BE)
    val silverLo = Color(0xFF55555A)
}

private fun family(name: String) = FontFamily(Typeface(android.graphics.Typeface.create(name, android.graphics.Typeface.NORMAL)))

/** Rótulos: Roboto Condensed. Números grandes: Roboto Condensed Light, finos como en el monitor original. */
val Cond = family("sans-serif-condensed")
/** Condensada en negrita de verdad (la de arriba se crea normal y el sistema no la engorda). */
val CondBold = FontFamily(Typeface(android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD)))
val CondLight = family("sans-serif-condensed-light")

private val Num = TextStyle(fontFamily = Cond, fontFeatureSettings = "tnum")
private val NumLight = TextStyle(fontFamily = CondLight, fontFeatureSettings = "tnum")
private val Caps = TextStyle(fontFamily = Cond, letterSpacing = 0.4.sp)
private fun Chamfer(cut: Dp) = CutCornerShape(topStart = 0.dp, topEnd = cut, bottomEnd = 0.dp, bottomStart = cut)
private val PanelShape = Chamfer(8.dp)

@Composable
private fun Dp.sp(): TextUnit = with(LocalDensity.current) { this@sp.toSp() }

enum class Tab(val heading: String) {
    PANEL("Performance"),
    MENU("Menú"),
    GRAFICAS("Gráficas"),
    BARRAS("Barras"),
    VIAJE("Viaje"),
    CRONO("Cronómetro"),
    DATOS("Datos en vivo"),
    AVERIAS("Averías"),
    AJUSTES("Ajustes"),
    RUEDAS("Ruedas"),
}

/** Fondo grafito con degradado y una fina trama en diagonal. */
private fun Modifier.carbon() = this
    .background(Brush.verticalGradient(listOf(K.bgTop, K.bgBottom)))
    .drawBehind {
        val step = 4.dp.toPx()
        var x = -size.height
        while (x < size.width) {
            drawLine(Color.White.copy(alpha = 0.022f), Offset(x, size.height), Offset(x + size.height, 0f), 1f)
            x += step
        }
        drawRect(Brush.radialGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.45f)), center, size.maxDimension * 0.75f))
    }

// ═══════════════════════════════════════════════════════════════════ Raíz

@Composable
fun ObdApp(vm: ObdViewModel) {
    val st by vm.state.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableStateOf(Tab.PANEL) }
    var immersive by rememberSaveable { mutableStateOf(false) }
    // Editor de la página: copia de los relojes mientras se mueven (null = no se está editando)
    var draft by remember { mutableStateOf<List<GaugeItem>?>(null) }
    var pickFor by remember { mutableStateOf<Int?>(null) }
    var pagesSheet by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(primary = K.red, background = K.bgBottom, surface = K.panel)) {
        Box(Modifier.fillMaxSize().carbon()) {
            Column(Modifier.fillMaxSize()) {
                AnimatedVisibility(!immersive, enter = fadeIn(), exit = fadeOut()) {
                    val d = draft
                    if (d != null) {
                        FrameBar(
                            top = true, left = "CANCELAR", center = "Editando: ${vm.pageName(st, st.page)}", right = "ORIGINAL",
                            onLeft = { draft = null }, onCenter = {},
                            onRight = { draft = defaultLayout(Params.defaultPages[st.page % Params.defaultPages.size]) },
                        )
                    } else {
                        val connLabel = when (st.conn) {
                            Conn.DESCONECTADO -> "CONECTAR"
                            Conn.CONECTANDO -> "CONECTANDO…"
                            Conn.CONECTADO -> if (st.demo) "SALIR DEMO" else "DESCONECTAR"
                        }
                        FrameBar(
                            top = true,
                            left = connLabel, center = "MENÚ", right = if (st.mil == true) "AVERÍAS •" else "AVERÍAS",
                            rightColor = if (st.mil == true) K.amber else K.label,
                            onLeft = { if (st.conn == Conn.DESCONECTADO) vm.connect() else vm.userDisconnect() },
                            onCenter = { tab = if (tab == Tab.MENU) Tab.PANEL else Tab.MENU },
                            onRight = { tab = Tab.AVERIAS },
                            // Ruedas con poco aire: el cochecito con esas ruedas en rojo, en el hueco junto a AVERÍAS
                            rightExtra = if (st.tyreFlats.isNotEmpty() && st.opt(AlertKey.TYRE_ON) == 1) ({
                                val blink = blinkValue(1400)
                                Canvas(Modifier.offset(y = (-3).dp).size(46.dp).clickable { tab = Tab.RUEDAS }) {
                                    drawCarTop(center, size.height * 0.43f, st.tyreFlats, blink)
                                }
                            }) else null,
                        )
                    }
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (tab) {
                        Tab.PANEL -> PanelScreen(
                            st, vm, immersive, draft,
                            onDraft = { draft = it }, onPick = { pickFor = it },
                        ) { immersive = !immersive }
                        Tab.MENU -> MenuScreen(st, vm, onGo = { tab = it }, onImmersive = { tab = Tab.PANEL; immersive = true })
                        Tab.GRAFICAS -> ChartsScreen(st, vm)
                        Tab.BARRAS -> BarsScreen(st, vm)
                        Tab.VIAJE -> TripScreen(st, vm)
                        Tab.CRONO -> AccelScreen(st, vm)
                        Tab.DATOS -> DataScreen(st, vm)
                        Tab.AVERIAS -> DtcScreen(st, vm)
                        Tab.AJUSTES -> SettingsScreen(st, vm)
                        Tab.RUEDAS -> TyreScreen(st, vm)
                    }
                }
                AnimatedVisibility(!immersive, enter = fadeIn(), exit = fadeOut()) {
                    val d = draft
                    when {
                        tab == Tab.PANEL && d != null -> FrameBar(
                            top = false, left = "＋ AÑADIR RELOJ", center = "GUARDAR", right = "PÁGINAS",
                            onLeft = { draft = d + GaugeItem("coolant", 0.5f, 0.5f, 0.5f) },
                            onCenter = { vm.setCurrentPage(d); draft = null },
                            onRight = { vm.setCurrentPage(d); draft = null; pagesSheet = true },
                        )
                        tab == Tab.PANEL -> FrameBar(
                            top = false,
                            left = "◁ ANTERIOR", center = "SETUP", right = "SIGUIENTE ▷",
                            onLeft = { vm.movePage(-1) },
                            onCenter = { draft = st.pages.getOrNull(st.page) ?: emptyList() },
                            onRight = { vm.movePage(1) },
                        )
                        else -> FrameBar(
                            top = false, left = "◁ MENÚ", center = tab.heading, right = "PERFORMANCE ▷",
                            onLeft = { tab = Tab.MENU }, onCenter = {}, onRight = { tab = Tab.PANEL },
                        )
                    }
                }
            }
        }
        val pf = pickFor
        val dr = draft
        if (pf != null && dr != null && pf in dr.indices) {
            ParamPicker("Dato del reloj", dr[pf].id, st, emptySet(), onPick = { id ->
                draft = dr.mapIndexed { j, g -> if (j == pf) g.copy(id = id) else g }
                pickFor = null
            }, onDismiss = { pickFor = null })
        }
        if (pagesSheet) PagesSheet(st, vm) { pagesSheet = false }
    }
}

// ═══════════════════════════════════════════════════════════════════ Barras con líneas rojas

/**
 * Barra con tres botones. Los laterales son paneles algo más claros con una línea roja
 * que corre por su borde y sube (o baja) en diagonal hacia el centro.
 */
@Composable
private fun FrameBar(
    top: Boolean,
    left: String, center: String, right: String,
    onLeft: () -> Unit, onCenter: () -> Unit, onRight: () -> Unit,
    rightColor: Color = K.label,
    /** Algo pequeño a la izquierda del texto de la derecha (el cochecito de las ruedas). */
    rightExtra: (@Composable () -> Unit)? = null,
) {
    Box(
        Modifier.fillMaxWidth().height(54.dp)
            .background(Brush.verticalGradient(if (top) listOf(Color(0xFF101011), K.bar) else listOf(K.bar, Color(0xFF101011))))
            .drawBehind {
                val w = size.width
                val h = size.height
                val sw = 2.6.dp.toPx()
                val tabW = w * 0.30f
                val slope = h * 0.55f
                // Paneles laterales
                val yEdge = if (top) h - 6.dp.toPx() else 6.dp.toPx()
                val yFar = if (top) 0f else h
                val lp = Path().apply { moveTo(0f, yFar); lineTo(tabW + slope, yFar); lineTo(tabW, yEdge); lineTo(0f, yEdge); close() }
                val rp = Path().apply { moveTo(w, yFar); lineTo(w - tabW - slope, yFar); lineTo(w - tabW, yEdge); lineTo(w, yEdge); close() }
                val tabBrush = Brush.verticalGradient(listOf(K.barTab, Color(0xFF1F1F21)))
                drawPath(lp, tabBrush)
                drawPath(rp, tabBrush)
                // Líneas rojas
                val yLine = yEdge + if (top) 2.dp.toPx() else (-2).dp.toPx()
                val yUp = if (top) 4.dp.toPx() else h - 4.dp.toPx()
                val l = Path().apply { moveTo(w * 0.015f, yLine); lineTo(tabW, yLine); lineTo(tabW + slope * 0.9f, yUp) }
                val r = Path().apply { moveTo(w * 0.985f, yLine); lineTo(w - tabW, yLine); lineTo(w - tabW - slope * 0.9f, yUp) }
                drawPath(l, K.red, style = Stroke(sw, join = StrokeJoin.Miter))
                drawPath(r, K.red, style = Stroke(sw, join = StrokeJoin.Miter))
                // Línea fina de separación con el contenido
                val ySep = if (top) h - 0.5f else 0.5f
                drawLine(Color.Black, Offset(0f, ySep), Offset(w, ySep), 1.5f)
            },
    ) {
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            BarText(left, Modifier.weight(0.30f), TextAlign.Start, K.label, onLeft)
            BarText(center, Modifier.weight(0.40f), TextAlign.Center, K.label, onCenter)
            if (rightExtra == null) BarText(right, Modifier.weight(0.30f), TextAlign.End, rightColor, onRight)
            else Row(Modifier.weight(0.30f).fillMaxHeight(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                rightExtra()
                BarText(right, Modifier, TextAlign.End, rightColor, onRight)
            }
        }
    }
}

@Composable
private fun BarText(text: String, modifier: Modifier, align: TextAlign, color: Color, onClick: () -> Unit) {
    Box(
        modifier.fillMaxHeight().clickable(enabled = text.isNotEmpty(), onClick = onClick).padding(horizontal = 22.dp),
        contentAlignment = when (align) { TextAlign.Start -> Alignment.CenterStart; TextAlign.End -> Alignment.CenterEnd; else -> Alignment.Center },
    ) {
        Text(text, color = color, style = Caps, fontSize = 21.sp, maxLines = 1)
    }
}

@Composable
fun RedButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.clip(Chamfer(8.dp)).background(if (enabled) K.red else K.panel2)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = if (enabled) Color.White else K.label3, style = Caps, fontSize = 16.sp) }
}

@Composable
fun BarButton(text: String, color: Color = K.label, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.clickable(enabled = enabled, onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp),
    ) { Text(text, color = if (enabled) color else K.label3, style = Caps, fontSize = 16.sp) }
}

// ═══════════════════════════════════════════════════════════════════ PANEL

@Composable
private fun PanelScreen(
    st: UiState, vm: ObdViewModel, immersive: Boolean,
    draft: List<GaugeItem>?, onDraft: (List<GaugeItem>) -> Unit, onPick: (Int) -> Unit,
    onToggleImmersive: () -> Unit,
) {
    val items = draft ?: st.pages.getOrNull(st.page) ?: emptyList()
    val editing = draft != null
    var fixOpen by remember { mutableStateOf(false) }
    if (fixOpen) FixDialog(st, vm) { fixOpen = false }
    val current by rememberUpdatedState(items)
    val setDraft by rememberUpdatedState(onDraft)
    // El logo va siempre en el reloj del medio (el más cercano al centro de la pantalla)
    val mainIndex = items.indices.minByOrNull { kotlin.math.abs(items[it].x - 0.5f) } ?: -1

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 4.dp)) {
        PageTitle(vm.pageName(st, st.page), st.pages.size, st.page, Modifier.fillMaxWidth().height(45.dp))
        BoxWithConstraints(
            Modifier.fillMaxWidth().weight(1f)
                .clickable(remember { MutableInteractionSource() }, null, enabled = immersive && !editing) { onToggleImmersive() },
        ) {
            val w = maxWidth
            val h = maxHeight
            val head = if (editing) 34.dp else 0.dp
            // Nombre del reloj: 17 sp y 8 dp por debajo del reloj (elegido en la réplica, 3-nov-2026)
            val extra = head + 33.dp
            val wPx = with(LocalDensity.current) { w.toPx() }
            val hPx = with(LocalDensity.current) { h.toPx() }
            items.forEachIndexed { i, g ->
                val p = Params.byId[g.id] ?: return@forEachIndexed
                val d = (h - extra) * g.size
                val slotW = maxOf(d, 230.dp)
                Box(
                    Modifier
                        .offset(x = w * g.x - slotW / 2, y = h * g.y - d / 2 - head)
                        .width(slotW)
                        .pointerInput(i, editing) {
                            if (editing) detectDragGestures { change, amount ->
                                change.consume()
                                val list = current
                                if (i in list.indices) {
                                    val it0 = list[i]
                                    setDraft(list.mapIndexed { j, x ->
                                        if (j == i) x.copy(
                                            x = (it0.x + amount.x / wPx).coerceIn(0f, 1f),
                                            y = (it0.y + amount.y / hPx).coerceIn(0f, 1f),
                                        ) else x
                                    })
                                }
                            }
                        },
                    contentAlignment = Alignment.TopCenter,
                ) {
                    GaugeSlot(
                        p, st, d, logo = if (i == mainIndex) st.logo else null,
                        editing = editing,
                        onUp = { vm.cycleGauge(i, -1) }, onDown = { vm.cycleGauge(i, 1) },
                        onBigger = { setDraft(current.mapIndexed { j, x -> if (j == i) x.copy(size = (x.size + 0.05f).coerceAtMost(1.6f)) else x }) },
                        onSmaller = { setDraft(current.mapIndexed { j, x -> if (j == i) x.copy(size = (x.size - 0.05f).coerceAtLeast(0.25f)) else x }) },
                        onRemove = { setDraft(current.filterIndexed { j, _ -> j != i }) },
                        onChange = { onPick(i) },
                        onFix = { fixOpen = true },
                    )
                }
            }
            if (editing) {
                Text(
                    "Arrastra los relojes para moverlos. Usa − y + para el tamaño, ✕ para quitar y CAMBIAR para elegir el dato.",
                    color = K.label2, fontSize = 13.sp, modifier = Modifier.align(Alignment.BottomCenter),
                )
            }
        }
    }
}

/** Título con una costura roja a cada lado (como el volante) y un trazo por página. */
@Composable
private fun PageTitle(title: String, pages: Int, page: Int, modifier: Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val y = size.height - 4.dp.toPx()
            val dash = PathEffect.dashPathEffect(floatArrayOf(7.dp.toPx(), 5.dp.toPx()))
            drawLine(K.red.copy(alpha = 0.75f), Offset(size.width * 0.12f, y), Offset(size.width * 0.38f, y), 1.6.dp.toPx(), pathEffect = dash)
            drawLine(K.red.copy(alpha = 0.75f), Offset(size.width * 0.62f, y), Offset(size.width * 0.88f, y), 1.6.dp.toPx(), pathEffect = dash)
            val segW = 22.dp.toPx()
            val gap = 6.dp.toPx()
            val total = pages * segW + (pages - 1) * gap
            var x = (size.width - total) / 2
            for (i in 0 until pages) {
                drawLine(if (i == page) K.red else K.label3, Offset(x, y), Offset(x + segW, y), 3.dp.toPx())
                x += segW + gap
            }
        }
        Text(title, color = K.label, style = Caps, fontSize = 20.sp, maxLines = 1, modifier = Modifier.padding(bottom = 9.dp))
    }
}

@Composable
private fun GaugeSlot(
    p: Param, st: UiState, d: Dp, logo: ImageBitmap?, editing: Boolean,
    onUp: () -> Unit, onDown: () -> Unit,
    onBigger: () -> Unit, onSmaller: () -> Unit, onRemove: () -> Unit, onChange: () -> Unit,
    onFix: () -> Unit = {},
) {
    val v = st.values[p.id]
    val (caption, capColor) = when {
        p.id == "oil" && v == null && st.conn == Conn.CONECTADO && !st.demo -> "Aceite · esperando a la centralita" to K.label2
        p.id == "oil" && p.isCold(v) -> "Aceite frío · no apures" to K.amber
        p.id == "oil" && p.isHot(v) -> "Aceite muy caliente" to K.redGlow
        (p.id == Params.BOOST || p.id == "map") && st.boostCapped -> "${p.short} · en el tope del dato OBD" to K.amber
        p.id == "speed" && st.limitOn -> st.limitRoad to K.label2
        p.isHot(v) -> "${p.short} · alto" to K.redGlow
        else -> p.short to K.label2
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        if (editing) {
            Row(Modifier.height(34.dp), verticalAlignment = Alignment.CenterVertically) {
                EditChip("−", onSmaller)
                EditChip("+", onBigger)
                EditChip("CAMBIAR", onChange)
                EditChip("✕", onRemove, K.redGlow)
            }
        }
        Box {
            // Tocar el reloj de velocidad: corregir el límite de la vía si no coincide con la señal
            val tap = if (p.id == "speed" && !editing && st.limitOn) Modifier.clickable(onClick = onFix) else Modifier
            ClusterGauge(p, st, logo, Modifier.size(d).then(tap))
            if (editing) {
                Canvas(Modifier.size(d)) {
                    drawCircle(
                        K.red, size.minDimension / 2, style = Stroke(
                            2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(8.dp.toPx(), 6.dp.toPx())),
                        ),
                    )
                }
            }
        }
        if (p.id == "speed" && st.limitOn) RoadText(st.limitRoad, Modifier.padding(top = 8.dp), small = true)
        else Text(caption, color = capColor, style = Caps, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun EditChip(text: String, onClick: () -> Unit, color: Color = K.label) {
    Box(
        Modifier.padding(horizontal = 3.dp).clip(Chamfer(5.dp)).background(K.panel2).border(1.dp, K.line, Chamfer(5.dp))
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 4.dp),
    ) { Text(text, color = color, style = Caps, fontSize = 15.sp) }
}

@Composable
private fun Chevron(up: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(width = 64.dp, height = 22.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(width = 18.dp, height = 8.dp)) {
            val p = Path().apply {
                if (up) { moveTo(0f, size.height); lineTo(size.width / 2, 0f); lineTo(size.width, size.height) }
                else { moveTo(0f, 0f); lineTo(size.width / 2, size.height); lineTo(size.width, 0f) }
            }
            drawPath(p, K.label2, style = Stroke(1.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

/** Ondas pequeñas entre x0 y x1 a la altura y. */
private fun DrawScope.wave(x0: Float, x1: Float, y: Float, s: Float, color: Color, sw: Float) {
    val seg = s * 0.09f
    val path = Path().apply {
        moveTo(x0, y)
        var x = x0
        var up = true
        while (x < x1 - 0.5f) {
            val nx = minOf(x + seg, x1)
            quadraticBezierTo((x + nx) / 2, y + if (up) -s * 0.06f else s * 0.06f, nx, y)
            x = nx; up = !up
        }
    }
    drawPath(path, color, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

/** Termómetro: varilla, tres rayitas a la derecha y bulbo abajo. */
private fun DrawScope.thermo(x: Float, top: Float, bottom: Float, s: Float, color: Color, sw: Float) {
    drawLine(color, Offset(x, top), Offset(x, bottom), sw * 1.25f, cap = StrokeCap.Round)
    for (k in 0..2) {
        val y = top + s * (0.06f + k * 0.11f)
        drawLine(color, Offset(x + s * 0.07f, y), Offset(x + s * 0.19f, y), sw * 0.8f, cap = StrokeCap.Round)
    }
    drawCircle(color, s * 0.1f, Offset(x, bottom + s * 0.06f))
}

/** Testigo de temperatura del refrigerante, como en el cuadro: termómetro metido en ondas. */
private fun DrawScope.drawCoolantIcon(c: Offset, s: Float, color: Color) {
    val sw = s * 0.08f
    thermo(c.x, c.y - s * 0.5f, c.y + s * 0.12f, s, color, sw)
    // Onda de arriba partida por el bulbo y onda de abajo entera
    wave(c.x - s * 0.5f, c.x - s * 0.15f, c.y + s * 0.22f, s, color, sw)
    wave(c.x + s * 0.15f, c.x + s * 0.5f, c.y + s * 0.22f, s, color, sw)
    wave(c.x - s * 0.45f, c.x + s * 0.45f, c.y + s * 0.4f, s, color, sw)
}

/** Testigo de temperatura del aceite, como en el cuadro: aceitera en línea con termómetro dentro y gota. */
private fun DrawScope.drawOilTempIcon(c: Offset, s: Float, color: Color) {
    val sw = s * 0.08f
    // Cuerpo de la aceitera (contorno)
    val body = Path().apply {
        moveTo(c.x - s * 0.08f, c.y + s * 0.02f)
        lineTo(c.x - s * 0.32f, c.y + s * 0.02f)
        lineTo(c.x - s * 0.32f, c.y + s * 0.32f)
        lineTo(c.x + s * 0.20f, c.y + s * 0.32f)
        lineTo(c.x + s * 0.56f, c.y + s * 0.04f)
        lineTo(c.x + s * 0.40f, c.y + s * 0.06f)
        lineTo(c.x + s * 0.16f, c.y + s * 0.02f)
    }
    drawPath(body, color, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
    // Asa redondeada a la izquierda
    drawRoundRect(
        color, Offset(c.x - s * 0.58f, c.y - s * 0.02f), Size(s * 0.26f, s * 0.2f),
        androidx.compose.ui.geometry.CornerRadius(s * 0.08f), style = Stroke(sw),
    )
    // Gota bajo el pico
    val drop = Path().apply {
        moveTo(c.x + s * 0.56f, c.y + s * 0.14f)
        quadraticBezierTo(c.x + s * 0.63f, c.y + s * 0.26f, c.x + s * 0.56f, c.y + s * 0.29f)
        quadraticBezierTo(c.x + s * 0.49f, c.y + s * 0.26f, c.x + s * 0.56f, c.y + s * 0.14f)
        close()
    }
    drawPath(drop, color)
    // Termómetro que sale de dentro de la aceitera
    thermo(c.x + s * 0.04f, c.y - s * 0.55f, c.y + s * 0.1f, s, color, sw)
}

/** Aro plateado fino con brillo arriba y sombra abajo. */
private fun DrawScope.silverRing(c: Offset, r: Float, width: Float) {
    drawCircle(
        Brush.verticalGradient(listOf(K.silverHi, K.silver, K.silverLo, K.silver), c.y - r, c.y + r),
        r, c, style = Stroke(width),
    )
}

/**
 * Nombre de la vía debajo del reloj de velocidad: abreviado como en las señales ("Av.", "C/", "Pl."…) y, si aun
 * así no cabe, se desplaza despacio para leerlo entero. Si cabe, se queda quieto.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RoadText(road: String, modifier: Modifier = Modifier, small: Boolean = false) {
    Text(
        RoadNames.short(road), color = K.label2, style = Caps, fontSize = if (small) 17.sp else 16.sp, maxLines = 1, softWrap = false,
        modifier = modifier.basicMarquee(iterations = Int.MAX_VALUE, delayMillis = 2000, initialDelayMillis = 1500, velocity = 35.dp),
    )
}

/** Rojo y negro de las señales de tráfico. */
private val SignRed = Color(0xFFD5001C)
private val SignInk = Color(0xFF111111)

/**
 * Señal de velocidad máxima (R-301) con las proporciones de la de la carretera: disco blanco, corona roja
 * ancha (una décima del diámetro) con un filo blanco por fuera, y número negro grueso y alto. Es la misma
 * en el reloj, en el diálogo de corregir y en cualquier otro sitio.
 */
private fun DrawScope.drawSpeedSign(tm: TextMeasurer, center: Offset, radius: Float, text: String, alpha: Float = 1f) {
    drawCircle(Color.Black.copy(alpha = 0.5f * alpha), radius * 1.03f, center)   // contorno para que el filo blanco se vea
    drawCircle(Color.White.copy(alpha = alpha), radius, center)
    drawCircle(SignRed.copy(alpha = alpha), radius * 0.87f, center, style = Stroke(radius * 0.20f))
    val res = tm.measure(
        AnnotatedString(text),
        TextStyle(
            color = SignInk.copy(alpha = alpha), fontSize = (radius * if (text.length >= 3) 0.78f else 1.0f).toSp(),
            fontFamily = CondBold, fontWeight = FontWeight.Bold,
        ),
    )
    drawText(res, topLeft = Offset(center.x - res.size.width / 2f, center.y - res.size.height / 2f - radius * 0.02f))
}

// ── Icono del radar ── estilo y posición elegidos en la réplica "Icono del radar"
// (posición en radios del reloj: x a la derecha, y hacia arriba; tamaño = alto del icono / radio)
// Elegido por ella el 4-nov-2026: "solo la cámara", en rojo.
private const val RADAR_STYLE = "camara"
private const val RADAR_MAIN_X = -1.15f
private const val RADAR_MAIN_Y = 0.80f
private const val RADAR_MAIN_SIZE = 0.32f
private const val RADAR_TRIP_X = -1.047f
private const val RADAR_TRIP_Y = 0.912f
private const val RADAR_TRIP_SIZE = 0.33f

/** Cámara de radar (caja con objetivo, poste y base). [bg] es el color de detrás, para hueco del objetivo. */
private fun DrawScope.radarCamera(x: Float, y: Float, s: Float, color: Color, bg: Color, alpha: Float) {
    val w = s * 0.62f
    val h = s * 0.34f
    val top = y - h / 2 - s * 0.06f
    drawRoundRect(color.copy(alpha = alpha), Offset(x - w / 2, top), Size(w, h), androidx.compose.ui.geometry.CornerRadius(s * 0.05f))
    drawRect(color.copy(alpha = alpha), Offset(x - s * 0.045f, top + h), Size(s * 0.09f, s * 0.26f))
    drawRect(color.copy(alpha = alpha), Offset(x - s * 0.2f, top + h + s * 0.24f), Size(s * 0.4f, s * 0.05f))
    drawRect(color.copy(alpha = alpha), Offset(x - w * 0.38f, top - s * 0.08f), Size(w * 0.26f, s * 0.08f))
    val lens = Offset(x + w * 0.18f, y - s * 0.06f)
    drawCircle(bg.copy(alpha = alpha), h * 0.3f, lens)
    drawCircle(color.copy(alpha = alpha), h * 0.17f, lens)
}

private fun DrawScope.radarInner(tm: TextMeasurer, x: Float, y: Float, s: Float, full: Float, labelY: Float, color: Color, bg: Color, tramo: Boolean, alpha: Float) {
    if (tramo) {
        radarCamera(x - s * 0.32f, y, s * 0.62f, color, bg, alpha)
        radarCamera(x + s * 0.32f, y, s * 0.62f, color, bg, alpha)
        val t = tm.measure(AnnotatedString("TRAMO"), TextStyle(color = color.copy(alpha = alpha), fontSize = (full * 0.18f).toSp(), fontFamily = CondBold, fontWeight = FontWeight.Bold))
        drawText(t, topLeft = Offset(x - t.size.width / 2f, labelY - t.size.height / 2f))
    } else radarCamera(x, y, s, color, bg, alpha)
}

/** Icono del radar centrado en [c]; [s] = alto del icono. Estilos: azul, triangulo, circulo, camara. */
private fun DrawScope.drawRadarIcon(tm: TextMeasurer, style: String, tramo: Boolean, c: Offset, s: Float, alpha: Float) {
    val white = Color.White
    val ink = Color(0xFF111111)
    when (style) {
        "triangulo" -> {
            val outer = Path().apply { moveTo(c.x, c.y - s * 0.52f); lineTo(c.x + s * 0.58f, c.y + s * 0.46f); lineTo(c.x - s * 0.58f, c.y + s * 0.46f); close() }
            val inner = Path().apply { moveTo(c.x, c.y - s * 0.32f); lineTo(c.x + s * 0.42f, c.y + s * 0.36f); lineTo(c.x - s * 0.42f, c.y + s * 0.36f); close() }
            drawPath(outer, SignRed.copy(alpha = alpha)); drawPath(inner, white.copy(alpha = alpha))
            radarInner(tm, c.x, c.y + s * 0.06f, s * (if (tramo) 0.34f else 0.46f), s * 0.7f, c.y + s * 0.27f, ink, white, tramo, alpha)
        }
        "circulo" -> {
            drawCircle(white.copy(alpha = alpha), s * 0.5f, c)
            drawCircle(SignRed.copy(alpha = alpha), s * 0.44f, c, style = Stroke(s * 0.1f))
            radarInner(tm, c.x, c.y - if (tramo) s * 0.07f else 0f, s * (if (tramo) 0.48f else 0.6f), s, c.y + s * 0.27f, ink, white, tramo, alpha)
        }
        "camara" -> radarInner(tm, c.x, c.y - if (tramo) s * 0.1f else 0f, s * (if (tramo) 0.8f else 1f), s, c.y + s * 0.27f, K.redGlow, Color.Black, tramo, alpha)
        else -> {   // señal azul
            val blue = Color(0xFF1F5FB4)
            drawRoundRect(white.copy(alpha = alpha), Offset(c.x - s * 0.5f, c.y - s * 0.5f), Size(s, s), androidx.compose.ui.geometry.CornerRadius(s * 0.12f))
            drawRoundRect(blue.copy(alpha = alpha), Offset(c.x - s * 0.44f, c.y - s * 0.44f), Size(s * 0.88f, s * 0.88f), androidx.compose.ui.geometry.CornerRadius(s * 0.09f))
            radarInner(tm, c.x, c.y - if (tramo) s * 0.09f else 0f, s * (if (tramo) 0.62f else 0.78f), s, c.y + s * 0.27f, white, blue, tramo, alpha)
        }
    }
}

// ── Ruedas con poco aire ──────────────────────────────────────────────────────────
private val WheelNames = listOf("delantera izquierda", "delantera derecha", "trasera izquierda", "trasera derecha")
private val WheelShort = listOf("DEL. IZQ.", "DEL. DER.", "TRAS. IZQ.", "TRAS. DER.")

/** Coche visto desde arriba, con el morro hacia arriba. [s] = medio alto. Las ruedas de [flats] en rojo. */
private fun DrawScope.drawCarTop(c: Offset, s: Float, flats: List<Int>, blink: Float) {
    val bw = s * 0.9f
    val bh = s * 2f
    drawRoundRect(Color(0xFF26262A), Offset(c.x - bw / 2, c.y - bh / 2), Size(bw, bh), androidx.compose.ui.geometry.CornerRadius(bw * 0.35f))
    drawRoundRect(K.silver, Offset(c.x - bw / 2, c.y - bh / 2), Size(bw, bh), androidx.compose.ui.geometry.CornerRadius(bw * 0.35f), style = Stroke(maxOf(1.2f, s * 0.04f)))
    drawRoundRect(Color(0xFF3A3A40), Offset(c.x - bw * 0.36f, c.y - bh * 0.22f), Size(bw * 0.72f, bh * 0.5f), androidx.compose.ui.geometry.CornerRadius(bw * 0.12f))
    drawRoundRect(Color(0xFF55555A), Offset(c.x - bw * 0.32f, c.y - bh * 0.30f), Size(bw * 0.64f, bh * 0.1f), androidx.compose.ui.geometry.CornerRadius(bw * 0.05f))
    val pos = listOf(-1f to -1f, 1f to -1f, -1f to 1f, 1f to 1f)
    pos.forEachIndexed { i, (x, y) ->
        val ww = bw * 0.26f
        val wh = bh * 0.2f
        val wc = Offset(c.x + x * bw * 0.58f, c.y + y * bh * 0.3f)
        val col = if (i in flats) K.redGlow.copy(alpha = 0.35f + 0.65f * blink) else Color(0xFFD0D0D4)
        drawRoundRect(col, Offset(wc.x - ww / 2, wc.y - wh / 2), Size(ww, wh), androidx.compose.ui.geometry.CornerRadius(ww * 0.3f))
    }
}

private fun flatTitle(f: List<Int>): String = when {
    f.isEmpty() -> "Las cuatro ruedas bien"
    f.size == 4 -> "Las cuatro ruedas con poco aire"
    f.size == 1 -> "Revisa la rueda ${WheelNames[f[0]]}"
    else -> "Revisa ${f.size} ruedas: " + f.map { WheelNames[it] }.let { n -> n.dropLast(1).joinToString(", ") + " y " + n.last() }
}

@Composable
private fun TyreScreen(st: UiState, vm: ObdViewModel) {
    val es = java.util.Locale("es", "ES")
    val blink = blinkValue(1400)
    val tm = rememberTextMeasurer()
    Row(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Canvas(Modifier.weight(0.46f).fillMaxHeight()) {
            val s = minOf(size.width * 0.26f, size.height * 0.42f)
            drawCarTop(center, s, st.tyreFlats, blink)
            val pos = listOf(-1f to -1f, 1f to -1f, -1f to 1f, 1f to 1f)
            pos.forEachIndexed { i, (x, y) ->
                val flat = i in st.tyreFlats
                val col = if (flat) K.redGlow else K.label2
                val tx = center.x + x * (s * 0.9f * 0.58f + s * 0.9f * 0.13f + s * 0.12f)
                val ty = center.y + y * s * 2f * 0.3f
                val dev = st.tyreDev?.getOrNull(i)
                val l1 = tm.measure(AnnotatedString(WheelShort[i]), TextStyle(color = col, fontSize = 13.sp, fontFamily = if (flat) CondBold else Cond))
                val l2 = tm.measure(AnnotatedString(dev?.let { String.format(es, "%+.1f %%", it) } ?: "— %"), TextStyle(color = col, fontSize = 12.sp, fontFamily = Cond))
                val lx = if (x < 0) tx - l1.size.width else tx
                drawText(l1, topLeft = Offset(lx, ty - l1.size.height))
                drawText(l2, topLeft = Offset(if (x < 0) tx - l2.size.width else tx, ty + 2f))
            }
        }
        Column(Modifier.weight(0.54f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.fillMaxWidth().clip(PanelShape).background(K.panel).border(1.dp, K.line, PanelShape).padding(14.dp)) {
                Text("ESTADO", color = K.label2, style = Caps, fontSize = 12.sp)
                val f = st.tyreFlats
                Text(
                    when {
                        st.tyreAvailable == false -> "No disponible en este coche"
                        st.tyreAvailable == null -> "Falta buscar las centralitas"
                        st.tyreLearn < 100 -> "Aprendiendo… ${st.tyreLearn} %"
                        else -> flatTitle(f)
                    },
                    color = if (f.isNotEmpty()) K.redGlow else if (st.tyreAvailable == true && st.tyreLearn >= 100) K.green else K.label,
                    fontSize = 21.sp, fontWeight = FontWeight.Bold,
                )
                Text(
                    when {
                        st.tyreAvailable == null -> "En Averías pulsa BUSCAR CENTRALITAS con el contacto puesto: así la app encuentra la velocidad de las cuatro ruedas en el ABS."
                        st.tyreAvailable == false -> "El ABS no da la velocidad de cada rueda por el camino que usa la app."
                        st.tyreLearn < 100 -> "Conduce unos minutos en recta, entre 30 y 130 km/h, con las cuatro ruedas a su presión."
                        f.size == 4 -> "Las cuatro giran más rápido que al calibrar, comparadas con la velocidad del GPS: han perdido aire. Para y mira la presión."
                        f.isNotEmpty() -> (if (f.size == 1) "Gira" else "Giran") + " más rápido que al calibrar: " + (if (f.size == 1) "tiene" else "tienen") + " menos aire. Para y mira la presión."
                        else -> "Ninguna gira distinto de como giraban al calibrar."
                    },
                    color = K.label2, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp),
                )
            }
            Column(Modifier.fillMaxWidth().clip(PanelShape).background(K.panel).border(1.dp, K.line, PanelShape)) {
                Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 8.dp).heightIn(min = 54.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Calibrado", color = K.label, fontSize = 16.sp)
                        Text(st.tyreCal.ifBlank { "Todavía no" }, color = K.label2, fontSize = 12.sp)
                    }
                    RedButton("CALIBRAR", enabled = st.tyreAvailable == true) { vm.calibrateTyres() }
                }
                Divider()
                InfoRow("Aprendiendo", if (st.tyreLearn >= 100) "Listo" else "${st.tyreLearn} %")
            }
            Text("Calibra con las cuatro ruedas a su presión, igual que el botón SET del coche, y cada vez que infles o cambies ruedas.", color = K.label3, fontSize = 12.sp)
        }
    }
}

@Composable
private fun TyreBlock(st: UiState, vm: ObdViewModel) {
    SwitchRow("Aviso de rueda con poco aire", "Compara la velocidad de las cuatro ruedas del ABS, como el testigo del coche, pero te dice cuál es", st.opt(AlertKey.TYRE_ON) == 1) {
        vm.setAlert(AlertKey.TYRE_ON, if (it) 1 else 0)
    }
    Divider()
    InfoRow(
        "Estado",
        when { st.tyreAvailable == null -> "Falta buscar las centralitas (en Averías)"; st.tyreAvailable == false -> "No disponible"; st.tyreLearn < 100 -> "Aprendiendo ${st.tyreLearn} %"; else -> flatTitle(st.tyreFlats) },
    )
    Divider()
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp).heightIn(min = 56.dp).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Calibrar", color = K.label, fontSize = 16.sp)
            Text("Con las cuatro ruedas a su presión · " + st.tyreCal.ifBlank { "sin calibrar" }, color = K.label2, fontSize = 12.sp)
        }
        RedButton("CALIBRAR", enabled = st.tyreAvailable == true) { vm.calibrateTyres() }
    }
    Divider()
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp).heightIn(min = 56.dp).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Sensibilidad", color = K.label, fontSize = 16.sp)
            Text("Alta avisa antes, pero puede avisar alguna vez sin motivo", color = K.label2, fontSize = 12.sp)
        }
        Segmented(listOf("Baja", "Normal", "Alta"), st.opt(AlertKey.TYRE_SENS)) { vm.setAlert(AlertKey.TYRE_SENS, it) }
    }
}

// ── Otras centralitas (Averías) ───────────────────────────────────────────────────

@Composable
private fun OtherModules(st: UiState, vm: ObdViewModel) {
    val connected = st.conn == Conn.CONECTADO && !st.demo
    var openAddr by remember { mutableStateOf<Int?>(null) }
    var askClear by remember { mutableStateOf<Int?>(null) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Otras centralitas", color = K.label, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text(
                st.modMessage.ifEmpty {
                    if (st.modules.isEmpty()) "ABS, airbag, cuadro, climatizador… Pulsa BUSCAR con el contacto puesto. Solo lee, no cambia nada."
                    else "${st.modules.count { it.proto != VagProto.NONE }} de ${st.modules.size} contestan"
                },
                color = K.label2, fontSize = 12.sp,
            )
        }
        Spacer(Modifier.width(8.dp))
        if (st.modules.any { it.proto != VagProto.NONE }) {
            BarButton(if (st.modBusy) "…" else "LEER", enabled = connected && !st.modBusy) { vm.readModuleDtcs() }
            Spacer(Modifier.width(6.dp))
        }
        RedButton(if (st.modBusy) "BUSCANDO…" else "BUSCAR CENTRALITAS", enabled = connected && !st.modBusy) { vm.scanModules() }
    }
    st.modules.forEach { m ->
        val def = VagModules.byAddr(m.addr) ?: return@forEach
        Divider()
        val n = m.dtcs?.size
        Row(
            Modifier.fillMaxWidth().clickable(enabled = m.proto != VagProto.NONE) { openAddr = if (openAddr == m.addr) null else m.addr }
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(def.label, color = if (m.proto == VagProto.NONE) K.label3 else K.label, fontSize = 16.sp)
                Text(
                    if (m.proto == VagProto.NONE && m.message.isNotBlank()) "No contesta · ${m.message}"
                    else m.proto.text + if (m.part.isNotBlank() && m.part != "—") " · ${m.part}" else "",
                    color = K.label2, fontSize = 12.sp,
                )
            }
            when {
                m.proto == VagProto.NONE -> Tag("NO CONTESTA", K.label3)
                n == null -> Tag("SIN LEER", K.label3)
                n == 0 -> Tag("BIEN", K.green)
                else -> Tag("$n ${if (n == 1) "AVERÍA" else "AVERÍAS"}", K.amber)
            }
        }
        if (openAddr == m.addr) {
            Column(Modifier.fillMaxWidth().padding(start = 28.dp, end = 16.dp, bottom = 10.dp)) {
                val list = m.dtcs
                if (list == null) Text("No se pudieron leer las averías.", color = K.label2, fontSize = 13.sp)
                else if (list.isEmpty()) Text("Sin averías guardadas.", color = K.green, fontSize = 13.sp)
                else list.forEach { d ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(d.code, color = K.amber, style = Num, fontSize = 15.sp, modifier = Modifier.width(80.dp))
                        Column(Modifier.weight(1f)) {
                            Text(d.text, color = K.label, fontSize = 14.sp)
                            Text("Estado %02X".format(d.status) + if (d.active) " · activa ahora" else "", color = K.label3, fontSize = 11.sp)
                        }
                    }
                }
                if (!list.isNullOrEmpty()) {
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.End) {
                        BarButton("BORRAR ESTAS AVERÍAS", enabled = connected && !st.modBusy) { askClear = m.addr }
                    }
                }
            }
        }
    }
    askClear?.let { a ->
        AlertPanel(
            title = "¿BORRAR LAS AVERÍAS?",
            message = "Se borran las averías de ${VagModules.byAddr(a)?.name ?: "la centralita"}. Hazlo con el contacto puesto y el motor parado. Las que sigan presentes volverán a aparecer.",
            confirm = "BORRAR", onConfirm = { askClear = null; vm.clearModuleDtcs(a) }, onDismiss = { askClear = null },
        )
    }
}

// ── Otras centralitas en vivo (Datos en vivo): solo ABS/ESP y cuadro, como una fila más con desplegable ──

@Composable
private fun ModuleLiveRow(st: UiState, vm: ObdViewModel, addr: Int) {
    val m = st.modules.firstOrNull { it.addr == addr && it.proto == VagProto.TP20 } ?: return
    val name = VagModules.byAddr(addr)?.name ?: return
    val open = st.liveMod == addr
    Row(
        Modifier.fillMaxWidth().clickable { if (open) vm.stopLive() else vm.startLive(addr) }.padding(start = 16.dp, end = 12.dp).heightIn(min = 56.dp).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(name, color = K.label, fontSize = 16.sp)
            Text("Centralita %02X · KWP2000".format(addr) + if (open) " · los relojes se paran mientras está abierto" else "", color = K.label2, fontSize = 12.sp)
        }
        Text(if (open) "⌃" else "⌄", color = K.label2, fontSize = 20.sp)
    }
    if (open) {
        Column(Modifier.fillMaxWidth().padding(start = 28.dp, end = 16.dp, bottom = 10.dp)) {
            if (st.liveMessage.isNotEmpty()) Text(st.liveMessage, color = K.label2, fontSize = 12.sp)
            st.liveGroups.toSortedMap().forEach { (g, values) ->
                val wheels = addr == 0x03 && m.wheelGroup == g
                values.forEachIndexed { i, v ->
                    Row(Modifier.fillMaxWidth().padding(top = 5.dp), verticalAlignment = Alignment.Bottom) {
                        Text(
                            if (wheels && i < 4) "Rueda ${WheelNames[i]}" else "Grupo %03d · valor %d".format(g, i + 1),
                            color = K.label2, fontSize = 14.sp, modifier = Modifier.weight(1f),
                        )
                        Text(v.text, color = K.label, style = Num, fontSize = 18.sp)
                        Text(if (v.unit.isEmpty()) "" else " ${v.unit}", color = K.label2, fontSize = 13.sp, modifier = Modifier.width(70.dp))
                    }
                }
            }
        }
    }
}

/** La misma señal, como elemento de pantalla (para listas y diálogos). */
@Composable
private fun SpeedSignView(kmh: Int, modifier: Modifier, selected: Boolean = false) {
    val tm = rememberTextMeasurer()
    Canvas(modifier) {
        val full = size.minDimension / 2
        if (selected) drawCircle(K.label, full, center, style = Stroke(2.5.dp.toPx()))
        drawSpeedSign(tm, center, full * 0.86f, kmh.toString())
    }
}

/** Valor que va de 1 a 0,15 y vuelve, cada [periodMs] milisegundos (null = sin parpadeo, siempre 1). */
@Composable
private fun blinkValue(periodMs: Int?): Float {
    if (periodMs == null) return 1f
    return key(periodMs) {
        rememberInfiniteTransition(label = "parpadeo").animateFloat(
            1f, 0.15f, infiniteRepeatable(tween(periodMs), RepeatMode.Reverse), label = "parpadeo",
        ).value
    }
}

private fun Param.isHot(v: Double?) = v != null && warnHigh != null && v >= warnHigh
private fun Param.isCold(v: Double?) = v != null && warnLow != null && v <= warnLow

/** Escala "redonda" para las marcas y números de un reloj (0-50, 0-220, -0,2-2,0…). */
private data class Scale(val lo: Double, val hi: Double, val step: Double) {
    val majors: Int get() = Math.round((hi - lo) / step).toInt()
    fun frac(v: Double?) = if (v == null) 0f else ((v - lo) / (hi - lo)).toFloat().coerceIn(0f, 1f)
}

private fun niceScale(p: Param): Scale {
    if (p.id == "speed") return Scale(0.0, 240.0, 20.0)   // como el cuadro: números de 20 en 20
    val range = p.max - p.min
    val mag = Math.pow(10.0, kotlin.math.floor(kotlin.math.log10(range / 6)))
    val step = listOf(1.0, 2.0, 2.5, 5.0, 10.0, 20.0).map { it * mag }.first { range / it <= 11 }
    return Scale(kotlin.math.floor(p.min / step) * step, kotlin.math.ceil(p.max / step) * step, step)
}

private fun scaleLabel(p: Param, value: Double, step: Double): String = when {
    p.id == "rpm" -> Math.round(value / 100).toString()
    step >= 1 -> Math.round(value).toString()
    else -> String.format(java.util.Locale("es", "ES"), "%.1f", value)
}

/**
 * Reloj al estilo del cuadro del Ibiza Bocanegra: esfera negra, marcas blancas finas,
 * números en cursiva, zona roja con banda y números rojos, aguja blanca larga con buje negro
 * y una pantallita roja abajo con el valor exacto, como el display del cuadro.
 */
@Composable
private fun ClusterGauge(
    p: Param, st: UiState, logo: ImageBitmap?, modifier: Modifier,
    signX: Float = 0.93f, signY: Float = 0.93f, signSize: Float = 0.16f,
    radarX: Float = RADAR_MAIN_X, radarY: Float = RADAR_MAIN_Y, radarSize: Float = RADAR_MAIN_SIZE,
) {
    val v = st.values[p.id]
    val sc = remember(p.id) { niceScale(p) }
    val anim by animateFloatAsState(sc.frac(v), spring(stiffness = Spring.StiffnessLow, dampingRatio = 0.85f), label = "n")
    val redFrom = when {
        p.id == "rpm" -> sc.frac(st.shiftRpm.toDouble())
        p.warnHigh != null -> sc.frac(p.warnHigh)
        else -> null
    }
    // Límite de velocidad (solo en el reloj de velocidad)
    val limit = if (p.id == "speed") st.shownLimit() else null
    val over = p.id == "speed" && st.overLimit()
    // Parpadeo mientras vas pasado (la animación solo existe mientras dura)
    // Radar por delante (solo en el reloj de velocidad)
    val radarOn = p.id == "speed" && st.radarAlert()
    val radarM = st.radarM
    // Parpadeo: el del radar manda sobre el de pasarse del límite. null = sin parpadeo.
    val period: Int? = when {
        // Pasado de velocidad manda siempre: parpadeo rápido y aro rojo, haya radar o no
        over -> when (st.opt(AlertKey.LIMIT_BLINK)) { 0 -> null; 1 -> 800; else -> 350 }
        radarOn && radarM != null -> when (st.opt(AlertKey.RADAR_BLINK)) {
            0 -> null
            1 -> 800
            2 -> 350
            else -> {
                val maxM = AlertOptions.radarDistances.getOrElse(st.opt(AlertKey.RADAR_DIST)) { 1000 }.toDouble()
                val f = radarM / maxM
                if (f > 0.66) 800 else if (f > 0.33) 450 else 220
            }
        }
        else -> null
    }
    val blink = blinkValue(period)
    val hot = p.isHot(v) || (p.id == "rpm" && v != null && v >= st.shiftRpm) || over
    val cold = p.isCold(v)
    val lcdColor by animateColorAsState(when { cold -> K.amber; hot -> Color(0xFFFF5040); else -> K.lcd }, label = "lcd")
    val tm = rememberTextMeasurer()
    val lcdK = AlertOptions.lcdScale(st.opt(AlertKey.LCD_SIZE))
    val caption = if (p.id == "rpm") "rpm x100" else p.unit

    Canvas(modifier) {
        val c = this.center
        val r = size.minDimension / 2
        // Sombra, esfera y aro
        drawCircle(Brush.radialGradient(listOf(Color.Black.copy(alpha = 0.6f), Color.Transparent), c, r * 1.08f), r * 1.08f, c)
        drawCircle(Brush.radialGradient(listOf(Color(0xFF1B1B1E), Color(0xFF040405)), c, r), r * 0.97f, c)
        silverRing(c, r * 0.975f, r * 0.03f)
        drawCircle(Color.Black, r * 0.945f, c, style = Stroke(r * 0.02f))
        // Banda roja de la zona roja
        if (redFrom != null && redFrom < 1f) {
            val rb = r * 0.875f
            drawArc(
                K.red.copy(alpha = 0.85f), 135f + 270f * redFrom, 270f * (1 - redFrom), false,
                Offset(c.x - rb, c.y - rb), Size(rb * 2, rb * 2), style = Stroke(r * 0.05f),
            )
        }
        // Marcas y números
        val majors = sc.majors
        val isSpeed = p.id == "speed"
        val minorPer = if (isSpeed) 4 else if (majors <= 6) 10 else 5
        val total = majors * minorPer
        val labelEvery = if (!isSpeed && majors > 8) 2 else 1
        val tickValue = sc.step / minorPer
        for (i in 0..total) {
            val f = i / total.toFloat()
            val a = Math.toRadians(135.0 + 270.0 * f)
            val major = i % minorPer == 0
            val half = !major && ((minorPer == 10 && i % 5 == 0) || (isSpeed && i % 2 == 0))
            val red = redFrom != null && f >= redFrom - 0.0001f
            // Raya del límite de la vía, en rojo
            val atLimit = limit != null && kotlin.math.abs(sc.lo + tickValue * i - limit) < 0.01
            val r1 = r * 0.90f
            val r2 = when { major || atLimit -> r * 0.78f; half -> r * 0.82f; else -> r * 0.855f }
            drawLine(
                when {
                    atLimit -> K.redGlow
                    red && !major -> Color.White.copy(alpha = 0.85f)
                    red -> Color.White
                    else -> Color.White.copy(alpha = if (major) 1f else 0.7f)
                },
                Offset(c.x + (r1 * cos(a)).toFloat(), c.y + (r1 * sin(a)).toFloat()),
                Offset(c.x + (r2 * cos(a)).toFloat(), c.y + (r2 * sin(a)).toFloat()),
                strokeWidth = when { atLimit -> r * 0.034f; major -> r * 0.022f; half -> r * 0.014f; else -> r * 0.009f },
            )
            val mi = i / minorPer
            if (major && mi % labelEvery == 0) {
                val value = sc.lo + sc.step * mi
                val res = tm.measure(
                    AnnotatedString(scaleLabel(p, value, sc.step)),
                    TextStyle(
                        color = if (red || atLimit) K.redGlow else Color.White,
                        fontSize = (r * if (isSpeed) 0.115f else 0.13f).toSp(),
                        fontWeight = if (atLimit) FontWeight.Bold else null,
                        fontFamily = Cond, fontStyle = FontStyle.Italic,
                    ),
                )
                val rt = r * 0.64f
                drawText(
                    res,
                    topLeft = Offset(
                        c.x + (rt * cos(a)).toFloat() - res.size.width / 2f,
                        c.y + (rt * sin(a)).toFloat() - res.size.height / 2f,
                    ),
                )
            }
        }
        // Aro rojo que parpadea si te pasas
        if (over) {
            drawCircle(K.redGlow.copy(alpha = 0.75f * blink), r * 0.99f, c, style = Stroke(r * 0.045f))
            drawCircle(K.red.copy(alpha = 0.18f * blink), r * 0.93f, c)
        }
        // Rótulo pequeño ("rpm x100", "°C"…)
        val cap = tm.measure(AnnotatedString(caption), TextStyle(color = K.label2, fontSize = (r * 0.075f).toSp(), fontFamily = Cond))
        val iconS = r * 0.16f
        val hasIcon = p.id == "oil" || p.id == "coolant"
        val capX = c.x - cap.size.width / 2f + if (hasIcon) iconS * 0.6f else 0f
        drawText(cap, topLeft = Offset(capX, c.y + r * 0.30f))
        if (hasIcon) {
            val ic = Offset(capX - iconS * 0.75f, c.y + r * 0.30f + cap.size.height / 2f)
            val icColor = when { cold -> K.amber; hot -> K.redGlow; else -> K.label2 }
            if (p.id == "oil") drawOilTempIcon(ic, iconS, icColor) else drawCoolantIcon(ic, iconS, icColor)
        }
        // Señal de límite de velocidad (en el sitio del logo). Si el límite es aproximado, pone "APROX." debajo.
        // Con un radar delante la señal parpadea (y si no se sabe el límite de la vía, lleva el del radar).
        val signKmh = limit ?: if (radarOn) st.radarKmh else null
        if (signKmh != null || radarOn) {
            // Con logo, la señal va fuera de la esfera, arriba a la derecha, sin tocar el aro
            val sc0 = if (logo == null) Offset(c.x, c.y - r * 0.36f) else Offset(c.x + r * signX, c.y - r * signY)
            val sr = if (logo == null) r * 0.17f else r * signSize
            val a = if (period != null) 0.25f + 0.75f * blink else 1f
            drawSpeedSign(tm, sc0, sr, signKmh?.toString() ?: "!", a)
        }
        // Icono del radar (fijo o tramo) con los metros que faltan debajo, donde se eligió en la réplica
        if (radarOn && radarM != null) {
            val ic = Offset(c.x + r * radarX, c.y - r * radarY)
            val s = r * radarSize
            val ra = 0.35f + 0.65f * blink
            drawRadarIcon(tm, RADAR_STYLE, st.radarTramo, ic, s, ra)
            val dres = tm.measure(
                AnnotatedString("${((radarM / 10).toInt() * 10)} m"),
                TextStyle(
                    color = K.redGlow.copy(alpha = 0.45f + 0.55f * blink), fontSize = maxOf(11f, s * 0.42f / density).sp,
                    fontFamily = CondBold, fontWeight = FontWeight.Bold, shadow = Shadow(Color.Black.copy(alpha = 0.8f), blurRadius = 4f),
                ),
            )
            drawText(dres, topLeft = Offset(ic.x - dres.size.width / 2f, ic.y + s * 0.62f))
        }
        // Logo propio (si se ha elegido) encima del eje de la aguja
        if (logo != null) {
            val lw = r * 0.46f
            val lh = lw * logo.height / logo.width.coerceAtLeast(1)
            val maxH = r * 0.26f
            val k = if (lh > maxH) maxH / lh else 1f
            val dw = (lw * k).toInt().coerceAtLeast(1)
            val dh = (lh * k).toInt().coerceAtLeast(1)
            drawImage(
                logo,
                dstOffset = IntOffset((c.x - dw / 2f).toInt(), (c.y - r * 0.30f - dh / 2f).toInt()),
                dstSize = IntSize(dw, dh),
            )
        }
        // Pantallita roja con el valor (tamaño a gusto en Ajustes → Panel)
        val lw = r * 0.56f * lcdK
        val lh = r * 0.21f * lcdK
        val lt = Offset(c.x - lw / 2, c.y + r * (0.53f - (lcdK - 1f) * 0.10f))
        drawRect(Color(0xFF150404), lt, Size(lw, lh))
        drawRect(Color(0xFF3A0C0C), lt, Size(lw, lh), style = Stroke(1.5f))
        // Trama de puntos tipo matriz
        val dotStep = r * 0.035f
        var yy = lt.y + dotStep / 2
        while (yy < lt.y + lh) {
            drawLine(Color.Black.copy(alpha = 0.35f), Offset(lt.x, yy), Offset(lt.x + lw, yy), 1f)
            yy += dotStep
        }
        val valTxt = if (v == null) "- - -" else p.format(v)
        val vres = tm.measure(
            AnnotatedString(valTxt),
            TextStyle(
                color = lcdColor, fontSize = (lh * 0.72f).toSp(), fontFamily = Cond, fontFeatureSettings = "tnum",
                shadow = Shadow(lcdColor.copy(alpha = 0.8f), blurRadius = lh * 0.3f),
            ),
        )
        drawText(vres, topLeft = Offset(c.x - vres.size.width / 2f, lt.y + (lh - vres.size.height) / 2f))
        // Aguja blanca larga con sombra
        val a = Math.toRadians(135.0 + 270.0 * (if (v == null) 0f else anim))
        val ca = cos(a).toFloat()
        val sa = sin(a).toFloat()
        fun needle(off: Offset): Path {
            val tip = Offset(c.x + off.x + r * 0.84f * ca, c.y + off.y + r * 0.84f * sa)
            val tail = Offset(c.x + off.x - r * 0.16f * ca, c.y + off.y - r * 0.16f * sa)
            val w = r * 0.032f
            return Path().apply {
                moveTo(tail.x - w * sa, tail.y + w * ca)
                lineTo(tip.x - w * 0.25f * sa, tip.y + w * 0.25f * ca)
                lineTo(tip.x + w * 0.25f * sa, tip.y - w * 0.25f * ca)
                lineTo(tail.x + w * sa, tail.y - w * ca)
                close()
            }
        }
        drawPath(needle(Offset(r * 0.02f, r * 0.03f)), Color.Black.copy(alpha = 0.55f))
        drawPath(needle(Offset.Zero), Brush.linearGradient(listOf(Color(0xFFDADADA), Color.White), c, c + Offset(r * ca, r * sa)))
        // Buje
        drawCircle(Brush.radialGradient(listOf(Color(0xFF3A3A3E), Color(0xFF0A0A0B)), c, r * 0.1f), r * 0.1f, c)
        drawCircle(Color(0xFF55555A), r * 0.1f, c, style = Stroke(r * 0.012f))
    }
}

@Composable
private fun Sparkline(hist: List<Float>?, color: Color, modifier: Modifier) {
    val h = hist?.takeLast(60)
    if (h == null || h.size < 2) return
    Canvas(modifier) {
        var lo = h.min()
        var hi = h.max()
        if (hi - lo < 1e-3f) { lo -= 1f; hi += 1f }
        val stepX = size.width / 59f
        val x0 = size.width - stepX * (h.size - 1)
        fun y(f: Float) = size.height - (f - lo) / (hi - lo) * size.height * 0.8f - size.height * 0.08f
        val line = Path().apply {
            h.forEachIndexed { i, f -> if (i == 0) moveTo(x0, y(f)) else lineTo(x0 + i * stepX, y(f)) }
        }
        drawPath(line, color.copy(alpha = 0.85f), style = Stroke(1.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

private fun fracOf(p: Param, v: Double?): Float =
    if (v == null) 0f else ((v - p.min) / (p.max - p.min)).toFloat().coerceIn(0f, 1f)

// ═══════════════════════════════════════════════════════════════════ MENÚ

@Composable
private fun MenuScreen(st: UiState, vm: ObdViewModel, onGo: (Tab) -> Unit, onImmersive: () -> Unit) {
    val items = mutableListOf<Triple<String, String, () -> Unit>>(
        Triple("Performance", "Los tres relojes", { onGo(Tab.PANEL) }),
        Triple("Gráficas", "Varios datos a lo largo del tiempo", { onGo(Tab.GRAFICAS) }),
        Triple("Barras", "Seis datos de un vistazo", { onGo(Tab.BARRAS) }),
        Triple("Viaje", "Distancia, medias y máximos", { onGo(Tab.VIAJE) }),
        Triple("Cronómetro", "0-100, 0-60 y 80-120", { onGo(Tab.CRONO) }),
        Triple("Datos en vivo", "Todos los datos del motor", { onGo(Tab.DATOS) }),
        Triple("Averías", "Leer y borrar códigos", { onGo(Tab.AVERIAS) }),
        Triple("Pantalla completa", "Solo los relojes; toca para volver", { onImmersive() }),
    )
    if (st.conn == Conn.DESCONECTADO) items += Triple("Demo", "Ver la app sin coche", { vm.startDemo(); onGo(Tab.PANEL) })
    items += Triple("Ruedas", "Qué rueda tiene poco aire", { onGo(Tab.RUEDAS) })
    items += Triple("Ajustes", "Aceite, revoluciones y consola", { onGo(Tab.AJUSTES) })

    BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 14.dp)) {
        val cols = if (maxWidth > maxHeight) 5 else 3
        val rows = (items.size + cols - 1) / cols
        val gap = 12.dp
        val w = (maxWidth - gap * (cols - 1)) / cols
        val h = ((maxHeight - gap * (rows - 1)) / rows).coerceAtMost(170.dp)
        Column(verticalArrangement = Arrangement.spacedBy(gap)) {
            items.chunked(cols).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    row.forEach { (title, sub, action) ->
                        Box(
                            Modifier.size(w, h).clip(PanelShape)
                                .background(Brush.verticalGradient(listOf(Color(0xFF2C2C2F), Color(0xFF151517))))
                                .border(1.dp, Brush.verticalGradient(listOf(Color(0xFF55555A), Color(0xFF222224))), PanelShape)
                                .clickable { action() }.padding(16.dp),
                        ) {
                            Canvas(Modifier.align(Alignment.TopStart).fillMaxWidth().height(3.dp)) {
                                drawLine(
                                    K.red.copy(alpha = 0.8f), Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 1.6.dp.toPx(),
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 4.dp.toPx())),
                                )
                            }
                            Column(Modifier.align(Alignment.BottomStart)) {
                                Text(title, color = K.label, style = Caps, fontSize = 22.sp, maxLines = 1)
                                Text(sub, color = K.label2, fontSize = 12.sp, maxLines = 2)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Pide a la app que lea estos datos mientras la pantalla está abierta. */
@Composable
private fun Focus(vm: ObdViewModel, ids: List<String>) {
    DisposableEffect(ids) {
        vm.setFocus(ids)
        onDispose { vm.setFocus(emptyList()) }
    }
}

/** Pantallita roja tipo display del cuadro. */
@Composable
private fun Lcd(text: String, modifier: Modifier = Modifier, size: TextUnit = 40.sp, color: Color = K.lcd) {
    Box(
        modifier.clip(Chamfer(6.dp)).background(Color(0xFF140404)).border(1.dp, Color(0xFF3A0C0C), Chamfer(6.dp))
            .drawBehind {
                var y = 2f
                while (y < this.size.height) { drawLine(Color.Black.copy(alpha = 0.3f), Offset(0f, y), Offset(this.size.width, y), 1f); y += 4f }
            }
            .padding(horizontal = 14.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text, maxLines = 1,
            style = TextStyle(
                color = color, fontSize = size, fontFamily = Cond, fontFeatureSettings = "tnum",
                shadow = Shadow(color.copy(alpha = 0.8f), blurRadius = 12f),
            ),
        )
    }
}

// ═══════════════════════════════════════════════════════════════════ GRÁFICAS

private val SeriesColors = listOf(Color(0xFFFF2B3F), Color(0xFFF2F2F2), Color(0xFFFFB020))

@Composable
private fun ChartsScreen(st: UiState, vm: ObdViewModel) {
    var series by rememberSaveable { mutableStateOf("rpm,${Params.BOOST},coolant") }
    var window by rememberSaveable { mutableStateOf(300) }
    var picking by remember { mutableStateOf<Int?>(null) }
    val ids = series.split(",").filter { it in Params.byId }
    Focus(vm, ids)

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ids.forEachIndexed { i, id ->
                val p = Params.byId.getValue(id)
                Column(
                    Modifier.weight(1f).clip(PanelShape).background(K.panel).border(1.dp, K.line, PanelShape)
                        .clickable { picking = i }.padding(horizontal = 12.dp, vertical = 8.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.width(18.dp).height(3.dp).background(SeriesColors[i]))
                        Spacer(Modifier.width(8.dp))
                        Text(p.short, color = K.label2, style = Caps, fontSize = 14.sp, maxLines = 1)
                    }
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(p.format(st.values[id]), color = K.label, style = NumLight, fontSize = 30.sp)
                        Text(" ${p.unit}", color = K.label2, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp))
                    }
                }
                if (i < ids.size - 1) Spacer(Modifier.width(10.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column {
                for ((n, lbl) in listOf(150 to "CORTO", 300 to "MEDIO", 600 to "LARGO")) {
                    Text(
                        lbl, color = if (window == n) K.label else K.label3, style = Caps, fontSize = 14.sp,
                        modifier = Modifier.clickable { window = n }.padding(horizontal = 8.dp, vertical = 3.dp),
                    )
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Canvas(Modifier.fillMaxWidth().weight(1f).clip(PanelShape).background(Color(0xFF0E0E10)).border(1.dp, K.line, PanelShape)) {
            val padL = 8.dp.toPx()
            val w = size.width - padL * 2
            val h = size.height - 16.dp.toPx()
            val top = 8.dp.toPx()
            for (k in 0..4) {
                val y = top + h * k / 4
                drawLine(K.line.copy(alpha = 0.6f), Offset(padL, y), Offset(padL + w, y), 1f)
            }
            for (k in 0..6) {
                val x = padL + w * k / 6
                drawLine(K.line.copy(alpha = 0.35f), Offset(x, top), Offset(x, top + h), 1f)
            }
            ids.forEachIndexed { i, id ->
                val p = Params.byId.getValue(id)
                val sc = niceScale(p)
                val data = st.history[id]?.takeLast(window) ?: return@forEachIndexed
                if (data.size < 2) return@forEachIndexed
                val stepX = w / (window - 1)
                val x0 = padL + w - stepX * (data.size - 1)
                val path = Path()
                data.forEachIndexed { j, f ->
                    val y = top + h * (1 - sc.frac(f.toDouble()))
                    if (j == 0) path.moveTo(x0, y) else path.lineTo(x0 + j * stepX, y)
                }
                drawPath(path, SeriesColors[i].copy(alpha = 0.25f), style = Stroke(6.dp.toPx(), join = StrokeJoin.Round))
                drawPath(path, SeriesColors[i], style = Stroke(2.dp.toPx(), join = StrokeJoin.Round, cap = StrokeCap.Round))
            }
        }
        Text(
            "Cada línea usa su propia escala. Toca un dato de arriba para cambiarlo.",
            color = K.label3, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
        )
    }

    picking?.let { slot ->
        ParamPicker("Dato de la gráfica", ids.getOrNull(slot), st, emptySet(), onPick = { id ->
            series = ids.mapIndexed { j, old -> if (j == slot) id else old }.joinToString(",")
            picking = null
        }, onDismiss = { picking = null })
    }
}

// ═══════════════════════════════════════════════════════════════════ BARRAS

@Composable
private fun BarsScreen(st: UiState, vm: ObdViewModel) {
    val ids = st.dashboard.take(6)
    var picking by remember { mutableStateOf<Int?>(null) }
    Focus(vm, ids)

    Row(
        Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        ids.forEachIndexed { i, id ->
            val p = Params.byId[id] ?: return@forEachIndexed
            val v = st.values[id]
            val sc = remember(id) { niceScale(p) }
            val f by animateFloatAsState(sc.frac(v), spring(stiffness = Spring.StiffnessLow), label = "bar$i")
            val redFrom = p.warnHigh?.let { sc.frac(it) } ?: 2f
            val peak = st.peaks[id]?.let { sc.frac(it) }
            val cold = p.isCold(v)
            Column(
                Modifier.weight(1f).fillMaxHeight().clickable { picking = i }.padding(horizontal = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Lcd(p.format(v), size = 26.sp, color = if (cold) K.amber else if (p.isHot(v)) Color(0xFFFF5040) else K.lcd)
                Text(p.unit, color = K.label2, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                Spacer(Modifier.height(8.dp))
                Canvas(Modifier.width(46.dp).weight(1f)) {
                    val n = 24
                    val gap = 3.dp.toPx()
                    val segH = (size.height - gap * (n - 1)) / n
                    for (k in 0 until n) {
                        val pos = (k + 0.5f) / n
                        val y = size.height - (k + 1) * segH - k * gap
                        val on = v != null && pos <= f
                        val col = when {
                            !on -> if (pos >= redFrom) Color(0xFF3A0E0E) else Color(0xFF242427)
                            cold -> K.amber
                            pos >= redFrom -> K.redGlow
                            else -> Color.White.copy(alpha = 0.55f + 0.45f * pos)
                        }
                        val skew = segH * 0.35f
                        val path = Path().apply {
                            moveTo(0f, y + segH); lineTo(size.width - skew, y + segH); lineTo(size.width, y); lineTo(skew, y); close()
                        }
                        drawPath(path, col)
                    }
                    peak?.let {
                        val y = size.height * (1 - it)
                        drawLine(K.red, Offset(-4.dp.toPx(), y), Offset(size.width + 4.dp.toPx(), y), 2.dp.toPx())
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(p.short, color = K.label, style = Caps, fontSize = 15.sp, maxLines = 1, textAlign = TextAlign.Center)
            }
        }
    }

    picking?.let { slot ->
        ParamPicker("Dato de la barra ${slot + 1}", ids.getOrNull(slot), st, emptySet(), onPick = { id ->
            vm.setDashboard(st.dashboard.take(6).mapIndexed { j, old -> if (j == slot) id else old })
            picking = null
        }, onDismiss = { picking = null })
    }
}

// ═══════════════════════════════════════════════════════════════════ VIAJE

private fun hms(seconds: Double): String {
    val s = seconds.toLong()
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s / 60) % 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
}

/** Texto rojo con brillo, como los dígitos del display del cuadro. */
@Composable
private fun LcdText(text: String, size: TextUnit, color: Color = K.lcd, light: Boolean = false) {
    Text(
        text, maxLines = 1,
        style = TextStyle(
            color = color, fontSize = size, fontFamily = if (light) CondLight else Cond, fontFeatureSettings = "tnum",
            shadow = Shadow(color.copy(alpha = if (color == TripValue) 0.9f else 0.75f), blurRadius = if (color == TripValue) 18f else 14f),
        ),
    )
}

/** Rojo de los números de Viaje (un poco más rojo que el de los relojes) y el de los rótulos, más oscuro. */
private val TripValue = Color(0xFFFF2A16)
private val TripLabelColor = Color(0xFFB8241A)

/** Rótulo de Viaje: la misma letra que los números, en un rojo más oscuro para que se distinga pero se lea. */
@Composable
private fun TripLabel(text: String, size: TextUnit = 13.sp) {
    Text(
        text, maxLines = 1,
        style = TextStyle(
            color = TripLabelColor, fontSize = size, fontFamily = Cond, fontWeight = FontWeight.Bold,
            shadow = Shadow(TripLabelColor.copy(alpha = 0.45f), blurRadius = 6f),
        ),
    )
}

/**
 * Ordenador de viaje con aspecto del cuadro del Bocanegra: el reloj de velocidad a la izquierda
 * y a la derecha un display rojo grande tipo MFA con los datos "desde salida".
 */
@Composable
private fun TripScreen(st: UiState, vm: ObdViewModel) {
    val t = st.trip
    val es = java.util.Locale("es", "ES")
    Focus(vm, listOf("speed", "fuelrate"))
    val fuelSrc = st.fuelSrc ?: Fuel.source(st.supportedPids)
    val lph = st.values["fuelrate"]
    val kmh = st.values["speed"] ?: 0.0
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(1000); now = System.currentTimeMillis() } }
    val clock = java.text.SimpleDateFormat("HH:mm", es).format(java.util.Date(now))

    BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 10.dp)) {
        val gauge = min(maxHeight - 30.dp, maxWidth * 0.40f)
        val leftW = maxWidth * 0.42f
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(leftW)) {
                var fixOpen by remember { mutableStateOf(false) }
                if (fixOpen) FixDialog(st, vm) { fixOpen = false }
                ClusterGauge(
                    Params.byId.getValue("speed"), st, st.logo,
                    Modifier.size(gauge).then(if (st.limitOn) Modifier.clickable { fixOpen = true } else Modifier),
                    // Posición elegida en la réplica de Viaje con las medidas reales (4-nov-2026)
                    signX = 0.876f, signY = 0.892f, signSize = 0.18f,
                    radarX = RADAR_TRIP_X, radarY = RADAR_TRIP_Y, radarSize = RADAR_TRIP_SIZE,
                )
                if (st.limitOn) RoadText(st.limitRoad, Modifier.padding(top = 4.dp))
                else Text("Velocidad", color = K.label2, style = Caps, fontSize = 16.sp, modifier = Modifier.padding(top = 4.dp))
            }
            // Display tipo MFA
            Column(
                Modifier.weight(1f).fillMaxHeight()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF120303), Color(0xFF070101))))
                    .border(1.5.dp, Brush.verticalGradient(listOf(Color(0xFF4A1010), Color(0xFF1A0505))), RoundedCornerShape(18.dp))
                    .drawBehind {
                        var y = 0f
                        val step = 3.dp.toPx()
                        while (y < size.height) { drawLine(Color.Black.copy(alpha = 0.35f), Offset(0f, y), Offset(size.width, y), 1f); y += step }
                    }
                    .padding(horizontal = 18.dp, vertical = 10.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LcdText("DESDE SALIDA", 16.sp, color = TripValue)
                    Spacer(Modifier.weight(1f))
                    // Arriba, junto a la hora, para que abajo quepan enteros los seis datos
                    Box(
                        Modifier.clip(Chamfer(6.dp)).border(1.dp, TripValue.copy(alpha = 0.6f), Chamfer(6.dp))
                            .clickable(onClick = vm::resetTrip).padding(horizontal = 10.dp, vertical = 2.dp),
                    ) { LcdText("PONER A CERO", 13.sp, color = TripValue) }
                    Spacer(Modifier.width(12.dp))
                    LcdText(clock, 20.sp, color = TripValue)
                }
                Canvas(Modifier.fillMaxWidth().padding(vertical = 5.dp).height(2.dp)) {
                    drawLine(
                        K.lcd.copy(alpha = 0.6f), Offset(0f, 1f), Offset(size.width, 1f), 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 4.dp.toPx())),
                    )
                }
                // Dato grande: distancia, y a la derecha el tiempo en marcha
                Row(verticalAlignment = Alignment.Bottom) {
                    LcdText(String.format(es, "%.1f", t.distanceKm), 34.sp, color = TripValue, light = true)
                    LcdText(" km", 16.sp, color = TripValue)
                    Spacer(Modifier.weight(1f))
                    Column(horizontalAlignment = Alignment.End) {
                        TripLabel("en marcha")
                        LcdText(hms(t.movingSeconds), 20.sp, color = TripValue)
                    }
                }
                Spacer(Modifier.height(4.dp))
                val per100 = lph?.let { Fuel.per100(it, kmh) }
                val nowText = when {
                    lph == null -> "- - -"
                    per100 != null -> String.format(es, "%.1f", per100.coerceAtMost(99.9))
                    else -> String.format(es, "%.1f", lph)
                }
                // Seis datos en dos columnas para que quepan todos en la pantalla del coche
                val left = listOf(
                    Triple("Consumo ahora", nowText, if (lph != null && per100 == null) "l/h" else "l/100 km"),
                    Triple("Consumo medio", t.avgConsumption?.let { String.format(es, "%.1f", it) } ?: "- - -", "l/100 km"),
                    Triple("Combustible gastado", t.fuelLitres?.let { String.format(es, "%.2f", it) } ?: "- - -", "l"),
                )
                val right = listOf(
                    Triple("Velocidad media", t.avgSpeed?.let { String.format(es, "%.0f", it) } ?: "- - -", "km/h"),
                    Triple("Velocidad máxima", String.format(es, "%.0f", t.maxSpeed), "km/h"),
                    Triple("Tiempo total", hms((now - t.startMs) / 1000.0), ""),
                )
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    for (col in listOf(left, right)) {
                        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly) {
                            col.forEach { (label, value, unit) ->
                                Column {
                                    TripLabel(label)
                                    Row(verticalAlignment = Alignment.Bottom) {
                                        LcdText(value, 20.sp, color = TripValue)
                                        if (unit.isNotEmpty()) TripLabel(" $unit", 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════ CRONÓMETRO

@Composable
private fun AccelScreen(st: UiState, vm: ObdViewModel) {
    val a = st.accel
    val es = java.util.Locale("es", "ES")
    Focus(vm, listOf("speed", "rpm"))
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(a.state) {
        while (a.state == AccelState.MIDIENDO) { kotlinx.coroutines.delay(30); now = System.currentTimeMillis() }
    }
    val speed = st.values["speed"]
    val shown = when (a.state) {
        AccelState.MIDIENDO -> (now - a.startMs) / 1000.0
        AccelState.HECHO -> a.resultS ?: 0.0
        else -> 0.0
    }
    val (msg, msgColor) = when (a.state) {
        AccelState.PARADO -> "Pulsa PREPARAR" to K.label2
        AccelState.PREPARADO ->
            if (a.mode.from == 0.0 && (speed ?: 0.0) > 0.5) "Detén el coche para empezar" to K.amber
            else if (a.mode.from == 0.0) "Listo: arranca cuando quieras" to K.green
            else "Listo: acelera al pasar de ${a.mode.from.toInt()} km/h" to K.green
        AccelState.MIDIENDO -> "Midiendo…" to K.redGlow
        AccelState.HECHO -> "Tiempo final" to K.label
    }
    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row {
            AccelMode.values().forEach { m ->
                val sel = m == a.mode
                Column(Modifier.clickable { vm.setAccelMode(m) }.padding(horizontal = 16.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(m.title, color = if (sel) K.label else K.label2, style = Caps, fontSize = 18.sp)
                    Spacer(Modifier.height(4.dp))
                    Box(Modifier.width(40.dp).height(2.5.dp).background(if (sel) K.red else Color.Transparent))
                }
            }
        }
        Spacer(Modifier.weight(0.3f))
        Lcd(String.format(es, "%05.2f", shown), size = 110.sp, color = if (a.state == AccelState.HECHO) Color.White else K.lcd)
        Text("segundos", color = K.label2, style = Caps, fontSize = 16.sp)
        Spacer(Modifier.height(10.dp))
        Text(msg, color = msgColor, style = Caps, fontSize = 22.sp)
        Spacer(Modifier.weight(0.3f))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Velocidad", color = K.label2, fontSize = 15.sp)
            Spacer(Modifier.width(8.dp))
            Lcd(speed?.let { String.format(es, "%.0f", it) } ?: "- - -", size = 28.sp)
            Text(" km/h", color = K.label2, fontSize = 14.sp)
            Spacer(Modifier.width(30.dp))
            Text("Mejor", color = K.label2, fontSize = 15.sp)
            Spacer(Modifier.width(8.dp))
            Lcd(a.best[a.mode]?.let { String.format(es, "%.2f", it) } ?: "- - -", size = 28.sp)
            Text(" s", color = K.label2, fontSize = 14.sp)
            Spacer(Modifier.width(30.dp))
            if (a.state == AccelState.PREPARADO || a.state == AccelState.MIDIENDO) RedButton("CANCELAR", onClick = vm::cancelAccel)
            else RedButton("PREPARAR", enabled = st.conn == Conn.CONECTADO, onClick = vm::armAccel)
        }
        Text(
            "Úsalo solo en un circuito o lugar cerrado al tráfico. La precisión depende de lo rápido que lea el cable.",
            color = K.label3, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp),
        )
    }
}

// ═══════════════════════════════════════════════════════════════════ PÁGINAS

@Composable
private fun PagesSheet(st: UiState, vm: ObdViewModel, onDone: () -> Unit) {
    Dialog(onDismissRequest = onDone, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxWidth(0.8f).fillMaxHeight(0.9f).clip(PanelShape).carbon().border(1.dp, K.line, PanelShape)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Páginas de relojes", color = K.label, style = Caps, fontSize = 24.sp, modifier = Modifier.weight(1f).padding(start = 10.dp))
                RedButton("LISTO", onClick = onDone)
            }
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                group(null) {
                    st.pages.forEachIndexed { i, pg ->
                        if (i > 0) Divider()
                        var name by remember(i, st.pageNames) { mutableStateOf(vm.pageName(st, i)) }
                        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp).height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                BasicTextField(
                                    value = name,
                                    onValueChange = { v -> name = v.take(24); vm.renamePage(i, name) },
                                    singleLine = true,
                                    textStyle = TextStyle(color = K.label, fontSize = 18.sp, fontFamily = Cond),
                                    cursorBrush = SolidColor(K.red),
                                    modifier = Modifier.fillMaxWidth(0.9f).clip(Chamfer(6.dp)).background(K.panel2).padding(horizontal = 10.dp, vertical = 6.dp),
                                )
                                Text(
                                    pg.joinToString(" · ") { Params.byId[it.id]?.short ?: it.id } + if (i == st.page) "   · en pantalla" else "",
                                    color = K.label2, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(top = 3.dp),
                                )
                            }
                            BarButton("VER") { vm.movePage(i - st.page); onDone() }
                            if (st.pages.size > 1) BarButton("QUITAR", color = K.redGlow) { vm.removePage(i) }
                        }
                    }
                }
                item {
                    Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        RedButton("AÑADIR PÁGINA", onClick = vm::addPage)
                        BarButton("VOLVER A LAS PÁGINAS ORIGINALES", color = K.label2, onClick = vm::resetPages)
                    }
                }
                footer("Toca el nombre de una página para cambiarlo. Para mover o cambiar sus relojes, ábrela y pulsa SETUP.")
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }
}

@Composable
private fun ParamPicker(
    title: String, selected: String?, st: UiState, exclude: Set<String>,
    onPick: (String) -> Unit, onDismiss: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxWidth(0.7f).fillMaxHeight(0.9f).clip(PanelShape).carbon().border(1.dp, K.line, PanelShape)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = K.label, style = Caps, fontSize = 22.sp, modifier = Modifier.weight(1f).padding(start = 10.dp))
                BarButton("CERRAR", onClick = onDismiss)
            }
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                Category.values().forEach { cat ->
                    val list = Params.all.filter { it.category == cat && it.id !in exclude }
                    if (list.isNotEmpty()) {
                        group(cat.title.uppercase()) {
                            list.forEachIndexed { i, p ->
                                if (i > 0) Divider()
                                val off = isUnsupported(p, st)
                                Row(
                                    Modifier.fillMaxWidth().clickable { onPick(p.id) }.padding(horizontal = 16.dp).height(50.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(p.name, color = if (off) K.label2 else K.label, fontSize = 16.sp)
                                        if (off) Text("Tu coche no lo da por OBD", color = K.label2, fontSize = 12.sp)
                                    }
                                    if (p.id == selected) Icon(Icons.Rounded.Check, null, tint = K.red)
                                }
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(20.dp)) }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════ Piezas de lista

private fun LazyListScope.group(title: String?, content: @Composable ColumnScope.() -> Unit) {
    item {
        Column(Modifier.padding(top = 16.dp)) {
            if (title != null) {
                Row(Modifier.padding(start = 4.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(14.dp).height(3.dp).background(K.red))
                    Spacer(Modifier.width(8.dp))
                    Text(title, color = K.label2, style = Caps, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
            Column(
                Modifier.fillMaxWidth().clip(PanelShape).background(K.panel.copy(alpha = 0.92f)).border(1.dp, K.line, PanelShape),
                content = content,
            )
        }
    }
}

private fun LazyListScope.footer(text: String) {
    item { Text(text, color = K.label2, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, top = 6.dp, end = 16.dp)) }
}

@Composable
private fun Divider() {
    Box(Modifier.fillMaxWidth().padding(start = 16.dp).height(1.dp).background(K.line))
}

@Composable
private fun NavRow(title: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 16.dp, end = 8.dp).height(50.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, color = K.label, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text(value, color = K.label2, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Icon(Icons.Rounded.KeyboardArrowRight, null, tint = K.red)
    }
}

@Composable
private fun InfoRow(title: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(48.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = K.label, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text(value, color = K.label2, style = Num, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun IconBtn(icon: ImageVector, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = if (enabled) K.label2 else K.label3) }
}

/** Interruptor propio: cápsula oscura con piloto rojo. */
@Composable
private fun Toggle(on: Boolean, onChange: (Boolean) -> Unit) {
    val x by animateFloatAsState(if (on) 1f else 0f, label = "tg")
    Box(
        Modifier.size(width = 52.dp, height = 28.dp).clip(CircleShape).background(K.panel2)
            .border(1.dp, if (on) K.red else K.line, CircleShape).clickable { onChange(!on) }.padding(3.dp),
    ) {
        Box(Modifier.offset(x = 24.dp * x).size(22.dp).clip(CircleShape).background(if (on) K.red else K.label3))
    }
}

private fun isUnsupported(p: Param, st: UiState): Boolean {
    if (st.supportedPids.isEmpty()) return false
    if (p.id == "oil" && st.oilSource.isNotEmpty()) return false
    if (p.id == "fuelrate") return (st.fuelSrc ?: Fuel.source(st.supportedPids)) == FuelSource.NONE
    val pid = when (p.id) { Params.BOOST -> 0x0B; Params.BATTERY -> return false; else -> p.pid ?: return false }
    return pid !in st.supportedPids
}

// ═══════════════════════════════════════════════════════════════════ DATOS

@Composable
private fun DataScreen(st: UiState, vm: ObdViewModel) {
    var cat by rememberSaveable { mutableStateOf<Category?>(null) }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        CategoryTabs(cat) { cat = it }
        val list = Params.all.filter { cat == null || it.category == cat }.sortedBy { isUnsupported(it, st) }
        LazyColumn(Modifier.fillMaxSize()) {
            group(null) {
                list.forEachIndexed { i, p ->
                    if (i > 0) Divider()
                    DataRow(p, st) {
                        vm.setDashboard(if (p.id in st.dashboard) st.dashboard - p.id else st.dashboard + p.id)
                    }
                }
                // ABS/ESP y cuadro (si se han encontrado al buscar centralitas): una fila más, con desplegable
                if (cat == null) {
                    DisposableEffect(Unit) { onDispose { vm.stopLive() } }
                    for (addr in listOf(0x03, 0x17)) {
                        if (st.modules.any { it.addr == addr && it.proto == VagProto.TP20 }) { Divider(); ModuleLiveRow(st, vm, addr) }
                    }
                }
            }
            footer("Los datos que no están en la página de relojes actual se actualizan por turnos para que los relojes vayan rápidos.")
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun CategoryTabs(cat: Category?, onSelect: (Category?) -> Unit) {
    Row(Modifier.padding(top = 8.dp).horizontalScroll(rememberScrollState())) {
        (listOf<Category?>(null) + Category.values()).forEach { c ->
            val sel = c == cat
            Column(
                Modifier.clickable { onSelect(c) }.padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text((c?.title ?: "Todo").uppercase(), color = if (sel) K.label else K.label2, style = Caps, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Box(Modifier.width(36.dp).height(2.5.dp).background(if (sel) K.red else Color.Transparent))
            }
        }
    }
}

@Composable
private fun DataRow(p: Param, st: UiState, onTogglePanel: () -> Unit) {
    val v = st.values[p.id]
    val off = isUnsupported(p, st)
    val warn = p.isWarning(v)
    val inPanel = p.id in st.dashboard
    Row(
        Modifier.fillMaxWidth().padding(start = 16.dp, end = 6.dp).height(60.dp).alpha(if (off) 0.45f else 1f),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(p.name, color = K.label, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (off) "No disponible en tu coche" else st.peaks[p.id]?.let { "Máx ${p.format(it)} ${p.unit}" } ?: p.category.title,
                color = K.label2, fontSize = 12.sp,
            )
        }
        if (!off) Sparkline(st.history[p.id], if (warn) K.amber else K.red, Modifier.width(110.dp).height(34.dp))
        Spacer(Modifier.width(14.dp))
        Row(Modifier.width(150.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.Bottom) {
            Text(p.format(v), color = if (warn) K.amber else K.label, style = Num, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(" ${p.unit}", color = K.label2, fontSize = 13.sp, modifier = Modifier.padding(bottom = 3.dp))
        }
    }
}

// ═══════════════════════════════════════════════════════════════════ AVERÍAS

@Composable
private fun DtcScreen(st: UiState, vm: ObdViewModel) {
    var confirm by remember { mutableStateOf(false) }
    var open by remember { mutableStateOf<Fault?>(null) }
    val list = remember(st.dtcs, st.pendingDtcs, st.permanentDtcs, st.udsDtcs) { faults(st) }
    val connected = st.conn == Conn.CONECTADO
    // Cada código cuenta una vez aunque salga en varias memorias
    val total = list.size
    val read = st.dtcs != null || st.udsDtcs != null

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        item {
            Row(
                Modifier.padding(top = 10.dp).fillMaxWidth().clip(PanelShape).background(K.panel).border(1.dp, K.line, PanelShape).padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val color = when { !read -> K.label3; total == 0 -> K.green; else -> K.amber }
                Box(Modifier.size(56.dp).clip(CircleShape).border(3.dp, color, CircleShape), contentAlignment = Alignment.Center) {
                    Text(if (!read) "?" else "$total", color = color, style = Num, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(18.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        when { !read -> "AVERÍAS SIN LEER"; total == 0 -> "SIN AVERÍAS"; total == 1 -> "1 AVERÍA"; else -> "$total AVERÍAS" },
                        color = K.label, style = Caps, fontSize = 26.sp, fontWeight = FontWeight.Bold,
                    )
                    Text(
                        when (st.mil) {
                            true -> "Testigo de motor encendido"
                            false -> "Testigo de motor apagado"
                            null -> if (connected) "Pulsa LEER para consultar la centralita" else "Conecta con el coche para leerlas"
                        },
                        color = K.label2, fontSize = 15.sp,
                    )
                    if (st.dtcMessage.isNotEmpty()) Text(st.dtcMessage, color = K.label2, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                }
                RedButton(if (st.dtcBusy) "LEYENDO…" else "LEER", enabled = connected && !st.dtcBusy) { vm.readDtcs() }
                Spacer(Modifier.width(8.dp))
                BarButton("BORRAR", enabled = connected && !st.dtcBusy) { confirm = true }
            }
        }
        moduleGroup(st, vm, list) { open = it }
        checkGroup(st)
        footer("Se lee la centralita del motor por OBD-II y su memoria propia de VAG (la que ven Autel o VCDS). BORRAR limpia las dos y luego comprueba que han quedado vacías. Las otras centralitas (ABS, airbag, cuadro…) se buscan con BUSCAR CENTRALITAS y cada una se borra por separado.")
        item { Spacer(Modifier.height(16.dp)) }
    }

    if (confirm) {
        AlertPanel(
            title = "¿BORRAR LAS AVERÍAS?",
            message = "Hazlo con el contacto puesto y el motor parado. Se borran las averías de la centralita (la memoria OBD y la propia de VAG, la que lee Autel), se apagará el testigo y se reiniciarán los controles que se revisan en la ITV hasta que conduzcas un rato. Las que sigan activas volverán a aparecer.",
            confirm = "BORRAR", onConfirm = { confirm = false; vm.clearDtcs() },
            onDismiss = { confirm = false },
        )
    }
    open?.let { f -> FaultSheet(f) { open = null } }
}

/** Una avería con lo que dice de ella cada memoria de la centralita (OBD y la propia de VAG). */
private class Fault(
    val code: String,
    val stored: Boolean,
    val pending: Boolean,
    val permanent: Boolean,
    val uds: UdsDtc?,
) {
    val def: DtcDef? = DtcInfo.def(code)
    val title: String = DtcInfo.describe(code)
    val active: Boolean get() = uds?.active == true
    val sporadic: Boolean get() = uds != null && !uds.active
    val confirmed: Boolean get() = stored || uds?.confirmed == true
    val isPending: Boolean get() = pending || (uds?.pending == true && uds.confirmed.not())
    val failure: String? get() = uds?.let { DtcInfo.failureType(it.ftb) }
}

/** Junta las memorias en una sola lista: primero las activas y, dentro, las más graves. */
private fun faults(st: UiState): List<Fault> {
    val codes = linkedSetOf<String>()
    st.udsDtcs?.forEach { codes += it.code }
    listOfNotNull(st.dtcs, st.pendingDtcs, st.permanentDtcs).forEach { codes += it }
    return codes.map { c ->
        Fault(
            c, st.dtcs?.contains(c) == true, st.pendingDtcs?.contains(c) == true, st.permanentDtcs?.contains(c) == true,
            st.udsDtcs?.firstOrNull { it.code == c },
        )
    }.sortedWith(compareByDescending<Fault> { it.active }.thenByDescending { it.def?.severity?.ordinal ?: 1 })
}

private fun severityColor(s: Severity?): Color = when (s) {
    Severity.LEVE -> K.label2
    Severity.MODERADA, null -> K.amber
    Severity.GRAVE -> K.redGlow
    Severity.CRITICA -> K.red
}

/** Etiquetas de estado de una avería (activa, confirmada, testigo…). */
private fun faultTags(f: Fault): List<Pair<String, Color>> = buildList {
    if (f.active) add("ACTIVA" to K.redGlow)
    else if (f.sporadic) add("NO PRESENTE" to K.green)
    if (f.confirmed) add("CONFIRMADA" to K.label)
    if (f.isPending) add("PENDIENTE" to K.amber)
    if (f.permanent) add("PERMANENTE" to K.label2)
    if (f.uds?.mil == true) add("TESTIGO" to K.amber)
}

@Composable
private fun Tag(text: String, color: Color) {
    Box(
        Modifier.padding(end = 6.dp, top = 4.dp).clip(Chamfer(4.dp)).border(1.dp, color.copy(alpha = 0.7f), Chamfer(4.dp))
            .padding(horizontal = 7.dp, vertical = 2.dp),
    ) { Text(text, color = color, style = Caps, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
}

/**
 * Centralitas, como en los equipos de taller: cada centralita con su estado; al abrirla, sus apartados;
 * y en cada apartado, sus componentes con "Correcto" o la avería (que se toca para ver la ficha).
 */
private fun LazyListScope.moduleGroup(st: UiState, vm: ObdViewModel, list: List<Fault>, onOpen: (Fault) -> Unit) {
    group("CENTRALITAS") {
        EngineModule(st, list, onOpen)
        Divider()
        OtherModules(st, vm)
    }
}

@Composable
private fun StatusTag(faults: Int, read: Boolean) = when {
    !read -> Tag("SIN LEER", K.label3)
    faults == 0 -> Tag("CORRECTO", K.green)
    faults == 1 -> Tag("1 AVERÍA", K.redGlow)
    else -> Tag("$faults AVERÍAS", K.redGlow)
}

@Composable
private fun EngineModule(st: UiState, list: List<Fault>, onOpen: (Fault) -> Unit) {
    val read = st.dtcs != null || st.udsDtcs != null
    val byCode = remember(list) { list.associateBy { it.code } }
    var expanded by remember(list.isNotEmpty()) { mutableStateOf(list.isNotEmpty()) }
    Row(
        Modifier.fillMaxWidth().clickable { expanded = !expanded }.padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(12.dp).clip(CircleShape).background(if (!read) K.label3 else if (list.isEmpty()) K.green else K.redGlow))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Motor", color = K.label, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text("01 · Electrónica del motor (J623) · OBD y memoria VAG", color = K.label2, fontSize = 12.sp)
        }
        StatusTag(list.size, read)
        Icon(if (expanded) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown, null, tint = K.red)
    }
    if (!expanded) return
    if (!read) {
        Text("Pulsa LEER para consultar la centralita.", color = K.label2, fontSize = 14.sp, modifier = Modifier.padding(start = 40.dp, bottom = 12.dp))
        return
    }
    EngineMap.subsystems.forEach { sub -> SubsystemBlock(sub, byCode, onOpen) }
    // Códigos que no son de ningún componente conocido
    val other = list.filter { EngineMap.find(it.code) == null }
    if (other.isNotEmpty()) {
        SubsystemBlock(Subsystem("Otros códigos", other.map { Component(it.title, setOf(it.code)) }), byCode, onOpen)
    }
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun SubsystemBlock(sub: Subsystem, byCode: Map<String, Fault>, onOpen: (Fault) -> Unit) {
    val faults = sub.components.flatMap { c -> c.codes.mapNotNull { byCode[it] } }
    var open by remember(sub.name, faults.size) { mutableStateOf(faults.isNotEmpty()) }
    Box(Modifier.fillMaxWidth().padding(start = 40.dp).height(1.dp).background(K.line))
    Row(
        Modifier.fillMaxWidth().clickable { open = !open }.padding(start = 40.dp, end = 8.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(if (faults.isEmpty()) "✔" else "✖", color = if (faults.isEmpty()) K.green else K.redGlow, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(24.dp))
        Text(sub.name, color = K.label, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text(
            if (faults.isEmpty()) "Correcto" else if (faults.size == 1) "1 avería" else "${faults.size} averías",
            color = if (faults.isEmpty()) K.green else K.redGlow, fontSize = 14.sp,
        )
        Icon(if (open) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown, null, tint = K.label2)
    }
    if (!open) return
    sub.components.forEach { c ->
        val cf = c.codes.mapNotNull { byCode[it] }
        Row(
            Modifier.fillMaxWidth().padding(start = 64.dp, end = 12.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(c.name, color = if (cf.isEmpty()) K.label2 else K.label, fontSize = 14.sp, modifier = Modifier.weight(1f))
            if (cf.isEmpty()) {
                Text("Correcto", color = K.green, fontSize = 13.sp)
            } else {
                cf.forEach { f ->
                    val color = if (f.active) K.redGlow else K.amber
                    Box(
                        Modifier.padding(start = 6.dp).clip(Chamfer(5.dp)).background(color.copy(alpha = 0.16f))
                            .border(1.dp, color.copy(alpha = 0.7f), Chamfer(5.dp)).clickable { onOpen(f) }
                            .padding(horizontal = 9.dp, vertical = 4.dp),
                    ) {
                        Text(f.code + if (f.active) " · ACTIVA" else "", color = color, style = Num, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
    Spacer(Modifier.height(4.dp))
}

/** Ficha técnica completa de una avería, como en un equipo de diagnosis de taller. */
@Composable
private fun FaultSheet(f: Fault, onClose: () -> Unit) {
    val d = f.def
    val color = severityColor(d?.severity)
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.widthIn(max = 720.dp).fillMaxWidth(0.94f).fillMaxHeight(0.94f)
                .clip(PanelShape).carbon().border(1.dp, K.red, PanelShape),
        ) {
            // Cabecera
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clip(Chamfer(6.dp)).background(color.copy(alpha = 0.18f)).padding(horizontal = 12.dp, vertical = 6.dp)) {
                    Text(f.code, color = color, style = Num, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(f.title, color = K.label, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Row { faultTags(f).forEach { (t, c) -> Tag(t, c) } }
                }
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(K.line))
            // Cuerpo
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp)) {
                SheetRow("Componente", d?.component ?: "—")
                SheetRow("Sistema", DtcInfo.system(f.code) + " · " + if (DtcInfo.isManufacturer(f.code)) "código del fabricante (VAG)" else "código genérico SAE")
                SheetRow("Centralita", "Motor (J623)")
                f.uds?.let { u ->
                    SheetRow("Tipo de fallo", (DtcInfo.failureType(u.ftb) ?: "Sin subtipo") + "  ·  FTB %02X".format(u.ftb))
                }
                SheetRow(
                    "Estado",
                    when {
                        f.active -> "Presente ahora: el fallo se está detectando en este momento"
                        f.sporadic -> "No presente ahora: ocurrió y ya no se detecta (esporádica o ya resuelta)"
                        f.permanent -> "Permanente: se borra sola cuando la centralita comprueba que está reparada"
                        f.isPending -> "Pendiente: detectada una vez, aún sin confirmar"
                        else -> "Guardada en la memoria OBD"
                    },
                )
                SheetRow(
                    "Origen",
                    listOfNotNull(
                        if (f.stored) "OBD confirmada (03)" else null,
                        if (f.pending) "OBD pendiente (07)" else null,
                        if (f.permanent) "OBD permanente (0A)" else null,
                        f.uds?.let { "Memoria VAG, estado %02X".format(it.status) },
                    ).joinToString(" · "),
                )
                f.uds?.let { SheetRow("Testigo de avería", if (it.mil) "Solicitado por esta avería" else "No lo enciende") }

                if (d != null) {
                    SheetTitle("GRAVEDAD")
                    Text(d.severity.label.uppercase(), color = color, style = Caps, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(d.severity.advice, color = K.label2, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp))
                    SheetTitle("EFECTO EN EL COCHE")
                    Text(d.effect, color = K.label, fontSize = 15.sp)
                    d.note?.let { note ->
                        Column(
                            Modifier.padding(top = 14.dp).fillMaxWidth().clip(Chamfer(6.dp)).background(K.amber.copy(alpha = 0.12f))
                                .border(1.dp, K.amber.copy(alpha = 0.6f), Chamfer(6.dp)).padding(12.dp),
                        ) {
                            Text("NOTA", color = K.amber, style = Caps, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(note, color = K.label, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp))
                        }
                    }
                    SheetTitle("POSIBLES CAUSAS · DE MÁS A MENOS PROBABLE")
                    d.causes.forEachIndexed { i, c -> Numbered(i + 1, c) }
                    SheetTitle("COMPROBACIONES RECOMENDADAS")
                    d.checks.forEachIndexed { i, c -> Numbered(i + 1, c) }
                } else {
                    SheetTitle("SIN FICHA EN EL CATÁLOGO")
                    Text(
                        "Este código no está en el catálogo de la app. Por su estructura corresponde a: ${DtcInfo.system(f.code)}. " +
                            "Consulta la documentación técnica del fabricante con el código exacto" +
                            (f.failure?.let { " y el tipo de fallo ($it)" } ?: "") + ".",
                        color = K.label, fontSize = 15.sp,
                    )
                    SheetTitle("COMPROBACIONES GENERALES")
                    listOf(
                        "Revisa el conector y el cableado del componente afectado (terminales, humedad, roces)",
                        "Comprueba en Datos en vivo los valores relacionados con ese sistema",
                        "Borra las averías y comprueba si vuelve a aparecer y si queda activa",
                    ).forEachIndexed { i, c -> Numbered(i + 1, c) }
                }
                Spacer(Modifier.height(10.dp))
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(K.line))
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.End) {
                RedButton("CERRAR", onClick = onClose)
            }
        }
    }
}

@Composable
private fun SheetRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
        Text(label, color = K.label2, fontSize = 14.sp, modifier = Modifier.width(150.dp))
        Text(value, color = K.label, fontSize = 15.sp, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun SheetTitle(text: String) {
    Row(Modifier.padding(top = 18.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(14.dp).height(3.dp).background(K.red))
        Spacer(Modifier.width(8.dp))
        Text(text, color = K.label2, style = Caps, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun Numbered(n: Int, text: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
        Text("$n.", color = K.red, style = Num, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(26.dp))
        Text(text, color = K.label, fontSize = 15.sp, modifier = Modifier.weight(1f))
    }
}

/** Diagnóstico: cada comprobación con su estado (bien / aviso / mal / informativo) y el porqué. */
private fun LazyListScope.checkGroup(st: UiState) {
    if (st.checks.isEmpty() && !st.dtcBusy) return
    group("COMPROBACIONES DEL MOTOR · DATOS EN VIVO Y CONTROLES ITV") {
        var open by remember { mutableStateOf(false) }
        val ok = st.checks.count { it.level == CheckLevel.OK }
        val warn = st.checks.count { it.level == CheckLevel.AVISO }
        val bad = st.checks.count { it.level == CheckLevel.MAL }
        Row(
            Modifier.fillMaxWidth().clickable { open = !open }.padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("$ok bien · $warn avisos · $bad mal", color = K.label, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Icon(if (open) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown, null, tint = K.red)
        }
        if (open) st.checks.forEachIndexed { i, c ->
            if (i > 0) Divider()
            val color = when (c.level) {
                CheckLevel.OK -> K.green
                CheckLevel.AVISO -> K.amber
                CheckLevel.MAL -> K.redGlow
                CheckLevel.INFO -> K.label2
            }
            val glyph = when (c.level) {
                CheckLevel.OK -> "✔"
                CheckLevel.AVISO -> "!"
                CheckLevel.MAL -> "✖"
                CheckLevel.INFO -> "i"
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.Top) {
                Box(Modifier.size(30.dp).clip(CircleShape).background(color.copy(alpha = 0.18f)).border(2.dp, color, CircleShape), contentAlignment = Alignment.Center) {
                    Text(glyph, color = color, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(c.name, color = K.label, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text(c.value, color = color, style = Num, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(c.why, color = K.label2, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
                }
            }
        }
        if (st.dtcBusy) {
            if (st.checks.isNotEmpty()) Divider()
            Text(st.dtcMessage, color = K.label2, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp))
        }
    }
}

@Composable
private fun AlertPanel(title: String, message: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.width(380.dp).clip(PanelShape).carbon().border(1.dp, K.red, PanelShape).padding(20.dp)) {
            Text(title, color = K.label, style = Caps, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(message, color = K.label2, fontSize = 14.sp)
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                BarButton("CANCELAR", color = K.label2, onClick = onDismiss)
                Spacer(Modifier.width(8.dp))
                RedButton(confirm, onClick = onConfirm)
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════ AJUSTES

@Composable
private fun SettingsScreen(st: UiState, vm: ObdViewModel) {
    var showLog by rememberSaveable { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        group("COCHE") {
            InfoRow("Versión de la app", "41")
            Divider(); InfoRow("Modelo", "SEAT Ibiza 6J · 2.0 TDI CFHD")
            Divider(); InfoRow("Bastidor", st.vin.ifEmpty { "—" })
            Divider(); InfoRow("Protocolo", st.protocol.ifEmpty { "—" })
            Divider(); InfoRow("Adaptador", st.adapter.ifEmpty { "—" })
            Divider(); InfoRow("Datos que da el coche", if (st.supportedPids.isEmpty()) "—" else "${st.supportedPids.size}")
            Divider(); InfoRow("Lecturas por segundo", if (st.conn == Conn.CONECTADO) String.format(java.util.Locale("es", "ES"), "%.1f", st.refreshHz) else "—")
        }
        group("TEMPERATURA DEL ACEITE") {
            InfoRow("Se lee de", "Centralita de motor (J623)")
            Divider(); InfoRow("Identificador", "22 11 BE")
            Divider(); InfoRow("Fórmula", "(A·256 + B − 2731) / 10 °C")
            Divider(); InfoRow("Estado", "Fijo · comprobado con Autel")
            Divider(); InfoRow("Ahora", st.values["oil"]?.let { String.format(java.util.Locale("es", "ES"), "%.1f °C", it) } ?: "—")
        }
        footer("La temperatura del aceite se lee siempre del mismo dato de la centralita, el que coincide con el Autel. No se busca ni se cambia.")
        group("PRESIÓN DEL TURBO") {
            InfoRow("Se lee de", "Centralita de motor (J623)")
            Divider(); InfoRow("Identificador", "22 11 49")
            Divider(); InfoRow("Fórmula", "A·256 + B = hPa · turbo = presión − atmosférica")
            Divider(); InfoRow("Estado", if (st.boostSource.startsWith("Centralita")) "Fijo · comprobado conduciendo" else "Fijo · ahora sin respuesta, se usa el dato estándar")
            Divider(); InfoRow("Ahora", st.values[Params.BOOST]?.let { String.format(java.util.Locale("es", "ES"), "%.2f bar", it) } ?: "—")
        }
        footer("La presión del turbo se lee siempre del mismo dato de la centralita, el comprobado conduciendo, con precisión de 1 hPa y sin el tope de 1,54 bar del dato OBD estándar. No se busca ni se cambia. Si un día no contesta, el reloj tira del dato estándar mientras tanto y vuelve a la centralita al reconectar.")
        group("LÍMITE DE VELOCIDAD") { LimitBlock(st, vm) }
        footer("Los límites salen del mapa de OpenStreetMap guardado en la pantalla y funcionan solo con el GPS. Si la vía no tiene el límite en el mapa, se deduce por el tipo de vía y sale con el aro discontinuo. Es una ayuda: mandan siempre las señales.")
        group("RADARES") { RadarBlock(st, vm) }
        footer("Radares fijos del mapa (OpenStreetMap) y los que añadas tú tocando el reloj de velocidad. Avisa del que tienes delante en tu dirección. Puede faltar alguno o haber alguno retirado, y no incluye radares móviles. Avisar con GPS y mapa es legal; los detectores no.")
        group("MAPA") { MapBlock(st, vm) }
        footer("La Comunitat Valenciana viene incluida en la app. Para otras zonas: descárgalas con wifi o impórtalas.")
        group("PRESIÓN DE NEUMÁTICOS") { TyreBlock(st, vm) }
        footer("Una rueda con menos aire tiene el radio más pequeño y gira algo más rápido. Avisa a partir de un 20–30 % de pérdida. Si pierden aire las cuatro, se nota comparándolas con la velocidad del GPS (menos preciso). Calibra después de inflar o cambiar ruedas. Es una ayuda: no sustituye al manómetro.")
        group("CONSUMO") { FuelBlock(st, vm) }
        footer("Si el coche no da el consumo por OBD (este motor de 2011 normalmente no lo da), la app lo calcula con la carga del motor y las revoluciones. Para dejarlo clavado: pon a cero el viaje del cuadro y el de la app, haz un trayecto largo y ajusta el porcentaje hasta que el consumo medio coincida (si la app marca 6,0 y el cuadro 5,4, baja un 10 %). Luego, parada al ralentí, ajusta el extra hasta que los l/h coincidan.")
        group("LOGO EN EL RELOJ PRINCIPAL") { LogoRow(st, vm) }
        footer("Elige una foto o imagen tuya (por ejemplo, del emblema de tu coche). Sale en el reloj más grande de cada página. Mejor con fondo transparente o negro.")
        group("PANEL") {
            ChoiceRow("Tamaño de los números digitales", "La pantallita roja de cada reloj", AlertOptions.lcdSizes, st.opt(AlertKey.LCD_SIZE)) { vm.setAlert(AlertKey.LCD_SIZE, it) }
            Divider()
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp).height(56.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Aviso de revoluciones", color = K.label, fontSize = 16.sp)
                    Text("El reloj de revoluciones se pone en rojo desde aquí", color = K.label2, fontSize = 12.sp)
                }
                Text("${st.shiftRpm} rpm", color = K.label, style = Num, fontSize = 18.sp)
                Spacer(Modifier.width(10.dp))
                Stepper(onMinus = { vm.setShiftRpm(st.shiftRpm - 100) }, onPlus = { vm.setShiftRpm(st.shiftRpm + 100) })
            }
            Divider()
            Row(
                Modifier.fillMaxWidth().clickable { vm.resetPeaks() }.padding(horizontal = 16.dp).height(50.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) { Text("Poner a cero los máximos", color = K.redGlow, fontSize = 16.sp) }
        }
        footer("Pantalla completa (en MENÚ) oculta las barras. Toca la pantalla para volver.")
        group("DIAGNÓSTICO USB") { UsbBlock(st, vm) }
        footer("Para averiguar por qué se desconecta el cable: cada vez que pasa se apunta la hora, la tensión de la batería (un bajón al arrancar el motor es una causa típica), si la pantalla o la app se acababan de abrir y si Android perdió el cable.")
        group("COMUNICACIÓN") {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp).height(52.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Registrar todo el tráfico OBD", color = K.label, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Toggle(st.traffic, vm::setTraffic)
            }
            Divider()
            NavRow("Registro y consola", "${st.log.size} líneas") { showLog = !showLog }
        }
        if (showLog) item { Console(st, vm) }
        item { Spacer(Modifier.height(20.dp)) }
    }
}

@Composable
private fun BoostBlock(st: UiState, vm: ObdViewModel) {
    val p = st.boostScanProgress
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Buscar la presión real en la centralita", color = K.label, fontSize = 16.sp)
                Text(
                    if (p != null) "Buscando… ${(p * 100).toInt()} % · ${st.boostMessage}"
                    else st.boostMessage.ifEmpty { "Con el motor al ralentí y el coche parado. Tarda unos minutos; si la paras, luego sigue donde se quedó. Los relojes siguen funcionando mientras busca." },
                    color = if (st.boostValidating) K.amber else K.label2, fontSize = 12.sp,
                )
            }
            if (p == null) {
                BarButton("ESTÁNDAR", color = K.label2, onClick = vm::forgetBoost)
                RedButton("BUSCAR", enabled = st.conn == Conn.CONECTADO && !st.demo && st.oilScanProgress == null, onClick = vm::scanBoost)
            } else {
                BarButton("PARAR", onClick = vm::stopBoostScan)
            }
        }
        if (p != null) {
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().height(4.dp).background(K.panel2)) {
                Box(Modifier.fillMaxWidth(p).fillMaxHeight().background(K.red))
            }
        }
        // Candidatos en directo: compáralos con el Autel y, si quieres, elige uno con USAR
        DisposableEffect(Unit) {
            vm.watchBoostCandidates(true)
            onDispose { vm.watchBoostCandidates(false) }
        }
        if (st.boostCands.isNotEmpty()) {
            val es = java.util.Locale("es", "ES")
            Text(
                "En directo · sensor estándar " + (st.boostRefHpa?.let { String.format(es, "%.0f hPa", it) } ?: "—") +
                    " (no pasa de 2550) · atmosférica " + (st.baroRefHpa?.let { String.format(es, "%.0f hPa", it) } ?: "—"),
                color = K.label2, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp),
            )
            Text(
                "La buena marca lo mismo que el sensor estándar (hasta 2550) y sigue subiendo por encima al acelerar fuerte. " +
                    "La que se queda quieta en unos 1000 es la presión atmosférica.",
                color = K.label3, fontSize = 12.sp,
            )
            st.boostCands.forEach { c ->
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("22%04X".format(c.did), color = if (c.discarded) K.label3 else K.label, style = Num, fontSize = 17.sp, modifier = Modifier.width(90.dp))
                    Text(
                        c.live?.let { String.format(es, "%.0f hPa", it) } ?: "— hPa",
                        color = if (c.live != null && !c.discarded) K.green else K.label3, style = Num, fontSize = 17.sp,
                        modifier = Modifier.width(110.dp),
                    )
                    Text(
                        when {
                            c.ambient -> "parece la presión atmosférica"
                            c.discarded -> "descartado: no sigue al turbo"
                            c.meanErr != null -> String.format(es, "se desvía %.0f hPa del sensor (%d muestras)", c.meanErr, c.n)
                            else -> "sin comparar todavía: acelera"
                        },
                        color = K.label2, fontSize = 12.sp, modifier = Modifier.weight(1f),
                    )
                    BarButton("USAR") { vm.useBoostCandidate(c.did, c.formula) }
                }
            }
        }
    }
}

/** Diagnóstico del USB de la pantalla: datos, root, reinicio del USB y registro de desconexiones. */
@Composable
private fun UsbBlock(st: UiState, vm: ObdViewModel) {
    LaunchedEffect(Unit) { vm.loadUsbInfo() }
    val clipboard = LocalClipboardManager.current
    st.usbInfo.forEachIndexed { i, (k, v) -> if (i > 0) Divider(); InfoRow(k, v) }
    Divider()
    InfoRow("USB del cable OBD", st.usbBus.ifEmpty { "Aún no se ha visto" })
    Divider()
    // Registro de desconexiones
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp).heightIn(min = 52.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Registro de desconexiones", color = K.label, fontSize = 16.sp)
            Text("Lo más nuevo, abajo. Se guarda aunque se apague la pantalla.", color = K.label2, fontSize = 12.sp)
        }
        BarButton("COPIAR") { clipboard.setText(AnnotatedString(vm.usbLogText())) }
        BarButton("BORRAR", color = K.label2) { vm.clearUsbLog() }
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 12.dp).clip(Chamfer(6.dp)).background(Color.Black.copy(alpha = 0.35f)).padding(10.dp)) {
        if (st.usbLog.isEmpty()) Text("Sin sucesos todavía.", color = K.label3, fontSize = 13.sp)
        st.usbLog.forEach { line ->
            val bad = line.contains("no ve", true) || line.contains("perdido", true) || line.contains("no contesta", true) || line.contains("NO ha vuelto")
            Text(
                line,
                color = when { line.startsWith("      ") -> K.label3; bad -> K.amber; else -> K.label2 },
                fontSize = 12.sp, fontFamily = FontFamily.Monospace,
            )
        }
    }
}

/** Corregir el límite de la vía por la que vas. Queda guardado para siempre. */
@Composable
private fun FixDialog(st: UiState, vm: ObdViewModel, onClose: () -> Unit) {
    val map = remember { vm.mapLimitNow() }
    var whole by remember { mutableStateOf(true) }
    var radarMsg by remember { mutableStateOf("") }
    val mineNear = remember(st.radarMine) { vm.myRadarNear() }
    // Ancho propio: con el ancho por defecto de Android la ventana se quedaba estrecha y se cortaban señales (60, 120)
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth(0.94f).widthIn(max = 640.dp).clip(PanelShape).carbon().border(1.dp, K.red, PanelShape)
                .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp),
        ) {
            // Compacta para que quepa entera en la pantalla del coche (683 × 400 dp) sin desplazar
            Row(verticalAlignment = Alignment.Bottom) {
                Text("CORREGIR EL LÍMITE", color = K.label, style = Caps, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(" · " + RoadNames.short(st.limitRoad.ifEmpty { "Vía sin nombre" }), color = K.label2, style = Caps, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            val said = map?.let { m -> m.kmh?.let { k -> (if (m.estimated) "aprox. " else "") + "$k km/h" } ?: "sin límite" }
            Text(
                if (map == null) "Todavía no sé por qué vía vas: espera a que el GPS la reconozca."
                else "El mapa dice: $said" + if (st.limitCorrected) " · ahora usas tu corrección (${st.speedLimit} km/h)" else "",
                color = K.label2, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp),
            )
            // Todos los límites de las señales de velocidad máxima en España (R-301)
            listOf(10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120).chunked(6).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    row.forEach { v ->
                        val sel = st.limitCorrected && st.speedLimit == v
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            SpeedSignView(
                                v,
                                Modifier.size(50.dp).clip(CircleShape).clickable(enabled = map != null) { vm.fixLimit(v, whole); onClose() },
                                selected = sel,
                            )
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Toda la calle", color = K.label, fontSize = 16.sp)
                    Text("Todos los tramos con este nombre, hasta 5 km", color = K.label2, fontSize = 12.sp)
                }
                Toggle(whole) { whole = it }
            }
            // Radares que no están en el mapa: se añaden aquí al pasar por ellos y desde entonces avisa
            Box(Modifier.padding(vertical = 8.dp).fillMaxWidth().height(1.dp).background(K.line))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("RADAR AQUÍ", color = K.label, style = Caps, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(
                        radarMsg.ifEmpty { "¿Has pasado un radar que no conocía? Añádelo y avisará" },
                        color = if (radarMsg.isNotEmpty()) K.green else K.label2, fontSize = 12.sp,
                    )
                }
                BarButton("＋ RADAR FIJO") { radarMsg = vm.addRadar(tramo = false) }
                BarButton("＋ TRAMO") { radarMsg = vm.addRadar(tramo = true) }
                if (mineNear) BarButton("QUITAR EL MÍO", color = K.label2) { radarMsg = vm.removeNearRadar() }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                if (st.limitCorrected) BarButton("QUITAR CORRECCIÓN", color = K.label2) { vm.removeLimitFix(); onClose() }
                Spacer(Modifier.width(8.dp))
                RedButton("CERRAR", onClick = onClose)
            }
        }
    }
}

@Composable
private fun SwitchRow(title: String, sub: String?, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp).heightIn(min = 56.dp).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = K.label, fontSize = 16.sp)
            if (sub != null) Text(sub, color = K.label2, fontSize = 12.sp)
        }
        Toggle(on, onChange)
    }
}

/** Fila con varias opciones: se pasa de una a otra con − y +. Con [onTest] sale un botón para probar el sonido. */
@Composable
private fun ChoiceRow(title: String, sub: String?, options: List<String>, sel: Int, enabled: Boolean = true, onTest: (() -> Unit)? = null, onSel: (Int) -> Unit) {
    val i = sel.coerceIn(0, options.size - 1)
    Row(
        Modifier.fillMaxWidth().alpha(if (enabled) 1f else 0.4f).padding(start = 16.dp, end = 8.dp).heightIn(min = 56.dp).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = K.label, fontSize = 16.sp)
            if (sub != null) Text(sub, color = K.label2, fontSize = 12.sp)
        }
        if (onTest != null) BarButton("▶ PROBAR", color = K.label2, enabled = enabled, onClick = onTest)
        Text(options[i], color = K.label, fontSize = 15.sp, textAlign = TextAlign.End, modifier = Modifier.widthIn(min = 70.dp, max = 190.dp))
        Spacer(Modifier.width(10.dp))
        Stepper(
            onMinus = { if (enabled) onSel((i - 1).coerceAtLeast(0)) },
            onPlus = { if (enabled) onSel((i + 1).coerceAtMost(options.size - 1)) },
        )
    }
}

@Composable
private fun LimitBlock(st: UiState, vm: ObdViewModel) {
    val es = java.util.Locale("es", "ES")
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { vm.refreshLocation() }
    SwitchRow("Límite en el reloj de velocidad", "Señal con el límite y la raya del límite en rojo", st.limitOn, vm::setLimitOn)
    if (!st.limitOn) return
    Divider()
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp).heightIn(min = 52.dp).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Estado", color = K.label, fontSize = 16.sp)
            Text(st.limitStatus.ifEmpty { "—" }, color = if (st.limitStatus.startsWith("Funcionando")) K.green else K.label2, fontSize = 12.sp)
        }
        if (!st.limitPermission) {
            RedButton("DAR PERMISO") {
                perm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            }
        }
    }
    Divider()
    InfoRow("Límite ahora", st.speedLimit?.let { (if (st.limitEstimated) "aprox. " else "") + "$it km/h" } ?: "—")
    Divider(); InfoRow("Vía", st.limitRoad.ifEmpty { "—" })
    Divider()
    InfoRow(
        "Velocidad GPS / coche",
        (st.gpsSpeed?.let { String.format(es, "%.0f", it) } ?: "—") + " / " +
            (st.values["speed"]?.takeIf { st.conn == Conn.CONECTADO }?.let { String.format(es, "%.0f", it) } ?: "—") + " km/h",
    )
    Divider()
    var fixOpen by remember { mutableStateOf(false) }
    var askClearFixes by remember { mutableStateOf(false) }
    if (fixOpen) FixDialog(st, vm) { fixOpen = false }
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp).heightIn(min = 56.dp).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Corregir el límite de esta vía", color = K.label, fontSize = 16.sp)
            Text(
                (if (st.limitCorrected) "Usando tu corrección · " else "También tocando el reloj de velocidad · ") + "${st.limitFixCount} correcciones guardadas",
                color = K.label2, fontSize = 12.sp,
            )
        }
        if (st.limitFixCount > 0) BarButton("BORRAR TODAS", color = K.label2) { askClearFixes = true }
        RedButton("CORREGIR") { fixOpen = true }
    }
    if (askClearFixes) {
        AlertPanel(
            title = "¿BORRAR LAS CORRECCIONES?",
            message = "Se borran los ${st.limitFixCount} límites que has corregido a mano y se vuelve a usar lo que dice el mapa.",
            confirm = "BORRAR", onConfirm = { askClearFixes = false; vm.clearLimitFixes() }, onDismiss = { askClearFixes = false },
        )
    }
    Divider()
    SwitchRow(
        "Mostrar límites aproximados", "Cuando la vía no tiene el límite en el mapa, enseñar el deducido por el tipo de vía",
        st.opt(AlertKey.LIMIT_EST) == 1,
    ) { vm.setAlert(AlertKey.LIMIT_EST, if (it) 1 else 0) }
    Divider()
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp).height(56.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Margen antes de avisar", color = K.label, fontSize = 16.sp)
            Text("Avisa al pasar del límite más este margen", color = K.label2, fontSize = 12.sp)
        }
        Text("+${st.limitMargin} km/h", color = K.label, style = Num, fontSize = 18.sp)
        Spacer(Modifier.width(10.dp))
        Stepper(onMinus = { vm.setLimitMargin(st.limitMargin - 1) }, onPlus = { vm.setLimitMargin(st.limitMargin + 1) })
    }
    Divider()
    ChoiceRow("Parpadeo al pasarte", "La señal y el aro del reloj", AlertOptions.limitBlinks, st.opt(AlertKey.LIMIT_BLINK)) { vm.setAlert(AlertKey.LIMIT_BLINK, it) }
    Divider()
    SwitchRow("Sonido al pasarte", "Apágalo si solo quieres el parpadeo en rojo, sin pitido", st.limitSound, vm::setLimitSound)
    Divider()
    ChoiceRow("Tipo de sonido", null, AlertOptions.tones, st.opt(AlertKey.LIMIT_TONE), enabled = st.limitSound, onTest = { vm.testSound(false) }) { vm.setAlert(AlertKey.LIMIT_TONE, it) }
    Divider()
    ChoiceRow("Repetir el sonido", "Mientras sigas pasado", AlertOptions.limitRepeats, st.opt(AlertKey.LIMIT_REPEAT), enabled = st.limitSound) { vm.setAlert(AlertKey.LIMIT_REPEAT, it) }
    Divider()
    ChoiceRow("Volumen", null, AlertOptions.volumes, st.opt(AlertKey.LIMIT_VOL), enabled = st.limitSound) { vm.setAlert(AlertKey.LIMIT_VOL, it) }
}

@Composable
private fun RadarBlock(st: UiState, vm: ObdViewModel) {
    val on = st.opt(AlertKey.RADAR_ON) == 1
    SwitchRow("Avisos de radar", "${st.radarCount} radares fijos en el mapa", on) { vm.setAlert(AlertKey.RADAR_ON, if (it) 1 else 0) }
    if (!on) return
    Divider()
    InfoRow(
        "Próximo radar",
        st.radarM?.let { (if (st.radarTramo) "tramo a " else "a ") + AlertOptions.distanceText((it / 10).toInt() * 10) + (st.radarKmh?.let { k -> " · $k km/h" } ?: "") } ?: "Ninguno delante",
    )
    Divider()
    // Para saber si un radar no avisa porque no está en el mapa o por otra cosa
    InfoRow("Radar más cercano (en cualquier dirección)", st.radarNearestM?.let { AlertOptions.distanceText((it / 10).toInt() * 10) } ?: "—")
    Divider()
    MyRadarsList(st, vm)
    Divider()
    ChoiceRow("Distancia de aviso", "Empieza a avisar a esta distancia del radar", AlertOptions.radarDistances.map { AlertOptions.distanceText(it) }, st.opt(AlertKey.RADAR_DIST)) { vm.setAlert(AlertKey.RADAR_DIST, it) }
    Divider()
    ChoiceRow("Parpadeo de la señal", null, AlertOptions.radarBlinks, st.opt(AlertKey.RADAR_BLINK)) { vm.setAlert(AlertKey.RADAR_BLINK, it) }
    Divider()
    val sound = st.opt(AlertKey.RADAR_SOUND) == 1
    SwitchRow("Sonido", null, sound) { vm.setAlert(AlertKey.RADAR_SOUND, if (it) 1 else 0) }
    Divider()
    ChoiceRow("Tipo de sonido", null, AlertOptions.tones, st.opt(AlertKey.RADAR_TONE), enabled = sound, onTest = { vm.testSound(true) }) { vm.setAlert(AlertKey.RADAR_TONE, it) }
    Divider()
    ChoiceRow("Repetir el sonido", "Mientras te acercas al radar", AlertOptions.radarRepeats, st.opt(AlertKey.RADAR_REPEAT), enabled = sound) { vm.setAlert(AlertKey.RADAR_REPEAT, it) }
    Divider()
    ChoiceRow("Volumen", null, AlertOptions.volumes, st.opt(AlertKey.RADAR_VOL), enabled = sound) { vm.setAlert(AlertKey.RADAR_VOL, it) }
    Divider()
    ChoiceRow(
        "La música mientras avisa", "El pitido del radar suena por encima de la radio o la música",
        listOf("La baja", "La para"), st.opt(AlertKey.RADAR_DUCK), enabled = sound,
    ) { vm.setAlert(AlertKey.RADAR_DUCK, it) }
}

// ── Mis radares: lista con el nombre de la calle y ficha de cada uno (como en la réplica aprobada el 4-nov-2026)

@Composable
private fun MyRadarsList(st: UiState, vm: ObdViewModel) {
    var open by remember { mutableStateOf<Int?>(null) }
    var askClear by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp).heightIn(min = 56.dp).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("MIS RADARES · GUARDADOS A MANO", color = K.label, style = Caps, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text(
                if (st.myRadars.isEmpty()) "Todavía no has guardado ninguno. Se guardan tocando el reloj de velocidad al pasar por debajo."
                else "${st.myRadars.size} guardados · del más nuevo al más antiguo · toca uno para cambiarlo",
                color = K.label2, fontSize = 12.sp,
            )
        }
        if (st.myRadars.size > 1) BarButton("BORRAR TODOS", color = K.label2) { askClear = true }
    }
    val tm = rememberTextMeasurer()
    st.myRadars.withIndex().reversed().forEach { (i, r) ->
        Divider()
        Row(
            Modifier.fillMaxWidth().clickable { open = i }.padding(start = 16.dp, end = 12.dp).heightIn(min = 54.dp).padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Canvas(Modifier.size(width = 34.dp, height = 30.dp)) {
                drawRadarIcon(tm, RADAR_STYLE, r.tramo, center, size.height * 0.95f, if (r.on) 1f else 0.3f)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(r.name.ifBlank { "Radar sin nombre" }, color = if (r.on) K.label else K.label3, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    (if (r.tramo) "Tramo" else "Radar fijo") + " · " + (if (r.both) "los dos sentidos" else "un sentido") +
                        (r.kmh?.let { " · $it km/h" } ?: "") + if (r.on) "" else " · sin aviso",
                    color = K.label2, fontSize = 12.sp,
                )
            }
            Text("›", color = K.label2, fontSize = 22.sp)
        }
    }
    val openI = open
    if (openI != null && openI in st.myRadars.indices) {
        MyRadarDialog(st.myRadars[openI], openI, vm) { open = null }
    }
    if (askClear) {
        AlertPanel(
            title = "¿BORRAR TODOS TUS RADARES?",
            message = "Se borran los ${st.myRadars.size} radares que has guardado a mano. Los del mapa siguen.",
            confirm = "BORRAR", onConfirm = { askClear = false; vm.clearMyRadars() }, onDismiss = { askClear = false },
        )
    }
}

/** Botones de elegir uno entre varios (el elegido en rojo). */
@Composable
private fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row {
        options.forEachIndexed { k, label ->
            val sel = k == selected
            Box(
                Modifier.background(if (sel) K.red else K.panel2).border(1.dp, if (sel) K.red else K.line)
                    .clickable { onSelect(k) }.padding(horizontal = 10.dp, vertical = 7.dp),
            ) { Text(label.uppercase(), color = if (sel) Color.White else K.label2, style = Caps, fontSize = 14.sp, maxLines = 1) }
        }
    }
}

/** Ficha de un radar tuyo: los cambios se guardan al momento. */
@Composable
private fun MyRadarDialog(r: Radar, i: Int, vm: ObdViewModel, onClose: () -> Unit) {
    var name by remember(i) { mutableStateOf(r.name) }
    var sure by remember(i) { mutableStateOf(false) }
    val tm = rememberTextMeasurer()
    val limits = listOf(10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120)
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth(0.94f).widthIn(max = 640.dp).clip(PanelShape).carbon().border(1.dp, K.red, PanelShape)
                .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Canvas(Modifier.size(width = 38.dp, height = 34.dp)) { drawRadarIcon(tm, RADAR_STYLE, r.tramo, center, size.height * 0.95f, if (r.on) 1f else 0.3f) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(r.name.ifBlank { "Radar sin nombre" }, color = K.label, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (r.date.isNotBlank()) "Guardado el ${r.date}" else "Guardado antes de la versión 39", color = K.label2, fontSize = 12.sp)
                }
                r.kmh?.let { SpeedSignView(it, Modifier.size(40.dp)) }
            }
            Box(Modifier.padding(vertical = 6.dp).fillMaxWidth().height(1.dp).background(K.line))
            DlgRow("Nombre", "El que sale en la lista") {
                BasicTextField(
                    value = name, onValueChange = { v -> name = v.take(60); vm.updateMyRadar(i) { it.copy(name = name) } }, singleLine = true,
                    textStyle = TextStyle(color = K.label, fontSize = 16.sp), cursorBrush = SolidColor(K.red),
                    modifier = Modifier.width(240.dp).background(Color.Black).border(1.dp, K.line).padding(horizontal = 8.dp, vertical = 7.dp),
                )
            }
            DlgRow("Tipo", "Cambia el icono que sale en el reloj") {
                Segmented(listOf("Radar fijo", "Tramo"), if (r.tramo) 1 else 0) { k -> vm.updateMyRadar(i) { it.copy(tramo = k == 1) } }
            }
            DlgRow("Sentido", "Si al volver también hay radar, elige «los dos»") {
                Segmented(listOf("Solo en el que lo guardé", "Los dos sentidos"), if (r.both) 1 else 0) { k -> vm.updateMyRadar(i) { it.copy(both = k == 1) } }
            }
            DlgRow("Límite del radar", "Sale en la señal mientras avisa") {
                Text(r.kmh?.let { "$it km/h" } ?: "—", color = K.label, style = Num, fontSize = 17.sp)
                Spacer(Modifier.width(10.dp))
                val k = limits.indexOf(r.kmh ?: 50).coerceAtLeast(0)
                Stepper(
                    onMinus = { vm.updateMyRadar(i) { it.copy(kmh = limits[(k - 1).coerceAtLeast(0)]) } },
                    onPlus = { vm.updateMyRadar(i) { it.copy(kmh = limits[(k + 1).coerceAtMost(limits.size - 1)]) } },
                )
            }
            DlgRow("Avisar de este radar", "Apágalo sin borrarlo, por ejemplo si lo han quitado unos días") {
                Toggle(r.on) { on -> vm.updateMyRadar(i) { it.copy(on = on) } }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                BarButton(if (sure) "¿SEGURO? TOCA OTRA VEZ" else "BORRAR ESTE RADAR", color = K.redGlow) {
                    if (sure) { vm.deleteMyRadar(i); onClose() } else sure = true
                }
                Spacer(Modifier.width(8.dp))
                RedButton("CERRAR", onClick = onClose)
            }
        }
    }
}

@Composable
private fun DlgRow(title: String, sub: String, content: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = K.label, fontSize = 16.sp)
            Text(sub, color = K.label2, fontSize = 12.sp)
        }
        content()
    }
}

@Composable
private fun MapBlock(st: UiState, vm: ObdViewModel) {
    InfoRow("Mapa guardado en la pantalla", st.limitSaved.ifEmpty { "—" })
    Divider()
    SwitchRow(
        "Guardar zonas nuevas con internet", "Si pasas por una zona sin mapa y hay internet, se descarga y se guarda sola",
        st.opt(AlertKey.AUTO_FETCH) == 1,
    ) { vm.setAlert(AlertKey.AUTO_FETCH, if (it) 1 else 0) }
    Divider()
    SwitchRow(
        "Actualizar con wifi", "Con wifi, baja sola las mejoras del mapa de los alrededores (zonas con más de un mes)",
        st.opt(AlertKey.WIFI_UPDATE) == 1,
    ) { vm.setAlert(AlertKey.WIFI_UPDATE, if (it) 1 else 0) }
    Divider()
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp).heightIn(min = 56.dp).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Actualizar ahora (con wifi)", color = K.label, fontSize = 16.sp)
            Text(
                "Vuelve a bajar del mapa de hoy los ${st.limitRegionKm} km alrededor · última: " + st.mapUpdated.ifEmpty { "mapa integrado del 2 nov 2026" },
                color = K.label2, fontSize = 12.sp,
            )
        }
        RedButton("ACTUALIZAR", enabled = st.limitRegionProgress == null, onClick = vm::updateLimitRegion)
    }
    Divider()
    // Descargar los alrededores con wifi
    val rp = st.limitRegionProgress
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Descargar los alrededores (con wifi)", color = K.label, fontSize = 16.sp)
                Text(
                    st.limitRegionText.ifEmpty { "Una vez, con wifi. Después funciona solo con el GPS, sin internet." },
                    color = K.label2, fontSize = 12.sp,
                )
            }
            if (rp == null) {
                Text("${st.limitRegionKm} km", color = K.label, style = Num, fontSize = 18.sp)
                Spacer(Modifier.width(10.dp))
                Stepper(onMinus = { vm.stepLimitRegionKm(-1) }, onPlus = { vm.stepLimitRegionKm(1) })
                Spacer(Modifier.width(10.dp))
                RedButton("DESCARGAR", onClick = vm::downloadLimitRegion)
            } else {
                BarButton("PARAR", onClick = vm::stopLimitRegion)
            }
        }
        if (rp != null) {
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().height(4.dp).background(K.panel2)) {
                Box(Modifier.fillMaxWidth(rp).fillMaxHeight().background(K.red))
            }
        }
    }
    Divider()
    // Importar un mapa preparado (archivo .zip)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) vm.importLimitMap(uri) }
    var askClear by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp).heightIn(min = 56.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Importar un mapa preparado", color = K.label, fontSize = 16.sp)
            Text("Archivo .zip con los límites de una zona entera", color = K.label2, fontSize = 12.sp)
        }
        BarButton("BORRAR", color = K.label2, enabled = rp == null) { askClear = true }
        RedButton("IMPORTAR", enabled = rp == null) { picker.launch("*/*") }
    }
    if (askClear) {
        AlertPanel(
            title = "¿BORRAR EL MAPA GUARDADO?",
            message = "Se borran todos los límites guardados en la pantalla. Para volver a tenerlos habrá que descargarlos o importarlos otra vez.",
            confirm = "BORRAR", onConfirm = { askClear = false; vm.clearLimitMaps() }, onDismiss = { askClear = false },
        )
    }
}

@Composable
private fun LogoRow(st: UiState, vm: ObdViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) vm.setLogo(uri) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(64.dp).clip(CircleShape).background(Color.Black).border(1.dp, K.line, CircleShape), contentAlignment = Alignment.Center) {
            val logo = st.logo
            if (logo != null) Image(bitmap = logo, contentDescription = null, modifier = Modifier.size(44.dp))
            else Text("—", color = K.label3)
        }
        Spacer(Modifier.width(14.dp))
        Text(if (st.logo == null) "Sin logo" else "Logo puesto", color = K.label, fontSize = 16.sp, modifier = Modifier.weight(1f))
        if (st.logo != null) BarButton("QUITAR", color = K.label2, onClick = vm::clearLogo)
        RedButton("ELEGIR IMAGEN") { picker.launch("image/*") }
    }
}

@Composable
private fun FuelBlock(st: UiState, vm: ObdViewModel) {
    val src = st.fuelSrc ?: Fuel.source(st.supportedPids)
    val es = java.util.Locale("es", "ES")
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text("De dónde sale", color = K.label2, fontSize = 12.sp)
        Text(if (st.supportedPids.isEmpty()) "Conecta con el coche para saberlo" else src.text, color = K.label, fontSize = 16.sp)
        st.values["fuelrate"]?.let { Text(String.format(es, "Ahora: %.1f l/h", it), color = K.label2, fontSize = 13.sp) }
        if (st.supportedPids.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text("Datos que da tu coche para calcularlo", color = K.label2, fontSize = 12.sp)
            Text(
                Fuel.relevant.joinToString("   ") { (pid, name) -> (if (pid in st.supportedPids) "✓ " else "✗ ") + name + " (01%02X)".format(pid) },
                color = K.label, fontSize = 13.sp,
            )
        }
    }
    Divider()
    FuelCalRow("Igualar con el cuadro", "Compara el consumo medio de un trayecto largo", AlertKey.FUEL_CAL, st, vm)
    Divider()
    FuelCalRow("Ajuste extra al ralentí", "Con el coche parado: compara los l/h con los del cuadro (se suma al de arriba)", AlertKey.FUEL_IDLE, st, vm)
    if (st.opt(AlertKey.FUEL_CAL) != 100 || st.opt(AlertKey.FUEL_IDLE) != 100) {
        Divider()
        Box(Modifier.fillMaxWidth().clickable { vm.setAlert(AlertKey.FUEL_CAL, 100); vm.setAlert(AlertKey.FUEL_IDLE, 100) }.padding(horizontal = 16.dp, vertical = 14.dp)) {
            Text("Quitar las correcciones", color = K.redGlow, fontSize = 16.sp)
        }
    }
}

@Composable
private fun FuelCalRow(title: String, sub: String, key: AlertKey, st: UiState, vm: ObdViewModel) {
    val pct = st.opt(key)
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp).heightIn(min = 64.dp).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = K.label, fontSize = 16.sp)
            Text(
                sub + " · " + if (pct == 100) "sin corregir" else if (pct > 100) "la app sube un ${pct - 100} %" else "la app baja un ${100 - pct} %",
                color = K.label2, fontSize = 12.sp,
            )
        }
        Text("$pct %", color = K.label, style = Num, fontSize = 18.sp)
        Spacer(Modifier.width(10.dp))
        Stepper(
            onMinus = { vm.setAlert(key, (pct - 1).coerceAtLeast(20)) },
            onPlus = { vm.setAlert(key, (pct + 1).coerceAtMost(200)) },
        )
    }
}

@Composable
private fun Stepper(onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.clip(Chamfer(6.dp)).background(K.panel2), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(width = 46.dp, height = 34.dp).clickable(onClick = onMinus), contentAlignment = Alignment.Center) {
            Box(Modifier.width(13.dp).height(2.dp).background(K.label))
        }
        Box(Modifier.width(1.dp).height(18.dp).background(K.line))
        Box(Modifier.size(width = 46.dp, height = 34.dp).clickable(onClick = onPlus), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Add, null, tint = K.label, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun Console(st: UiState, vm: ObdViewModel) {
    var cmd by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(st.log.size) { if (st.log.isNotEmpty()) listState.scrollToItem(st.log.size - 1) }
    Column(
        Modifier.padding(top = 12.dp).fillMaxWidth().clip(PanelShape).background(Color(0xFF0A0A0B))
            .border(1.dp, K.line, PanelShape).padding(12.dp),
    ) {
        LazyColumn(state = listState, modifier = Modifier.fillMaxWidth().height(260.dp)) {
            items(st.log) { Text(it, color = K.label2, fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(
                value = cmd, onValueChange = { cmd = it }, singleLine = true,
                textStyle = TextStyle(color = K.label, fontSize = 15.sp, fontFamily = FontFamily.Monospace),
                cursorBrush = SolidColor(K.red),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { if (cmd.isNotBlank()) { vm.sendRaw(cmd); cmd = "" } }),
                modifier = Modifier.weight(1f).clip(Chamfer(6.dp)).background(K.panel2).padding(12.dp),
                decorationBox = { inner ->
                    if (cmd.isEmpty()) Text("Orden ELM327, por ejemplo ATRV o 010C", color = K.label3, fontSize = 15.sp)
                    inner()
                },
            )
            Spacer(Modifier.width(8.dp))
            RedButton("ENVIAR") { if (cmd.isNotBlank()) { vm.sendRaw(cmd); cmd = "" } }
        }
    }
}
