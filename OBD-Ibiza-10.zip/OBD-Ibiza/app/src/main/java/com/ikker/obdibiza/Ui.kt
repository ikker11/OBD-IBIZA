package com.ikker.obdibiza

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.Image
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.Typeface
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.cos
import kotlin.math.sin

// ═══════════════════════════════════════════════════════════════════ Estilo
// Inspirado en el monitor de prestaciones de los Leon deportivos: gris grafito con textura,
// barras superior e inferior con líneas rojas en diagonal, relojes de bisel plateado fino,
// aguja roja corta y número grande y fino en un buje cromado.

object K {
    val bgTop = Color(0xFF2A2A2C)
    val bgBottom = Color(0xFF121213)
    val bar = Color(0xFF1C1C1E)
    val barTab = Color(0xFF2E2E31)
    val panel = Color(0xFF1B1B1D)
    val panel2 = Color(0xFF2A2A2D)
    val line = Color(0xFF3A3A3E)
    val label = Color(0xFFEDEDED)
    val label2 = Color(0xFFA0A0A6)
    val label3 = Color(0xFF5A5A60)
    val red = Color(0xFFE2001A)
    val redGlow = Color(0xFFFF2B3F)
    val amber = Color(0xFFFFB020)
    val green = Color(0xFF34C759)
    /** Rojo anaranjado de los displays del cuadro y la radio. */
    val lcd = Color(0xFFFF3A22)
    val silverHi = Color(0xFFF4F4F6)
    val silver = Color(0xFFB9B9BE)
    val silverLo = Color(0xFF55555A)
}

private fun family(name: String) = FontFamily(Typeface(android.graphics.Typeface.create(name, android.graphics.Typeface.NORMAL)))

/** Rótulos: Roboto Condensed. Números grandes: Roboto Condensed Light, finos como en el monitor original. */
val Cond = family("sans-serif-condensed")
val CondLight = family("sans-serif-condensed-light")

private val Num = TextStyle(fontFamily = Cond, fontFeatureSettings = "tnum")
private val NumLight = TextStyle(fontFamily = CondLight, fontFeatureSettings = "tnum")
private val Caps = TextStyle(fontFamily = Cond, letterSpacing = 0.4.sp)
private fun Chamfer(cut: Dp) = CutCornerShape(topStart = 0.dp, topEnd = cut, bottomEnd = 0.dp, bottomStart = cut)
private val PanelShape = Chamfer(8.dp)

@Composable
private fun Dp.sp(): TextUnit = with(LocalDensity.current) { this@sp.toSp() }

enum class Tab(val heading: String) {
    PANEL("Performance"),
    MENU("Menú"),
    GRAFICAS("Gráficas"),
    BARRAS("Barras"),
    VIAJE("Viaje"),
    CRONO("Cronómetro"),
    DATOS("Datos en vivo"),
    AVERIAS("Averías"),
    AJUSTES("Ajustes"),
}

/** Fondo grafito con degradado y una fina trama en diagonal. */
private fun Modifier.carbon() = this
    .background(Brush.verticalGradient(listOf(K.bgTop, K.bgBottom)))
    .drawBehind {
        val step = 4.dp.toPx()
        var x = -size.height
        while (x < size.width) {
            drawLine(Color.White.copy(alpha = 0.022f), Offset(x, size.height), Offset(x + size.height, 0f), 1f)
            x += step
        }
        drawRect(Brush.radialGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.45f)), center, size.maxDimension * 0.75f))
    }

// ═══════════════════════════════════════════════════════════════════ Raíz

@Composable
fun ObdApp(vm: ObdViewModel) {
    val st by vm.state.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableStateOf(Tab.PANEL) }
    var immersive by rememberSaveable { mutableStateOf(false) }
    // Editor de la página: copia de los relojes mientras se mueven (null = no se está editando)
    var draft by remember { mutableStateOf<List<GaugeItem>?>(null) }
    var pickFor by remember { mutableStateOf<Int?>(null) }
    var pagesSheet by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(primary = K.red, background = K.bgBottom, surface = K.panel)) {
        Box(Modifier.fillMaxSize().carbon()) {
            Column(Modifier.fillMaxSize()) {
                AnimatedVisibility(!immersive, enter = fadeIn(), exit = fadeOut()) {
                    val d = draft
                    if (d != null) {
                        FrameBar(
                            top = true, left = "CANCELAR", center = "Editando: ${vm.pageName(st, st.page)}", right = "ORIGINAL",
                            onLeft = { draft = null }, onCenter = {},
                            onRight = { draft = defaultLayout(Params.defaultPages[st.page % Params.defaultPages.size]) },
                        )
                    } else {
                        val connLabel = when (st.conn) {
                            Conn.DESCONECTADO -> "CONECTAR"
                            Conn.CONECTANDO -> "CONECTANDO…"
                            Conn.CONECTADO -> if (st.demo) "SALIR DEMO" else "DESCONECTAR"
                        }
                        FrameBar(
                            top = true,
                            left = connLabel, center = "MENÚ", right = if (st.mil == true) "AVERÍAS •" else "AVERÍAS",
                            rightColor = if (st.mil == true) K.amber else K.label,
                            onLeft = { if (st.conn == Conn.DESCONECTADO) vm.connect() else vm.userDisconnect() },
                            onCenter = { tab = if (tab == Tab.MENU) Tab.PANEL else Tab.MENU },
                            onRight = { tab = Tab.AVERIAS },
                        )
                    }
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (tab) {
                        Tab.PANEL -> PanelScreen(
                            st, vm, immersive, draft,
                            onDraft = { draft = it }, onPick = { pickFor = it },
                        ) { immersive = !immersive }
                        Tab.MENU -> MenuScreen(st, vm, onGo = { tab = it }, onImmersive = { tab = Tab.PANEL; immersive = true })
                        Tab.GRAFICAS -> ChartsScreen(st, vm)
                        Tab.BARRAS -> BarsScreen(st, vm)
                        Tab.VIAJE -> TripScreen(st, vm)
                        Tab.CRONO -> AccelScreen(st, vm)
                        Tab.DATOS -> DataScreen(st, vm)
                        Tab.AVERIAS -> DtcScreen(st, vm)
                        Tab.AJUSTES -> SettingsScreen(st, vm)
                    }
                }
                AnimatedVisibility(!immersive, enter = fadeIn(), exit = fadeOut()) {
                    val d = draft
                    when {
                        tab == Tab.PANEL && d != null -> FrameBar(
                            top = false, left = "＋ AÑADIR RELOJ", center = "GUARDAR", right = "PÁGINAS",
                            onLeft = { draft = d + GaugeItem("coolant", 0.5f, 0.5f, 0.5f) },
                            onCenter = { vm.setCurrentPage(d); draft = null },
                            onRight = { vm.setCurrentPage(d); draft = null; pagesSheet = true },
                        )
                        tab == Tab.PANEL -> FrameBar(
                            top = false,
                            left = "◁ ANTERIOR", center = "SETUP", right = "SIGUIENTE ▷",
                            onLeft = { vm.movePage(-1) },
                            onCenter = { draft = st.pages.getOrNull(st.page) ?: emptyList() },
                            onRight = { vm.movePage(1) },
                        )
                        else -> FrameBar(
                            top = false, left = "◁ MENÚ", center = tab.heading, right = "PERFORMANCE ▷",
                            onLeft = { tab = Tab.MENU }, onCenter = {}, onRight = { tab = Tab.PANEL },
                        )
                    }
                }
            }
        }
        val pf = pickFor
        val dr = draft
        if (pf != null && dr != null && pf in dr.indices) {
            ParamPicker("Dato del reloj", dr[pf].id, st, emptySet(), onPick = { id ->
                draft = dr.mapIndexed { j, g -> if (j == pf) g.copy(id = id) else g }
                pickFor = null
            }, onDismiss = { pickFor = null })
        }
        if (pagesSheet) PagesSheet(st, vm) { pagesSheet = false }
    }
}

// ═══════════════════════════════════════════════════════════════════ Barras con líneas rojas

/**
 * Barra con tres botones. Los laterales son paneles algo más claros con una línea roja
 * que corre por su borde y sube (o baja) en diagonal hacia el centro.
 */
@Composable
private fun FrameBar(
    top: Boolean,
    left: String, center: String, right: String,
    onLeft: () -> Unit, onCenter: () -> Unit, onRight: () -> Unit,
    rightColor: Color = K.label,
) {
    Box(
        Modifier.fillMaxWidth().height(54.dp)
            .background(Brush.verticalGradient(if (top) listOf(Color(0xFF101011), K.bar) else listOf(K.bar, Color(0xFF101011))))
            .drawBehind {
                val w = size.width
                val h = size.height
                val sw = 2.6.dp.toPx()
                val tabW = w * 0.30f
                val slope = h * 0.55f
                // Paneles laterales
                val yEdge = if (top) h - 6.dp.toPx() else 6.dp.toPx()
                val yFar = if (top) 0f else h
                val lp = Path().apply { moveTo(0f, yFar); lineTo(tabW + slope, yFar); lineTo(tabW, yEdge); lineTo(0f, yEdge); close() }
                val rp = Path().apply { moveTo(w, yFar); lineTo(w - tabW - slope, yFar); lineTo(w - tabW, yEdge); lineTo(w, yEdge); close() }
                val tabBrush = Brush.verticalGradient(listOf(K.barTab, Color(0xFF1F1F21)))
                drawPath(lp, tabBrush)
                drawPath(rp, tabBrush)
                // Líneas rojas
                val yLine = yEdge + if (top) 2.dp.toPx() else (-2).dp.toPx()
                val yUp = if (top) 4.dp.toPx() else h - 4.dp.toPx()
                val l = Path().apply { moveTo(w * 0.015f, yLine); lineTo(tabW, yLine); lineTo(tabW + slope * 0.9f, yUp) }
                val r = Path().apply { moveTo(w * 0.985f, yLine); lineTo(w - tabW, yLine); lineTo(w - tabW - slope * 0.9f, yUp) }
                drawPath(l, K.red, style = Stroke(sw, join = StrokeJoin.Miter))
                drawPath(r, K.red, style = Stroke(sw, join = StrokeJoin.Miter))
                // Línea fina de separación con el contenido
                val ySep = if (top) h - 0.5f else 0.5f
                drawLine(Color.Black, Offset(0f, ySep), Offset(w, ySep), 1.5f)
            },
    ) {
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            BarText(left, Modifier.weight(0.30f), TextAlign.Start, K.label, onLeft)
            BarText(center, Modifier.weight(0.40f), TextAlign.Center, K.label, onCenter)
            BarText(right, Modifier.weight(0.30f), TextAlign.End, rightColor, onRight)
        }
    }
}

@Composable
private fun BarText(text: String, modifier: Modifier, align: TextAlign, color: Color, onClick: () -> Unit) {
    Box(
        modifier.fillMaxHeight().clickable(enabled = text.isNotEmpty(), onClick = onClick).padding(horizontal = 22.dp),
        contentAlignment = when (align) { TextAlign.Start -> Alignment.CenterStart; TextAlign.End -> Alignment.CenterEnd; else -> Alignment.Center },
    ) {
        Text(text, color = color, style = Caps, fontSize = 21.sp, maxLines = 1)
    }
}

@Composable
fun RedButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.clip(Chamfer(8.dp)).background(if (enabled) K.red else K.panel2)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = if (enabled) Color.White else K.label3, style = Caps, fontSize = 16.sp) }
}

@Composable
fun BarButton(text: String, color: Color = K.label, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.clickable(enabled = enabled, onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp),
    ) { Text(text, color = if (enabled) color else K.label3, style = Caps, fontSize = 16.sp) }
}

// ═══════════════════════════════════════════════════════════════════ PANEL

@Composable
private fun PanelScreen(
    st: UiState, vm: ObdViewModel, immersive: Boolean,
    draft: List<GaugeItem>?, onDraft: (List<GaugeItem>) -> Unit, onPick: (Int) -> Unit,
    onToggleImmersive: () -> Unit,
) {
    val items = draft ?: st.pages.getOrNull(st.page) ?: emptyList()
    val editing = draft != null
    val current by rememberUpdatedState(items)
    val setDraft by rememberUpdatedState(onDraft)
    // El reloj más grande de la página es el "principal" y lleva el logo
    val mainIndex = items.indices.maxByOrNull { items[it].size } ?: -1

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 4.dp)) {
        PageTitle(vm.pageName(st, st.page), st.pages.size, st.page, Modifier.fillMaxWidth().height(44.dp))
        BoxWithConstraints(
            Modifier.fillMaxWidth().weight(1f)
                .clickable(remember { MutableInteractionSource() }, null, enabled = immersive && !editing) { onToggleImmersive() },
        ) {
            val w = maxWidth
            val h = maxHeight
            val head = if (editing) 34.dp else 22.dp
            val extra = head + 22.dp + 22.dp
            val wPx = with(LocalDensity.current) { w.toPx() }
            val hPx = with(LocalDensity.current) { h.toPx() }
            items.forEachIndexed { i, g ->
                val p = Params.byId[g.id] ?: return@forEachIndexed
                val d = (h - extra) * g.size
                val slotW = maxOf(d, 230.dp)
                Box(
                    Modifier
                        .offset(x = w * g.x - slotW / 2, y = h * g.y - d / 2 - head)
                        .width(slotW)
                        .pointerInput(i, editing) {
                            if (editing) detectDragGestures { change, amount ->
                                change.consume()
                                val list = current
                                if (i in list.indices) {
                                    val it0 = list[i]
                                    setDraft(list.mapIndexed { j, x ->
                                        if (j == i) x.copy(
                                            x = (it0.x + amount.x / wPx).coerceIn(0f, 1f),
                                            y = (it0.y + amount.y / hPx).coerceIn(0f, 1f),
                                        ) else x
                                    })
                                }
                            }
                        },
                    contentAlignment = Alignment.TopCenter,
                ) {
                    GaugeSlot(
                        p, st, d, logo = if (i == mainIndex) st.logo else null,
                        editing = editing,
                        onUp = { vm.cycleGauge(i, -1) }, onDown = { vm.cycleGauge(i, 1) },
                        onBigger = { setDraft(current.mapIndexed { j, x -> if (j == i) x.copy(size = (x.size + 0.05f).coerceAtMost(1f)) else x }) },
                        onSmaller = { setDraft(current.mapIndexed { j, x -> if (j == i) x.copy(size = (x.size - 0.05f).coerceAtLeast(0.25f)) else x }) },
                        onRemove = { setDraft(current.filterIndexed { j, _ -> j != i }) },
                        onChange = { onPick(i) },
                    )
                }
            }
            if (editing) {
                Text(
                    "Arrastra los relojes para moverlos. Usa − y + para el tamaño, ✕ para quitar y CAMBIAR para elegir el dato.",
                    color = K.label2, fontSize = 13.sp, modifier = Modifier.align(Alignment.BottomCenter),
                )
            }
        }
    }
}

/** Título con una costura roja a cada lado (como el volante) y un trazo por página. */
@Composable
private fun PageTitle(title: String, pages: Int, page: Int, modifier: Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val y = size.height - 6.dp.toPx()
            val dash = PathEffect.dashPathEffect(floatArrayOf(7.dp.toPx(), 5.dp.toPx()))
            drawLine(K.red.copy(alpha = 0.75f), Offset(size.width * 0.12f, y), Offset(size.width * 0.38f, y), 1.6.dp.toPx(), pathEffect = dash)
            drawLine(K.red.copy(alpha = 0.75f), Offset(size.width * 0.62f, y), Offset(size.width * 0.88f, y), 1.6.dp.toPx(), pathEffect = dash)
            val segW = 22.dp.toPx()
            val gap = 6.dp.toPx()
            val total = pages * segW + (pages - 1) * gap
            var x = (size.width - total) / 2
            for (i in 0 until pages) {
                drawLine(if (i == page) K.red else K.label3, Offset(x, y), Offset(x + segW, y), 3.dp.toPx())
                x += segW + gap
            }
        }
        Text(title, color = K.label, style = Caps, fontSize = 26.sp, maxLines = 1, modifier = Modifier.padding(bottom = 10.dp))
    }
}

@Composable
private fun GaugeSlot(
    p: Param, st: UiState, d: Dp, logo: ImageBitmap?, editing: Boolean,
    onUp: () -> Unit, onDown: () -> Unit,
    onBigger: () -> Unit, onSmaller: () -> Unit, onRemove: () -> Unit, onChange: () -> Unit,
) {
    val v = st.values[p.id]
    val (caption, capColor) = when {
        p.id == "oil" && v == null && st.conn == Conn.CONECTADO && st.oilSource.isEmpty() -> "Aceite · búscalo en Ajustes" to K.label2
        p.id == "oil" && p.isCold(v) -> "Aceite frío · no apures" to K.amber
        p.id == "oil" && p.isHot(v) -> "Aceite muy caliente" to K.redGlow
        p.isHot(v) -> "${p.short} · alto" to K.redGlow
        else -> p.short to K.label2
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        if (editing) {
            Row(Modifier.height(34.dp), verticalAlignment = Alignment.CenterVertically) {
                EditChip("−", onSmaller)
                EditChip("+", onBigger)
                EditChip("CAMBIAR", onChange)
                EditChip("✕", onRemove, K.redGlow)
            }
        } else {
            Chevron(up = true, onClick = onUp)
        }
        Box {
            ClusterGauge(p, st, logo, Modifier.size(d))
            if (editing) {
                Canvas(Modifier.size(d)) {
                    drawCircle(
                        K.red, size.minDimension / 2, style = Stroke(
                            2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(8.dp.toPx(), 6.dp.toPx())),
                        ),
                    )
                }
            }
        }
        Chevron(up = false, onClick = if (editing) ({}) else onDown)
        Text(caption, color = capColor, style = Caps, fontSize = 16.sp, maxLines = 1)
    }
}

@Composable
private fun EditChip(text: String, onClick: () -> Unit, color: Color = K.label) {
    Box(
        Modifier.padding(horizontal = 3.dp).clip(Chamfer(5.dp)).background(K.panel2).border(1.dp, K.line, Chamfer(5.dp))
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 4.dp),
    ) { Text(text, color = color, style = Caps, fontSize = 15.sp) }
}

@Composable
private fun Chevron(up: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(width = 64.dp, height = 22.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(width = 18.dp, height = 8.dp)) {
            val p = Path().apply {
                if (up) { moveTo(0f, size.height); lineTo(size.width / 2, 0f); lineTo(size.width, size.height) }
                else { moveTo(0f, 0f); lineTo(size.width / 2, size.height); lineTo(size.width, 0f) }
            }
            drawPath(p, K.label2, style = Stroke(1.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

/** Ondas pequeñas entre x0 y x1 a la altura y. */
private fun DrawScope.wave(x0: Float, x1: Float, y: Float, s: Float, color: Color, sw: Float) {
    val seg = s * 0.09f
    val path = Path().apply {
        moveTo(x0, y)
        var x = x0
        var up = true
        while (x < x1 - 0.5f) {
            val nx = minOf(x + seg, x1)
            quadraticBezierTo((x + nx) / 2, y + if (up) -s * 0.06f else s * 0.06f, nx, y)
            x = nx; up = !up
        }
    }
    drawPath(path, color, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

/** Termómetro: varilla, tres rayitas a la derecha y bulbo abajo. */
private fun DrawScope.thermo(x: Float, top: Float, bottom: Float, s: Float, color: Color, sw: Float) {
    drawLine(color, Offset(x, top), Offset(x, bottom), sw * 1.25f, cap = StrokeCap.Round)
    for (k in 0..2) {
        val y = top + s * (0.06f + k * 0.11f)
        drawLine(color, Offset(x + s * 0.07f, y), Offset(x + s * 0.19f, y), sw * 0.8f, cap = StrokeCap.Round)
    }
    drawCircle(color, s * 0.1f, Offset(x, bottom + s * 0.06f))
}

/** Testigo de temperatura del refrigerante, como en el cuadro: termómetro metido en ondas. */
private fun DrawScope.drawCoolantIcon(c: Offset, s: Float, color: Color) {
    val sw = s * 0.08f
    thermo(c.x, c.y - s * 0.5f, c.y + s * 0.12f, s, color, sw)
    // Onda de arriba partida por el bulbo y onda de abajo entera
    wave(c.x - s * 0.5f, c.x - s * 0.15f, c.y + s * 0.22f, s, color, sw)
    wave(c.x + s * 0.15f, c.x + s * 0.5f, c.y + s * 0.22f, s, color, sw)
    wave(c.x - s * 0.45f, c.x + s * 0.45f, c.y + s * 0.4f, s, color, sw)
}

/** Testigo de temperatura del aceite, como en el cuadro: aceitera en línea con termómetro dentro y gota. */
private fun DrawScope.drawOilTempIcon(c: Offset, s: Float, color: Color) {
    val sw = s * 0.08f
    // Cuerpo de la aceitera (contorno)
    val body = Path().apply {
        moveTo(c.x - s * 0.08f, c.y + s * 0.02f)
        lineTo(c.x - s * 0.32f, c.y + s * 0.02f)
        lineTo(c.x - s * 0.32f, c.y + s * 0.32f)
        lineTo(c.x + s * 0.20f, c.y + s * 0.32f)
        lineTo(c.x + s * 0.56f, c.y + s * 0.04f)
        lineTo(c.x + s * 0.40f, c.y + s * 0.06f)
        lineTo(c.x + s * 0.16f, c.y + s * 0.02f)
    }
    drawPath(body, color, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
    // Asa redondeada a la izquierda
    drawRoundRect(
        color, Offset(c.x - s * 0.58f, c.y - s * 0.02f), Size(s * 0.26f, s * 0.2f),
        androidx.compose.ui.geometry.CornerRadius(s * 0.08f), style = Stroke(sw),
    )
    // Gota bajo el pico
    val drop = Path().apply {
        moveTo(c.x + s * 0.56f, c.y + s * 0.14f)
        quadraticBezierTo(c.x + s * 0.63f, c.y + s * 0.26f, c.x + s * 0.56f, c.y + s * 0.29f)
        quadraticBezierTo(c.x + s * 0.49f, c.y + s * 0.26f, c.x + s * 0.56f, c.y + s * 0.14f)
        close()
    }
    drawPath(drop, color)
    // Termómetro que sale de dentro de la aceitera
    thermo(c.x + s * 0.04f, c.y - s * 0.55f, c.y + s * 0.1f, s, color, sw)
}

/** Aro plateado fino con brillo arriba y sombra abajo. */
private fun DrawScope.silverRing(c: Offset, r: Float, width: Float) {
    drawCircle(
        Brush.verticalGradient(listOf(K.silverHi, K.silver, K.silverLo, K.silver), c.y - r, c.y + r),
        r, c, style = Stroke(width),
    )
}

private fun Param.isHot(v: Double?) = v != null && warnHigh != null && v >= warnHigh
private fun Param.isCold(v: Double?) = v != null && warnLow != null && v <= warnLow

/** Escala "redonda" para las marcas y números de un reloj (0-50, 0-220, -0,2-2,0…). */
private data class Scale(val lo: Double, val hi: Double, val step: Double) {
    val majors: Int get() = Math.round((hi - lo) / step).toInt()
    fun frac(v: Double?) = if (v == null) 0f else ((v - lo) / (hi - lo)).toFloat().coerceIn(0f, 1f)
}

private fun niceScale(p: Param): Scale {
    val range = p.max - p.min
    val mag = Math.pow(10.0, kotlin.math.floor(kotlin.math.log10(range / 6)))
    val step = listOf(1.0, 2.0, 2.5, 5.0, 10.0, 20.0).map { it * mag }.first { range / it <= 11 }
    return Scale(kotlin.math.floor(p.min / step) * step, kotlin.math.ceil(p.max / step) * step, step)
}

private fun scaleLabel(p: Param, value: Double, step: Double): String = when {
    p.id == "rpm" -> Math.round(value / 100).toString()
    step >= 1 -> Math.round(value).toString()
    else -> String.format(java.util.Locale("es", "ES"), "%.1f", value)
}

/**
 * Reloj al estilo del cuadro del Ibiza Bocanegra: esfera negra, marcas blancas finas,
 * números en cursiva, zona roja con banda y números rojos, aguja blanca larga con buje negro
 * y una pantallita roja abajo con el valor exacto, como el display del cuadro.
 */
@Composable
private fun ClusterGauge(p: Param, st: UiState, logo: ImageBitmap?, modifier: Modifier) {
    val v = st.values[p.id]
    val sc = remember(p.id) { niceScale(p) }
    val anim by animateFloatAsState(sc.frac(v), spring(stiffness = Spring.StiffnessLow, dampingRatio = 0.85f), label = "n")
    val redFrom = when {
        p.id == "rpm" -> sc.frac(st.shiftRpm.toDouble())
        p.warnHigh != null -> sc.frac(p.warnHigh)
        else -> null
    }
    val hot = p.isHot(v) || (p.id == "rpm" && v != null && v >= st.shiftRpm)
    val cold = p.isCold(v)
    val lcdColor by animateColorAsState(when { cold -> K.amber; hot -> Color(0xFFFF5040); else -> K.lcd }, label = "lcd")
    val tm = rememberTextMeasurer()
    val caption = if (p.id == "rpm") "rpm x100" else p.unit

    Canvas(modifier) {
        val c = this.center
        val r = size.minDimension / 2
        // Sombra, esfera y aro
        drawCircle(Brush.radialGradient(listOf(Color.Black.copy(alpha = 0.6f), Color.Transparent), c, r * 1.08f), r * 1.08f, c)
        drawCircle(Brush.radialGradient(listOf(Color(0xFF1B1B1E), Color(0xFF040405)), c, r), r * 0.97f, c)
        silverRing(c, r * 0.975f, r * 0.03f)
        drawCircle(Color.Black, r * 0.945f, c, style = Stroke(r * 0.02f))
        // Banda roja de la zona roja
        if (redFrom != null && redFrom < 1f) {
            val rb = r * 0.875f
            drawArc(
                K.red.copy(alpha = 0.85f), 135f + 270f * redFrom, 270f * (1 - redFrom), false,
                Offset(c.x - rb, c.y - rb), Size(rb * 2, rb * 2), style = Stroke(r * 0.05f),
            )
        }
        // Marcas y números
        val majors = sc.majors
        val minorPer = if (majors <= 6) 10 else 5
        val total = majors * minorPer
        val labelEvery = if (majors > 8) 2 else 1
        for (i in 0..total) {
            val f = i / total.toFloat()
            val a = Math.toRadians(135.0 + 270.0 * f)
            val major = i % minorPer == 0
            val half = !major && minorPer == 10 && i % 5 == 0
            val red = redFrom != null && f >= redFrom - 0.0001f
            val r1 = r * 0.90f
            val r2 = when { major -> r * 0.78f; half -> r * 0.82f; else -> r * 0.855f }
            drawLine(
                if (red && !major) Color.White.copy(alpha = 0.85f) else if (red) Color.White else Color.White.copy(alpha = if (major) 1f else 0.7f),
                Offset(c.x + (r1 * cos(a)).toFloat(), c.y + (r1 * sin(a)).toFloat()),
                Offset(c.x + (r2 * cos(a)).toFloat(), c.y + (r2 * sin(a)).toFloat()),
                strokeWidth = when { major -> r * 0.022f; half -> r * 0.014f; else -> r * 0.009f },
            )
            val mi = i / minorPer
            if (major && mi % labelEvery == 0) {
                val value = sc.lo + sc.step * mi
                val res = tm.measure(
                    AnnotatedString(scaleLabel(p, value, sc.step)),
                    TextStyle(
                        color = if (red) K.redGlow else Color.White, fontSize = (r * 0.13f).toSp(),
                        fontFamily = Cond, fontStyle = FontStyle.Italic,
                    ),
                )
                val rt = r * 0.64f
                drawText(
                    res,
                    topLeft = Offset(
                        c.x + (rt * cos(a)).toFloat() - res.size.width / 2f,
                        c.y + (rt * sin(a)).toFloat() - res.size.height / 2f,
                    ),
                )
            }
        }
        // Rótulo pequeño ("rpm x100", "°C"…)
        val cap = tm.measure(AnnotatedString(caption), TextStyle(color = K.label2, fontSize = (r * 0.075f).toSp(), fontFamily = Cond))
        val iconS = r * 0.16f
        val hasIcon = p.id == "oil" || p.id == "coolant"
        val capX = c.x - cap.size.width / 2f + if (hasIcon) iconS * 0.6f else 0f
        drawText(cap, topLeft = Offset(capX, c.y + r * 0.30f))
        if (hasIcon) {
            val ic = Offset(capX - iconS * 0.75f, c.y + r * 0.30f + cap.size.height / 2f)
            val icColor = when { cold -> K.amber; hot -> K.redGlow; else -> K.label2 }
            if (p.id == "oil") drawOilTempIcon(ic, iconS, icColor) else drawCoolantIcon(ic, iconS, icColor)
        }
        // Logo propio (si se ha elegido) encima del eje de la aguja
        if (logo != null) {
            val lw = r * 0.46f
            val lh = lw * logo.height / logo.width.coerceAtLeast(1)
            val maxH = r * 0.26f
            val k = if (lh > maxH) maxH / lh else 1f
            val dw = (lw * k).toInt().coerceAtLeast(1)
            val dh = (lh * k).toInt().coerceAtLeast(1)
            drawImage(
                logo,
                dstOffset = IntOffset((c.x - dw / 2f).toInt(), (c.y - r * 0.30f - dh / 2f).toInt()),
                dstSize = IntSize(dw, dh),
            )
        }
        // Pantallita roja con el valor
        val lw = r * 0.56f
        val lh = r * 0.21f
        val lt = Offset(c.x - lw / 2, c.y + r * 0.53f)
        drawRect(Color(0xFF150404), lt, Size(lw, lh))
        drawRect(Color(0xFF3A0C0C), lt, Size(lw, lh), style = Stroke(1.5f))
        // Trama de puntos tipo matriz
        val dotStep = r * 0.035f
        var yy = lt.y + dotStep / 2
        while (yy < lt.y + lh) {
            drawLine(Color.Black.copy(alpha = 0.35f), Offset(lt.x, yy), Offset(lt.x + lw, yy), 1f)
            yy += dotStep
        }
        val valTxt = if (v == null) "- - -" else p.format(v)
        val vres = tm.measure(
            AnnotatedString(valTxt),
            TextStyle(
                color = lcdColor, fontSize = (lh * 0.72f).toSp(), fontFamily = Cond, fontFeatureSettings = "tnum",
                shadow = Shadow(lcdColor.copy(alpha = 0.8f), blurRadius = lh * 0.3f),
            ),
        )
        drawText(vres, topLeft = Offset(c.x - vres.size.width / 2f, lt.y + (lh - vres.size.height) / 2f))
        // Aguja blanca larga con sombra
        val a = Math.toRadians(135.0 + 270.0 * (if (v == null) 0f else anim))
        val ca = cos(a).toFloat()
        val sa = sin(a).toFloat()
        fun needle(off: Offset): Path {
            val tip = Offset(c.x + off.x + r * 0.84f * ca, c.y + off.y + r * 0.84f * sa)
            val tail = Offset(c.x + off.x - r * 0.16f * ca, c.y + off.y - r * 0.16f * sa)
            val w = r * 0.032f
            return Path().apply {
                moveTo(tail.x - w * sa, tail.y + w * ca)
                lineTo(tip.x - w * 0.25f * sa, tip.y + w * 0.25f * ca)
                lineTo(tip.x + w * 0.25f * sa, tip.y - w * 0.25f * ca)
                lineTo(tail.x + w * sa, tail.y - w * ca)
                close()
            }
        }
        drawPath(needle(Offset(r * 0.02f, r * 0.03f)), Color.Black.copy(alpha = 0.55f))
        drawPath(needle(Offset.Zero), Brush.linearGradient(listOf(Color(0xFFDADADA), Color.White), c, c + Offset(r * ca, r * sa)))
        // Buje
        drawCircle(Brush.radialGradient(listOf(Color(0xFF3A3A3E), Color(0xFF0A0A0B)), c, r * 0.1f), r * 0.1f, c)
        drawCircle(Color(0xFF55555A), r * 0.1f, c, style = Stroke(r * 0.012f))
    }
}

@Composable
private fun Sparkline(hist: List<Float>?, color: Color, modifier: Modifier) {
    val h = hist?.takeLast(60)
    if (h == null || h.size < 2) return
    Canvas(modifier) {
        var lo = h.min()
        var hi = h.max()
        if (hi - lo < 1e-3f) { lo -= 1f; hi += 1f }
        val stepX = size.width / 59f
        val x0 = size.width - stepX * (h.size - 1)
        fun y(f: Float) = size.height - (f - lo) / (hi - lo) * size.height * 0.8f - size.height * 0.08f
        val line = Path().apply {
            h.forEachIndexed { i, f -> if (i == 0) moveTo(x0, y(f)) else lineTo(x0 + i * stepX, y(f)) }
        }
        drawPath(line, color.copy(alpha = 0.85f), style = Stroke(1.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

private fun fracOf(p: Param, v: Double?): Float =
    if (v == null) 0f else ((v - p.min) / (p.max - p.min)).toFloat().coerceIn(0f, 1f)

// ═══════════════════════════════════════════════════════════════════ MENÚ

@Composable
private fun MenuScreen(st: UiState, vm: ObdViewModel, onGo: (Tab) -> Unit, onImmersive: () -> Unit) {
    val items = mutableListOf<Triple<String, String, () -> Unit>>(
        Triple("Performance", "Los tres relojes", { onGo(Tab.PANEL) }),
        Triple("Gráficas", "Varios datos a lo largo del tiempo", { onGo(Tab.GRAFICAS) }),
        Triple("Barras", "Seis datos de un vistazo", { onGo(Tab.BARRAS) }),
        Triple("Viaje", "Distancia, medias y máximos", { onGo(Tab.VIAJE) }),
        Triple("Cronómetro", "0-100, 0-60 y 80-120", { onGo(Tab.CRONO) }),
        Triple("Datos en vivo", "Todos los datos del motor", { onGo(Tab.DATOS) }),
        Triple("Averías", "Leer y borrar códigos", { onGo(Tab.AVERIAS) }),
        Triple("Pantalla completa", "Solo los relojes; toca para volver", { onImmersive() }),
    )
    if (st.conn == Conn.DESCONECTADO) items += Triple("Demo", "Ver la app sin coche", { vm.startDemo(); onGo(Tab.PANEL) })
    items += Triple("Ajustes", "Aceite, revoluciones y consola", { onGo(Tab.AJUSTES) })

    BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 14.dp)) {
        val cols = if (maxWidth > maxHeight) 5 else 3
        val rows = (items.size + cols - 1) / cols
        val gap = 12.dp
        val w = (maxWidth - gap * (cols - 1)) / cols
        val h = ((maxHeight - gap * (rows - 1)) / rows).coerceAtMost(170.dp)
        Column(verticalArrangement = Arrangement.spacedBy(gap)) {
            items.chunked(cols).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    row.forEach { (title, sub, action) ->
                        Box(
                            Modifier.size(w, h).clip(PanelShape)
                                .background(Brush.verticalGradient(listOf(Color(0xFF2C2C2F), Color(0xFF151517))))
                                .border(1.dp, Brush.verticalGradient(listOf(Color(0xFF55555A), Color(0xFF222224))), PanelShape)
                                .clickable { action() }.padding(16.dp),
                        ) {
                            Canvas(Modifier.align(Alignment.TopStart).fillMaxWidth().height(3.dp)) {
                                drawLine(
                                    K.red.copy(alpha = 0.8f), Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 1.6.dp.toPx(),
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 4.dp.toPx())),
                                )
                            }
                            Column(Modifier.align(Alignment.BottomStart)) {
                                Text(title, color = K.label, style = Caps, fontSize = 22.sp, maxLines = 1)
                                Text(sub, color = K.label2, fontSize = 12.sp, maxLines = 2)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Pide a la app que lea estos datos mientras la pantalla está abierta. */
@Composable
private fun Focus(vm: ObdViewModel, ids: List<String>) {
    DisposableEffect(ids) {
        vm.setFocus(ids)
        onDispose { vm.setFocus(emptyList()) }
    }
}

/** Pantallita roja tipo display del cuadro. */
@Composable
private fun Lcd(text: String, modifier: Modifier = Modifier, size: TextUnit = 40.sp, color: Color = K.lcd) {
    Box(
        modifier.clip(Chamfer(6.dp)).background(Color(0xFF140404)).border(1.dp, Color(0xFF3A0C0C), Chamfer(6.dp))
            .drawBehind {
                var y = 2f
                while (y < this.size.height) { drawLine(Color.Black.copy(alpha = 0.3f), Offset(0f, y), Offset(this.size.width, y), 1f); y += 4f }
            }
            .padding(horizontal = 14.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text, maxLines = 1,
            style = TextStyle(
                color = color, fontSize = size, fontFamily = Cond, fontFeatureSettings = "tnum",
                shadow = Shadow(color.copy(alpha = 0.8f), blurRadius = 12f),
            ),
        )
    }
}

// ═══════════════════════════════════════════════════════════════════ GRÁFICAS

private val SeriesColors = listOf(Color(0xFFFF2B3F), Color(0xFFF2F2F2), Color(0xFFFFB020))

@Composable
private fun ChartsScreen(st: UiState, vm: ObdViewModel) {
    var series by rememberSaveable { mutableStateOf("rpm,${Params.BOOST},coolant") }
    var window by rememberSaveable { mutableStateOf(300) }
    var picking by remember { mutableStateOf<Int?>(null) }
    val ids = series.split(",").filter { it in Params.byId }
    Focus(vm, ids)

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ids.forEachIndexed { i, id ->
                val p = Params.byId.getValue(id)
                Column(
                    Modifier.weight(1f).clip(PanelShape).background(K.panel).border(1.dp, K.line, PanelShape)
                        .clickable { picking = i }.padding(horizontal = 12.dp, vertical = 8.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.width(18.dp).height(3.dp).background(SeriesColors[i]))
                        Spacer(Modifier.width(8.dp))
                        Text(p.short, color = K.label2, style = Caps, fontSize = 14.sp, maxLines = 1)
                    }
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(p.format(st.values[id]), color = K.label, style = NumLight, fontSize = 30.sp)
                        Text(" ${p.unit}", color = K.label2, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp))
                    }
                }
                if (i < ids.size - 1) Spacer(Modifier.width(10.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column {
                for ((n, lbl) in listOf(150 to "CORTO", 300 to "MEDIO", 600 to "LARGO")) {
                    Text(
                        lbl, color = if (window == n) K.label else K.label3, style = Caps, fontSize = 14.sp,
                        modifier = Modifier.clickable { window = n }.padding(horizontal = 8.dp, vertical = 3.dp),
                    )
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Canvas(Modifier.fillMaxWidth().weight(1f).clip(PanelShape).background(Color(0xFF0E0E10)).border(1.dp, K.line, PanelShape)) {
            val padL = 8.dp.toPx()
            val w = size.width - padL * 2
            val h = size.height - 16.dp.toPx()
            val top = 8.dp.toPx()
            for (k in 0..4) {
                val y = top + h * k / 4
                drawLine(K.line.copy(alpha = 0.6f), Offset(padL, y), Offset(padL + w, y), 1f)
            }
            for (k in 0..6) {
                val x = padL + w * k / 6
                drawLine(K.line.copy(alpha = 0.35f), Offset(x, top), Offset(x, top + h), 1f)
            }
            ids.forEachIndexed { i, id ->
                val p = Params.byId.getValue(id)
                val sc = niceScale(p)
                val data = st.history[id]?.takeLast(window) ?: return@forEachIndexed
                if (data.size < 2) return@forEachIndexed
                val stepX = w / (window - 1)
                val x0 = padL + w - stepX * (data.size - 1)
                val path = Path()
                data.forEachIndexed { j, f ->
                    val y = top + h * (1 - sc.frac(f.toDouble()))
                    if (j == 0) path.moveTo(x0, y) else path.lineTo(x0 + j * stepX, y)
                }
                drawPath(path, SeriesColors[i].copy(alpha = 0.25f), style = Stroke(6.dp.toPx(), join = StrokeJoin.Round))
                drawPath(path, SeriesColors[i], style = Stroke(2.dp.toPx(), join = StrokeJoin.Round, cap = StrokeCap.Round))
            }
        }
        Text(
            "Cada línea usa su propia escala. Toca un dato de arriba para cambiarlo.",
            color = K.label3, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
        )
    }

    picking?.let { slot ->
        ParamPicker("Dato de la gráfica", ids.getOrNull(slot), st, emptySet(), onPick = { id ->
            series = ids.mapIndexed { j, old -> if (j == slot) id else old }.joinToString(",")
            picking = null
        }, onDismiss = { picking = null })
    }
}

// ═══════════════════════════════════════════════════════════════════ BARRAS

@Composable
private fun BarsScreen(st: UiState, vm: ObdViewModel) {
    val ids = st.dashboard.take(6)
    var picking by remember { mutableStateOf<Int?>(null) }
    Focus(vm, ids)

    Row(
        Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        ids.forEachIndexed { i, id ->
            val p = Params.byId[id] ?: return@forEachIndexed
            val v = st.values[id]
            val sc = remember(id) { niceScale(p) }
            val f by animateFloatAsState(sc.frac(v), spring(stiffness = Spring.StiffnessLow), label = "bar$i")
            val redFrom = p.warnHigh?.let { sc.frac(it) } ?: 2f
            val peak = st.peaks[id]?.let { sc.frac(it) }
            val cold = p.isCold(v)
            Column(
                Modifier.weight(1f).fillMaxHeight().clickable { picking = i }.padding(horizontal = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Lcd(p.format(v), size = 26.sp, color = if (cold) K.amber else if (p.isHot(v)) Color(0xFFFF5040) else K.lcd)
                Text(p.unit, color = K.label2, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                Spacer(Modifier.height(8.dp))
                Canvas(Modifier.width(46.dp).weight(1f)) {
                    val n = 24
                    val gap = 3.dp.toPx()
                    val segH = (size.height - gap * (n - 1)) / n
                    for (k in 0 until n) {
                        val pos = (k + 0.5f) / n
                        val y = size.height - (k + 1) * segH - k * gap
                        val on = v != null && pos <= f
                        val col = when {
                            !on -> if (pos >= redFrom) Color(0xFF3A0E0E) else Color(0xFF242427)
                            cold -> K.amber
                            pos >= redFrom -> K.redGlow
                            else -> Color.White.copy(alpha = 0.55f + 0.45f * pos)
                        }
                        val skew = segH * 0.35f
                        val path = Path().apply {
                            moveTo(0f, y + segH); lineTo(size.width - skew, y + segH); lineTo(size.width, y); lineTo(skew, y); close()
                        }
                        drawPath(path, col)
                    }
                    peak?.let {
                        val y = size.height * (1 - it)
                        drawLine(K.red, Offset(-4.dp.toPx(), y), Offset(size.width + 4.dp.toPx(), y), 2.dp.toPx())
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(p.short, color = K.label, style = Caps, fontSize = 15.sp, maxLines = 1, textAlign = TextAlign.Center)
            }
        }
    }

    picking?.let { slot ->
        ParamPicker("Dato de la barra ${slot + 1}", ids.getOrNull(slot), st, emptySet(), onPick = { id ->
            vm.setDashboard(st.dashboard.take(6).mapIndexed { j, old -> if (j == slot) id else old })
            picking = null
        }, onDismiss = { picking = null })
    }
}

// ═══════════════════════════════════════════════════════════════════ VIAJE

private fun hms(seconds: Double): String {
    val s = seconds.toLong()
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s / 60) % 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
}

/** Texto rojo con brillo, como los dígitos del display del cuadro. */
@Composable
private fun LcdText(text: String, size: TextUnit, color: Color = K.lcd, light: Boolean = false) {
    Text(
        text, maxLines = 1,
        style = TextStyle(
            color = color, fontSize = size, fontFamily = if (light) CondLight else Cond, fontFeatureSettings = "tnum",
            shadow = Shadow(color.copy(alpha = 0.75f), blurRadius = 14f),
        ),
    )
}

/**
 * Ordenador de viaje con aspecto del cuadro del Bocanegra: el reloj de velocidad a la izquierda
 * y a la derecha un display rojo grande tipo MFA con los datos "desde salida".
 */
@Composable
private fun TripScreen(st: UiState, vm: ObdViewModel) {
    val t = st.trip
    val es = java.util.Locale("es", "ES")
    Focus(vm, listOf("speed", "fuelrate"))
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(1000); now = System.currentTimeMillis() } }
    val clock = java.text.SimpleDateFormat("HH:mm", es).format(java.util.Date(now))

    BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 10.dp)) {
        val gauge = min(maxHeight - 30.dp, maxWidth * 0.40f)
        val leftW = maxWidth * 0.42f
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(leftW)) {
                ClusterGauge(Params.byId.getValue("speed"), st, st.logo, Modifier.size(gauge))
                Text("Velocidad", color = K.label2, style = Caps, fontSize = 16.sp, modifier = Modifier.padding(top = 4.dp))
            }
            // Display tipo MFA
            Column(
                Modifier.weight(1f).fillMaxHeight()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF120303), Color(0xFF070101))))
                    .border(1.5.dp, Brush.verticalGradient(listOf(Color(0xFF4A1010), Color(0xFF1A0505))), RoundedCornerShape(18.dp))
                    .drawBehind {
                        var y = 0f
                        val step = 3.dp.toPx()
                        while (y < size.height) { drawLine(Color.Black.copy(alpha = 0.35f), Offset(0f, y), Offset(size.width, y), 1f); y += step }
                    }
                    .padding(horizontal = 22.dp, vertical = 14.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LcdText("DESDE SALIDA", 18.sp)
                    Spacer(Modifier.weight(1f))
                    LcdText(clock, 22.sp)
                }
                Canvas(Modifier.fillMaxWidth().padding(vertical = 8.dp).height(2.dp)) {
                    drawLine(
                        K.lcd.copy(alpha = 0.6f), Offset(0f, 1f), Offset(size.width, 1f), 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 4.dp.toPx())),
                    )
                }
                // Dato grande: distancia
                Row(verticalAlignment = Alignment.Bottom) {
                    LcdText(String.format(es, "%.1f", t.distanceKm), 64.sp, light = true)
                    LcdText(" km", 22.sp)
                    Spacer(Modifier.weight(1f))
                    Column(horizontalAlignment = Alignment.End) {
                        Text("en marcha", color = K.lcd.copy(alpha = 0.6f), fontSize = 13.sp)
                        LcdText(hms(t.movingSeconds), 30.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                val rows = listOf(
                    Triple("Velocidad media", t.avgSpeed?.let { String.format(es, "%.0f", it) } ?: "- - -", "km/h"),
                    Triple("Velocidad máxima", String.format(es, "%.0f", t.maxSpeed), "km/h"),
                    Triple("Consumo medio", t.avgConsumption?.let { String.format(es, "%.1f", it) } ?: "- - -", "l/100 km"),
                    Triple("Combustible gastado", t.fuelLitres?.let { String.format(es, "%.2f", it) } ?: "- - -", "l"),
                    Triple("Tiempo total", hms((now - t.startMs) / 1000.0), ""),
                )
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.SpaceEvenly) {
                    rows.forEach { (label, value, unit) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(label, color = K.lcd.copy(alpha = 0.65f), fontSize = 16.sp, modifier = Modifier.weight(1f))
                            LcdText(value, 30.sp)
                            Text(if (unit.isEmpty()) "" else " $unit", color = K.lcd.copy(alpha = 0.65f), fontSize = 14.sp, modifier = Modifier.width(76.dp))
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (t.fuelLitres == null) "El consumo solo sale si el coche da el caudal de combustible." else "",
                        color = K.lcd.copy(alpha = 0.45f), fontSize = 12.sp, modifier = Modifier.weight(1f),
                    )
                    Box(
                        Modifier.clip(Chamfer(6.dp)).border(1.dp, K.lcd.copy(alpha = 0.6f), Chamfer(6.dp))
                            .clickable(onClick = vm::resetTrip).padding(horizontal = 14.dp, vertical = 6.dp),
                    ) { LcdText("PONER A CERO", 15.sp) }
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════ CRONÓMETRO

@Composable
private fun AccelScreen(st: UiState, vm: ObdViewModel) {
    val a = st.accel
    val es = java.util.Locale("es", "ES")
    Focus(vm, listOf("speed", "rpm"))
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(a.state) {
        while (a.state == AccelState.MIDIENDO) { kotlinx.coroutines.delay(30); now = System.currentTimeMillis() }
    }
    val speed = st.values["speed"]
    val shown = when (a.state) {
        AccelState.MIDIENDO -> (now - a.startMs) / 1000.0
        AccelState.HECHO -> a.resultS ?: 0.0
        else -> 0.0
    }
    val (msg, msgColor) = when (a.state) {
        AccelState.PARADO -> "Pulsa PREPARAR" to K.label2
        AccelState.PREPARADO ->
            if (a.mode.from == 0.0 && (speed ?: 0.0) > 0.5) "Detén el coche para empezar" to K.amber
            else if (a.mode.from == 0.0) "Listo: arranca cuando quieras" to K.green
            else "Listo: acelera al pasar de ${a.mode.from.toInt()} km/h" to K.green
        AccelState.MIDIENDO -> "Midiendo…" to K.redGlow
        AccelState.HECHO -> "Tiempo final" to K.label
    }
    Column(
        Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row {
            AccelMode.values().forEach { m ->
                val sel = m == a.mode
                Column(Modifier.clickable { vm.setAccelMode(m) }.padding(horizontal = 16.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(m.title, color = if (sel) K.label else K.label2, style = Caps, fontSize = 18.sp)
                    Spacer(Modifier.height(4.dp))
                    Box(Modifier.width(40.dp).height(2.5.dp).background(if (sel) K.red else Color.Transparent))
                }
            }
        }
        Spacer(Modifier.weight(0.3f))
        Lcd(String.format(es, "%05.2f", shown), size = 110.sp, color = if (a.state == AccelState.HECHO) Color.White else K.lcd)
        Text("segundos", color = K.label2, style = Caps, fontSize = 16.sp)
        Spacer(Modifier.height(10.dp))
        Text(msg, color = msgColor, style = Caps, fontSize = 22.sp)
        Spacer(Modifier.weight(0.3f))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Velocidad", color = K.label2, fontSize = 15.sp)
            Spacer(Modifier.width(8.dp))
            Lcd(speed?.let { String.format(es, "%.0f", it) } ?: "- - -", size = 28.sp)
            Text(" km/h", color = K.label2, fontSize = 14.sp)
            Spacer(Modifier.width(30.dp))
            Text("Mejor", color = K.label2, fontSize = 15.sp)
            Spacer(Modifier.width(8.dp))
            Lcd(a.best[a.mode]?.let { String.format(es, "%.2f", it) } ?: "- - -", size = 28.sp)
            Text(" s", color = K.label2, fontSize = 14.sp)
            Spacer(Modifier.width(30.dp))
            if (a.state == AccelState.PREPARADO || a.state == AccelState.MIDIENDO) RedButton("CANCELAR", onClick = vm::cancelAccel)
            else RedButton("PREPARAR", enabled = st.conn == Conn.CONECTADO, onClick = vm::armAccel)
        }
        Text(
            "Úsalo solo en un circuito o lugar cerrado al tráfico. La precisión depende de lo rápido que lea el cable.",
            color = K.label3, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp),
        )
    }
}

// ═══════════════════════════════════════════════════════════════════ PÁGINAS

@Composable
private fun PagesSheet(st: UiState, vm: ObdViewModel, onDone: () -> Unit) {
    Dialog(onDismissRequest = onDone, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxWidth(0.8f).fillMaxHeight(0.9f).clip(PanelShape).carbon().border(1.dp, K.line, PanelShape)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Páginas de relojes", color = K.label, style = Caps, fontSize = 24.sp, modifier = Modifier.weight(1f).padding(start = 10.dp))
                RedButton("LISTO", onClick = onDone)
            }
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                group(null) {
                    st.pages.forEachIndexed { i, pg ->
                        if (i > 0) Divider()
                        var name by remember(i, st.pageNames) { mutableStateOf(vm.pageName(st, i)) }
                        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp).height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                BasicTextField(
                                    value = name,
                                    onValueChange = { v -> name = v.take(24); vm.renamePage(i, name) },
                                    singleLine = true,
                                    textStyle = TextStyle(color = K.label, fontSize = 18.sp, fontFamily = Cond),
                                    cursorBrush = SolidColor(K.red),
                                    modifier = Modifier.fillMaxWidth(0.9f).clip(Chamfer(6.dp)).background(K.panel2).padding(horizontal = 10.dp, vertical = 6.dp),
                                )
                                Text(
                                    pg.joinToString(" · ") { Params.byId[it.id]?.short ?: it.id } + if (i == st.page) "   · en pantalla" else "",
                                    color = K.label2, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(top = 3.dp),
                                )
                            }
                            BarButton("VER") { vm.movePage(i - st.page); onDone() }
                            if (st.pages.size > 1) BarButton("QUITAR", color = K.redGlow) { vm.removePage(i) }
                        }
                    }
                }
                item {
                    Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        RedButton("AÑADIR PÁGINA", onClick = vm::addPage)
                        BarButton("VOLVER A LAS PÁGINAS ORIGINALES", color = K.label2, onClick = vm::resetPages)
                    }
                }
                footer("Toca el nombre de una página para cambiarlo. Para mover o cambiar sus relojes, ábrela y pulsa SETUP.")
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }
}

@Composable
private fun ParamPicker(
    title: String, selected: String?, st: UiState, exclude: Set<String>,
    onPick: (String) -> Unit, onDismiss: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxWidth(0.7f).fillMaxHeight(0.9f).clip(PanelShape).carbon().border(1.dp, K.line, PanelShape)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = K.label, style = Caps, fontSize = 22.sp, modifier = Modifier.weight(1f).padding(start = 10.dp))
                BarButton("CERRAR", onClick = onDismiss)
            }
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                Category.values().forEach { cat ->
                    val list = Params.all.filter { it.category == cat && it.id !in exclude }
                    if (list.isNotEmpty()) {
                        group(cat.title.uppercase()) {
                            list.forEachIndexed { i, p ->
                                if (i > 0) Divider()
                                val off = isUnsupported(p, st)
                                Row(
                                    Modifier.fillMaxWidth().clickable { onPick(p.id) }.padding(horizontal = 16.dp).height(50.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(p.name, color = if (off) K.label2 else K.label, fontSize = 16.sp)
                                        if (off) Text("Tu coche no lo da por OBD", color = K.label2, fontSize = 12.sp)
                                    }
                                    if (p.id == selected) Icon(Icons.Rounded.Check, null, tint = K.red)
                                }
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(20.dp)) }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════ Piezas de lista

private fun LazyListScope.group(title: String?, content: @Composable ColumnScope.() -> Unit) {
    item {
        Column(Modifier.padding(top = 16.dp)) {
            if (title != null) {
                Row(Modifier.padding(start = 4.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(14.dp).height(3.dp).background(K.red))
                    Spacer(Modifier.width(8.dp))
                    Text(title, color = K.label2, style = Caps, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
            Column(
                Modifier.fillMaxWidth().clip(PanelShape).background(K.panel.copy(alpha = 0.92f)).border(1.dp, K.line, PanelShape),
                content = content,
            )
        }
    }
}

private fun LazyListScope.footer(text: String) {
    item { Text(text, color = K.label2, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, top = 6.dp, end = 16.dp)) }
}

@Composable
private fun Divider() {
    Box(Modifier.fillMaxWidth().padding(start = 16.dp).height(1.dp).background(K.line))
}

@Composable
private fun NavRow(title: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 16.dp, end = 8.dp).height(50.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, color = K.label, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text(value, color = K.label2, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Icon(Icons.Rounded.KeyboardArrowRight, null, tint = K.red)
    }
}

@Composable
private fun InfoRow(title: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(48.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = K.label, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text(value, color = K.label2, style = Num, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun IconBtn(icon: ImageVector, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = if (enabled) K.label2 else K.label3) }
}

/** Interruptor propio: cápsula oscura con piloto rojo. */
@Composable
private fun Toggle(on: Boolean, onChange: (Boolean) -> Unit) {
    val x by animateFloatAsState(if (on) 1f else 0f, label = "tg")
    Box(
        Modifier.size(width = 52.dp, height = 28.dp).clip(CircleShape).background(K.panel2)
            .border(1.dp, if (on) K.red else K.line, CircleShape).clickable { onChange(!on) }.padding(3.dp),
    ) {
        Box(Modifier.offset(x = 24.dp * x).size(22.dp).clip(CircleShape).background(if (on) K.red else K.label3))
    }
}

private fun isUnsupported(p: Param, st: UiState): Boolean {
    if (st.supportedPids.isEmpty()) return false
    if (p.id == "oil" && st.oilSource.isNotEmpty()) return false
    val pid = when (p.id) { Params.BOOST -> 0x0B; Params.BATTERY -> return false; else -> p.pid ?: return false }
    return pid !in st.supportedPids
}

// ═══════════════════════════════════════════════════════════════════ DATOS

@Composable
private fun DataScreen(st: UiState, vm: ObdViewModel) {
    var cat by rememberSaveable { mutableStateOf<Category?>(null) }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        CategoryTabs(cat) { cat = it }
        val list = Params.all.filter { cat == null || it.category == cat }.sortedBy { isUnsupported(it, st) }
        LazyColumn(Modifier.fillMaxSize()) {
            group(null) {
                list.forEachIndexed { i, p ->
                    if (i > 0) Divider()
                    DataRow(p, st) {
                        vm.setDashboard(if (p.id in st.dashboard) st.dashboard - p.id else st.dashboard + p.id)
                    }
                }
            }
            footer("Los datos que no están en la página de relojes actual se actualizan por turnos para que los relojes vayan rápidos.")
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun CategoryTabs(cat: Category?, onSelect: (Category?) -> Unit) {
    Row(Modifier.padding(top = 8.dp).horizontalScroll(rememberScrollState())) {
        (listOf<Category?>(null) + Category.values()).forEach { c ->
            val sel = c == cat
            Column(
                Modifier.clickable { onSelect(c) }.padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text((c?.title ?: "Todo").uppercase(), color = if (sel) K.label else K.label2, style = Caps, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Box(Modifier.width(36.dp).height(2.5.dp).background(if (sel) K.red else Color.Transparent))
            }
        }
    }
}

@Composable
private fun DataRow(p: Param, st: UiState, onTogglePanel: () -> Unit) {
    val v = st.values[p.id]
    val off = isUnsupported(p, st)
    val warn = p.isWarning(v)
    val inPanel = p.id in st.dashboard
    Row(
        Modifier.fillMaxWidth().padding(start = 16.dp, end = 6.dp).height(60.dp).alpha(if (off) 0.45f else 1f),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(p.name, color = K.label, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (off) "No disponible en tu coche" else st.peaks[p.id]?.let { "Máx ${p.format(it)} ${p.unit}" } ?: p.category.title,
                color = K.label2, fontSize = 12.sp,
            )
        }
        if (!off) Sparkline(st.history[p.id], if (warn) K.amber else K.red, Modifier.width(110.dp).height(34.dp))
        Spacer(Modifier.width(14.dp))
        Row(Modifier.width(150.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.Bottom) {
            Text(p.format(v), color = if (warn) K.amber else K.label, style = Num, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(" ${p.unit}", color = K.label2, fontSize = 13.sp, modifier = Modifier.padding(bottom = 3.dp))
        }
    }
}

// ═══════════════════════════════════════════════════════════════════ AVERÍAS

@Composable
private fun DtcScreen(st: UiState, vm: ObdViewModel) {
    var confirm by remember { mutableStateOf(false) }
    val connected = st.conn == Conn.CONECTADO
    val total = listOfNotNull(st.dtcs, st.pendingDtcs, st.permanentDtcs).sumOf { it.size }
    val read = st.dtcs != null

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        item {
            Row(
                Modifier.padding(top = 10.dp).fillMaxWidth().clip(PanelShape).background(K.panel).border(1.dp, K.line, PanelShape).padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val color = when { !read -> K.label3; total == 0 -> K.green; else -> K.amber }
                Box(Modifier.size(56.dp).clip(CircleShape).border(3.dp, color, CircleShape), contentAlignment = Alignment.Center) {
                    Text(if (!read) "?" else "$total", color = color, style = Num, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(18.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        when { !read -> "AVERÍAS SIN LEER"; total == 0 -> "SIN AVERÍAS"; total == 1 -> "1 AVERÍA"; else -> "$total AVERÍAS" },
                        color = K.label, style = Caps, fontSize = 26.sp, fontWeight = FontWeight.Bold,
                    )
                    Text(
                        when (st.mil) {
                            true -> "Testigo de motor encendido"
                            false -> "Testigo de motor apagado"
                            null -> if (connected) "Pulsa LEER para consultar la centralita" else "Conecta con el coche para leerlas"
                        },
                        color = K.label2, fontSize = 15.sp,
                    )
                    if (st.dtcMessage.isNotEmpty()) Text(st.dtcMessage, color = K.label2, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                }
                RedButton(if (st.dtcBusy) "LEYENDO…" else "LEER", enabled = connected && !st.dtcBusy) { vm.readDtcs() }
                Spacer(Modifier.width(8.dp))
                BarButton("BORRAR", enabled = connected && !st.dtcBusy) { confirm = true }
            }
        }
        checkGroup(st)
        dtcGroup("CONFIRMADAS", st.dtcs, K.redGlow)
        dtcGroup("PENDIENTES · DETECTADAS, AÚN SIN CONFIRMAR", st.pendingDtcs, K.amber)
        dtcGroup("PERMANENTES · SE BORRAN SOLAS AL REPARAR", st.permanentDtcs, K.label2)
        footer("Se lee la centralita del motor por OBD-II estándar. ABS, airbag o confort usan la diagnosis propia de VW/Seat y no salen aquí.")
        item { Spacer(Modifier.height(16.dp)) }
    }

    if (confirm) {
        AlertPanel(
            title = "¿BORRAR LAS AVERÍAS?",
            message = "Hazlo con el contacto puesto y el motor parado. Se apagará el testigo y se reiniciarán los controles que se revisan en la ITV hasta que conduzcas un rato. Si el fallo sigue, volverá a aparecer.",
            confirm = "BORRAR", onConfirm = { confirm = false; vm.clearDtcs() },
            onDismiss = { confirm = false },
        )
    }
}

/** Diagnóstico: cada comprobación con su estado (bien / aviso / mal / informativo) y el porqué. */
private fun LazyListScope.checkGroup(st: UiState) {
    if (st.checks.isEmpty() && !st.dtcBusy) return
    group("DIAGNÓSTICO · LO QUE SE HA COMPROBADO") {
        st.checks.forEachIndexed { i, c ->
            if (i > 0) Divider()
            val color = when (c.level) {
                CheckLevel.OK -> K.green
                CheckLevel.AVISO -> K.amber
                CheckLevel.MAL -> K.redGlow
                CheckLevel.INFO -> K.label2
            }
            val glyph = when (c.level) {
                CheckLevel.OK -> "✔"
                CheckLevel.AVISO -> "!"
                CheckLevel.MAL -> "✖"
                CheckLevel.INFO -> "i"
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.Top) {
                Box(Modifier.size(30.dp).clip(CircleShape).background(color.copy(alpha = 0.18f)).border(2.dp, color, CircleShape), contentAlignment = Alignment.Center) {
                    Text(glyph, color = color, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(c.name, color = K.label, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text(c.value, color = color, style = Num, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(c.why, color = K.label2, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
                }
            }
        }
        if (st.dtcBusy) {
            if (st.checks.isNotEmpty()) Divider()
            Text(st.dtcMessage, color = K.label2, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp))
        }
    }
}

private fun LazyListScope.dtcGroup(title: String, codes: List<String>?, color: Color) {
    if (codes.isNullOrEmpty()) return
    group(title) {
        codes.forEachIndexed { i, code ->
            if (i > 0) Divider()
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clip(Chamfer(6.dp)).background(color.copy(alpha = 0.16f)).padding(horizontal = 10.dp, vertical = 5.dp)) {
                    Text(code, color = color, style = Num, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(14.dp))
                Text(DtcInfo.describe(code), color = K.label, fontSize = 15.sp)
            }
        }
    }
}

@Composable
private fun AlertPanel(title: String, message: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.width(380.dp).clip(PanelShape).carbon().border(1.dp, K.red, PanelShape).padding(20.dp)) {
            Text(title, color = K.label, style = Caps, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(message, color = K.label2, fontSize = 14.sp)
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                BarButton("CANCELAR", color = K.label2, onClick = onDismiss)
                Spacer(Modifier.width(8.dp))
                RedButton(confirm, onClick = onConfirm)
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════ AJUSTES

@Composable
private fun SettingsScreen(st: UiState, vm: ObdViewModel) {
    var showLog by rememberSaveable { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        group("COCHE") {
            InfoRow("Modelo", "SEAT Ibiza 6J · 2.0 TDI CFHD")
            Divider(); InfoRow("Bastidor", st.vin.ifEmpty { "—" })
            Divider(); InfoRow("Protocolo", st.protocol.ifEmpty { "—" })
            Divider(); InfoRow("Adaptador", st.adapter.ifEmpty { "—" })
            Divider(); InfoRow("Datos que da el coche", if (st.supportedPids.isEmpty()) "—" else "${st.supportedPids.size}")
            Divider(); InfoRow("Lecturas por segundo", if (st.conn == Conn.CONECTADO) String.format(java.util.Locale("es", "ES"), "%.1f", st.refreshHz) else "—")
        }
        group("TEMPERATURA DEL ACEITE") {
            InfoRow("Se lee de", st.oilSource.ifEmpty { if (st.conn == Conn.CONECTADO) "No encontrada todavía" else "—" })
            Divider()
            OilScanBlock(st, vm)
            Divider()
            OilCustomRow(st, vm)
        }
        footer("Al conectar se prueba el dato OBD estándar y el de diagnosis de la centralita. Si no aparece, usa BUSCAR con el motor caliente: la app lee (sin cambiar nada) cientos de datos de la centralita y te enseña los que podrían ser la temperatura del aceite. Elige el que coincida con lo que marca Carly.")
        group("LOGO EN EL RELOJ PRINCIPAL") { LogoRow(st, vm) }
        footer("Elige una foto o imagen tuya (por ejemplo, del emblema de tu coche). Sale en el reloj más grande de cada página. Mejor con fondo transparente o negro.")
        group("PANEL") {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp).height(56.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Aviso de revoluciones", color = K.label, fontSize = 16.sp)
                    Text("El reloj de revoluciones se pone en rojo desde aquí", color = K.label2, fontSize = 12.sp)
                }
                Text("${st.shiftRpm} rpm", color = K.label, style = Num, fontSize = 18.sp)
                Spacer(Modifier.width(10.dp))
                Stepper(onMinus = { vm.setShiftRpm(st.shiftRpm - 100) }, onPlus = { vm.setShiftRpm(st.shiftRpm + 100) })
            }
            Divider()
            Row(
                Modifier.fillMaxWidth().clickable { vm.resetPeaks() }.padding(horizontal = 16.dp).height(50.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) { Text("Poner a cero los máximos", color = K.redGlow, fontSize = 16.sp) }
        }
        footer("Pantalla completa (en MENÚ) oculta las barras. Toca la pantalla para volver.")
        group("COMUNICACIÓN") {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp).height(52.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Registrar todo el tráfico OBD", color = K.label, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Toggle(st.traffic, vm::setTraffic)
            }
            Divider()
            NavRow("Registro y consola", "${st.log.size} líneas") { showLog = !showLog }
        }
        if (showLog) item { Console(st, vm) }
        item { Spacer(Modifier.height(20.dp)) }
    }
}

@Composable
private fun LogoRow(st: UiState, vm: ObdViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) vm.setLogo(uri) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(64.dp).clip(CircleShape).background(Color.Black).border(1.dp, K.line, CircleShape), contentAlignment = Alignment.Center) {
            val logo = st.logo
            if (logo != null) Image(bitmap = logo, contentDescription = null, modifier = Modifier.size(44.dp))
            else Text("—", color = K.label3)
        }
        Spacer(Modifier.width(14.dp))
        Text(if (st.logo == null) "Sin logo" else "Logo puesto", color = K.label, fontSize = 16.sp, modifier = Modifier.weight(1f))
        if (st.logo != null) BarButton("QUITAR", color = K.label2, onClick = vm::clearLogo)
        RedButton("ELEGIR IMAGEN") { picker.launch("image/*") }
    }
}

@Composable
private fun OilScanBlock(st: UiState, vm: ObdViewModel) {
    val p = st.oilScanProgress
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Buscar el dato en la centralita", color = K.label, fontSize = 16.sp)
                Text(
                    if (p != null) "Rastreando… ${(p * 100).toInt()} %"
                    else st.oilTestMessage.ifEmpty { "Mejor con el motor caliente y el coche parado. Sigue en segundo plano y se pausa si el coche se mueve." },
                    color = K.label2, fontSize = 12.sp,
                )
            }
            if (p == null) {
                BarButton("PROBAR", onClick = vm::retestOil)
                RedButton("BUSCAR", enabled = st.conn == Conn.CONECTADO && !st.demo, onClick = vm::scanOil)
            } else {
                BarButton("PARAR", onClick = vm::stopOilScan)
            }
        }
        if (p != null) {
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().height(4.dp).background(K.panel2)) {
                Box(Modifier.fillMaxWidth(p).fillMaxHeight().background(K.red))
            }
        }
        DisposableEffect(Unit) {
            vm.watchCandidates(true)
            onDispose { vm.watchCandidates(false) }
        }
        if (st.oilCandidates.isNotEmpty()) {
            Text(
                "Refrigerante ahora: ${st.values["coolant"]?.let { "%.0f °C".format(it) } ?: "—"}. " +
                    "Con el motor frío el aceite debe marcar casi lo mismo que el refrigerante y subir más despacio. " +
                    "Descarta los que no se muevan o no se parezcan.",
                color = K.label2, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp),
            )
        }
        st.oilCandidates.forEach { c ->
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("22%04X".format(c.did), color = K.label, style = Num, fontSize = 17.sp, modifier = Modifier.width(90.dp))
                val now = st.candLive[c.did]
                Text(
                    if (now != null) String.format(java.util.Locale("es", "ES"), "%.1f °C", now) else "— °C",
                    color = if (now != null) K.green else K.label3, style = Num,
                    fontSize = 17.sp, modifier = Modifier.width(110.dp),
                )
                Text(
                    String.format(java.util.Locale("es", "ES"), "al buscar %.0f", c.value), color = K.label2,
                    fontSize = 12.sp, modifier = Modifier.weight(1f),
                )
                BarButton("USAR") { vm.useOilCandidate(c) }
            }
        }
    }
}

@Composable
private fun OilCustomRow(st: UiState, vm: ObdViewModel) {
    var did by remember(st.oilCustomDid) { mutableStateOf(st.oilCustomDid) }
    val formulas = listOf("A − 40", "Décimas de kelvin", "Kelvin ÷ 10", "A directo", "A × 0,75 − 48", "Décimas de °C")
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Identificador manual", color = K.label, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Text("22", color = K.label2, style = Num, fontSize = 18.sp)
            BasicTextField(
                value = did,
                onValueChange = { t -> did = t.uppercase().filter { it in "0123456789ABCDEF" }.take(4); vm.setOilCustom(did, st.oilCustomFormula) },
                singleLine = true,
                textStyle = TextStyle(color = K.label, fontSize = 18.sp, fontFamily = Cond),
                cursorBrush = SolidColor(K.red),
                modifier = Modifier.width(90.dp).clip(Chamfer(6.dp)).background(K.panel2).padding(horizontal = 10.dp, vertical = 6.dp),
                decorationBox = { inner -> if (did.isEmpty()) Text("XXXX", color = K.label3, fontSize = 18.sp); inner() },
            )
        }
        Spacer(Modifier.height(8.dp))
        formulas.withIndex().chunked(3).forEach { chunk ->
            Row {
                chunk.forEach { item ->
                    val i = item.index
                    val sel = i == st.oilCustomFormula
                    Column(Modifier.clickable { vm.setOilCustom(did, i) }.padding(end = 16.dp, top = 4.dp)) {
                        Text(item.value, color = if (sel) K.label else K.label2, fontSize = 14.sp)
                        Spacer(Modifier.height(3.dp))
                        Box(Modifier.width(30.dp).height(2.dp).background(if (sel) K.red else Color.Transparent))
                    }
                }
            }
        }
    }
}

@Composable
private fun Stepper(onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.clip(Chamfer(6.dp)).background(K.panel2), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(width = 46.dp, height = 34.dp).clickable(onClick = onMinus), contentAlignment = Alignment.Center) {
            Box(Modifier.width(13.dp).height(2.dp).background(K.label))
        }
        Box(Modifier.width(1.dp).height(18.dp).background(K.line))
        Box(Modifier.size(width = 46.dp, height = 34.dp).clickable(onClick = onPlus), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Add, null, tint = K.label, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun Console(st: UiState, vm: ObdViewModel) {
    var cmd by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(st.log.size) { if (st.log.isNotEmpty()) listState.scrollToItem(st.log.size - 1) }
    Column(
        Modifier.padding(top = 12.dp).fillMaxWidth().clip(PanelShape).background(Color(0xFF0A0A0B))
            .border(1.dp, K.line, PanelShape).padding(12.dp),
    ) {
        LazyColumn(state = listState, modifier = Modifier.fillMaxWidth().height(260.dp)) {
            items(st.log) { Text(it, color = K.label2, fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(
                value = cmd, onValueChange = { cmd = it }, singleLine = true,
                textStyle = TextStyle(color = K.label, fontSize = 15.sp, fontFamily = FontFamily.Monospace),
                cursorBrush = SolidColor(K.red),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { if (cmd.isNotBlank()) { vm.sendRaw(cmd); cmd = "" } }),
                modifier = Modifier.weight(1f).clip(Chamfer(6.dp)).background(K.panel2).padding(12.dp),
                decorationBox = { inner ->
                    if (cmd.isEmpty()) Text("Orden ELM327, por ejemplo ATRV o 010C", color = K.label3, fontSize = 15.sp)
                    inner()
                },
            )
            Spacer(Modifier.width(8.dp))
            RedButton("ENVIAR") { if (cmd.isNotBlank()) { vm.sendRaw(cmd); cmd = "" } }
        }
    }
}
