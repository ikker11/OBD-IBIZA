package com.ikker.obdibiza

/** Categorías = submenús de la pantalla "Datos". */
enum class Category(val title: String) {
    MOTOR("Motor"),
    TURBO("Turbo y admisión"),
    COMBUSTIBLE("Combustible"),
    TEMPERATURAS("Temperaturas"),
    ELECTRICO("Eléctrico"),
    ESTADISTICAS("Estadísticas"),
}

/**
 * Un parámetro que se puede mostrar en el panel o en los submenús.
 * - pid != null  -> se lee con modo 01 (OBD-II estándar)
 * - pid == null  -> parámetro calculado (turbo) o del adaptador (batería)
 */
class Param(
    val id: String,
    val name: String,
    val short: String,
    val unit: String,
    val category: Category,
    val min: Double,
    val max: Double,
    val decimals: Int = 0,
    val warnLow: Double? = null,
    val warnHigh: Double? = null,
    val pid: Int? = null,
    val calc: (IntArray) -> Double = { 0.0 },
) {
    fun format(v: Double?): String = when {
        v == null -> "—"
        decimals == 0 -> Math.round(v).toString()
        else -> String.format(java.util.Locale("es", "ES"), "%.${decimals}f", v)
    }

    fun isWarning(v: Double?): Boolean =
        v != null && ((warnHigh != null && v >= warnHigh) || (warnLow != null && v <= warnLow))
}

private fun ab(d: IntArray) = d[0] * 256 + d[1]

object Params {
    const val BOOST = "boost"
    const val BATTERY = "battery"

    val all: List<Param> = listOf(
        // ---------- Motor ----------
        Param("rpm", "Revoluciones", "Revoluciones", "rpm", Category.MOTOR, 0.0, 5000.0, warnHigh = 4500.0, pid = 0x0C) { ab(it) / 4.0 },
        Param("speed", "Velocidad", "Velocidad", "km/h", Category.MOTOR, 0.0, 220.0, pid = 0x0D) { it[0].toDouble() },
        Param("load", "Carga del motor", "Carga", "%", Category.MOTOR, 0.0, 100.0, pid = 0x04) { it[0] * 100.0 / 255 },
        Param("absload", "Carga absoluta", "Carga absoluta", "%", Category.MOTOR, 0.0, 100.0, pid = 0x43) { ab(it) * 100.0 / 255 },
        Param("pedal", "Pedal acelerador", "Pedal", "%", Category.MOTOR, 0.0, 100.0, pid = 0x49) { it[0] * 100.0 / 255 },
        Param("pedal2", "Pedal acelerador (sensor 2)", "Pedal (2)", "%", Category.MOTOR, 0.0, 100.0, pid = 0x4A) { it[0] * 100.0 / 255 },
        Param("throttle", "Mariposa", "Mariposa", "%", Category.MOTOR, 0.0, 100.0, pid = 0x11) { it[0] * 100.0 / 255 },
        Param("throttlecmd", "Mariposa (ordenada)", "Mariposa pedida", "%", Category.MOTOR, 0.0, 100.0, pid = 0x4C) { it[0] * 100.0 / 255 },
        Param("relthrottle", "Mariposa relativa", "Mariposa relativa", "%", Category.MOTOR, 0.0, 100.0, pid = 0x45) { it[0] * 100.0 / 255 },
        Param("torquedem", "Par solicitado", "Par pedido", "%", Category.MOTOR, 0.0, 100.0, pid = 0x61) { it[0] - 125.0 },
        Param("torque", "Par real", "Par", "%", Category.MOTOR, 0.0, 100.0, pid = 0x62) { it[0] - 125.0 },
        Param("torqueref", "Par de referencia", "Par de referencia", "Nm", Category.MOTOR, 0.0, 500.0, pid = 0x63) { ab(it).toDouble() },

        // ---------- Turbo y admisión ----------
        Param(BOOST, "Presión turbo (relativa)", "Turbo", "bar", Category.TURBO, -0.2, 2.0, decimals = 2, warnHigh = 1.7),
        Param("map", "Presión colector (absoluta)", "Colector", "kPa", Category.TURBO, 0.0, 300.0, pid = 0x0B) { it[0].toDouble() },
        Param("baro", "Presión atmosférica", "Atmosférica", "kPa", Category.TURBO, 60.0, 110.0, pid = 0x33) { it[0].toDouble() },
        Param("maf", "Caudal de aire (MAF)", "Caudal de aire", "g/s", Category.TURBO, 0.0, 200.0, decimals = 1, pid = 0x10) { ab(it) / 100.0 },
        Param("egrcmd", "EGR ordenada", "EGR", "%", Category.TURBO, 0.0, 100.0, pid = 0x2C) { it[0] * 100.0 / 255 },
        Param("egrerr", "Error EGR", "Error EGR", "%", Category.TURBO, -100.0, 100.0, pid = 0x2D) { it[0] * 100.0 / 128 - 100 },

        // ---------- Combustible ----------
        Param("rail", "Presión rail (inyección)", "Rail", "bar", Category.COMBUSTIBLE, 0.0, 2000.0, pid = 0x23) { ab(it) / 10.0 },
        Param("fuelrate", "Consumo instantáneo", "Consumo", "L/h", Category.COMBUSTIBLE, 0.0, 30.0, decimals = 1, pid = 0x5E) { ab(it) / 20.0 },
        Param("fuellevel", "Nivel de combustible", "Depósito", "%", Category.COMBUSTIBLE, 0.0, 100.0, warnLow = 10.0, pid = 0x2F) { it[0] * 100.0 / 255 },
        Param("injtiming", "Avance de inyección", "Avance", "°", Category.COMBUSTIBLE, -30.0, 30.0, decimals = 1, pid = 0x5D) { ab(it) / 128.0 - 210 },

        // ---------- Temperaturas ----------
        Param("coolant", "Temperatura refrigerante", "Refrigerante", "°C", Category.TEMPERATURAS, 0.0, 130.0, warnHigh = 105.0, pid = 0x05) { it[0] - 40.0 },
        Param("iat", "Temperatura aire admisión", "Aire admisión", "°C", Category.TEMPERATURAS, -20.0, 80.0, warnHigh = 60.0, pid = 0x0F) { it[0] - 40.0 },
        Param("ambient", "Temperatura exterior", "Exterior", "°C", Category.TEMPERATURAS, -20.0, 50.0, pid = 0x46) { it[0] - 40.0 },
        Param("oil", "Temperatura del aceite", "Aceite", "°C", Category.TEMPERATURAS, 0.0, 150.0, warnLow = 60.0, warnHigh = 125.0, pid = 0x5C) { it[0] - 40.0 },

        // ---------- Eléctrico ----------
        Param(BATTERY, "Tensión batería (OBD)", "Batería", "V", Category.ELECTRICO, 10.0, 16.0, decimals = 1, warnLow = 11.8, warnHigh = 15.0),
        Param("modvolt", "Tensión centralita motor", "Tensión ECU", "V", Category.ELECTRICO, 10.0, 16.0, decimals = 2, warnLow = 11.8, warnHigh = 15.0, pid = 0x42) { ab(it) / 1000.0 },

        // ---------- Estadísticas ----------
        Param("runtime", "Tiempo desde arranque", "En marcha", "min", Category.ESTADISTICAS, 0.0, 600.0, decimals = 1, pid = 0x1F) { ab(it) / 60.0 },
        Param("distmil", "Km con testigo de avería", "Km con testigo", "km", Category.ESTADISTICAS, 0.0, 65535.0, pid = 0x21) { ab(it).toDouble() },
        Param("timemil", "Minutos con testigo de avería", "Min con testigo", "min", Category.ESTADISTICAS, 0.0, 65535.0, pid = 0x4D) { ab(it).toDouble() },
        Param("distclr", "Km desde borrado de averías", "Km desde borrado", "km", Category.ESTADISTICAS, 0.0, 65535.0, pid = 0x31) { ab(it).toDouble() },
        Param("timeclr", "Minutos desde borrado de averías", "Min desde borrado", "min", Category.ESTADISTICAS, 0.0, 65535.0, pid = 0x4E) { ab(it).toDouble() },
        Param("warmups", "Calentamientos desde borrado", "Calentamientos", "", Category.ESTADISTICAS, 0.0, 255.0, pid = 0x30) { it[0].toDouble() },
    )

    val byId: Map<String, Param> = all.associateBy { it.id }
    val byPid: Map<Int, Param> = all.filter { it.pid != null }.associateBy { it.pid!! }

    /** Bytes de datos que devuelve cada PID (para validar la respuesta). */
    fun bytesFor(pid: Int): Int = when (pid) {
        0x0C, 0x10, 0x1F, 0x21, 0x23, 0x31, 0x42, 0x43, 0x4D, 0x4E, 0x5D, 0x5E, 0x63 -> 2
        else -> 1
    }

    val defaultPageNames = listOf("Performance", "Crucero", "Motor", "Diésel")

    /** Páginas iniciales del panel (izquierda, centro, derecha). */
    val defaultPages = listOf(
        listOf("oil", "rpm", BOOST),
        listOf("coolant", "speed", "iat"),
        listOf("load", "maf", BATTERY),
        listOf("rail", "torque", "egrcmd"),
    )

    val defaultDashboard = listOf(BOOST, "oil", "coolant", "iat", "load", BATTERY)
}
